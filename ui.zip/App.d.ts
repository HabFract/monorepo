import "./App.css";
import "habit-fract-design-system/dist/style.css";
import "./typo.css";
export declare const logMemoryUsage: (tag: string) => void;
export declare const useInitializeBodyAttributes: () => void;
declare function App({ children: pageComponent }: {
    children: any;
}): import("react/jsx-runtime").JSX.Element;
export default App;
//# sourceMappingURL=App.d.ts.map