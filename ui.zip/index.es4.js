function Zi(t, e) {
  for (var r = 0; r < e.length; r++) {
    const n = e[r];
    if (typeof n != "string" && !Array.isArray(n)) {
      for (const s in n)
        if (s !== "default" && !(s in t)) {
          const i = Object.getOwnPropertyDescriptor(n, s);
          i && Object.defineProperty(t, s, i.get ? i : {
            enumerable: !0,
            get: () => n[s]
          });
        }
    }
  }
  return Object.freeze(Object.defineProperty(t, Symbol.toStringTag, { value: "Module" }));
}
var Kh = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};
function Qi(t) {
  return t && t.__esModule && Object.prototype.hasOwnProperty.call(t, "default") ? t.default : t;
}
function ep(t) {
  if (t.__esModule) return t;
  var e = t.default;
  if (typeof e == "function") {
    var r = function n() {
      return this instanceof n ? Reflect.construct(e, arguments, this.constructor) : e.apply(this, arguments);
    };
    r.prototype = e.prototype;
  } else r = {};
  return Object.defineProperty(r, "__esModule", { value: !0 }), Object.keys(t).forEach(function(n) {
    var s = Object.getOwnPropertyDescriptor(t, n);
    Object.defineProperty(r, n, s.get ? s : {
      enumerable: !0,
      get: function() {
        return t[n];
      }
    });
  }), r;
}
var Tn = { exports: {} }, H = {};
/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var Gs;
function Ju() {
  if (Gs) return H;
  Gs = 1;
  var t = Symbol.for("react.element"), e = Symbol.for("react.portal"), r = Symbol.for("react.fragment"), n = Symbol.for("react.strict_mode"), s = Symbol.for("react.profiler"), i = Symbol.for("react.provider"), a = Symbol.for("react.context"), u = Symbol.for("react.forward_ref"), c = Symbol.for("react.suspense"), l = Symbol.for("react.memo"), d = Symbol.for("react.lazy"), v = Symbol.iterator;
  function T(h) {
    return h === null || typeof h != "object" ? null : (h = v && h[v] || h["@@iterator"], typeof h == "function" ? h : null);
  }
  var O = { isMounted: function() {
    return !1;
  }, enqueueForceUpdate: function() {
  }, enqueueReplaceState: function() {
  }, enqueueSetState: function() {
  } }, I = Object.assign, _ = {};
  function E(h, S, W) {
    this.props = h, this.context = S, this.refs = _, this.updater = W || O;
  }
  E.prototype.isReactComponent = {}, E.prototype.setState = function(h, S) {
    if (typeof h != "object" && typeof h != "function" && h != null) throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");
    this.updater.enqueueSetState(this, h, S, "setState");
  }, E.prototype.forceUpdate = function(h) {
    this.updater.enqueueForceUpdate(this, h, "forceUpdate");
  };
  function y() {
  }
  y.prototype = E.prototype;
  function b(h, S, W) {
    this.props = h, this.context = S, this.refs = _, this.updater = W || O;
  }
  var A = b.prototype = new y();
  A.constructor = b, I(A, E.prototype), A.isPureReactComponent = !0;
  var R = Array.isArray, $ = Object.prototype.hasOwnProperty, D = { current: null }, j = { key: !0, ref: !0, __self: !0, __source: !0 };
  function V(h, S, W) {
    var K, Y = {}, re = null, de = null;
    if (S != null) for (K in S.ref !== void 0 && (de = S.ref), S.key !== void 0 && (re = "" + S.key), S) $.call(S, K) && !j.hasOwnProperty(K) && (Y[K] = S[K]);
    var ne = arguments.length - 2;
    if (ne === 1) Y.children = W;
    else if (1 < ne) {
      for (var se = Array(ne), Te = 0; Te < ne; Te++) se[Te] = arguments[Te + 2];
      Y.children = se;
    }
    if (h && h.defaultProps) for (K in ne = h.defaultProps, ne) Y[K] === void 0 && (Y[K] = ne[K]);
    return { $$typeof: t, type: h, key: re, ref: de, props: Y, _owner: D.current };
  }
  function C(h, S) {
    return { $$typeof: t, type: h.type, key: S, ref: h.ref, props: h.props, _owner: h._owner };
  }
  function q(h) {
    return typeof h == "object" && h !== null && h.$$typeof === t;
  }
  function te(h) {
    var S = { "=": "=0", ":": "=2" };
    return "$" + h.replace(/[=:]/g, function(W) {
      return S[W];
    });
  }
  var je = /\/+/g;
  function ze(h, S) {
    return typeof h == "object" && h !== null && h.key != null ? te("" + h.key) : S.toString(36);
  }
  function Ye(h, S, W, K, Y) {
    var re = typeof h;
    (re === "undefined" || re === "boolean") && (h = null);
    var de = !1;
    if (h === null) de = !0;
    else switch (re) {
      case "string":
      case "number":
        de = !0;
        break;
      case "object":
        switch (h.$$typeof) {
          case t:
          case e:
            de = !0;
        }
    }
    if (de) return de = h, Y = Y(de), h = K === "" ? "." + ze(de, 0) : K, R(Y) ? (W = "", h != null && (W = h.replace(je, "$&/") + "/"), Ye(Y, S, W, "", function(Te) {
      return Te;
    })) : Y != null && (q(Y) && (Y = C(Y, W + (!Y.key || de && de.key === Y.key ? "" : ("" + Y.key).replace(je, "$&/") + "/") + h)), S.push(Y)), 1;
    if (de = 0, K = K === "" ? "." : K + ":", R(h)) for (var ne = 0; ne < h.length; ne++) {
      re = h[ne];
      var se = K + ze(re, ne);
      de += Ye(re, S, W, se, Y);
    }
    else if (se = T(h), typeof se == "function") for (h = se.call(h), ne = 0; !(re = h.next()).done; ) re = re.value, se = K + ze(re, ne++), de += Ye(re, S, W, se, Y);
    else if (re === "object") throw S = String(h), Error("Objects are not valid as a React child (found: " + (S === "[object Object]" ? "object with keys {" + Object.keys(h).join(", ") + "}" : S) + "). If you meant to render a collection of children, use an array instead.");
    return de;
  }
  function ft(h, S, W) {
    if (h == null) return h;
    var K = [], Y = 0;
    return Ye(h, K, "", "", function(re) {
      return S.call(W, re, Y++);
    }), K;
  }
  function Be(h) {
    if (h._status === -1) {
      var S = h._result;
      S = S(), S.then(function(W) {
        (h._status === 0 || h._status === -1) && (h._status = 1, h._result = W);
      }, function(W) {
        (h._status === 0 || h._status === -1) && (h._status = 2, h._result = W);
      }), h._status === -1 && (h._status = 0, h._result = S);
    }
    if (h._status === 1) return h._result.default;
    throw h._result;
  }
  var ce = { current: null }, z = { transition: null }, er = { ReactCurrentDispatcher: ce, ReactCurrentBatchConfig: z, ReactCurrentOwner: D };
  function Ct() {
    throw Error("act(...) is not supported in production builds of React.");
  }
  return H.Children = { map: ft, forEach: function(h, S, W) {
    ft(h, function() {
      S.apply(this, arguments);
    }, W);
  }, count: function(h) {
    var S = 0;
    return ft(h, function() {
      S++;
    }), S;
  }, toArray: function(h) {
    return ft(h, function(S) {
      return S;
    }) || [];
  }, only: function(h) {
    if (!q(h)) throw Error("React.Children.only expected to receive a single React element child.");
    return h;
  } }, H.Component = E, H.Fragment = r, H.Profiler = s, H.PureComponent = b, H.StrictMode = n, H.Suspense = c, H.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = er, H.act = Ct, H.cloneElement = function(h, S, W) {
    if (h == null) throw Error("React.cloneElement(...): The argument must be a React element, but you passed " + h + ".");
    var K = I({}, h.props), Y = h.key, re = h.ref, de = h._owner;
    if (S != null) {
      if (S.ref !== void 0 && (re = S.ref, de = D.current), S.key !== void 0 && (Y = "" + S.key), h.type && h.type.defaultProps) var ne = h.type.defaultProps;
      for (se in S) $.call(S, se) && !j.hasOwnProperty(se) && (K[se] = S[se] === void 0 && ne !== void 0 ? ne[se] : S[se]);
    }
    var se = arguments.length - 2;
    if (se === 1) K.children = W;
    else if (1 < se) {
      ne = Array(se);
      for (var Te = 0; Te < se; Te++) ne[Te] = arguments[Te + 2];
      K.children = ne;
    }
    return { $$typeof: t, type: h.type, key: Y, ref: re, props: K, _owner: de };
  }, H.createContext = function(h) {
    return h = { $$typeof: a, _currentValue: h, _currentValue2: h, _threadCount: 0, Provider: null, Consumer: null, _defaultValue: null, _globalName: null }, h.Provider = { $$typeof: i, _context: h }, h.Consumer = h;
  }, H.createElement = V, H.createFactory = function(h) {
    var S = V.bind(null, h);
    return S.type = h, S;
  }, H.createRef = function() {
    return { current: null };
  }, H.forwardRef = function(h) {
    return { $$typeof: u, render: h };
  }, H.isValidElement = q, H.lazy = function(h) {
    return { $$typeof: d, _payload: { _status: -1, _result: h }, _init: Be };
  }, H.memo = function(h, S) {
    return { $$typeof: l, type: h, compare: S === void 0 ? null : S };
  }, H.startTransition = function(h) {
    var S = z.transition;
    z.transition = {};
    try {
      h();
    } finally {
      z.transition = S;
    }
  }, H.unstable_act = Ct, H.useCallback = function(h, S) {
    return ce.current.useCallback(h, S);
  }, H.useContext = function(h) {
    return ce.current.useContext(h);
  }, H.useDebugValue = function() {
  }, H.useDeferredValue = function(h) {
    return ce.current.useDeferredValue(h);
  }, H.useEffect = function(h, S) {
    return ce.current.useEffect(h, S);
  }, H.useId = function() {
    return ce.current.useId();
  }, H.useImperativeHandle = function(h, S, W) {
    return ce.current.useImperativeHandle(h, S, W);
  }, H.useInsertionEffect = function(h, S) {
    return ce.current.useInsertionEffect(h, S);
  }, H.useLayoutEffect = function(h, S) {
    return ce.current.useLayoutEffect(h, S);
  }, H.useMemo = function(h, S) {
    return ce.current.useMemo(h, S);
  }, H.useReducer = function(h, S, W) {
    return ce.current.useReducer(h, S, W);
  }, H.useRef = function(h) {
    return ce.current.useRef(h);
  }, H.useState = function(h) {
    return ce.current.useState(h);
  }, H.useSyncExternalStore = function(h, S, W) {
    return ce.current.useSyncExternalStore(h, S, W);
  }, H.useTransition = function() {
    return ce.current.useTransition();
  }, H.version = "18.3.1", H;
}
var Pt = { exports: {} };
Pt.exports;
var Zs;
function Xu() {
  return Zs || (Zs = 1, function(t, e) {
    var r = {};
    /**
     * @license React
     * react.development.js
     *
     * Copyright (c) Facebook, Inc. and its affiliates.
     *
     * This source code is licensed under the MIT license found in the
     * LICENSE file in the root directory of this source tree.
     */
    r.NODE_ENV !== "production" && function() {
      typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u" && typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart == "function" && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(new Error());
      var n = "18.3.1", s = Symbol.for("react.element"), i = Symbol.for("react.portal"), a = Symbol.for("react.fragment"), u = Symbol.for("react.strict_mode"), c = Symbol.for("react.profiler"), l = Symbol.for("react.provider"), d = Symbol.for("react.context"), v = Symbol.for("react.forward_ref"), T = Symbol.for("react.suspense"), O = Symbol.for("react.suspense_list"), I = Symbol.for("react.memo"), _ = Symbol.for("react.lazy"), E = Symbol.for("react.offscreen"), y = Symbol.iterator, b = "@@iterator";
      function A(o) {
        if (o === null || typeof o != "object")
          return null;
        var f = y && o[y] || o[b];
        return typeof f == "function" ? f : null;
      }
      var R = {
        /**
         * @internal
         * @type {ReactComponent}
         */
        current: null
      }, $ = {
        transition: null
      }, D = {
        current: null,
        // Used to reproduce behavior of `batchedUpdates` in legacy mode.
        isBatchingLegacy: !1,
        didScheduleLegacyUpdate: !1
      }, j = {
        /**
         * @internal
         * @type {ReactComponent}
         */
        current: null
      }, V = {}, C = null;
      function q(o) {
        C = o;
      }
      V.setExtraStackFrame = function(o) {
        C = o;
      }, V.getCurrentStack = null, V.getStackAddendum = function() {
        var o = "";
        C && (o += C);
        var f = V.getCurrentStack;
        return f && (o += f() || ""), o;
      };
      var te = !1, je = !1, ze = !1, Ye = !1, ft = !1, Be = {
        ReactCurrentDispatcher: R,
        ReactCurrentBatchConfig: $,
        ReactCurrentOwner: j
      };
      Be.ReactDebugCurrentFrame = V, Be.ReactCurrentActQueue = D;
      function ce(o) {
        {
          for (var f = arguments.length, p = new Array(f > 1 ? f - 1 : 0), m = 1; m < f; m++)
            p[m - 1] = arguments[m];
          er("warn", o, p);
        }
      }
      function z(o) {
        {
          for (var f = arguments.length, p = new Array(f > 1 ? f - 1 : 0), m = 1; m < f; m++)
            p[m - 1] = arguments[m];
          er("error", o, p);
        }
      }
      function er(o, f, p) {
        {
          var m = Be.ReactDebugCurrentFrame, w = m.getStackAddendum();
          w !== "" && (f += "%s", p = p.concat([w]));
          var x = p.map(function(k) {
            return String(k);
          });
          x.unshift("Warning: " + f), Function.prototype.apply.call(console[o], console, x);
        }
      }
      var Ct = {};
      function h(o, f) {
        {
          var p = o.constructor, m = p && (p.displayName || p.name) || "ReactClass", w = m + "." + f;
          if (Ct[w])
            return;
          z("Can't call %s on a component that is not yet mounted. This is a no-op, but it might indicate a bug in your application. Instead, assign to `this.state` directly or define a `state = {};` class property with the desired state in the %s component.", f, m), Ct[w] = !0;
        }
      }
      var S = {
        /**
         * Checks whether or not this composite component is mounted.
         * @param {ReactClass} publicInstance The instance we want to test.
         * @return {boolean} True if mounted, false otherwise.
         * @protected
         * @final
         */
        isMounted: function(o) {
          return !1;
        },
        /**
         * Forces an update. This should only be invoked when it is known with
         * certainty that we are **not** in a DOM transaction.
         *
         * You may want to call this when you know that some deeper aspect of the
         * component's state has changed but `setState` was not called.
         *
         * This will not invoke `shouldComponentUpdate`, but it will invoke
         * `componentWillUpdate` and `componentDidUpdate`.
         *
         * @param {ReactClass} publicInstance The instance that should rerender.
         * @param {?function} callback Called after component is updated.
         * @param {?string} callerName name of the calling function in the public API.
         * @internal
         */
        enqueueForceUpdate: function(o, f, p) {
          h(o, "forceUpdate");
        },
        /**
         * Replaces all of the state. Always use this or `setState` to mutate state.
         * You should treat `this.state` as immutable.
         *
         * There is no guarantee that `this.state` will be immediately updated, so
         * accessing `this.state` after calling this method may return the old value.
         *
         * @param {ReactClass} publicInstance The instance that should rerender.
         * @param {object} completeState Next state.
         * @param {?function} callback Called after component is updated.
         * @param {?string} callerName name of the calling function in the public API.
         * @internal
         */
        enqueueReplaceState: function(o, f, p, m) {
          h(o, "replaceState");
        },
        /**
         * Sets a subset of the state. This only exists because _pendingState is
         * internal. This provides a merging strategy that is not available to deep
         * properties which is confusing. TODO: Expose pendingState or don't use it
         * during the merge.
         *
         * @param {ReactClass} publicInstance The instance that should rerender.
         * @param {object} partialState Next partial state to be merged with state.
         * @param {?function} callback Called after component is updated.
         * @param {?string} Name of the calling function in the public API.
         * @internal
         */
        enqueueSetState: function(o, f, p, m) {
          h(o, "setState");
        }
      }, W = Object.assign, K = {};
      Object.freeze(K);
      function Y(o, f, p) {
        this.props = o, this.context = f, this.refs = K, this.updater = p || S;
      }
      Y.prototype.isReactComponent = {}, Y.prototype.setState = function(o, f) {
        if (typeof o != "object" && typeof o != "function" && o != null)
          throw new Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");
        this.updater.enqueueSetState(this, o, f, "setState");
      }, Y.prototype.forceUpdate = function(o) {
        this.updater.enqueueForceUpdate(this, o, "forceUpdate");
      };
      {
        var re = {
          isMounted: ["isMounted", "Instead, make sure to clean up subscriptions and pending requests in componentWillUnmount to prevent memory leaks."],
          replaceState: ["replaceState", "Refactor your code to use setState instead (see https://github.com/facebook/react/issues/3236)."]
        }, de = function(o, f) {
          Object.defineProperty(Y.prototype, o, {
            get: function() {
              ce("%s(...) is deprecated in plain JavaScript React classes. %s", f[0], f[1]);
            }
          });
        };
        for (var ne in re)
          re.hasOwnProperty(ne) && de(ne, re[ne]);
      }
      function se() {
      }
      se.prototype = Y.prototype;
      function Te(o, f, p) {
        this.props = o, this.context = f, this.refs = K, this.updater = p || S;
      }
      var Yr = Te.prototype = new se();
      Yr.constructor = Te, W(Yr, Y.prototype), Yr.isPureReactComponent = !0;
      function Yo() {
        var o = {
          current: null
        };
        return Object.seal(o), o;
      }
      var Bo = Array.isArray;
      function tr(o) {
        return Bo(o);
      }
      function qo(o) {
        {
          var f = typeof Symbol == "function" && Symbol.toStringTag, p = f && o[Symbol.toStringTag] || o.constructor.name || "Object";
          return p;
        }
      }
      function Go(o) {
        try {
          return fs(o), !1;
        } catch {
          return !0;
        }
      }
      function fs(o) {
        return "" + o;
      }
      function rr(o) {
        if (Go(o))
          return z("The provided key is an unsupported type %s. This value must be coerced to a string before before using it here.", qo(o)), fs(o);
      }
      function Zo(o, f, p) {
        var m = o.displayName;
        if (m)
          return m;
        var w = f.displayName || f.name || "";
        return w !== "" ? p + "(" + w + ")" : p;
      }
      function ds(o) {
        return o.displayName || "Context";
      }
      function qe(o) {
        if (o == null)
          return null;
        if (typeof o.tag == "number" && z("Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."), typeof o == "function")
          return o.displayName || o.name || null;
        if (typeof o == "string")
          return o;
        switch (o) {
          case a:
            return "Fragment";
          case i:
            return "Portal";
          case c:
            return "Profiler";
          case u:
            return "StrictMode";
          case T:
            return "Suspense";
          case O:
            return "SuspenseList";
        }
        if (typeof o == "object")
          switch (o.$$typeof) {
            case d:
              var f = o;
              return ds(f) + ".Consumer";
            case l:
              var p = o;
              return ds(p._context) + ".Provider";
            case v:
              return Zo(o, o.render, "ForwardRef");
            case I:
              var m = o.displayName || null;
              return m !== null ? m : qe(o.type) || "Memo";
            case _: {
              var w = o, x = w._payload, k = w._init;
              try {
                return qe(k(x));
              } catch {
                return null;
              }
            }
          }
        return null;
      }
      var At = Object.prototype.hasOwnProperty, hs = {
        key: !0,
        ref: !0,
        __self: !0,
        __source: !0
      }, ps, ms, Br;
      Br = {};
      function ys(o) {
        if (At.call(o, "ref")) {
          var f = Object.getOwnPropertyDescriptor(o, "ref").get;
          if (f && f.isReactWarning)
            return !1;
        }
        return o.ref !== void 0;
      }
      function vs(o) {
        if (At.call(o, "key")) {
          var f = Object.getOwnPropertyDescriptor(o, "key").get;
          if (f && f.isReactWarning)
            return !1;
        }
        return o.key !== void 0;
      }
      function Qo(o, f) {
        var p = function() {
          ps || (ps = !0, z("%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://reactjs.org/link/special-props)", f));
        };
        p.isReactWarning = !0, Object.defineProperty(o, "key", {
          get: p,
          configurable: !0
        });
      }
      function Jo(o, f) {
        var p = function() {
          ms || (ms = !0, z("%s: `ref` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://reactjs.org/link/special-props)", f));
        };
        p.isReactWarning = !0, Object.defineProperty(o, "ref", {
          get: p,
          configurable: !0
        });
      }
      function Xo(o) {
        if (typeof o.ref == "string" && j.current && o.__self && j.current.stateNode !== o.__self) {
          var f = qe(j.current.type);
          Br[f] || (z('Component "%s" contains the string ref "%s". Support for string refs will be removed in a future major release. This case cannot be automatically converted to an arrow function. We ask you to manually fix this case by using useRef() or createRef() instead. Learn more about using refs safely here: https://reactjs.org/link/strict-mode-string-ref', f, o.ref), Br[f] = !0);
        }
      }
      var qr = function(o, f, p, m, w, x, k) {
        var U = {
          // This tag allows us to uniquely identify this as a React Element
          $$typeof: s,
          // Built-in properties that belong on the element
          type: o,
          key: f,
          ref: p,
          props: k,
          // Record the component responsible for creating this element.
          _owner: x
        };
        return U._store = {}, Object.defineProperty(U._store, "validated", {
          configurable: !1,
          enumerable: !1,
          writable: !0,
          value: !1
        }), Object.defineProperty(U, "_self", {
          configurable: !1,
          enumerable: !1,
          writable: !1,
          value: m
        }), Object.defineProperty(U, "_source", {
          configurable: !1,
          enumerable: !1,
          writable: !1,
          value: w
        }), Object.freeze && (Object.freeze(U.props), Object.freeze(U)), U;
      };
      function Ko(o, f, p) {
        var m, w = {}, x = null, k = null, U = null, B = null;
        if (f != null) {
          ys(f) && (k = f.ref, Xo(f)), vs(f) && (rr(f.key), x = "" + f.key), U = f.__self === void 0 ? null : f.__self, B = f.__source === void 0 ? null : f.__source;
          for (m in f)
            At.call(f, m) && !hs.hasOwnProperty(m) && (w[m] = f[m]);
        }
        var ee = arguments.length - 2;
        if (ee === 1)
          w.children = p;
        else if (ee > 1) {
          for (var ie = Array(ee), ae = 0; ae < ee; ae++)
            ie[ae] = arguments[ae + 2];
          Object.freeze && Object.freeze(ie), w.children = ie;
        }
        if (o && o.defaultProps) {
          var ue = o.defaultProps;
          for (m in ue)
            w[m] === void 0 && (w[m] = ue[m]);
        }
        if (x || k) {
          var he = typeof o == "function" ? o.displayName || o.name || "Unknown" : o;
          x && Qo(w, he), k && Jo(w, he);
        }
        return qr(o, x, k, U, B, j.current, w);
      }
      function eu(o, f) {
        var p = qr(o.type, f, o.ref, o._self, o._source, o._owner, o.props);
        return p;
      }
      function tu(o, f, p) {
        if (o == null)
          throw new Error("React.cloneElement(...): The argument must be a React element, but you passed " + o + ".");
        var m, w = W({}, o.props), x = o.key, k = o.ref, U = o._self, B = o._source, ee = o._owner;
        if (f != null) {
          ys(f) && (k = f.ref, ee = j.current), vs(f) && (rr(f.key), x = "" + f.key);
          var ie;
          o.type && o.type.defaultProps && (ie = o.type.defaultProps);
          for (m in f)
            At.call(f, m) && !hs.hasOwnProperty(m) && (f[m] === void 0 && ie !== void 0 ? w[m] = ie[m] : w[m] = f[m]);
        }
        var ae = arguments.length - 2;
        if (ae === 1)
          w.children = p;
        else if (ae > 1) {
          for (var ue = Array(ae), he = 0; he < ae; he++)
            ue[he] = arguments[he + 2];
          w.children = ue;
        }
        return qr(o.type, x, k, U, B, ee, w);
      }
      function dt(o) {
        return typeof o == "object" && o !== null && o.$$typeof === s;
      }
      var gs = ".", ru = ":";
      function nu(o) {
        var f = /[=:]/g, p = {
          "=": "=0",
          ":": "=2"
        }, m = o.replace(f, function(w) {
          return p[w];
        });
        return "$" + m;
      }
      var Es = !1, su = /\/+/g;
      function Os(o) {
        return o.replace(su, "$&/");
      }
      function Gr(o, f) {
        return typeof o == "object" && o !== null && o.key != null ? (rr(o.key), nu("" + o.key)) : f.toString(36);
      }
      function nr(o, f, p, m, w) {
        var x = typeof o;
        (x === "undefined" || x === "boolean") && (o = null);
        var k = !1;
        if (o === null)
          k = !0;
        else
          switch (x) {
            case "string":
            case "number":
              k = !0;
              break;
            case "object":
              switch (o.$$typeof) {
                case s:
                case i:
                  k = !0;
              }
          }
        if (k) {
          var U = o, B = w(U), ee = m === "" ? gs + Gr(U, 0) : m;
          if (tr(B)) {
            var ie = "";
            ee != null && (ie = Os(ee) + "/"), nr(B, f, ie, "", function(Qu) {
              return Qu;
            });
          } else B != null && (dt(B) && (B.key && (!U || U.key !== B.key) && rr(B.key), B = eu(
            B,
            // Keep both the (mapped) and old keys if they differ, just as
            // traverseAllChildren used to do for objects as children
            p + // $FlowFixMe Flow incorrectly thinks React.Portal doesn't have a key
            (B.key && (!U || U.key !== B.key) ? (
              // $FlowFixMe Flow incorrectly thinks existing element's key can be a number
              // eslint-disable-next-line react-internal/safe-string-coercion
              Os("" + B.key) + "/"
            ) : "") + ee
          )), f.push(B));
          return 1;
        }
        var ae, ue, he = 0, Ee = m === "" ? gs : m + ru;
        if (tr(o))
          for (var fr = 0; fr < o.length; fr++)
            ae = o[fr], ue = Ee + Gr(ae, fr), he += nr(ae, f, p, ue, w);
        else {
          var nn = A(o);
          if (typeof nn == "function") {
            var Ys = o;
            nn === Ys.entries && (Es || ce("Using Maps as children is not supported. Use an array of keyed ReactElements instead."), Es = !0);
            for (var Gu = nn.call(Ys), Bs, Zu = 0; !(Bs = Gu.next()).done; )
              ae = Bs.value, ue = Ee + Gr(ae, Zu++), he += nr(ae, f, p, ue, w);
          } else if (x === "object") {
            var qs = String(o);
            throw new Error("Objects are not valid as a React child (found: " + (qs === "[object Object]" ? "object with keys {" + Object.keys(o).join(", ") + "}" : qs) + "). If you meant to render a collection of children, use an array instead.");
          }
        }
        return he;
      }
      function sr(o, f, p) {
        if (o == null)
          return o;
        var m = [], w = 0;
        return nr(o, m, "", "", function(x) {
          return f.call(p, x, w++);
        }), m;
      }
      function iu(o) {
        var f = 0;
        return sr(o, function() {
          f++;
        }), f;
      }
      function au(o, f, p) {
        sr(o, function() {
          f.apply(this, arguments);
        }, p);
      }
      function ou(o) {
        return sr(o, function(f) {
          return f;
        }) || [];
      }
      function uu(o) {
        if (!dt(o))
          throw new Error("React.Children.only expected to receive a single React element child.");
        return o;
      }
      function cu(o) {
        var f = {
          $$typeof: d,
          // As a workaround to support multiple concurrent renderers, we categorize
          // some renderers as primary and others as secondary. We only expect
          // there to be two concurrent renderers at most: React Native (primary) and
          // Fabric (secondary); React DOM (primary) and React ART (secondary).
          // Secondary renderers store their context values on separate fields.
          _currentValue: o,
          _currentValue2: o,
          // Used to track how many concurrent renderers this context currently
          // supports within in a single renderer. Such as parallel server rendering.
          _threadCount: 0,
          // These are circular
          Provider: null,
          Consumer: null,
          // Add these to use same hidden class in VM as ServerContext
          _defaultValue: null,
          _globalName: null
        };
        f.Provider = {
          $$typeof: l,
          _context: f
        };
        var p = !1, m = !1, w = !1;
        {
          var x = {
            $$typeof: d,
            _context: f
          };
          Object.defineProperties(x, {
            Provider: {
              get: function() {
                return m || (m = !0, z("Rendering <Context.Consumer.Provider> is not supported and will be removed in a future major release. Did you mean to render <Context.Provider> instead?")), f.Provider;
              },
              set: function(k) {
                f.Provider = k;
              }
            },
            _currentValue: {
              get: function() {
                return f._currentValue;
              },
              set: function(k) {
                f._currentValue = k;
              }
            },
            _currentValue2: {
              get: function() {
                return f._currentValue2;
              },
              set: function(k) {
                f._currentValue2 = k;
              }
            },
            _threadCount: {
              get: function() {
                return f._threadCount;
              },
              set: function(k) {
                f._threadCount = k;
              }
            },
            Consumer: {
              get: function() {
                return p || (p = !0, z("Rendering <Context.Consumer.Consumer> is not supported and will be removed in a future major release. Did you mean to render <Context.Consumer> instead?")), f.Consumer;
              }
            },
            displayName: {
              get: function() {
                return f.displayName;
              },
              set: function(k) {
                w || (ce("Setting `displayName` on Context.Consumer has no effect. You should set it directly on the context with Context.displayName = '%s'.", k), w = !0);
              }
            }
          }), f.Consumer = x;
        }
        return f._currentRenderer = null, f._currentRenderer2 = null, f;
      }
      var Rt = -1, Zr = 0, ws = 1, lu = 2;
      function fu(o) {
        if (o._status === Rt) {
          var f = o._result, p = f();
          if (p.then(function(x) {
            if (o._status === Zr || o._status === Rt) {
              var k = o;
              k._status = ws, k._result = x;
            }
          }, function(x) {
            if (o._status === Zr || o._status === Rt) {
              var k = o;
              k._status = lu, k._result = x;
            }
          }), o._status === Rt) {
            var m = o;
            m._status = Zr, m._result = p;
          }
        }
        if (o._status === ws) {
          var w = o._result;
          return w === void 0 && z(`lazy: Expected the result of a dynamic import() call. Instead received: %s

Your code should look like: 
  const MyComponent = lazy(() => import('./MyComponent'))

Did you accidentally put curly braces around the import?`, w), "default" in w || z(`lazy: Expected the result of a dynamic import() call. Instead received: %s

Your code should look like: 
  const MyComponent = lazy(() => import('./MyComponent'))`, w), w.default;
        } else
          throw o._result;
      }
      function du(o) {
        var f = {
          // We use these fields to store the result.
          _status: Rt,
          _result: o
        }, p = {
          $$typeof: _,
          _payload: f,
          _init: fu
        };
        {
          var m, w;
          Object.defineProperties(p, {
            defaultProps: {
              configurable: !0,
              get: function() {
                return m;
              },
              set: function(x) {
                z("React.lazy(...): It is not supported to assign `defaultProps` to a lazy component import. Either specify them where the component is defined, or create a wrapping component around it."), m = x, Object.defineProperty(p, "defaultProps", {
                  enumerable: !0
                });
              }
            },
            propTypes: {
              configurable: !0,
              get: function() {
                return w;
              },
              set: function(x) {
                z("React.lazy(...): It is not supported to assign `propTypes` to a lazy component import. Either specify them where the component is defined, or create a wrapping component around it."), w = x, Object.defineProperty(p, "propTypes", {
                  enumerable: !0
                });
              }
            }
          });
        }
        return p;
      }
      function hu(o) {
        o != null && o.$$typeof === I ? z("forwardRef requires a render function but received a `memo` component. Instead of forwardRef(memo(...)), use memo(forwardRef(...)).") : typeof o != "function" ? z("forwardRef requires a render function but was given %s.", o === null ? "null" : typeof o) : o.length !== 0 && o.length !== 2 && z("forwardRef render functions accept exactly two parameters: props and ref. %s", o.length === 1 ? "Did you forget to use the ref parameter?" : "Any additional parameter will be undefined."), o != null && (o.defaultProps != null || o.propTypes != null) && z("forwardRef render functions do not support propTypes or defaultProps. Did you accidentally pass a React component?");
        var f = {
          $$typeof: v,
          render: o
        };
        {
          var p;
          Object.defineProperty(f, "displayName", {
            enumerable: !1,
            configurable: !0,
            get: function() {
              return p;
            },
            set: function(m) {
              p = m, !o.name && !o.displayName && (o.displayName = m);
            }
          });
        }
        return f;
      }
      var bs;
      bs = Symbol.for("react.module.reference");
      function Ts(o) {
        return !!(typeof o == "string" || typeof o == "function" || o === a || o === c || ft || o === u || o === T || o === O || Ye || o === E || te || je || ze || typeof o == "object" && o !== null && (o.$$typeof === _ || o.$$typeof === I || o.$$typeof === l || o.$$typeof === d || o.$$typeof === v || // This needs to include all possible module reference object
        // types supported by any Flight configuration anywhere since
        // we don't know which Flight build this will end up being used
        // with.
        o.$$typeof === bs || o.getModuleId !== void 0));
      }
      function pu(o, f) {
        Ts(o) || z("memo: The first argument must be a component. Instead received: %s", o === null ? "null" : typeof o);
        var p = {
          $$typeof: I,
          type: o,
          compare: f === void 0 ? null : f
        };
        {
          var m;
          Object.defineProperty(p, "displayName", {
            enumerable: !1,
            configurable: !0,
            get: function() {
              return m;
            },
            set: function(w) {
              m = w, !o.name && !o.displayName && (o.displayName = w);
            }
          });
        }
        return p;
      }
      function Se() {
        var o = R.current;
        return o === null && z(`Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for one of the following reasons:
1. You might have mismatching versions of React and the renderer (such as React DOM)
2. You might be breaking the Rules of Hooks
3. You might have more than one copy of React in the same app
See https://reactjs.org/link/invalid-hook-call for tips about how to debug and fix this problem.`), o;
      }
      function mu(o) {
        var f = Se();
        if (o._context !== void 0) {
          var p = o._context;
          p.Consumer === o ? z("Calling useContext(Context.Consumer) is not supported, may cause bugs, and will be removed in a future major release. Did you mean to call useContext(Context) instead?") : p.Provider === o && z("Calling useContext(Context.Provider) is not supported. Did you mean to call useContext(Context) instead?");
        }
        return f.useContext(o);
      }
      function yu(o) {
        var f = Se();
        return f.useState(o);
      }
      function vu(o, f, p) {
        var m = Se();
        return m.useReducer(o, f, p);
      }
      function gu(o) {
        var f = Se();
        return f.useRef(o);
      }
      function Eu(o, f) {
        var p = Se();
        return p.useEffect(o, f);
      }
      function Ou(o, f) {
        var p = Se();
        return p.useInsertionEffect(o, f);
      }
      function wu(o, f) {
        var p = Se();
        return p.useLayoutEffect(o, f);
      }
      function bu(o, f) {
        var p = Se();
        return p.useCallback(o, f);
      }
      function Tu(o, f) {
        var p = Se();
        return p.useMemo(o, f);
      }
      function Su(o, f, p) {
        var m = Se();
        return m.useImperativeHandle(o, f, p);
      }
      function _u(o, f) {
        {
          var p = Se();
          return p.useDebugValue(o, f);
        }
      }
      function Iu() {
        var o = Se();
        return o.useTransition();
      }
      function Nu(o) {
        var f = Se();
        return f.useDeferredValue(o);
      }
      function ku() {
        var o = Se();
        return o.useId();
      }
      function Du(o, f, p) {
        var m = Se();
        return m.useSyncExternalStore(o, f, p);
      }
      var xt = 0, Ss, _s, Is, Ns, ks, Ds, Cs;
      function As() {
      }
      As.__reactDisabledLog = !0;
      function Cu() {
        {
          if (xt === 0) {
            Ss = console.log, _s = console.info, Is = console.warn, Ns = console.error, ks = console.group, Ds = console.groupCollapsed, Cs = console.groupEnd;
            var o = {
              configurable: !0,
              enumerable: !0,
              value: As,
              writable: !0
            };
            Object.defineProperties(console, {
              info: o,
              log: o,
              warn: o,
              error: o,
              group: o,
              groupCollapsed: o,
              groupEnd: o
            });
          }
          xt++;
        }
      }
      function Au() {
        {
          if (xt--, xt === 0) {
            var o = {
              configurable: !0,
              enumerable: !0,
              writable: !0
            };
            Object.defineProperties(console, {
              log: W({}, o, {
                value: Ss
              }),
              info: W({}, o, {
                value: _s
              }),
              warn: W({}, o, {
                value: Is
              }),
              error: W({}, o, {
                value: Ns
              }),
              group: W({}, o, {
                value: ks
              }),
              groupCollapsed: W({}, o, {
                value: Ds
              }),
              groupEnd: W({}, o, {
                value: Cs
              })
            });
          }
          xt < 0 && z("disabledDepth fell below zero. This is a bug in React. Please file an issue.");
        }
      }
      var Qr = Be.ReactCurrentDispatcher, Jr;
      function ir(o, f, p) {
        {
          if (Jr === void 0)
            try {
              throw Error();
            } catch (w) {
              var m = w.stack.trim().match(/\n( *(at )?)/);
              Jr = m && m[1] || "";
            }
          return `
` + Jr + o;
        }
      }
      var Xr = !1, ar;
      {
        var Ru = typeof WeakMap == "function" ? WeakMap : Map;
        ar = new Ru();
      }
      function Rs(o, f) {
        if (!o || Xr)
          return "";
        {
          var p = ar.get(o);
          if (p !== void 0)
            return p;
        }
        var m;
        Xr = !0;
        var w = Error.prepareStackTrace;
        Error.prepareStackTrace = void 0;
        var x;
        x = Qr.current, Qr.current = null, Cu();
        try {
          if (f) {
            var k = function() {
              throw Error();
            };
            if (Object.defineProperty(k.prototype, "props", {
              set: function() {
                throw Error();
              }
            }), typeof Reflect == "object" && Reflect.construct) {
              try {
                Reflect.construct(k, []);
              } catch (Ee) {
                m = Ee;
              }
              Reflect.construct(o, [], k);
            } else {
              try {
                k.call();
              } catch (Ee) {
                m = Ee;
              }
              o.call(k.prototype);
            }
          } else {
            try {
              throw Error();
            } catch (Ee) {
              m = Ee;
            }
            o();
          }
        } catch (Ee) {
          if (Ee && m && typeof Ee.stack == "string") {
            for (var U = Ee.stack.split(`
`), B = m.stack.split(`
`), ee = U.length - 1, ie = B.length - 1; ee >= 1 && ie >= 0 && U[ee] !== B[ie]; )
              ie--;
            for (; ee >= 1 && ie >= 0; ee--, ie--)
              if (U[ee] !== B[ie]) {
                if (ee !== 1 || ie !== 1)
                  do
                    if (ee--, ie--, ie < 0 || U[ee] !== B[ie]) {
                      var ae = `
` + U[ee].replace(" at new ", " at ");
                      return o.displayName && ae.includes("<anonymous>") && (ae = ae.replace("<anonymous>", o.displayName)), typeof o == "function" && ar.set(o, ae), ae;
                    }
                  while (ee >= 1 && ie >= 0);
                break;
              }
          }
        } finally {
          Xr = !1, Qr.current = x, Au(), Error.prepareStackTrace = w;
        }
        var ue = o ? o.displayName || o.name : "", he = ue ? ir(ue) : "";
        return typeof o == "function" && ar.set(o, he), he;
      }
      function xu(o, f, p) {
        return Rs(o, !1);
      }
      function Mu(o) {
        var f = o.prototype;
        return !!(f && f.isReactComponent);
      }
      function or(o, f, p) {
        if (o == null)
          return "";
        if (typeof o == "function")
          return Rs(o, Mu(o));
        if (typeof o == "string")
          return ir(o);
        switch (o) {
          case T:
            return ir("Suspense");
          case O:
            return ir("SuspenseList");
        }
        if (typeof o == "object")
          switch (o.$$typeof) {
            case v:
              return xu(o.render);
            case I:
              return or(o.type, f, p);
            case _: {
              var m = o, w = m._payload, x = m._init;
              try {
                return or(x(w), f, p);
              } catch {
              }
            }
          }
        return "";
      }
      var xs = {}, Ms = Be.ReactDebugCurrentFrame;
      function ur(o) {
        if (o) {
          var f = o._owner, p = or(o.type, o._source, f ? f.type : null);
          Ms.setExtraStackFrame(p);
        } else
          Ms.setExtraStackFrame(null);
      }
      function Lu(o, f, p, m, w) {
        {
          var x = Function.call.bind(At);
          for (var k in o)
            if (x(o, k)) {
              var U = void 0;
              try {
                if (typeof o[k] != "function") {
                  var B = Error((m || "React class") + ": " + p + " type `" + k + "` is invalid; it must be a function, usually from the `prop-types` package, but received `" + typeof o[k] + "`.This often happens because of typos such as `PropTypes.function` instead of `PropTypes.func`.");
                  throw B.name = "Invariant Violation", B;
                }
                U = o[k](f, k, m, p, null, "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED");
              } catch (ee) {
                U = ee;
              }
              U && !(U instanceof Error) && (ur(w), z("%s: type specification of %s `%s` is invalid; the type checker function must return `null` or an `Error` but returned a %s. You may have forgotten to pass an argument to the type checker creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and shape all require an argument).", m || "React class", p, k, typeof U), ur(null)), U instanceof Error && !(U.message in xs) && (xs[U.message] = !0, ur(w), z("Failed %s type: %s", p, U.message), ur(null));
            }
        }
      }
      function ht(o) {
        if (o) {
          var f = o._owner, p = or(o.type, o._source, f ? f.type : null);
          q(p);
        } else
          q(null);
      }
      var Kr;
      Kr = !1;
      function Ls() {
        if (j.current) {
          var o = qe(j.current.type);
          if (o)
            return `

Check the render method of \`` + o + "`.";
        }
        return "";
      }
      function Fu(o) {
        if (o !== void 0) {
          var f = o.fileName.replace(/^.*[\\\/]/, ""), p = o.lineNumber;
          return `

Check your code at ` + f + ":" + p + ".";
        }
        return "";
      }
      function Pu(o) {
        return o != null ? Fu(o.__source) : "";
      }
      var Fs = {};
      function Vu(o) {
        var f = Ls();
        if (!f) {
          var p = typeof o == "string" ? o : o.displayName || o.name;
          p && (f = `

Check the top-level render call using <` + p + ">.");
        }
        return f;
      }
      function Ps(o, f) {
        if (!(!o._store || o._store.validated || o.key != null)) {
          o._store.validated = !0;
          var p = Vu(f);
          if (!Fs[p]) {
            Fs[p] = !0;
            var m = "";
            o && o._owner && o._owner !== j.current && (m = " It was passed a child from " + qe(o._owner.type) + "."), ht(o), z('Each child in a list should have a unique "key" prop.%s%s See https://reactjs.org/link/warning-keys for more information.', p, m), ht(null);
          }
        }
      }
      function Vs(o, f) {
        if (typeof o == "object") {
          if (tr(o))
            for (var p = 0; p < o.length; p++) {
              var m = o[p];
              dt(m) && Ps(m, f);
            }
          else if (dt(o))
            o._store && (o._store.validated = !0);
          else if (o) {
            var w = A(o);
            if (typeof w == "function" && w !== o.entries)
              for (var x = w.call(o), k; !(k = x.next()).done; )
                dt(k.value) && Ps(k.value, f);
          }
        }
      }
      function Us(o) {
        {
          var f = o.type;
          if (f == null || typeof f == "string")
            return;
          var p;
          if (typeof f == "function")
            p = f.propTypes;
          else if (typeof f == "object" && (f.$$typeof === v || // Note: Memo only checks outer props here.
          // Inner props are checked in the reconciler.
          f.$$typeof === I))
            p = f.propTypes;
          else
            return;
          if (p) {
            var m = qe(f);
            Lu(p, o.props, "prop", m, o);
          } else if (f.PropTypes !== void 0 && !Kr) {
            Kr = !0;
            var w = qe(f);
            z("Component %s declared `PropTypes` instead of `propTypes`. Did you misspell the property assignment?", w || "Unknown");
          }
          typeof f.getDefaultProps == "function" && !f.getDefaultProps.isReactClassApproved && z("getDefaultProps is only used on classic React.createClass definitions. Use a static property named `defaultProps` instead.");
        }
      }
      function Uu(o) {
        {
          for (var f = Object.keys(o.props), p = 0; p < f.length; p++) {
            var m = f[p];
            if (m !== "children" && m !== "key") {
              ht(o), z("Invalid prop `%s` supplied to `React.Fragment`. React.Fragment can only have `key` and `children` props.", m), ht(null);
              break;
            }
          }
          o.ref !== null && (ht(o), z("Invalid attribute `ref` supplied to `React.Fragment`."), ht(null));
        }
      }
      function $s(o, f, p) {
        var m = Ts(o);
        if (!m) {
          var w = "";
          (o === void 0 || typeof o == "object" && o !== null && Object.keys(o).length === 0) && (w += " You likely forgot to export your component from the file it's defined in, or you might have mixed up default and named imports.");
          var x = Pu(f);
          x ? w += x : w += Ls();
          var k;
          o === null ? k = "null" : tr(o) ? k = "array" : o !== void 0 && o.$$typeof === s ? (k = "<" + (qe(o.type) || "Unknown") + " />", w = " Did you accidentally export a JSX literal instead of a component?") : k = typeof o, z("React.createElement: type is invalid -- expected a string (for built-in components) or a class/function (for composite components) but got: %s.%s", k, w);
        }
        var U = Ko.apply(this, arguments);
        if (U == null)
          return U;
        if (m)
          for (var B = 2; B < arguments.length; B++)
            Vs(arguments[B], o);
        return o === a ? Uu(U) : Us(U), U;
      }
      var Ws = !1;
      function $u(o) {
        var f = $s.bind(null, o);
        return f.type = o, Ws || (Ws = !0, ce("React.createFactory() is deprecated and will be removed in a future major release. Consider using JSX or use React.createElement() directly instead.")), Object.defineProperty(f, "type", {
          enumerable: !1,
          get: function() {
            return ce("Factory.type is deprecated. Access the class directly before passing it to createFactory."), Object.defineProperty(this, "type", {
              value: o
            }), o;
          }
        }), f;
      }
      function Wu(o, f, p) {
        for (var m = tu.apply(this, arguments), w = 2; w < arguments.length; w++)
          Vs(arguments[w], m.type);
        return Us(m), m;
      }
      function Hu(o, f) {
        var p = $.transition;
        $.transition = {};
        var m = $.transition;
        $.transition._updatedFibers = /* @__PURE__ */ new Set();
        try {
          o();
        } finally {
          if ($.transition = p, p === null && m._updatedFibers) {
            var w = m._updatedFibers.size;
            w > 10 && ce("Detected a large number of updates inside startTransition. If this is due to a subscription please re-write it to use React provided hooks. Otherwise concurrent mode guarantees are off the table."), m._updatedFibers.clear();
          }
        }
      }
      var Hs = !1, cr = null;
      function ju(o) {
        if (cr === null)
          try {
            var f = ("require" + Math.random()).slice(0, 7), p = t && t[f];
            cr = p.call(t, "timers").setImmediate;
          } catch {
            cr = function(w) {
              Hs === !1 && (Hs = !0, typeof MessageChannel > "u" && z("This browser does not have a MessageChannel implementation, so enqueuing tasks via await act(async () => ...) will fail. Please file an issue at https://github.com/facebook/react/issues if you encounter this warning."));
              var x = new MessageChannel();
              x.port1.onmessage = w, x.port2.postMessage(void 0);
            };
          }
        return cr(o);
      }
      var pt = 0, js = !1;
      function zs(o) {
        {
          var f = pt;
          pt++, D.current === null && (D.current = []);
          var p = D.isBatchingLegacy, m;
          try {
            if (D.isBatchingLegacy = !0, m = o(), !p && D.didScheduleLegacyUpdate) {
              var w = D.current;
              w !== null && (D.didScheduleLegacyUpdate = !1, rn(w));
            }
          } catch (ue) {
            throw lr(f), ue;
          } finally {
            D.isBatchingLegacy = p;
          }
          if (m !== null && typeof m == "object" && typeof m.then == "function") {
            var x = m, k = !1, U = {
              then: function(ue, he) {
                k = !0, x.then(function(Ee) {
                  lr(f), pt === 0 ? en(Ee, ue, he) : ue(Ee);
                }, function(Ee) {
                  lr(f), he(Ee);
                });
              }
            };
            return !js && typeof Promise < "u" && Promise.resolve().then(function() {
            }).then(function() {
              k || (js = !0, z("You called act(async () => ...) without await. This could lead to unexpected testing behaviour, interleaving multiple act calls and mixing their scopes. You should - await act(async () => ...);"));
            }), U;
          } else {
            var B = m;
            if (lr(f), pt === 0) {
              var ee = D.current;
              ee !== null && (rn(ee), D.current = null);
              var ie = {
                then: function(ue, he) {
                  D.current === null ? (D.current = [], en(B, ue, he)) : ue(B);
                }
              };
              return ie;
            } else {
              var ae = {
                then: function(ue, he) {
                  ue(B);
                }
              };
              return ae;
            }
          }
        }
      }
      function lr(o) {
        o !== pt - 1 && z("You seem to have overlapping act() calls, this is not supported. Be sure to await previous act() calls before making a new one. "), pt = o;
      }
      function en(o, f, p) {
        {
          var m = D.current;
          if (m !== null)
            try {
              rn(m), ju(function() {
                m.length === 0 ? (D.current = null, f(o)) : en(o, f, p);
              });
            } catch (w) {
              p(w);
            }
          else
            f(o);
        }
      }
      var tn = !1;
      function rn(o) {
        if (!tn) {
          tn = !0;
          var f = 0;
          try {
            for (; f < o.length; f++) {
              var p = o[f];
              do
                p = p(!0);
              while (p !== null);
            }
            o.length = 0;
          } catch (m) {
            throw o = o.slice(f + 1), m;
          } finally {
            tn = !1;
          }
        }
      }
      var zu = $s, Yu = Wu, Bu = $u, qu = {
        map: sr,
        forEach: au,
        count: iu,
        toArray: ou,
        only: uu
      };
      e.Children = qu, e.Component = Y, e.Fragment = a, e.Profiler = c, e.PureComponent = Te, e.StrictMode = u, e.Suspense = T, e.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = Be, e.act = zs, e.cloneElement = Yu, e.createContext = cu, e.createElement = zu, e.createFactory = Bu, e.createRef = Yo, e.forwardRef = hu, e.isValidElement = dt, e.lazy = du, e.memo = pu, e.startTransition = Hu, e.unstable_act = zs, e.useCallback = bu, e.useContext = mu, e.useDebugValue = _u, e.useDeferredValue = Nu, e.useEffect = Eu, e.useId = ku, e.useImperativeHandle = Su, e.useInsertionEffect = Ou, e.useLayoutEffect = wu, e.useMemo = Tu, e.useReducer = vu, e.useRef = gu, e.useState = yu, e.useSyncExternalStore = Du, e.useTransition = Iu, e.version = n, typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u" && typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop == "function" && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(new Error());
    }();
  }(Pt, Pt.exports)), Pt.exports;
}
var Ku = {};
Ku.NODE_ENV === "production" ? Tn.exports = Ju() : Tn.exports = Xu();
var qn = Tn.exports;
const ec = /* @__PURE__ */ Qi(qn), tp = /* @__PURE__ */ Zi({
  __proto__: null,
  default: ec
}, [qn]), Ji = globalThis || void 0 || self;
var Sn = function(t, e) {
  return Sn = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(r, n) {
    r.__proto__ = n;
  } || function(r, n) {
    for (var s in n) Object.prototype.hasOwnProperty.call(n, s) && (r[s] = n[s]);
  }, Sn(t, e);
};
function Xi(t, e) {
  if (typeof e != "function" && e !== null)
    throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
  Sn(t, e);
  function r() {
    this.constructor = t;
  }
  t.prototype = e === null ? Object.create(e) : (r.prototype = e.prototype, new r());
}
var J = function() {
  return J = Object.assign || function(e) {
    for (var r, n = 1, s = arguments.length; n < s; n++) {
      r = arguments[n];
      for (var i in r) Object.prototype.hasOwnProperty.call(r, i) && (e[i] = r[i]);
    }
    return e;
  }, J.apply(this, arguments);
};
function Ki(t, e) {
  var r = {};
  for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && e.indexOf(n) < 0 && (r[n] = t[n]);
  if (t != null && typeof Object.getOwnPropertySymbols == "function")
    for (var s = 0, n = Object.getOwnPropertySymbols(t); s < n.length; s++)
      e.indexOf(n[s]) < 0 && Object.prototype.propertyIsEnumerable.call(t, n[s]) && (r[n[s]] = t[n[s]]);
  return r;
}
function rp(t, e, r, n) {
  function s(i) {
    return i instanceof r ? i : new r(function(a) {
      a(i);
    });
  }
  return new (r || (r = Promise))(function(i, a) {
    function u(d) {
      try {
        l(n.next(d));
      } catch (v) {
        a(v);
      }
    }
    function c(d) {
      try {
        l(n.throw(d));
      } catch (v) {
        a(v);
      }
    }
    function l(d) {
      d.done ? i(d.value) : s(d.value).then(u, c);
    }
    l((n = n.apply(t, e || [])).next());
  });
}
function np(t, e) {
  var r = { label: 0, sent: function() {
    if (i[0] & 1) throw i[1];
    return i[1];
  }, trys: [], ops: [] }, n, s, i, a = Object.create((typeof Iterator == "function" ? Iterator : Object).prototype);
  return a.next = u(0), a.throw = u(1), a.return = u(2), typeof Symbol == "function" && (a[Symbol.iterator] = function() {
    return this;
  }), a;
  function u(l) {
    return function(d) {
      return c([l, d]);
    };
  }
  function c(l) {
    if (n) throw new TypeError("Generator is already executing.");
    for (; a && (a = 0, l[0] && (r = 0)), r; ) try {
      if (n = 1, s && (i = l[0] & 2 ? s.return : l[0] ? s.throw || ((i = s.return) && i.call(s), 0) : s.next) && !(i = i.call(s, l[1])).done) return i;
      switch (s = 0, i && (l = [l[0] & 2, i.value]), l[0]) {
        case 0:
        case 1:
          i = l;
          break;
        case 4:
          return r.label++, { value: l[1], done: !1 };
        case 5:
          r.label++, s = l[1], l = [0];
          continue;
        case 7:
          l = r.ops.pop(), r.trys.pop();
          continue;
        default:
          if (i = r.trys, !(i = i.length > 0 && i[i.length - 1]) && (l[0] === 6 || l[0] === 2)) {
            r = 0;
            continue;
          }
          if (l[0] === 3 && (!i || l[1] > i[0] && l[1] < i[3])) {
            r.label = l[1];
            break;
          }
          if (l[0] === 6 && r.label < i[1]) {
            r.label = i[1], i = l;
            break;
          }
          if (i && r.label < i[2]) {
            r.label = i[2], r.ops.push(l);
            break;
          }
          i[2] && r.ops.pop(), r.trys.pop();
          continue;
      }
      l = e.call(t, r);
    } catch (d) {
      l = [6, d], s = 0;
    } finally {
      n = i = 0;
    }
    if (l[0] & 5) throw l[1];
    return { value: l[0] ? l[1] : void 0, done: !0 };
  }
}
function Ve(t, e, r) {
  if (r || arguments.length === 2) for (var n = 0, s = e.length, i; n < s; n++)
    (i || !(n in e)) && (i || (i = Array.prototype.slice.call(e, 0, n)), i[n] = e[n]);
  return t.concat(i || Array.prototype.slice.call(e));
}
var sn = "Invariant Violation", Qs = Object.setPrototypeOf, tc = Qs === void 0 ? function(t, e) {
  return t.__proto__ = e, t;
} : Qs, ea = (
  /** @class */
  function(t) {
    Xi(e, t);
    function e(r) {
      r === void 0 && (r = sn);
      var n = t.call(this, typeof r == "number" ? sn + ": " + r + " (see https://github.com/apollographql/invariant-packages)" : r) || this;
      return n.framesToPop = 1, n.name = sn, tc(n, e.prototype), n;
    }
    return e;
  }(Error)
);
function st(t, e) {
  if (!t)
    throw new ea(e);
}
var ta = ["debug", "log", "warn", "error", "silent"], rc = ta.indexOf("log");
function dr(t) {
  return function() {
    if (ta.indexOf(t) >= rc) {
      var e = console[t] || console.log;
      return e.apply(console, arguments);
    }
  };
}
(function(t) {
  t.debug = dr("debug"), t.log = dr("log"), t.warn = dr("warn"), t.error = dr("error");
})(st || (st = {}));
var ra = "3.11.8";
function $e(t) {
  try {
    return t();
  } catch {
  }
}
const _n = $e(function() {
  return globalThis;
}) || $e(function() {
  return window;
}) || $e(function() {
  return self;
}) || $e(function() {
  return Ji;
}) || // We don't expect the Function constructor ever to be invoked at runtime, as
// long as at least one of globalThis, window, self, or global is defined, so
// we are under no obligation to make it easy for static analysis tools to
// detect syntactic usage of the Function constructor. If you think you can
// improve your static analysis to detect this obfuscation, think again. This
// is an arms race you cannot win, at least not in JavaScript.
$e(function() {
  return $e.constructor("return this")();
});
var Js = /* @__PURE__ */ new Map();
function nc(t) {
  var e = Js.get(t) || 1;
  return Js.set(t, e + 1), "".concat(t, ":").concat(e, ":").concat(Math.random().toString(36).slice(2));
}
function sc(t, e) {
  e === void 0 && (e = 0);
  var r = nc("stringifyForDisplay");
  return JSON.stringify(t, function(n, s) {
    return s === void 0 ? r : s;
  }, e).split(JSON.stringify(r)).join("<undefined>");
}
function hr(t) {
  return function(e) {
    for (var r = [], n = 1; n < arguments.length; n++)
      r[n - 1] = arguments[n];
    if (typeof e == "number") {
      var s = e;
      e = Gn(s), e || (e = Zn(s, r), r = []);
    }
    t.apply(void 0, [e].concat(r));
  };
}
var We = Object.assign(function(e, r) {
  for (var n = [], s = 2; s < arguments.length; s++)
    n[s - 2] = arguments[s];
  e || st(e, Gn(r, n) || Zn(r, n));
}, {
  debug: hr(st.debug),
  log: hr(st.log),
  warn: hr(st.warn),
  error: hr(st.error)
});
function sp(t) {
  for (var e = [], r = 1; r < arguments.length; r++)
    e[r - 1] = arguments[r];
  return new ea(Gn(t, e) || Zn(t, e));
}
var Xs = Symbol.for("ApolloErrorMessageHandler_" + ra);
function na(t) {
  if (typeof t == "string")
    return t;
  try {
    return sc(t, 2).slice(0, 1e3);
  } catch {
    return "<non-serializable>";
  }
}
function Gn(t, e) {
  if (e === void 0 && (e = []), !!t)
    return _n[Xs] && _n[Xs](t, e.map(na));
}
function Zn(t, e) {
  if (e === void 0 && (e = []), !!t)
    return "An error occurred! For more details, see the full error text at https://go.apollo.dev/c/err#".concat(encodeURIComponent(JSON.stringify({
      version: ra,
      message: t,
      args: e.map(na)
    })));
}
function an(t, e) {
  if (!!!t)
    throw new Error(e);
}
function ic(t) {
  return typeof t == "object" && t !== null;
}
function ac(t, e) {
  if (!!!t)
    throw new Error(
      e ?? "Unexpected invariant triggered."
    );
}
const oc = /\r\n|[\n\r]/g;
function In(t, e) {
  let r = 0, n = 1;
  for (const s of t.body.matchAll(oc)) {
    if (typeof s.index == "number" || ac(!1), s.index >= e)
      break;
    r = s.index + s[0].length, n += 1;
  }
  return {
    line: n,
    column: e + 1 - r
  };
}
function uc(t) {
  return sa(
    t.source,
    In(t.source, t.start)
  );
}
function sa(t, e) {
  const r = t.locationOffset.column - 1, n = "".padStart(r) + t.body, s = e.line - 1, i = t.locationOffset.line - 1, a = e.line + i, u = e.line === 1 ? r : 0, c = e.column + u, l = `${t.name}:${a}:${c}
`, d = n.split(/\r\n|[\n\r]/g), v = d[s];
  if (v.length > 120) {
    const T = Math.floor(c / 80), O = c % 80, I = [];
    for (let _ = 0; _ < v.length; _ += 80)
      I.push(v.slice(_, _ + 80));
    return l + Ks([
      [`${a} |`, I[0]],
      ...I.slice(1, T + 1).map((_) => ["|", _]),
      ["|", "^".padStart(O)],
      ["|", I[T + 1]]
    ]);
  }
  return l + Ks([
    // Lines specified like this: ["prefix", "string"],
    [`${a - 1} |`, d[s - 1]],
    [`${a} |`, v],
    ["|", "^".padStart(c)],
    [`${a + 1} |`, d[s + 1]]
  ]);
}
function Ks(t) {
  const e = t.filter(([n, s]) => s !== void 0), r = Math.max(...e.map(([n]) => n.length));
  return e.map(([n, s]) => n.padStart(r) + (s ? " " + s : "")).join(`
`);
}
function cc(t) {
  const e = t[0];
  return e == null || "kind" in e || "length" in e ? {
    nodes: e,
    source: t[1],
    positions: t[2],
    path: t[3],
    originalError: t[4],
    extensions: t[5]
  } : e;
}
class Qn extends Error {
  /**
   * An array of `{ line, column }` locations within the source GraphQL document
   * which correspond to this error.
   *
   * Errors during validation often contain multiple locations, for example to
   * point out two things with the same name. Errors during execution include a
   * single location, the field which produced the error.
   *
   * Enumerable, and appears in the result of JSON.stringify().
   */
  /**
   * An array describing the JSON-path into the execution response which
   * corresponds to this error. Only included for errors during execution.
   *
   * Enumerable, and appears in the result of JSON.stringify().
   */
  /**
   * An array of GraphQL AST Nodes corresponding to this error.
   */
  /**
   * The source GraphQL document for the first location of this error.
   *
   * Note that if this Error represents more than one node, the source may not
   * represent nodes after the first node.
   */
  /**
   * An array of character offsets within the source GraphQL document
   * which correspond to this error.
   */
  /**
   * The original error thrown from a field resolver during execution.
   */
  /**
   * Extension fields to add to the formatted error.
   */
  /**
   * @deprecated Please use the `GraphQLErrorOptions` constructor overload instead.
   */
  constructor(e, ...r) {
    var n, s, i;
    const { nodes: a, source: u, positions: c, path: l, originalError: d, extensions: v } = cc(r);
    super(e), this.name = "GraphQLError", this.path = l ?? void 0, this.originalError = d ?? void 0, this.nodes = ei(
      Array.isArray(a) ? a : a ? [a] : void 0
    );
    const T = ei(
      (n = this.nodes) === null || n === void 0 ? void 0 : n.map((I) => I.loc).filter((I) => I != null)
    );
    this.source = u ?? (T == null || (s = T[0]) === null || s === void 0 ? void 0 : s.source), this.positions = c ?? T?.map((I) => I.start), this.locations = c && u ? c.map((I) => In(u, I)) : T?.map((I) => In(I.source, I.start));
    const O = ic(
      d?.extensions
    ) ? d?.extensions : void 0;
    this.extensions = (i = v ?? O) !== null && i !== void 0 ? i : /* @__PURE__ */ Object.create(null), Object.defineProperties(this, {
      message: {
        writable: !0,
        enumerable: !0
      },
      name: {
        enumerable: !1
      },
      nodes: {
        enumerable: !1
      },
      source: {
        enumerable: !1
      },
      positions: {
        enumerable: !1
      },
      originalError: {
        enumerable: !1
      }
    }), d != null && d.stack ? Object.defineProperty(this, "stack", {
      value: d.stack,
      writable: !0,
      configurable: !0
    }) : Error.captureStackTrace ? Error.captureStackTrace(this, Qn) : Object.defineProperty(this, "stack", {
      value: Error().stack,
      writable: !0,
      configurable: !0
    });
  }
  get [Symbol.toStringTag]() {
    return "GraphQLError";
  }
  toString() {
    let e = this.message;
    if (this.nodes)
      for (const r of this.nodes)
        r.loc && (e += `

` + uc(r.loc));
    else if (this.source && this.locations)
      for (const r of this.locations)
        e += `

` + sa(this.source, r);
    return e;
  }
  toJSON() {
    const e = {
      message: this.message
    };
    return this.locations != null && (e.locations = this.locations), this.path != null && (e.path = this.path), this.extensions != null && Object.keys(this.extensions).length > 0 && (e.extensions = this.extensions), e;
  }
}
function ei(t) {
  return t === void 0 || t.length === 0 ? void 0 : t;
}
function ge(t, e, r) {
  return new Qn(`Syntax Error: ${r}`, {
    source: t,
    positions: [e]
  });
}
class lc {
  /**
   * The character offset at which this Node begins.
   */
  /**
   * The character offset at which this Node ends.
   */
  /**
   * The Token at which this Node begins.
   */
  /**
   * The Token at which this Node ends.
   */
  /**
   * The Source document the AST represents.
   */
  constructor(e, r, n) {
    this.start = e.start, this.end = r.end, this.startToken = e, this.endToken = r, this.source = n;
  }
  get [Symbol.toStringTag]() {
    return "Location";
  }
  toJSON() {
    return {
      start: this.start,
      end: this.end
    };
  }
}
class ia {
  /**
   * The kind of Token.
   */
  /**
   * The character offset at which this Node begins.
   */
  /**
   * The character offset at which this Node ends.
   */
  /**
   * The 1-indexed line number on which this Token appears.
   */
  /**
   * The 1-indexed column number at which this Token begins.
   */
  /**
   * For non-punctuation tokens, represents the interpreted value of the token.
   *
   * Note: is undefined for punctuation tokens, but typed as string for
   * convenience in the parser.
   */
  /**
   * Tokens exist as nodes in a double-linked-list amongst all tokens
   * including ignored tokens. <SOF> is always the first node and <EOF>
   * the last.
   */
  constructor(e, r, n, s, i, a) {
    this.kind = e, this.start = r, this.end = n, this.line = s, this.column = i, this.value = a, this.prev = null, this.next = null;
  }
  get [Symbol.toStringTag]() {
    return "Token";
  }
  toJSON() {
    return {
      kind: this.kind,
      value: this.value,
      line: this.line,
      column: this.column
    };
  }
}
const fc = {
  Name: [],
  Document: ["definitions"],
  OperationDefinition: [
    "name",
    "variableDefinitions",
    "directives",
    "selectionSet"
  ],
  VariableDefinition: ["variable", "type", "defaultValue", "directives"],
  Variable: ["name"],
  SelectionSet: ["selections"],
  Field: ["alias", "name", "arguments", "directives", "selectionSet"],
  Argument: ["name", "value"],
  FragmentSpread: ["name", "directives"],
  InlineFragment: ["typeCondition", "directives", "selectionSet"],
  FragmentDefinition: [
    "name",
    // Note: fragment variable definitions are deprecated and will removed in v17.0.0
    "variableDefinitions",
    "typeCondition",
    "directives",
    "selectionSet"
  ],
  IntValue: [],
  FloatValue: [],
  StringValue: [],
  BooleanValue: [],
  NullValue: [],
  EnumValue: [],
  ListValue: ["values"],
  ObjectValue: ["fields"],
  ObjectField: ["name", "value"],
  Directive: ["name", "arguments"],
  NamedType: ["name"],
  ListType: ["type"],
  NonNullType: ["type"],
  SchemaDefinition: ["description", "directives", "operationTypes"],
  OperationTypeDefinition: ["type"],
  ScalarTypeDefinition: ["description", "name", "directives"],
  ObjectTypeDefinition: [
    "description",
    "name",
    "interfaces",
    "directives",
    "fields"
  ],
  FieldDefinition: ["description", "name", "arguments", "type", "directives"],
  InputValueDefinition: [
    "description",
    "name",
    "type",
    "defaultValue",
    "directives"
  ],
  InterfaceTypeDefinition: [
    "description",
    "name",
    "interfaces",
    "directives",
    "fields"
  ],
  UnionTypeDefinition: ["description", "name", "directives", "types"],
  EnumTypeDefinition: ["description", "name", "directives", "values"],
  EnumValueDefinition: ["description", "name", "directives"],
  InputObjectTypeDefinition: ["description", "name", "directives", "fields"],
  DirectiveDefinition: ["description", "name", "arguments", "locations"],
  SchemaExtension: ["directives", "operationTypes"],
  ScalarTypeExtension: ["name", "directives"],
  ObjectTypeExtension: ["name", "interfaces", "directives", "fields"],
  InterfaceTypeExtension: ["name", "interfaces", "directives", "fields"],
  UnionTypeExtension: ["name", "directives", "types"],
  EnumTypeExtension: ["name", "directives", "values"],
  InputObjectTypeExtension: ["name", "directives", "fields"]
}, dc = new Set(Object.keys(fc));
function ip(t) {
  const e = t?.kind;
  return typeof e == "string" && dc.has(e);
}
var Ot;
(function(t) {
  t.QUERY = "query", t.MUTATION = "mutation", t.SUBSCRIPTION = "subscription";
})(Ot || (Ot = {}));
var Nn;
(function(t) {
  t.QUERY = "QUERY", t.MUTATION = "MUTATION", t.SUBSCRIPTION = "SUBSCRIPTION", t.FIELD = "FIELD", t.FRAGMENT_DEFINITION = "FRAGMENT_DEFINITION", t.FRAGMENT_SPREAD = "FRAGMENT_SPREAD", t.INLINE_FRAGMENT = "INLINE_FRAGMENT", t.VARIABLE_DEFINITION = "VARIABLE_DEFINITION", t.SCHEMA = "SCHEMA", t.SCALAR = "SCALAR", t.OBJECT = "OBJECT", t.FIELD_DEFINITION = "FIELD_DEFINITION", t.ARGUMENT_DEFINITION = "ARGUMENT_DEFINITION", t.INTERFACE = "INTERFACE", t.UNION = "UNION", t.ENUM = "ENUM", t.ENUM_VALUE = "ENUM_VALUE", t.INPUT_OBJECT = "INPUT_OBJECT", t.INPUT_FIELD_DEFINITION = "INPUT_FIELD_DEFINITION";
})(Nn || (Nn = {}));
var L;
(function(t) {
  t.NAME = "Name", t.DOCUMENT = "Document", t.OPERATION_DEFINITION = "OperationDefinition", t.VARIABLE_DEFINITION = "VariableDefinition", t.SELECTION_SET = "SelectionSet", t.FIELD = "Field", t.ARGUMENT = "Argument", t.FRAGMENT_SPREAD = "FragmentSpread", t.INLINE_FRAGMENT = "InlineFragment", t.FRAGMENT_DEFINITION = "FragmentDefinition", t.VARIABLE = "Variable", t.INT = "IntValue", t.FLOAT = "FloatValue", t.STRING = "StringValue", t.BOOLEAN = "BooleanValue", t.NULL = "NullValue", t.ENUM = "EnumValue", t.LIST = "ListValue", t.OBJECT = "ObjectValue", t.OBJECT_FIELD = "ObjectField", t.DIRECTIVE = "Directive", t.NAMED_TYPE = "NamedType", t.LIST_TYPE = "ListType", t.NON_NULL_TYPE = "NonNullType", t.SCHEMA_DEFINITION = "SchemaDefinition", t.OPERATION_TYPE_DEFINITION = "OperationTypeDefinition", t.SCALAR_TYPE_DEFINITION = "ScalarTypeDefinition", t.OBJECT_TYPE_DEFINITION = "ObjectTypeDefinition", t.FIELD_DEFINITION = "FieldDefinition", t.INPUT_VALUE_DEFINITION = "InputValueDefinition", t.INTERFACE_TYPE_DEFINITION = "InterfaceTypeDefinition", t.UNION_TYPE_DEFINITION = "UnionTypeDefinition", t.ENUM_TYPE_DEFINITION = "EnumTypeDefinition", t.ENUM_VALUE_DEFINITION = "EnumValueDefinition", t.INPUT_OBJECT_TYPE_DEFINITION = "InputObjectTypeDefinition", t.DIRECTIVE_DEFINITION = "DirectiveDefinition", t.SCHEMA_EXTENSION = "SchemaExtension", t.SCALAR_TYPE_EXTENSION = "ScalarTypeExtension", t.OBJECT_TYPE_EXTENSION = "ObjectTypeExtension", t.INTERFACE_TYPE_EXTENSION = "InterfaceTypeExtension", t.UNION_TYPE_EXTENSION = "UnionTypeExtension", t.ENUM_TYPE_EXTENSION = "EnumTypeExtension", t.INPUT_OBJECT_TYPE_EXTENSION = "InputObjectTypeExtension";
})(L || (L = {}));
function kn(t) {
  return t === 9 || t === 32;
}
function Ht(t) {
  return t >= 48 && t <= 57;
}
function aa(t) {
  return t >= 97 && t <= 122 || // A-Z
  t >= 65 && t <= 90;
}
function oa(t) {
  return aa(t) || t === 95;
}
function hc(t) {
  return aa(t) || Ht(t) || t === 95;
}
function pc(t) {
  var e;
  let r = Number.MAX_SAFE_INTEGER, n = null, s = -1;
  for (let a = 0; a < t.length; ++a) {
    var i;
    const u = t[a], c = mc(u);
    c !== u.length && (n = (i = n) !== null && i !== void 0 ? i : a, s = a, a !== 0 && c < r && (r = c));
  }
  return t.map((a, u) => u === 0 ? a : a.slice(r)).slice(
    (e = n) !== null && e !== void 0 ? e : 0,
    s + 1
  );
}
function mc(t) {
  let e = 0;
  for (; e < t.length && kn(t.charCodeAt(e)); )
    ++e;
  return e;
}
function ap(t, e) {
  const r = t.replace(/"""/g, '\\"""'), n = r.split(/\r\n|[\n\r]/g), s = n.length === 1, i = n.length > 1 && n.slice(1).every((O) => O.length === 0 || kn(O.charCodeAt(0))), a = r.endsWith('\\"""'), u = t.endsWith('"') && !a, c = t.endsWith("\\"), l = u || c, d = (
    // add leading and trailing new lines only if it improves readability
    !s || t.length > 70 || l || i || a
  );
  let v = "";
  const T = s && kn(t.charCodeAt(0));
  return (d && !T || i) && (v += `
`), v += r, (d || l) && (v += `
`), '"""' + v + '"""';
}
var g;
(function(t) {
  t.SOF = "<SOF>", t.EOF = "<EOF>", t.BANG = "!", t.DOLLAR = "$", t.AMP = "&", t.PAREN_L = "(", t.PAREN_R = ")", t.SPREAD = "...", t.COLON = ":", t.EQUALS = "=", t.AT = "@", t.BRACKET_L = "[", t.BRACKET_R = "]", t.BRACE_L = "{", t.PIPE = "|", t.BRACE_R = "}", t.NAME = "Name", t.INT = "Int", t.FLOAT = "Float", t.STRING = "String", t.BLOCK_STRING = "BlockString", t.COMMENT = "Comment";
})(g || (g = {}));
class yc {
  /**
   * The previously focused non-ignored token.
   */
  /**
   * The currently focused non-ignored token.
   */
  /**
   * The (1-indexed) line containing the current token.
   */
  /**
   * The character offset at which the current line begins.
   */
  constructor(e) {
    const r = new ia(g.SOF, 0, 0, 0, 0);
    this.source = e, this.lastToken = r, this.token = r, this.line = 1, this.lineStart = 0;
  }
  get [Symbol.toStringTag]() {
    return "Lexer";
  }
  /**
   * Advances the token stream to the next non-ignored token.
   */
  advance() {
    return this.lastToken = this.token, this.token = this.lookahead();
  }
  /**
   * Looks ahead and returns the next non-ignored token, but does not change
   * the state of Lexer.
   */
  lookahead() {
    let e = this.token;
    if (e.kind !== g.EOF)
      do
        if (e.next)
          e = e.next;
        else {
          const r = gc(this, e.end);
          e.next = r, r.prev = e, e = r;
        }
      while (e.kind === g.COMMENT);
    return e;
  }
}
function vc(t) {
  return t === g.BANG || t === g.DOLLAR || t === g.AMP || t === g.PAREN_L || t === g.PAREN_R || t === g.SPREAD || t === g.COLON || t === g.EQUALS || t === g.AT || t === g.BRACKET_L || t === g.BRACKET_R || t === g.BRACE_L || t === g.PIPE || t === g.BRACE_R;
}
function _t(t) {
  return t >= 0 && t <= 55295 || t >= 57344 && t <= 1114111;
}
function Pr(t, e) {
  return ua(t.charCodeAt(e)) && ca(t.charCodeAt(e + 1));
}
function ua(t) {
  return t >= 55296 && t <= 56319;
}
function ca(t) {
  return t >= 56320 && t <= 57343;
}
function ot(t, e) {
  const r = t.source.body.codePointAt(e);
  if (r === void 0)
    return g.EOF;
  if (r >= 32 && r <= 126) {
    const n = String.fromCodePoint(r);
    return n === '"' ? `'"'` : `"${n}"`;
  }
  return "U+" + r.toString(16).toUpperCase().padStart(4, "0");
}
function pe(t, e, r, n, s) {
  const i = t.line, a = 1 + r - t.lineStart;
  return new ia(e, r, n, i, a, s);
}
function gc(t, e) {
  const r = t.source.body, n = r.length;
  let s = e;
  for (; s < n; ) {
    const i = r.charCodeAt(s);
    switch (i) {
      case 65279:
      case 9:
      case 32:
      case 44:
        ++s;
        continue;
      case 10:
        ++s, ++t.line, t.lineStart = s;
        continue;
      case 13:
        r.charCodeAt(s + 1) === 10 ? s += 2 : ++s, ++t.line, t.lineStart = s;
        continue;
      case 35:
        return Ec(t, s);
      case 33:
        return pe(t, g.BANG, s, s + 1);
      case 36:
        return pe(t, g.DOLLAR, s, s + 1);
      case 38:
        return pe(t, g.AMP, s, s + 1);
      case 40:
        return pe(t, g.PAREN_L, s, s + 1);
      case 41:
        return pe(t, g.PAREN_R, s, s + 1);
      case 46:
        if (r.charCodeAt(s + 1) === 46 && r.charCodeAt(s + 2) === 46)
          return pe(t, g.SPREAD, s, s + 3);
        break;
      case 58:
        return pe(t, g.COLON, s, s + 1);
      case 61:
        return pe(t, g.EQUALS, s, s + 1);
      case 64:
        return pe(t, g.AT, s, s + 1);
      case 91:
        return pe(t, g.BRACKET_L, s, s + 1);
      case 93:
        return pe(t, g.BRACKET_R, s, s + 1);
      case 123:
        return pe(t, g.BRACE_L, s, s + 1);
      case 124:
        return pe(t, g.PIPE, s, s + 1);
      case 125:
        return pe(t, g.BRACE_R, s, s + 1);
      case 34:
        return r.charCodeAt(s + 1) === 34 && r.charCodeAt(s + 2) === 34 ? _c(t, s) : wc(t, s);
    }
    if (Ht(i) || i === 45)
      return Oc(t, s, i);
    if (oa(i))
      return Ic(t, s);
    throw ge(
      t.source,
      s,
      i === 39 ? `Unexpected single quote character ('), did you mean to use a double quote (")?` : _t(i) || Pr(r, s) ? `Unexpected character: ${ot(t, s)}.` : `Invalid character: ${ot(t, s)}.`
    );
  }
  return pe(t, g.EOF, n, n);
}
function Ec(t, e) {
  const r = t.source.body, n = r.length;
  let s = e + 1;
  for (; s < n; ) {
    const i = r.charCodeAt(s);
    if (i === 10 || i === 13)
      break;
    if (_t(i))
      ++s;
    else if (Pr(r, s))
      s += 2;
    else
      break;
  }
  return pe(
    t,
    g.COMMENT,
    e,
    s,
    r.slice(e + 1, s)
  );
}
function Oc(t, e, r) {
  const n = t.source.body;
  let s = e, i = r, a = !1;
  if (i === 45 && (i = n.charCodeAt(++s)), i === 48) {
    if (i = n.charCodeAt(++s), Ht(i))
      throw ge(
        t.source,
        s,
        `Invalid number, unexpected digit after 0: ${ot(
          t,
          s
        )}.`
      );
  } else
    s = on(t, s, i), i = n.charCodeAt(s);
  if (i === 46 && (a = !0, i = n.charCodeAt(++s), s = on(t, s, i), i = n.charCodeAt(s)), (i === 69 || i === 101) && (a = !0, i = n.charCodeAt(++s), (i === 43 || i === 45) && (i = n.charCodeAt(++s)), s = on(t, s, i), i = n.charCodeAt(s)), i === 46 || oa(i))
    throw ge(
      t.source,
      s,
      `Invalid number, expected digit but got: ${ot(
        t,
        s
      )}.`
    );
  return pe(
    t,
    a ? g.FLOAT : g.INT,
    e,
    s,
    n.slice(e, s)
  );
}
function on(t, e, r) {
  if (!Ht(r))
    throw ge(
      t.source,
      e,
      `Invalid number, expected digit but got: ${ot(
        t,
        e
      )}.`
    );
  const n = t.source.body;
  let s = e + 1;
  for (; Ht(n.charCodeAt(s)); )
    ++s;
  return s;
}
function wc(t, e) {
  const r = t.source.body, n = r.length;
  let s = e + 1, i = s, a = "";
  for (; s < n; ) {
    const u = r.charCodeAt(s);
    if (u === 34)
      return a += r.slice(i, s), pe(t, g.STRING, e, s + 1, a);
    if (u === 92) {
      a += r.slice(i, s);
      const c = r.charCodeAt(s + 1) === 117 ? r.charCodeAt(s + 2) === 123 ? bc(t, s) : Tc(t, s) : Sc(t, s);
      a += c.value, s += c.size, i = s;
      continue;
    }
    if (u === 10 || u === 13)
      break;
    if (_t(u))
      ++s;
    else if (Pr(r, s))
      s += 2;
    else
      throw ge(
        t.source,
        s,
        `Invalid character within String: ${ot(
          t,
          s
        )}.`
      );
  }
  throw ge(t.source, s, "Unterminated string.");
}
function bc(t, e) {
  const r = t.source.body;
  let n = 0, s = 3;
  for (; s < 12; ) {
    const i = r.charCodeAt(e + s++);
    if (i === 125) {
      if (s < 5 || !_t(n))
        break;
      return {
        value: String.fromCodePoint(n),
        size: s
      };
    }
    if (n = n << 4 | Vt(i), n < 0)
      break;
  }
  throw ge(
    t.source,
    e,
    `Invalid Unicode escape sequence: "${r.slice(
      e,
      e + s
    )}".`
  );
}
function Tc(t, e) {
  const r = t.source.body, n = ti(r, e + 2);
  if (_t(n))
    return {
      value: String.fromCodePoint(n),
      size: 6
    };
  if (ua(n) && r.charCodeAt(e + 6) === 92 && r.charCodeAt(e + 7) === 117) {
    const s = ti(r, e + 8);
    if (ca(s))
      return {
        value: String.fromCodePoint(n, s),
        size: 12
      };
  }
  throw ge(
    t.source,
    e,
    `Invalid Unicode escape sequence: "${r.slice(e, e + 6)}".`
  );
}
function ti(t, e) {
  return Vt(t.charCodeAt(e)) << 12 | Vt(t.charCodeAt(e + 1)) << 8 | Vt(t.charCodeAt(e + 2)) << 4 | Vt(t.charCodeAt(e + 3));
}
function Vt(t) {
  return t >= 48 && t <= 57 ? t - 48 : t >= 65 && t <= 70 ? t - 55 : t >= 97 && t <= 102 ? t - 87 : -1;
}
function Sc(t, e) {
  const r = t.source.body;
  switch (r.charCodeAt(e + 1)) {
    case 34:
      return {
        value: '"',
        size: 2
      };
    case 92:
      return {
        value: "\\",
        size: 2
      };
    case 47:
      return {
        value: "/",
        size: 2
      };
    case 98:
      return {
        value: "\b",
        size: 2
      };
    case 102:
      return {
        value: "\f",
        size: 2
      };
    case 110:
      return {
        value: `
`,
        size: 2
      };
    case 114:
      return {
        value: "\r",
        size: 2
      };
    case 116:
      return {
        value: "	",
        size: 2
      };
  }
  throw ge(
    t.source,
    e,
    `Invalid character escape sequence: "${r.slice(
      e,
      e + 2
    )}".`
  );
}
function _c(t, e) {
  const r = t.source.body, n = r.length;
  let s = t.lineStart, i = e + 3, a = i, u = "";
  const c = [];
  for (; i < n; ) {
    const l = r.charCodeAt(i);
    if (l === 34 && r.charCodeAt(i + 1) === 34 && r.charCodeAt(i + 2) === 34) {
      u += r.slice(a, i), c.push(u);
      const d = pe(
        t,
        g.BLOCK_STRING,
        e,
        i + 3,
        // Return a string of the lines joined with U+000A.
        pc(c).join(`
`)
      );
      return t.line += c.length - 1, t.lineStart = s, d;
    }
    if (l === 92 && r.charCodeAt(i + 1) === 34 && r.charCodeAt(i + 2) === 34 && r.charCodeAt(i + 3) === 34) {
      u += r.slice(a, i), a = i + 1, i += 4;
      continue;
    }
    if (l === 10 || l === 13) {
      u += r.slice(a, i), c.push(u), l === 13 && r.charCodeAt(i + 1) === 10 ? i += 2 : ++i, u = "", a = i, s = i;
      continue;
    }
    if (_t(l))
      ++i;
    else if (Pr(r, i))
      i += 2;
    else
      throw ge(
        t.source,
        i,
        `Invalid character within String: ${ot(
          t,
          i
        )}.`
      );
  }
  throw ge(t.source, i, "Unterminated string.");
}
function Ic(t, e) {
  const r = t.source.body, n = r.length;
  let s = e + 1;
  for (; s < n; ) {
    const i = r.charCodeAt(s);
    if (hc(i))
      ++s;
    else
      break;
  }
  return pe(
    t,
    g.NAME,
    e,
    s,
    r.slice(e, s)
  );
}
const Nc = 10, la = 2;
function fa(t) {
  return Vr(t, []);
}
function Vr(t, e) {
  switch (typeof t) {
    case "string":
      return JSON.stringify(t);
    case "function":
      return t.name ? `[function ${t.name}]` : "[function]";
    case "object":
      return kc(t, e);
    default:
      return String(t);
  }
}
function kc(t, e) {
  if (t === null)
    return "null";
  if (e.includes(t))
    return "[Circular]";
  const r = [...e, t];
  if (Dc(t)) {
    const n = t.toJSON();
    if (n !== t)
      return typeof n == "string" ? n : Vr(n, r);
  } else if (Array.isArray(t))
    return Ac(t, r);
  return Cc(t, r);
}
function Dc(t) {
  return typeof t.toJSON == "function";
}
function Cc(t, e) {
  const r = Object.entries(t);
  return r.length === 0 ? "{}" : e.length > la ? "[" + Rc(t) + "]" : "{ " + r.map(
    ([s, i]) => s + ": " + Vr(i, e)
  ).join(", ") + " }";
}
function Ac(t, e) {
  if (t.length === 0)
    return "[]";
  if (e.length > la)
    return "[Array]";
  const r = Math.min(Nc, t.length), n = t.length - r, s = [];
  for (let i = 0; i < r; ++i)
    s.push(Vr(t[i], e));
  return n === 1 ? s.push("... 1 more item") : n > 1 && s.push(`... ${n} more items`), "[" + s.join(", ") + "]";
}
function Rc(t) {
  const e = Object.prototype.toString.call(t).replace(/^\[object /, "").replace(/]$/, "");
  if (e === "Object" && typeof t.constructor == "function") {
    const r = t.constructor.name;
    if (typeof r == "string" && r !== "")
      return r;
  }
  return e;
}
var xc = {};
const Mc = globalThis.process && // eslint-disable-next-line no-undef
xc.NODE_ENV === "production", Lc = (
  /* c8 ignore next 6 */
  // FIXME: https://github.com/graphql/graphql-js/issues/2317
  Mc ? function(e, r) {
    return e instanceof r;
  } : function(e, r) {
    if (e instanceof r)
      return !0;
    if (typeof e == "object" && e !== null) {
      var n;
      const s = r.prototype[Symbol.toStringTag], i = (
        // We still need to support constructor's name to detect conflicts with older versions of this library.
        Symbol.toStringTag in e ? e[Symbol.toStringTag] : (n = e.constructor) === null || n === void 0 ? void 0 : n.name
      );
      if (s === i) {
        const a = fa(e);
        throw new Error(`Cannot use ${s} "${a}" from another module or realm.

Ensure that there is only one instance of "graphql" in the node_modules
directory. If different versions of "graphql" are the dependencies of other
relied on modules, use "resolutions" to ensure only one version is installed.

https://yarnpkg.com/en/docs/selective-version-resolutions

Duplicate "graphql" modules cannot be used at the same time since different
versions may have different capabilities and behavior. The data from one
version used in the function from another could produce confusing and
spurious results.`);
      }
    }
    return !1;
  }
);
class da {
  constructor(e, r = "GraphQL request", n = {
    line: 1,
    column: 1
  }) {
    typeof e == "string" || an(!1, `Body must be a string. Received: ${fa(e)}.`), this.body = e, this.name = r, this.locationOffset = n, this.locationOffset.line > 0 || an(
      !1,
      "line in locationOffset is 1-indexed and must be positive."
    ), this.locationOffset.column > 0 || an(
      !1,
      "column in locationOffset is 1-indexed and must be positive."
    );
  }
  get [Symbol.toStringTag]() {
    return "Source";
  }
}
function Fc(t) {
  return Lc(t, da);
}
function Pc(t, e) {
  return new Vc(t, e).parseDocument();
}
class Vc {
  constructor(e, r = {}) {
    const n = Fc(e) ? e : new da(e);
    this._lexer = new yc(n), this._options = r, this._tokenCounter = 0;
  }
  /**
   * Converts a name lex token into a name parse node.
   */
  parseName() {
    const e = this.expectToken(g.NAME);
    return this.node(e, {
      kind: L.NAME,
      value: e.value
    });
  }
  // Implements the parsing rules in the Document section.
  /**
   * Document : Definition+
   */
  parseDocument() {
    return this.node(this._lexer.token, {
      kind: L.DOCUMENT,
      definitions: this.many(
        g.SOF,
        this.parseDefinition,
        g.EOF
      )
    });
  }
  /**
   * Definition :
   *   - ExecutableDefinition
   *   - TypeSystemDefinition
   *   - TypeSystemExtension
   *
   * ExecutableDefinition :
   *   - OperationDefinition
   *   - FragmentDefinition
   *
   * TypeSystemDefinition :
   *   - SchemaDefinition
   *   - TypeDefinition
   *   - DirectiveDefinition
   *
   * TypeDefinition :
   *   - ScalarTypeDefinition
   *   - ObjectTypeDefinition
   *   - InterfaceTypeDefinition
   *   - UnionTypeDefinition
   *   - EnumTypeDefinition
   *   - InputObjectTypeDefinition
   */
  parseDefinition() {
    if (this.peek(g.BRACE_L))
      return this.parseOperationDefinition();
    const e = this.peekDescription(), r = e ? this._lexer.lookahead() : this._lexer.token;
    if (r.kind === g.NAME) {
      switch (r.value) {
        case "schema":
          return this.parseSchemaDefinition();
        case "scalar":
          return this.parseScalarTypeDefinition();
        case "type":
          return this.parseObjectTypeDefinition();
        case "interface":
          return this.parseInterfaceTypeDefinition();
        case "union":
          return this.parseUnionTypeDefinition();
        case "enum":
          return this.parseEnumTypeDefinition();
        case "input":
          return this.parseInputObjectTypeDefinition();
        case "directive":
          return this.parseDirectiveDefinition();
      }
      if (e)
        throw ge(
          this._lexer.source,
          this._lexer.token.start,
          "Unexpected description, descriptions are supported only on type definitions."
        );
      switch (r.value) {
        case "query":
        case "mutation":
        case "subscription":
          return this.parseOperationDefinition();
        case "fragment":
          return this.parseFragmentDefinition();
        case "extend":
          return this.parseTypeSystemExtension();
      }
    }
    throw this.unexpected(r);
  }
  // Implements the parsing rules in the Operations section.
  /**
   * OperationDefinition :
   *  - SelectionSet
   *  - OperationType Name? VariableDefinitions? Directives? SelectionSet
   */
  parseOperationDefinition() {
    const e = this._lexer.token;
    if (this.peek(g.BRACE_L))
      return this.node(e, {
        kind: L.OPERATION_DEFINITION,
        operation: Ot.QUERY,
        name: void 0,
        variableDefinitions: [],
        directives: [],
        selectionSet: this.parseSelectionSet()
      });
    const r = this.parseOperationType();
    let n;
    return this.peek(g.NAME) && (n = this.parseName()), this.node(e, {
      kind: L.OPERATION_DEFINITION,
      operation: r,
      name: n,
      variableDefinitions: this.parseVariableDefinitions(),
      directives: this.parseDirectives(!1),
      selectionSet: this.parseSelectionSet()
    });
  }
  /**
   * OperationType : one of query mutation subscription
   */
  parseOperationType() {
    const e = this.expectToken(g.NAME);
    switch (e.value) {
      case "query":
        return Ot.QUERY;
      case "mutation":
        return Ot.MUTATION;
      case "subscription":
        return Ot.SUBSCRIPTION;
    }
    throw this.unexpected(e);
  }
  /**
   * VariableDefinitions : ( VariableDefinition+ )
   */
  parseVariableDefinitions() {
    return this.optionalMany(
      g.PAREN_L,
      this.parseVariableDefinition,
      g.PAREN_R
    );
  }
  /**
   * VariableDefinition : Variable : Type DefaultValue? Directives[Const]?
   */
  parseVariableDefinition() {
    return this.node(this._lexer.token, {
      kind: L.VARIABLE_DEFINITION,
      variable: this.parseVariable(),
      type: (this.expectToken(g.COLON), this.parseTypeReference()),
      defaultValue: this.expectOptionalToken(g.EQUALS) ? this.parseConstValueLiteral() : void 0,
      directives: this.parseConstDirectives()
    });
  }
  /**
   * Variable : $ Name
   */
  parseVariable() {
    const e = this._lexer.token;
    return this.expectToken(g.DOLLAR), this.node(e, {
      kind: L.VARIABLE,
      name: this.parseName()
    });
  }
  /**
   * ```
   * SelectionSet : { Selection+ }
   * ```
   */
  parseSelectionSet() {
    return this.node(this._lexer.token, {
      kind: L.SELECTION_SET,
      selections: this.many(
        g.BRACE_L,
        this.parseSelection,
        g.BRACE_R
      )
    });
  }
  /**
   * Selection :
   *   - Field
   *   - FragmentSpread
   *   - InlineFragment
   */
  parseSelection() {
    return this.peek(g.SPREAD) ? this.parseFragment() : this.parseField();
  }
  /**
   * Field : Alias? Name Arguments? Directives? SelectionSet?
   *
   * Alias : Name :
   */
  parseField() {
    const e = this._lexer.token, r = this.parseName();
    let n, s;
    return this.expectOptionalToken(g.COLON) ? (n = r, s = this.parseName()) : s = r, this.node(e, {
      kind: L.FIELD,
      alias: n,
      name: s,
      arguments: this.parseArguments(!1),
      directives: this.parseDirectives(!1),
      selectionSet: this.peek(g.BRACE_L) ? this.parseSelectionSet() : void 0
    });
  }
  /**
   * Arguments[Const] : ( Argument[?Const]+ )
   */
  parseArguments(e) {
    const r = e ? this.parseConstArgument : this.parseArgument;
    return this.optionalMany(g.PAREN_L, r, g.PAREN_R);
  }
  /**
   * Argument[Const] : Name : Value[?Const]
   */
  parseArgument(e = !1) {
    const r = this._lexer.token, n = this.parseName();
    return this.expectToken(g.COLON), this.node(r, {
      kind: L.ARGUMENT,
      name: n,
      value: this.parseValueLiteral(e)
    });
  }
  parseConstArgument() {
    return this.parseArgument(!0);
  }
  // Implements the parsing rules in the Fragments section.
  /**
   * Corresponds to both FragmentSpread and InlineFragment in the spec.
   *
   * FragmentSpread : ... FragmentName Directives?
   *
   * InlineFragment : ... TypeCondition? Directives? SelectionSet
   */
  parseFragment() {
    const e = this._lexer.token;
    this.expectToken(g.SPREAD);
    const r = this.expectOptionalKeyword("on");
    return !r && this.peek(g.NAME) ? this.node(e, {
      kind: L.FRAGMENT_SPREAD,
      name: this.parseFragmentName(),
      directives: this.parseDirectives(!1)
    }) : this.node(e, {
      kind: L.INLINE_FRAGMENT,
      typeCondition: r ? this.parseNamedType() : void 0,
      directives: this.parseDirectives(!1),
      selectionSet: this.parseSelectionSet()
    });
  }
  /**
   * FragmentDefinition :
   *   - fragment FragmentName on TypeCondition Directives? SelectionSet
   *
   * TypeCondition : NamedType
   */
  parseFragmentDefinition() {
    const e = this._lexer.token;
    return this.expectKeyword("fragment"), this._options.allowLegacyFragmentVariables === !0 ? this.node(e, {
      kind: L.FRAGMENT_DEFINITION,
      name: this.parseFragmentName(),
      variableDefinitions: this.parseVariableDefinitions(),
      typeCondition: (this.expectKeyword("on"), this.parseNamedType()),
      directives: this.parseDirectives(!1),
      selectionSet: this.parseSelectionSet()
    }) : this.node(e, {
      kind: L.FRAGMENT_DEFINITION,
      name: this.parseFragmentName(),
      typeCondition: (this.expectKeyword("on"), this.parseNamedType()),
      directives: this.parseDirectives(!1),
      selectionSet: this.parseSelectionSet()
    });
  }
  /**
   * FragmentName : Name but not `on`
   */
  parseFragmentName() {
    if (this._lexer.token.value === "on")
      throw this.unexpected();
    return this.parseName();
  }
  // Implements the parsing rules in the Values section.
  /**
   * Value[Const] :
   *   - [~Const] Variable
   *   - IntValue
   *   - FloatValue
   *   - StringValue
   *   - BooleanValue
   *   - NullValue
   *   - EnumValue
   *   - ListValue[?Const]
   *   - ObjectValue[?Const]
   *
   * BooleanValue : one of `true` `false`
   *
   * NullValue : `null`
   *
   * EnumValue : Name but not `true`, `false` or `null`
   */
  parseValueLiteral(e) {
    const r = this._lexer.token;
    switch (r.kind) {
      case g.BRACKET_L:
        return this.parseList(e);
      case g.BRACE_L:
        return this.parseObject(e);
      case g.INT:
        return this.advanceLexer(), this.node(r, {
          kind: L.INT,
          value: r.value
        });
      case g.FLOAT:
        return this.advanceLexer(), this.node(r, {
          kind: L.FLOAT,
          value: r.value
        });
      case g.STRING:
      case g.BLOCK_STRING:
        return this.parseStringLiteral();
      case g.NAME:
        switch (this.advanceLexer(), r.value) {
          case "true":
            return this.node(r, {
              kind: L.BOOLEAN,
              value: !0
            });
          case "false":
            return this.node(r, {
              kind: L.BOOLEAN,
              value: !1
            });
          case "null":
            return this.node(r, {
              kind: L.NULL
            });
          default:
            return this.node(r, {
              kind: L.ENUM,
              value: r.value
            });
        }
      case g.DOLLAR:
        if (e)
          if (this.expectToken(g.DOLLAR), this._lexer.token.kind === g.NAME) {
            const n = this._lexer.token.value;
            throw ge(
              this._lexer.source,
              r.start,
              `Unexpected variable "$${n}" in constant value.`
            );
          } else
            throw this.unexpected(r);
        return this.parseVariable();
      default:
        throw this.unexpected();
    }
  }
  parseConstValueLiteral() {
    return this.parseValueLiteral(!0);
  }
  parseStringLiteral() {
    const e = this._lexer.token;
    return this.advanceLexer(), this.node(e, {
      kind: L.STRING,
      value: e.value,
      block: e.kind === g.BLOCK_STRING
    });
  }
  /**
   * ListValue[Const] :
   *   - [ ]
   *   - [ Value[?Const]+ ]
   */
  parseList(e) {
    const r = () => this.parseValueLiteral(e);
    return this.node(this._lexer.token, {
      kind: L.LIST,
      values: this.any(g.BRACKET_L, r, g.BRACKET_R)
    });
  }
  /**
   * ```
   * ObjectValue[Const] :
   *   - { }
   *   - { ObjectField[?Const]+ }
   * ```
   */
  parseObject(e) {
    const r = () => this.parseObjectField(e);
    return this.node(this._lexer.token, {
      kind: L.OBJECT,
      fields: this.any(g.BRACE_L, r, g.BRACE_R)
    });
  }
  /**
   * ObjectField[Const] : Name : Value[?Const]
   */
  parseObjectField(e) {
    const r = this._lexer.token, n = this.parseName();
    return this.expectToken(g.COLON), this.node(r, {
      kind: L.OBJECT_FIELD,
      name: n,
      value: this.parseValueLiteral(e)
    });
  }
  // Implements the parsing rules in the Directives section.
  /**
   * Directives[Const] : Directive[?Const]+
   */
  parseDirectives(e) {
    const r = [];
    for (; this.peek(g.AT); )
      r.push(this.parseDirective(e));
    return r;
  }
  parseConstDirectives() {
    return this.parseDirectives(!0);
  }
  /**
   * ```
   * Directive[Const] : @ Name Arguments[?Const]?
   * ```
   */
  parseDirective(e) {
    const r = this._lexer.token;
    return this.expectToken(g.AT), this.node(r, {
      kind: L.DIRECTIVE,
      name: this.parseName(),
      arguments: this.parseArguments(e)
    });
  }
  // Implements the parsing rules in the Types section.
  /**
   * Type :
   *   - NamedType
   *   - ListType
   *   - NonNullType
   */
  parseTypeReference() {
    const e = this._lexer.token;
    let r;
    if (this.expectOptionalToken(g.BRACKET_L)) {
      const n = this.parseTypeReference();
      this.expectToken(g.BRACKET_R), r = this.node(e, {
        kind: L.LIST_TYPE,
        type: n
      });
    } else
      r = this.parseNamedType();
    return this.expectOptionalToken(g.BANG) ? this.node(e, {
      kind: L.NON_NULL_TYPE,
      type: r
    }) : r;
  }
  /**
   * NamedType : Name
   */
  parseNamedType() {
    return this.node(this._lexer.token, {
      kind: L.NAMED_TYPE,
      name: this.parseName()
    });
  }
  // Implements the parsing rules in the Type Definition section.
  peekDescription() {
    return this.peek(g.STRING) || this.peek(g.BLOCK_STRING);
  }
  /**
   * Description : StringValue
   */
  parseDescription() {
    if (this.peekDescription())
      return this.parseStringLiteral();
  }
  /**
   * ```
   * SchemaDefinition : Description? schema Directives[Const]? { OperationTypeDefinition+ }
   * ```
   */
  parseSchemaDefinition() {
    const e = this._lexer.token, r = this.parseDescription();
    this.expectKeyword("schema");
    const n = this.parseConstDirectives(), s = this.many(
      g.BRACE_L,
      this.parseOperationTypeDefinition,
      g.BRACE_R
    );
    return this.node(e, {
      kind: L.SCHEMA_DEFINITION,
      description: r,
      directives: n,
      operationTypes: s
    });
  }
  /**
   * OperationTypeDefinition : OperationType : NamedType
   */
  parseOperationTypeDefinition() {
    const e = this._lexer.token, r = this.parseOperationType();
    this.expectToken(g.COLON);
    const n = this.parseNamedType();
    return this.node(e, {
      kind: L.OPERATION_TYPE_DEFINITION,
      operation: r,
      type: n
    });
  }
  /**
   * ScalarTypeDefinition : Description? scalar Name Directives[Const]?
   */
  parseScalarTypeDefinition() {
    const e = this._lexer.token, r = this.parseDescription();
    this.expectKeyword("scalar");
    const n = this.parseName(), s = this.parseConstDirectives();
    return this.node(e, {
      kind: L.SCALAR_TYPE_DEFINITION,
      description: r,
      name: n,
      directives: s
    });
  }
  /**
   * ObjectTypeDefinition :
   *   Description?
   *   type Name ImplementsInterfaces? Directives[Const]? FieldsDefinition?
   */
  parseObjectTypeDefinition() {
    const e = this._lexer.token, r = this.parseDescription();
    this.expectKeyword("type");
    const n = this.parseName(), s = this.parseImplementsInterfaces(), i = this.parseConstDirectives(), a = this.parseFieldsDefinition();
    return this.node(e, {
      kind: L.OBJECT_TYPE_DEFINITION,
      description: r,
      name: n,
      interfaces: s,
      directives: i,
      fields: a
    });
  }
  /**
   * ImplementsInterfaces :
   *   - implements `&`? NamedType
   *   - ImplementsInterfaces & NamedType
   */
  parseImplementsInterfaces() {
    return this.expectOptionalKeyword("implements") ? this.delimitedMany(g.AMP, this.parseNamedType) : [];
  }
  /**
   * ```
   * FieldsDefinition : { FieldDefinition+ }
   * ```
   */
  parseFieldsDefinition() {
    return this.optionalMany(
      g.BRACE_L,
      this.parseFieldDefinition,
      g.BRACE_R
    );
  }
  /**
   * FieldDefinition :
   *   - Description? Name ArgumentsDefinition? : Type Directives[Const]?
   */
  parseFieldDefinition() {
    const e = this._lexer.token, r = this.parseDescription(), n = this.parseName(), s = this.parseArgumentDefs();
    this.expectToken(g.COLON);
    const i = this.parseTypeReference(), a = this.parseConstDirectives();
    return this.node(e, {
      kind: L.FIELD_DEFINITION,
      description: r,
      name: n,
      arguments: s,
      type: i,
      directives: a
    });
  }
  /**
   * ArgumentsDefinition : ( InputValueDefinition+ )
   */
  parseArgumentDefs() {
    return this.optionalMany(
      g.PAREN_L,
      this.parseInputValueDef,
      g.PAREN_R
    );
  }
  /**
   * InputValueDefinition :
   *   - Description? Name : Type DefaultValue? Directives[Const]?
   */
  parseInputValueDef() {
    const e = this._lexer.token, r = this.parseDescription(), n = this.parseName();
    this.expectToken(g.COLON);
    const s = this.parseTypeReference();
    let i;
    this.expectOptionalToken(g.EQUALS) && (i = this.parseConstValueLiteral());
    const a = this.parseConstDirectives();
    return this.node(e, {
      kind: L.INPUT_VALUE_DEFINITION,
      description: r,
      name: n,
      type: s,
      defaultValue: i,
      directives: a
    });
  }
  /**
   * InterfaceTypeDefinition :
   *   - Description? interface Name Directives[Const]? FieldsDefinition?
   */
  parseInterfaceTypeDefinition() {
    const e = this._lexer.token, r = this.parseDescription();
    this.expectKeyword("interface");
    const n = this.parseName(), s = this.parseImplementsInterfaces(), i = this.parseConstDirectives(), a = this.parseFieldsDefinition();
    return this.node(e, {
      kind: L.INTERFACE_TYPE_DEFINITION,
      description: r,
      name: n,
      interfaces: s,
      directives: i,
      fields: a
    });
  }
  /**
   * UnionTypeDefinition :
   *   - Description? union Name Directives[Const]? UnionMemberTypes?
   */
  parseUnionTypeDefinition() {
    const e = this._lexer.token, r = this.parseDescription();
    this.expectKeyword("union");
    const n = this.parseName(), s = this.parseConstDirectives(), i = this.parseUnionMemberTypes();
    return this.node(e, {
      kind: L.UNION_TYPE_DEFINITION,
      description: r,
      name: n,
      directives: s,
      types: i
    });
  }
  /**
   * UnionMemberTypes :
   *   - = `|`? NamedType
   *   - UnionMemberTypes | NamedType
   */
  parseUnionMemberTypes() {
    return this.expectOptionalToken(g.EQUALS) ? this.delimitedMany(g.PIPE, this.parseNamedType) : [];
  }
  /**
   * EnumTypeDefinition :
   *   - Description? enum Name Directives[Const]? EnumValuesDefinition?
   */
  parseEnumTypeDefinition() {
    const e = this._lexer.token, r = this.parseDescription();
    this.expectKeyword("enum");
    const n = this.parseName(), s = this.parseConstDirectives(), i = this.parseEnumValuesDefinition();
    return this.node(e, {
      kind: L.ENUM_TYPE_DEFINITION,
      description: r,
      name: n,
      directives: s,
      values: i
    });
  }
  /**
   * ```
   * EnumValuesDefinition : { EnumValueDefinition+ }
   * ```
   */
  parseEnumValuesDefinition() {
    return this.optionalMany(
      g.BRACE_L,
      this.parseEnumValueDefinition,
      g.BRACE_R
    );
  }
  /**
   * EnumValueDefinition : Description? EnumValue Directives[Const]?
   */
  parseEnumValueDefinition() {
    const e = this._lexer.token, r = this.parseDescription(), n = this.parseEnumValueName(), s = this.parseConstDirectives();
    return this.node(e, {
      kind: L.ENUM_VALUE_DEFINITION,
      description: r,
      name: n,
      directives: s
    });
  }
  /**
   * EnumValue : Name but not `true`, `false` or `null`
   */
  parseEnumValueName() {
    if (this._lexer.token.value === "true" || this._lexer.token.value === "false" || this._lexer.token.value === "null")
      throw ge(
        this._lexer.source,
        this._lexer.token.start,
        `${pr(
          this._lexer.token
        )} is reserved and cannot be used for an enum value.`
      );
    return this.parseName();
  }
  /**
   * InputObjectTypeDefinition :
   *   - Description? input Name Directives[Const]? InputFieldsDefinition?
   */
  parseInputObjectTypeDefinition() {
    const e = this._lexer.token, r = this.parseDescription();
    this.expectKeyword("input");
    const n = this.parseName(), s = this.parseConstDirectives(), i = this.parseInputFieldsDefinition();
    return this.node(e, {
      kind: L.INPUT_OBJECT_TYPE_DEFINITION,
      description: r,
      name: n,
      directives: s,
      fields: i
    });
  }
  /**
   * ```
   * InputFieldsDefinition : { InputValueDefinition+ }
   * ```
   */
  parseInputFieldsDefinition() {
    return this.optionalMany(
      g.BRACE_L,
      this.parseInputValueDef,
      g.BRACE_R
    );
  }
  /**
   * TypeSystemExtension :
   *   - SchemaExtension
   *   - TypeExtension
   *
   * TypeExtension :
   *   - ScalarTypeExtension
   *   - ObjectTypeExtension
   *   - InterfaceTypeExtension
   *   - UnionTypeExtension
   *   - EnumTypeExtension
   *   - InputObjectTypeDefinition
   */
  parseTypeSystemExtension() {
    const e = this._lexer.lookahead();
    if (e.kind === g.NAME)
      switch (e.value) {
        case "schema":
          return this.parseSchemaExtension();
        case "scalar":
          return this.parseScalarTypeExtension();
        case "type":
          return this.parseObjectTypeExtension();
        case "interface":
          return this.parseInterfaceTypeExtension();
        case "union":
          return this.parseUnionTypeExtension();
        case "enum":
          return this.parseEnumTypeExtension();
        case "input":
          return this.parseInputObjectTypeExtension();
      }
    throw this.unexpected(e);
  }
  /**
   * ```
   * SchemaExtension :
   *  - extend schema Directives[Const]? { OperationTypeDefinition+ }
   *  - extend schema Directives[Const]
   * ```
   */
  parseSchemaExtension() {
    const e = this._lexer.token;
    this.expectKeyword("extend"), this.expectKeyword("schema");
    const r = this.parseConstDirectives(), n = this.optionalMany(
      g.BRACE_L,
      this.parseOperationTypeDefinition,
      g.BRACE_R
    );
    if (r.length === 0 && n.length === 0)
      throw this.unexpected();
    return this.node(e, {
      kind: L.SCHEMA_EXTENSION,
      directives: r,
      operationTypes: n
    });
  }
  /**
   * ScalarTypeExtension :
   *   - extend scalar Name Directives[Const]
   */
  parseScalarTypeExtension() {
    const e = this._lexer.token;
    this.expectKeyword("extend"), this.expectKeyword("scalar");
    const r = this.parseName(), n = this.parseConstDirectives();
    if (n.length === 0)
      throw this.unexpected();
    return this.node(e, {
      kind: L.SCALAR_TYPE_EXTENSION,
      name: r,
      directives: n
    });
  }
  /**
   * ObjectTypeExtension :
   *  - extend type Name ImplementsInterfaces? Directives[Const]? FieldsDefinition
   *  - extend type Name ImplementsInterfaces? Directives[Const]
   *  - extend type Name ImplementsInterfaces
   */
  parseObjectTypeExtension() {
    const e = this._lexer.token;
    this.expectKeyword("extend"), this.expectKeyword("type");
    const r = this.parseName(), n = this.parseImplementsInterfaces(), s = this.parseConstDirectives(), i = this.parseFieldsDefinition();
    if (n.length === 0 && s.length === 0 && i.length === 0)
      throw this.unexpected();
    return this.node(e, {
      kind: L.OBJECT_TYPE_EXTENSION,
      name: r,
      interfaces: n,
      directives: s,
      fields: i
    });
  }
  /**
   * InterfaceTypeExtension :
   *  - extend interface Name ImplementsInterfaces? Directives[Const]? FieldsDefinition
   *  - extend interface Name ImplementsInterfaces? Directives[Const]
   *  - extend interface Name ImplementsInterfaces
   */
  parseInterfaceTypeExtension() {
    const e = this._lexer.token;
    this.expectKeyword("extend"), this.expectKeyword("interface");
    const r = this.parseName(), n = this.parseImplementsInterfaces(), s = this.parseConstDirectives(), i = this.parseFieldsDefinition();
    if (n.length === 0 && s.length === 0 && i.length === 0)
      throw this.unexpected();
    return this.node(e, {
      kind: L.INTERFACE_TYPE_EXTENSION,
      name: r,
      interfaces: n,
      directives: s,
      fields: i
    });
  }
  /**
   * UnionTypeExtension :
   *   - extend union Name Directives[Const]? UnionMemberTypes
   *   - extend union Name Directives[Const]
   */
  parseUnionTypeExtension() {
    const e = this._lexer.token;
    this.expectKeyword("extend"), this.expectKeyword("union");
    const r = this.parseName(), n = this.parseConstDirectives(), s = this.parseUnionMemberTypes();
    if (n.length === 0 && s.length === 0)
      throw this.unexpected();
    return this.node(e, {
      kind: L.UNION_TYPE_EXTENSION,
      name: r,
      directives: n,
      types: s
    });
  }
  /**
   * EnumTypeExtension :
   *   - extend enum Name Directives[Const]? EnumValuesDefinition
   *   - extend enum Name Directives[Const]
   */
  parseEnumTypeExtension() {
    const e = this._lexer.token;
    this.expectKeyword("extend"), this.expectKeyword("enum");
    const r = this.parseName(), n = this.parseConstDirectives(), s = this.parseEnumValuesDefinition();
    if (n.length === 0 && s.length === 0)
      throw this.unexpected();
    return this.node(e, {
      kind: L.ENUM_TYPE_EXTENSION,
      name: r,
      directives: n,
      values: s
    });
  }
  /**
   * InputObjectTypeExtension :
   *   - extend input Name Directives[Const]? InputFieldsDefinition
   *   - extend input Name Directives[Const]
   */
  parseInputObjectTypeExtension() {
    const e = this._lexer.token;
    this.expectKeyword("extend"), this.expectKeyword("input");
    const r = this.parseName(), n = this.parseConstDirectives(), s = this.parseInputFieldsDefinition();
    if (n.length === 0 && s.length === 0)
      throw this.unexpected();
    return this.node(e, {
      kind: L.INPUT_OBJECT_TYPE_EXTENSION,
      name: r,
      directives: n,
      fields: s
    });
  }
  /**
   * ```
   * DirectiveDefinition :
   *   - Description? directive @ Name ArgumentsDefinition? `repeatable`? on DirectiveLocations
   * ```
   */
  parseDirectiveDefinition() {
    const e = this._lexer.token, r = this.parseDescription();
    this.expectKeyword("directive"), this.expectToken(g.AT);
    const n = this.parseName(), s = this.parseArgumentDefs(), i = this.expectOptionalKeyword("repeatable");
    this.expectKeyword("on");
    const a = this.parseDirectiveLocations();
    return this.node(e, {
      kind: L.DIRECTIVE_DEFINITION,
      description: r,
      name: n,
      arguments: s,
      repeatable: i,
      locations: a
    });
  }
  /**
   * DirectiveLocations :
   *   - `|`? DirectiveLocation
   *   - DirectiveLocations | DirectiveLocation
   */
  parseDirectiveLocations() {
    return this.delimitedMany(g.PIPE, this.parseDirectiveLocation);
  }
  /*
   * DirectiveLocation :
   *   - ExecutableDirectiveLocation
   *   - TypeSystemDirectiveLocation
   *
   * ExecutableDirectiveLocation : one of
   *   `QUERY`
   *   `MUTATION`
   *   `SUBSCRIPTION`
   *   `FIELD`
   *   `FRAGMENT_DEFINITION`
   *   `FRAGMENT_SPREAD`
   *   `INLINE_FRAGMENT`
   *
   * TypeSystemDirectiveLocation : one of
   *   `SCHEMA`
   *   `SCALAR`
   *   `OBJECT`
   *   `FIELD_DEFINITION`
   *   `ARGUMENT_DEFINITION`
   *   `INTERFACE`
   *   `UNION`
   *   `ENUM`
   *   `ENUM_VALUE`
   *   `INPUT_OBJECT`
   *   `INPUT_FIELD_DEFINITION`
   */
  parseDirectiveLocation() {
    const e = this._lexer.token, r = this.parseName();
    if (Object.prototype.hasOwnProperty.call(Nn, r.value))
      return r;
    throw this.unexpected(e);
  }
  // Core parsing utility functions
  /**
   * Returns a node that, if configured to do so, sets a "loc" field as a
   * location object, used to identify the place in the source that created a
   * given parsed object.
   */
  node(e, r) {
    return this._options.noLocation !== !0 && (r.loc = new lc(
      e,
      this._lexer.lastToken,
      this._lexer.source
    )), r;
  }
  /**
   * Determines if the next token is of a given kind
   */
  peek(e) {
    return this._lexer.token.kind === e;
  }
  /**
   * If the next token is of the given kind, return that token after advancing the lexer.
   * Otherwise, do not change the parser state and throw an error.
   */
  expectToken(e) {
    const r = this._lexer.token;
    if (r.kind === e)
      return this.advanceLexer(), r;
    throw ge(
      this._lexer.source,
      r.start,
      `Expected ${ha(e)}, found ${pr(r)}.`
    );
  }
  /**
   * If the next token is of the given kind, return "true" after advancing the lexer.
   * Otherwise, do not change the parser state and return "false".
   */
  expectOptionalToken(e) {
    return this._lexer.token.kind === e ? (this.advanceLexer(), !0) : !1;
  }
  /**
   * If the next token is a given keyword, advance the lexer.
   * Otherwise, do not change the parser state and throw an error.
   */
  expectKeyword(e) {
    const r = this._lexer.token;
    if (r.kind === g.NAME && r.value === e)
      this.advanceLexer();
    else
      throw ge(
        this._lexer.source,
        r.start,
        `Expected "${e}", found ${pr(r)}.`
      );
  }
  /**
   * If the next token is a given keyword, return "true" after advancing the lexer.
   * Otherwise, do not change the parser state and return "false".
   */
  expectOptionalKeyword(e) {
    const r = this._lexer.token;
    return r.kind === g.NAME && r.value === e ? (this.advanceLexer(), !0) : !1;
  }
  /**
   * Helper function for creating an error when an unexpected lexed token is encountered.
   */
  unexpected(e) {
    const r = e ?? this._lexer.token;
    return ge(
      this._lexer.source,
      r.start,
      `Unexpected ${pr(r)}.`
    );
  }
  /**
   * Returns a possibly empty list of parse nodes, determined by the parseFn.
   * This list begins with a lex token of openKind and ends with a lex token of closeKind.
   * Advances the parser to the next lex token after the closing token.
   */
  any(e, r, n) {
    this.expectToken(e);
    const s = [];
    for (; !this.expectOptionalToken(n); )
      s.push(r.call(this));
    return s;
  }
  /**
   * Returns a list of parse nodes, determined by the parseFn.
   * It can be empty only if open token is missing otherwise it will always return non-empty list
   * that begins with a lex token of openKind and ends with a lex token of closeKind.
   * Advances the parser to the next lex token after the closing token.
   */
  optionalMany(e, r, n) {
    if (this.expectOptionalToken(e)) {
      const s = [];
      do
        s.push(r.call(this));
      while (!this.expectOptionalToken(n));
      return s;
    }
    return [];
  }
  /**
   * Returns a non-empty list of parse nodes, determined by the parseFn.
   * This list begins with a lex token of openKind and ends with a lex token of closeKind.
   * Advances the parser to the next lex token after the closing token.
   */
  many(e, r, n) {
    this.expectToken(e);
    const s = [];
    do
      s.push(r.call(this));
    while (!this.expectOptionalToken(n));
    return s;
  }
  /**
   * Returns a non-empty list of parse nodes, determined by the parseFn.
   * This list may begin with a lex token of delimiterKind followed by items separated by lex tokens of tokenKind.
   * Advances the parser to the next lex token after last item in the list.
   */
  delimitedMany(e, r) {
    this.expectOptionalToken(e);
    const n = [];
    do
      n.push(r.call(this));
    while (this.expectOptionalToken(e));
    return n;
  }
  advanceLexer() {
    const { maxTokens: e } = this._options, r = this._lexer.advance();
    if (e !== void 0 && r.kind !== g.EOF && (++this._tokenCounter, this._tokenCounter > e))
      throw ge(
        this._lexer.source,
        r.start,
        `Document contains more that ${e} tokens. Parsing aborted.`
      );
  }
}
function pr(t) {
  const e = t.value;
  return ha(t.kind) + (e != null ? ` "${e}"` : "");
}
function ha(t) {
  return vc(t) ? `"${t}"` : t;
}
var pa = $e(function() {
  return navigator.product;
}) == "ReactNative", op = typeof WeakMap == "function" && !(pa && !Ji.HermesInternal), up = typeof WeakSet == "function", ma = typeof Symbol == "function" && typeof Symbol.for == "function", cp = ma && Symbol.asyncIterator, ya = typeof $e(function() {
  return window.document.createElement;
}) == "function", Uc = (
  // Following advice found in this comment from @domenic (maintainer of jsdom):
  // https://github.com/jsdom/jsdom/issues/1537#issuecomment-229405327
  //
  // Since we control the version of Jest and jsdom used when running Apollo
  // Client tests, and that version is recent enought to include " jsdom/x.y.z"
  // at the end of the user agent string, I believe this case is all we need to
  // check. Testing for "Node.js" was recommended for backwards compatibility
  // with older version of jsdom, but we don't have that problem.
  $e(function() {
    return navigator.userAgent.indexOf("jsdom") >= 0;
  }) || !1
), $c = (ya || pa) && !Uc;
function Dn(t) {
  return t !== null && typeof t == "object";
}
function Wc() {
}
class ri {
  constructor(e = 1 / 0, r = Wc) {
    this.max = e, this.dispose = r, this.map = /* @__PURE__ */ new Map(), this.newest = null, this.oldest = null;
  }
  has(e) {
    return this.map.has(e);
  }
  get(e) {
    const r = this.getNode(e);
    return r && r.value;
  }
  get size() {
    return this.map.size;
  }
  getNode(e) {
    const r = this.map.get(e);
    if (r && r !== this.newest) {
      const { older: n, newer: s } = r;
      s && (s.older = n), n && (n.newer = s), r.older = this.newest, r.older.newer = r, r.newer = null, this.newest = r, r === this.oldest && (this.oldest = s);
    }
    return r;
  }
  set(e, r) {
    let n = this.getNode(e);
    return n ? n.value = r : (n = {
      key: e,
      value: r,
      newer: null,
      older: this.newest
    }, this.newest && (this.newest.newer = n), this.newest = n, this.oldest = this.oldest || n, this.map.set(e, n), n.value);
  }
  clean() {
    for (; this.oldest && this.map.size > this.max; )
      this.delete(this.oldest.key);
  }
  delete(e) {
    const r = this.map.get(e);
    return r ? (r === this.newest && (this.newest = r.older), r === this.oldest && (this.oldest = r.newer), r.newer && (r.newer.older = r.older), r.older && (r.older.newer = r.newer), this.map.delete(e), this.dispose(r.value, e), !0) : !1;
  }
}
function Cn() {
}
const Hc = Cn, jc = typeof WeakRef < "u" ? WeakRef : function(t) {
  return { deref: () => t };
}, zc = typeof WeakMap < "u" ? WeakMap : Map, Yc = typeof FinalizationRegistry < "u" ? FinalizationRegistry : function() {
  return {
    register: Cn,
    unregister: Cn
  };
}, Bc = 10024;
class ni {
  constructor(e = 1 / 0, r = Hc) {
    this.max = e, this.dispose = r, this.map = new zc(), this.newest = null, this.oldest = null, this.unfinalizedNodes = /* @__PURE__ */ new Set(), this.finalizationScheduled = !1, this.size = 0, this.finalize = () => {
      const n = this.unfinalizedNodes.values();
      for (let s = 0; s < Bc; s++) {
        const i = n.next().value;
        if (!i)
          break;
        this.unfinalizedNodes.delete(i);
        const a = i.key;
        delete i.key, i.keyRef = new jc(a), this.registry.register(a, i, i);
      }
      this.unfinalizedNodes.size > 0 ? queueMicrotask(this.finalize) : this.finalizationScheduled = !1;
    }, this.registry = new Yc(this.deleteNode.bind(this));
  }
  has(e) {
    return this.map.has(e);
  }
  get(e) {
    const r = this.getNode(e);
    return r && r.value;
  }
  getNode(e) {
    const r = this.map.get(e);
    if (r && r !== this.newest) {
      const { older: n, newer: s } = r;
      s && (s.older = n), n && (n.newer = s), r.older = this.newest, r.older.newer = r, r.newer = null, this.newest = r, r === this.oldest && (this.oldest = s);
    }
    return r;
  }
  set(e, r) {
    let n = this.getNode(e);
    return n ? n.value = r : (n = {
      key: e,
      value: r,
      newer: null,
      older: this.newest
    }, this.newest && (this.newest.newer = n), this.newest = n, this.oldest = this.oldest || n, this.scheduleFinalization(n), this.map.set(e, n), this.size++, n.value);
  }
  clean() {
    for (; this.oldest && this.size > this.max; )
      this.deleteNode(this.oldest);
  }
  deleteNode(e) {
    e === this.newest && (this.newest = e.older), e === this.oldest && (this.oldest = e.newer), e.newer && (e.newer.older = e.older), e.older && (e.older.newer = e.newer), this.size--;
    const r = e.key || e.keyRef && e.keyRef.deref();
    this.dispose(e.value, r), e.keyRef ? this.registry.unregister(e) : this.unfinalizedNodes.delete(e), r && this.map.delete(r);
  }
  delete(e) {
    const r = this.map.get(e);
    return r ? (this.deleteNode(r), !0) : !1;
  }
  scheduleFinalization(e) {
    this.unfinalizedNodes.add(e), this.finalizationScheduled || (this.finalizationScheduled = !0, queueMicrotask(this.finalize));
  }
}
var un = /* @__PURE__ */ new WeakSet();
function va(t) {
  t.size <= (t.max || -1) || un.has(t) || (un.add(t), setTimeout(function() {
    t.clean(), un.delete(t);
  }, 100));
}
var qc = function(t, e) {
  var r = new ni(t, e);
  return r.set = function(n, s) {
    var i = ni.prototype.set.call(this, n, s);
    return va(this), i;
  }, r;
}, lp = function(t, e) {
  var r = new ri(t, e);
  return r.set = function(n, s) {
    var i = ri.prototype.set.call(this, n, s);
    return va(this), i;
  }, r;
}, Gc = Symbol.for("apollo.cacheSize"), ga = J({}, _n[Gc]), nt = {};
function Zc(t, e) {
  nt[t] = e;
}
var fp = globalThis.__DEV__ !== !1 ? Jc : void 0, dp = globalThis.__DEV__ !== !1 ? Xc : void 0, hp = globalThis.__DEV__ !== !1 ? Ea : void 0;
function Qc() {
  var t = {
    parser: 1e3,
    canonicalStringify: 1e3,
    print: 2e3,
    "documentTransform.cache": 2e3,
    "queryManager.getDocumentInfo": 2e3,
    "PersistedQueryLink.persistedQueryHashes": 2e3,
    "fragmentRegistry.transform": 2e3,
    "fragmentRegistry.lookup": 1e3,
    "fragmentRegistry.findFragmentSpreads": 4e3,
    "cache.fragmentQueryDocuments": 1e3,
    "removeTypenameFromVariables.getVariableDefinitions": 2e3,
    "inMemoryCache.maybeBroadcastWatch": 5e3,
    "inMemoryCache.executeSelectionSet": 5e4,
    "inMemoryCache.executeSubSelectedArray": 1e4
  };
  return Object.fromEntries(Object.entries(t).map(function(e) {
    var r = e[0], n = e[1];
    return [
      r,
      ga[r] || n
    ];
  }));
}
function Jc() {
  var t, e, r, n, s;
  if (globalThis.__DEV__ === !1)
    throw new Error("only supported in development mode");
  return {
    limits: Qc(),
    sizes: J({ print: (t = nt.print) === null || t === void 0 ? void 0 : t.call(nt), parser: (e = nt.parser) === null || e === void 0 ? void 0 : e.call(nt), canonicalStringify: (r = nt.canonicalStringify) === null || r === void 0 ? void 0 : r.call(nt), links: Rn(this.link), queryManager: {
      getDocumentInfo: this.queryManager.transformCache.size,
      documentTransforms: wa(this.queryManager.documentTransform)
    } }, (s = (n = this.cache).getMemoryInternals) === null || s === void 0 ? void 0 : s.call(n))
  };
}
function Ea() {
  return {
    cache: {
      fragmentQueryDocuments: Qe(this.getFragmentDoc)
    }
  };
}
function Xc() {
  var t = this.config.fragments;
  return J(J({}, Ea.apply(this)), { addTypenameDocumentTransform: wa(this.addTypenameTransform), inMemoryCache: {
    executeSelectionSet: Qe(this.storeReader.executeSelectionSet),
    executeSubSelectedArray: Qe(this.storeReader.executeSubSelectedArray),
    maybeBroadcastWatch: Qe(this.maybeBroadcastWatch)
  }, fragmentRegistry: {
    findFragmentSpreads: Qe(t?.findFragmentSpreads),
    lookup: Qe(t?.lookup),
    transform: Qe(t?.transform)
  } });
}
function Kc(t) {
  return !!t && "dirtyKey" in t;
}
function Qe(t) {
  return Kc(t) ? t.size : void 0;
}
function Oa(t) {
  return t != null;
}
function wa(t) {
  return An(t).map(function(e) {
    return { cache: e };
  });
}
function An(t) {
  return t ? Ve(Ve([
    Qe(t?.performWork)
  ], An(t?.left), !0), An(t?.right), !0).filter(Oa) : [];
}
function Rn(t) {
  var e;
  return t ? Ve(Ve([
    (e = t?.getMemoryInternals) === null || e === void 0 ? void 0 : e.call(t)
  ], Rn(t?.left), !0), Rn(t?.right), !0).filter(Oa) : [];
}
var pp = Array.isArray;
function ba(t) {
  return Array.isArray(t) && t.length > 0;
}
function el(t) {
  var e = /* @__PURE__ */ new Set([t]);
  return e.forEach(function(r) {
    Dn(r) && tl(r) === r && Object.getOwnPropertyNames(r).forEach(function(n) {
      Dn(r[n]) && e.add(r[n]);
    });
  }), t;
}
function tl(t) {
  if (globalThis.__DEV__ !== !1 && !Object.isFrozen(t))
    try {
      Object.freeze(t);
    } catch (e) {
      if (e instanceof TypeError)
        return null;
      throw e;
    }
  return t;
}
function Ta(t) {
  return globalThis.__DEV__ !== !1 && el(t), t;
}
function xn() {
  for (var t = [], e = 0; e < arguments.length; e++)
    t[e] = arguments[e];
  var r = /* @__PURE__ */ Object.create(null);
  return t.forEach(function(n) {
    n && Object.keys(n).forEach(function(s) {
      var i = n[s];
      i !== void 0 && (r[s] = i);
    });
  }), r;
}
function kr(t, e) {
  return xn(t, e, e.variables && {
    variables: xn(J(J({}, t && t.variables), e.variables))
  });
}
var rl = Symbol();
function mp(t) {
  return t.extensions ? Array.isArray(t.extensions[rl]) : !1;
}
function yp(t) {
  return t.hasOwnProperty("graphQLErrors");
}
var nl = function(t) {
  var e = Ve(Ve(Ve([], t.graphQLErrors, !0), t.clientErrors, !0), t.protocolErrors, !0);
  return t.networkError && e.push(t.networkError), e.map(function(r) {
    return Dn(r) && r.message || "Error message not found.";
  }).join(`
`);
}, Jn = (
  /** @class */
  function(t) {
    Xi(e, t);
    function e(r) {
      var n = r.graphQLErrors, s = r.protocolErrors, i = r.clientErrors, a = r.networkError, u = r.errorMessage, c = r.extraInfo, l = t.call(this, u) || this;
      return l.name = "ApolloError", l.graphQLErrors = n || [], l.protocolErrors = s || [], l.clientErrors = i || [], l.networkError = a || null, l.message = u || nl(l), l.extraInfo = c, l.cause = Ve(Ve(Ve([
        a
      ], n || [], !0), s || [], !0), i || [], !0).find(function(d) {
        return !!d;
      }) || null, l.__proto__ = e.prototype, l;
    }
    return e;
  }(Error)
);
const { toString: si, hasOwnProperty: sl } = Object.prototype, ii = Function.prototype.toString, Mn = /* @__PURE__ */ new Map();
function jt(t, e) {
  try {
    return Ln(t, e);
  } finally {
    Mn.clear();
  }
}
function Ln(t, e) {
  if (t === e)
    return !0;
  const r = si.call(t), n = si.call(e);
  if (r !== n)
    return !1;
  switch (r) {
    case "[object Array]":
      if (t.length !== e.length)
        return !1;
    case "[object Object]": {
      if (oi(t, e))
        return !0;
      const s = ai(t), i = ai(e), a = s.length;
      if (a !== i.length)
        return !1;
      for (let u = 0; u < a; ++u)
        if (!sl.call(e, s[u]))
          return !1;
      for (let u = 0; u < a; ++u) {
        const c = s[u];
        if (!Ln(t[c], e[c]))
          return !1;
      }
      return !0;
    }
    case "[object Error]":
      return t.name === e.name && t.message === e.message;
    case "[object Number]":
      if (t !== t)
        return e !== e;
    case "[object Boolean]":
    case "[object Date]":
      return +t == +e;
    case "[object RegExp]":
    case "[object String]":
      return t == `${e}`;
    case "[object Map]":
    case "[object Set]": {
      if (t.size !== e.size)
        return !1;
      if (oi(t, e))
        return !0;
      const s = t.entries(), i = r === "[object Map]";
      for (; ; ) {
        const a = s.next();
        if (a.done)
          break;
        const [u, c] = a.value;
        if (!e.has(u) || i && !Ln(c, e.get(u)))
          return !1;
      }
      return !0;
    }
    case "[object Uint16Array]":
    case "[object Uint8Array]":
    case "[object Uint32Array]":
    case "[object Int32Array]":
    case "[object Int8Array]":
    case "[object Int16Array]":
    case "[object ArrayBuffer]":
      t = new Uint8Array(t), e = new Uint8Array(e);
    case "[object DataView]": {
      let s = t.byteLength;
      if (s === e.byteLength)
        for (; s-- && t[s] === e[s]; )
          ;
      return s === -1;
    }
    case "[object AsyncFunction]":
    case "[object GeneratorFunction]":
    case "[object AsyncGeneratorFunction]":
    case "[object Function]": {
      const s = ii.call(t);
      return s !== ii.call(e) ? !1 : !ol(s, al);
    }
  }
  return !1;
}
function ai(t) {
  return Object.keys(t).filter(il, t);
}
function il(t) {
  return this[t] !== void 0;
}
const al = "{ [native code] }";
function ol(t, e) {
  const r = t.length - e.length;
  return r >= 0 && t.indexOf(e, r) === r;
}
function oi(t, e) {
  let r = Mn.get(t);
  if (r) {
    if (r.has(e))
      return !0;
  } else
    Mn.set(t, r = /* @__PURE__ */ new Set());
  return r.add(e), !1;
}
var ut;
(function(t) {
  t[t.loading = 1] = "loading", t[t.setVariables = 2] = "setVariables", t[t.fetchMore = 3] = "fetchMore", t[t.refetch = 4] = "refetch", t[t.poll = 6] = "poll", t[t.ready = 7] = "ready", t[t.error = 8] = "error";
})(ut || (ut = {}));
function vp(t) {
  return t ? t < 7 : !1;
}
var br = /* @__PURE__ */ new Map(), Fn = /* @__PURE__ */ new Map(), Sa = !0, Dr = !1;
function _a(t) {
  return t.replace(/[\s,]+/g, " ").trim();
}
function ul(t) {
  return _a(t.source.body.substring(t.start, t.end));
}
function cl(t) {
  var e = /* @__PURE__ */ new Set(), r = [];
  return t.definitions.forEach(function(n) {
    if (n.kind === "FragmentDefinition") {
      var s = n.name.value, i = ul(n.loc), a = Fn.get(s);
      a && !a.has(i) ? Sa && console.warn("Warning: fragment with name " + s + ` already exists.
graphql-tag enforces all fragment names across your application to be unique; read more about
this in the docs: http://dev.apollodata.com/core/fragments.html#unique-names`) : a || Fn.set(s, a = /* @__PURE__ */ new Set()), a.add(i), e.has(i) || (e.add(i), r.push(n));
    } else
      r.push(n);
  }), J(J({}, t), { definitions: r });
}
function ll(t) {
  var e = new Set(t.definitions);
  e.forEach(function(n) {
    n.loc && delete n.loc, Object.keys(n).forEach(function(s) {
      var i = n[s];
      i && typeof i == "object" && e.add(i);
    });
  });
  var r = t.loc;
  return r && (delete r.startToken, delete r.endToken), t;
}
function fl(t) {
  var e = _a(t);
  if (!br.has(e)) {
    var r = Pc(t, {
      experimentalFragmentVariables: Dr,
      allowLegacyFragmentVariables: Dr
    });
    if (!r || r.kind !== "Document")
      throw new Error("Not a valid GraphQL document.");
    br.set(e, ll(cl(r)));
  }
  return br.get(e);
}
function ye(t) {
  for (var e = [], r = 1; r < arguments.length; r++)
    e[r - 1] = arguments[r];
  typeof t == "string" && (t = [t]);
  var n = t[0];
  return e.forEach(function(s, i) {
    s && s.kind === "Document" ? n += s.loc.source.body : n += s, n += t[i + 1];
  }), fl(n);
}
function dl() {
  br.clear(), Fn.clear();
}
function hl() {
  Sa = !1;
}
function pl() {
  Dr = !0;
}
function ml() {
  Dr = !1;
}
var Mt = {
  gql: ye,
  resetCaches: dl,
  disableFragmentWarnings: hl,
  enableExperimentalFragmentVariables: pl,
  disableExperimentalFragmentVariables: ml
};
(function(t) {
  t.gql = Mt.gql, t.resetCaches = Mt.resetCaches, t.disableFragmentWarnings = Mt.disableFragmentWarnings, t.enableExperimentalFragmentVariables = Mt.enableExperimentalFragmentVariables, t.disableExperimentalFragmentVariables = Mt.disableExperimentalFragmentVariables;
})(ye || (ye = {}));
ye.default = ye;
var Ia = { exports: {} };
(function(t) {
  t.exports.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = void 0, t.exports.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = void 0, t.exports.__SERVER_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = void 0, Object.assign(t.exports, qn);
})(Ia);
var Z = Ia.exports;
const yl = /* @__PURE__ */ Qi(Z), Na = /* @__PURE__ */ Zi({
  __proto__: null,
  default: yl
}, [Z]);
var ui = ma ? Symbol.for("__APOLLO_CONTEXT__") : "__APOLLO_CONTEXT__";
function ka() {
  We("createContext" in Na, 46);
  var t = Z.createContext[ui];
  return t || (Object.defineProperty(Z.createContext, ui, {
    value: t = Z.createContext({}),
    enumerable: !1,
    writable: !1,
    configurable: !0
  }), t.displayName = "ApolloContext"), t;
}
function Xn(t) {
  var e = Z.useContext(ka()), r = t || e.client;
  return We(!!r, 50), r;
}
var ci = !1, vl = "useSyncExternalStore", gl = Na[vl], El = gl || function(t, e, r) {
  var n = e();
  // DEVIATION: Using __DEV__
  globalThis.__DEV__ !== !1 && !ci && // DEVIATION: Not using Object.is because we know our snapshots will never
  // be exotic primitive values like NaN, which is !== itself.
  n !== e() && (ci = !0, globalThis.__DEV__ !== !1 && We.error(60));
  var s = Z.useState({
    inst: { value: n, getSnapshot: e }
  }), i = s[0].inst, a = s[1];
  return $c ? Z.useLayoutEffect(function() {
    Object.assign(i, { value: n, getSnapshot: e }), cn(i) && a({ inst: i });
  }, [t, n, e]) : Object.assign(i, { value: n, getSnapshot: e }), Z.useEffect(function() {
    return cn(i) && a({ inst: i }), t(function() {
      cn(i) && a({ inst: i });
    });
  }, [t]), n;
};
function cn(t) {
  var e = t.value, r = t.getSnapshot;
  try {
    return e !== r();
  } catch {
    return !0;
  }
}
var Ue;
(function(t) {
  t[t.Query = 0] = "Query", t[t.Mutation = 1] = "Mutation", t[t.Subscription = 2] = "Subscription";
})(Ue || (Ue = {}));
var it;
function li(t) {
  var e;
  switch (t) {
    case Ue.Query:
      e = "Query";
      break;
    case Ue.Mutation:
      e = "Mutation";
      break;
    case Ue.Subscription:
      e = "Subscription";
      break;
  }
  return e;
}
function Da(t) {
  it || (it = new qc(
    ga.parser || 1e3
    /* defaultCacheSizes.parser */
  ));
  var e = it.get(t);
  if (e)
    return e;
  var r, n, s;
  We(!!t && !!t.kind, 62, t);
  for (var i = [], a = [], u = [], c = [], l = 0, d = t.definitions; l < d.length; l++) {
    var v = d[l];
    if (v.kind === "FragmentDefinition") {
      i.push(v);
      continue;
    }
    if (v.kind === "OperationDefinition")
      switch (v.operation) {
        case "query":
          a.push(v);
          break;
        case "mutation":
          u.push(v);
          break;
        case "subscription":
          c.push(v);
          break;
      }
  }
  We(!i.length || a.length || u.length || c.length, 63), We(
    a.length + u.length + c.length <= 1,
    64,
    t,
    a.length,
    c.length,
    u.length
  ), n = a.length ? Ue.Query : Ue.Mutation, !a.length && !u.length && (n = Ue.Subscription);
  var T = a.length ? a : u.length ? u : c;
  We(T.length === 1, 65, t, T.length);
  var O = T[0];
  r = O.variableDefinitions || [], O.name && O.name.kind === "Name" ? s = O.name.value : s = "data";
  var I = { name: s, type: n, variables: r };
  return it.set(t, I), I;
}
Da.resetCache = function() {
  it = void 0;
};
globalThis.__DEV__ !== !1 && Zc("parser", function() {
  return it ? it.size : 0;
});
function Ca(t, e) {
  var r = Da(t), n = li(e), s = li(r.type);
  We(
    r.type === e,
    66,
    n,
    n,
    s
  );
}
var Aa = ya ? Z.useLayoutEffect : Z.useEffect, Ol = Symbol.for("apollo.hook.wrappers");
function wl(t, e, r) {
  var n = r.queryManager, s = n && n[Ol], i = s && s[t];
  return i ? i(e) : e;
}
var bl = Object.prototype.hasOwnProperty;
function fi() {
}
var Tr = Symbol();
function qt(t, e) {
  return e === void 0 && (e = /* @__PURE__ */ Object.create(null)), wl("useQuery", Tl, Xn(e && e.client))(t, e);
}
function Tl(t, e) {
  var r = Ra(t, e), n = r.result, s = r.obsQueryFields;
  return Z.useMemo(function() {
    return J(J({}, n), s);
  }, [n, s]);
}
function Sl(t, e, r, n, s) {
  function i(v) {
    var T;
    Ca(e, Ue.Query);
    var O = {
      client: t,
      query: e,
      observable: (
        // See if there is an existing observable that was used to fetch the same
        // data and if so, use it instead since it will contain the proper queryId
        // to fetch the result set. This is used during SSR.
        n && n.getSSRObservable(s()) || t.watchQuery(Kn(void 0, t, r, s()))
      ),
      resultData: {
        // Reuse previousData from previous InternalState (if any) to provide
        // continuity of previousData even if/when the query or client changes.
        previousData: (T = v?.resultData.current) === null || T === void 0 ? void 0 : T.data
      }
    };
    return O;
  }
  var a = Z.useState(i), u = a[0], c = a[1];
  function l(v) {
    var T, O;
    Object.assign(u.observable, (T = {}, T[Tr] = v, T));
    var I = u.resultData;
    c(J(J({}, u), {
      // might be a different query
      query: v.query,
      resultData: Object.assign(I, {
        // We need to modify the previous `resultData` object as we rely on the
        // object reference in other places
        previousData: ((O = I.current) === null || O === void 0 ? void 0 : O.data) || I.previousData,
        current: void 0
      })
    }));
  }
  if (t !== u.client || e !== u.query) {
    var d = i(u);
    return c(d), [d, l];
  }
  return [u, l];
}
function Ra(t, e) {
  var r = Xn(e.client), n = Z.useContext(ka()).renderPromises, s = !!n, i = r.disableNetworkFetches, a = e.ssr !== !1 && !e.skip, u = e.partialRefetch, c = xa(r, t, e, s), l = Sl(r, t, e, n, c), d = l[0], v = d.observable, T = d.resultData, O = l[1], I = c(v);
  Nl(
    T,
    // might get mutated during render
    v,
    // might get mutated during render
    r,
    e,
    I
  );
  var _ = Z.useMemo(function() {
    return Al(v);
  }, [v]);
  Il(v, n, a);
  var E = _l(T, v, r, e, I, i, u, s, {
    onCompleted: e.onCompleted || fi,
    onError: e.onError || fi
  });
  return {
    result: E,
    obsQueryFields: _,
    observable: v,
    resultData: T,
    client: r,
    onQueryExecuted: O
  };
}
function _l(t, e, r, n, s, i, a, u, c) {
  var l = Z.useRef(c);
  Z.useEffect(function() {
    l.current = c;
  });
  var d = (u || i) && n.ssr === !1 && !n.skip ? (
    // If SSR has been explicitly disabled, and this function has been called
    // on the server side, return the default loading state.
    Ma
  ) : n.skip || s.fetchPolicy === "standby" ? (
    // When skipping a query (ie. we're not querying for data but still want to
    // render children), make sure the `data` is cleared out and `loading` is
    // set to `false` (since we aren't loading anything).
    //
    // NOTE: We no longer think this is the correct behavior. Skipping should
    // not automatically set `data` to `undefined`, but instead leave the
    // previous data in place. In other words, skipping should not mandate that
    // previously received data is all of a sudden removed. Unfortunately,
    // changing this is breaking, so we'll have to wait until Apollo Client 4.0
    // to address this.
    La
  ) : void 0, v = t.previousData, T = Z.useMemo(function() {
    return d && Cr(d, v, e, r);
  }, [r, e, d, v]);
  return El(Z.useCallback(function(O) {
    if (u)
      return function() {
      };
    var I = function() {
      var y = t.current, b = e.getCurrentResult();
      y && y.loading === b.loading && y.networkStatus === b.networkStatus && jt(y.data, b.data) || Pn(b, t, e, r, a, O, l.current);
    }, _ = function(y) {
      if (E.current.unsubscribe(), E.current = e.resubscribeAfterError(I, _), !bl.call(y, "graphQLErrors"))
        throw y;
      var b = t.current;
      (!b || b && b.loading || !jt(y, b.error)) && Pn({
        data: b && b.data,
        error: y,
        loading: !1,
        networkStatus: ut.error
      }, t, e, r, a, O, l.current);
    }, E = { current: e.subscribe(I, _) };
    return function() {
      setTimeout(function() {
        return E.current.unsubscribe();
      });
    };
  }, [
    i,
    u,
    e,
    t,
    a,
    r
  ]), function() {
    return T || di(t, e, l.current, a, r);
  }, function() {
    return T || di(t, e, l.current, a, r);
  });
}
function Il(t, e, r) {
  e && r && (e.registerSSRObservable(t), t.getCurrentResult().loading && e.addObservableQueryPromise(t));
}
function Nl(t, e, r, n, s) {
  var i;
  e[Tr] && !jt(e[Tr], s) && (e.reobserve(Kn(e, r, n, s)), t.previousData = ((i = t.current) === null || i === void 0 ? void 0 : i.data) || t.previousData, t.current = void 0), e[Tr] = s;
}
function xa(t, e, r, n) {
  r === void 0 && (r = {});
  var s = r.skip;
  r.ssr, r.onCompleted, r.onError;
  var i = r.defaultOptions, a = Ki(r, ["skip", "ssr", "onCompleted", "onError", "defaultOptions"]);
  return function(u) {
    var c = Object.assign(a, { query: e });
    return n && (c.fetchPolicy === "network-only" || c.fetchPolicy === "cache-and-network") && (c.fetchPolicy = "cache-first"), c.variables || (c.variables = {}), s ? (c.initialFetchPolicy = c.initialFetchPolicy || c.fetchPolicy || Vn(i, t.defaultOptions), c.fetchPolicy = "standby") : c.fetchPolicy || (c.fetchPolicy = u?.options.initialFetchPolicy || Vn(i, t.defaultOptions)), c;
  };
}
function Kn(t, e, r, n) {
  var s = [], i = e.defaultOptions.watchQuery;
  return i && s.push(i), r.defaultOptions && s.push(r.defaultOptions), s.push(xn(t && t.options, n)), s.reduce(kr);
}
function Pn(t, e, r, n, s, i, a) {
  var u = e.current;
  u && u.data && (e.previousData = u.data), !t.error && ba(t.errors) && (t.error = new Jn({ graphQLErrors: t.errors })), e.current = Cr(Cl(t, r, s), e.previousData, r, n), i(), kl(t, u?.networkStatus, a);
}
function kl(t, e, r) {
  if (!t.loading) {
    var n = Dl(t);
    Promise.resolve().then(function() {
      n ? r.onError(n) : t.data && e !== t.networkStatus && t.networkStatus === ut.ready && r.onCompleted(t.data);
    }).catch(function(s) {
      globalThis.__DEV__ !== !1 && We.warn(s);
    });
  }
}
function di(t, e, r, n, s) {
  return t.current || Pn(e.getCurrentResult(), t, e, s, n, function() {
  }, r), t.current;
}
function Vn(t, e) {
  var r;
  return t?.fetchPolicy || ((r = e?.watchQuery) === null || r === void 0 ? void 0 : r.fetchPolicy) || "cache-first";
}
function Dl(t) {
  return ba(t.errors) ? new Jn({ graphQLErrors: t.errors }) : t.error;
}
function Cr(t, e, r, n) {
  var s = t.data;
  t.partial;
  var i = Ki(t, ["data", "partial"]), a = J(J({ data: s }, i), { client: n, observable: r, variables: r.variables, called: t !== Ma && t !== La, previousData: e });
  return a;
}
function Cl(t, e, r) {
  return t.partial && r && !t.loading && (!t.data || Object.keys(t.data).length === 0) && e.options.fetchPolicy !== "cache-only" ? (e.refetch(), J(J({}, t), { loading: !0, networkStatus: ut.refetch })) : t;
}
var Ma = Ta({
  loading: !0,
  data: void 0,
  error: void 0,
  networkStatus: ut.loading
}), La = Ta({
  loading: !1,
  data: void 0,
  error: void 0,
  networkStatus: ut.ready
});
function Al(t) {
  return {
    refetch: t.refetch.bind(t),
    reobserve: t.reobserve.bind(t),
    fetchMore: t.fetchMore.bind(t),
    updateQuery: t.updateQuery.bind(t),
    startPolling: t.startPolling.bind(t),
    stopPolling: t.stopPolling.bind(t),
    subscribeToMore: t.subscribeToMore.bind(t)
  };
}
var Rl = [
  "refetch",
  "reobserve",
  "fetchMore",
  "updateQuery",
  "startPolling",
  "stopPolling",
  "subscribeToMore"
];
function es(t, e) {
  var r, n = Z.useRef(), s = Z.useRef(), i = Z.useRef(), a = kr(e, n.current || {}), u = (r = a?.query) !== null && r !== void 0 ? r : t;
  s.current = e, i.current = u;
  var c = J(J({}, a), { skip: !n.current }), l = Ra(u, c), d = l.obsQueryFields, v = l.result, T = l.client, O = l.resultData, I = l.observable, _ = l.onQueryExecuted, E = I.options.initialFetchPolicy || Vn(c.defaultOptions, T.defaultOptions), y = Z.useReducer(function(V) {
    return V + 1;
  }, 0)[1], b = Z.useMemo(function() {
    for (var V = {}, C = function(ze) {
      var Ye = d[ze];
      V[ze] = function() {
        return n.current || (n.current = /* @__PURE__ */ Object.create(null), y()), Ye.apply(this, arguments);
      };
    }, q = 0, te = Rl; q < te.length; q++) {
      var je = te[q];
      C(je);
    }
    return V;
  }, [y, d]), A = !!n.current, R = Z.useMemo(function() {
    return J(J(J({}, v), b), { called: A });
  }, [v, b, A]), $ = Z.useCallback(function(V) {
    n.current = V ? J(J({}, V), { fetchPolicy: V.fetchPolicy || E }) : {
      fetchPolicy: E
    };
    var C = kr(s.current, J({ query: i.current }, n.current)), q = xl(O, I, T, u, J(J({}, C), { skip: !1 }), _).then(function(te) {
      return Object.assign(te, b);
    });
    return q.catch(function() {
    }), q;
  }, [
    T,
    u,
    b,
    E,
    I,
    O,
    _
  ]), D = Z.useRef($);
  Aa(function() {
    D.current = $;
  });
  var j = Z.useCallback(function() {
    for (var V = [], C = 0; C < arguments.length; C++)
      V[C] = arguments[C];
    return D.current.apply(D, V);
  }, []);
  return [j, R];
}
function xl(t, e, r, n, s, i) {
  var a = s.query || n, u = xa(r, a, s, !1)(e), c = e.reobserveAsConcast(Kn(e, r, s, u));
  return i(u), new Promise(function(l) {
    var d;
    c.subscribe({
      next: function(v) {
        d = v;
      },
      error: function() {
        l(Cr(e.getCurrentResult(), t.previousData, e, r));
      },
      complete: function() {
        l(Cr(d, t.previousData, e, r));
      }
    });
  });
}
function ct(t, e) {
  var r = Xn(e?.client);
  Ca(t, Ue.Mutation);
  var n = Z.useState({
    called: !1,
    loading: !1,
    client: r
  }), s = n[0], i = n[1], a = Z.useRef({
    result: s,
    mutationId: 0,
    isMounted: !0,
    client: r,
    mutation: t,
    options: e
  });
  Aa(function() {
    Object.assign(a.current, { client: r, options: e, mutation: t });
  });
  var u = Z.useCallback(function(l) {
    l === void 0 && (l = {});
    var d = a.current, v = d.options, T = d.mutation, O = J(J({}, v), { mutation: T }), I = l.client || a.current.client;
    !a.current.result.loading && !O.ignoreResults && a.current.isMounted && i(a.current.result = {
      loading: !0,
      error: void 0,
      data: void 0,
      called: !0,
      client: I
    });
    var _ = ++a.current.mutationId, E = kr(O, l);
    return I.mutate(E).then(function(y) {
      var b, A, R = y.data, $ = y.errors, D = $ && $.length > 0 ? new Jn({ graphQLErrors: $ }) : void 0, j = l.onError || ((b = a.current.options) === null || b === void 0 ? void 0 : b.onError);
      if (D && j && j(D, E), _ === a.current.mutationId && !E.ignoreResults) {
        var V = {
          called: !0,
          loading: !1,
          data: R,
          error: D,
          client: I
        };
        a.current.isMounted && !jt(a.current.result, V) && i(a.current.result = V);
      }
      var C = l.onCompleted || ((A = a.current.options) === null || A === void 0 ? void 0 : A.onCompleted);
      return D || C?.(y.data, E), y;
    }).catch(function(y) {
      var b;
      if (_ === a.current.mutationId && a.current.isMounted) {
        var A = {
          loading: !1,
          error: y,
          data: void 0,
          called: !0,
          client: I
        };
        jt(a.current.result, A) || i(a.current.result = A);
      }
      var R = l.onError || ((b = a.current.options) === null || b === void 0 ? void 0 : b.onError);
      if (R)
        return R(y, E), { data: void 0, errors: y };
      throw y;
    });
  }, []), c = Z.useCallback(function() {
    if (a.current.isMounted) {
      var l = {
        called: !1,
        loading: !1,
        client: a.current.client
      };
      Object.assign(a.current, { mutationId: 0, result: l }), i(l);
    }
  }, []);
  return Z.useEffect(function() {
    var l = a.current;
    return l.isMounted = !0, function() {
      l.isMounted = !1;
    };
  }, []), [u, J({ reset: c }, s)];
}
const Ne = {};
var _e = /* @__PURE__ */ ((t) => (t.OneShot = "ONE_SHOT", t.DailyOrMore_1d = "DAILY_OR_MORE_1d", t.DailyOrMore_2d = "DAILY_OR_MORE_2d", t.DailyOrMore_3d = "DAILY_OR_MORE_3d", t.DailyOrMore_4d = "DAILY_OR_MORE_4d", t.DailyOrMore_5d = "DAILY_OR_MORE_5d", t.DailyOrMore_6d = "DAILY_OR_MORE_6d", t.DailyOrMore_7d = "DAILY_OR_MORE_7d", t.DailyOrMore_8d = "DAILY_OR_MORE_8d", t.DailyOrMore_9d = "DAILY_OR_MORE_9d", t.DailyOrMore_10d = "DAILY_OR_MORE_10d", t.LessThanDaily_1w = "LESS_THAN_DAILY_1w", t.LessThanDaily_1m = "LESS_THAN_DAILY_1m", t.LessThanDaily_1q = "LESS_THAN_DAILY_1q", t))(_e || {}), Ml = /* @__PURE__ */ ((t) => (t.Astro = "Astro", t.Sub = "Sub", t.Atom = "Atom", t))(Ml || {});
const Ll = ye`
    mutation createOrbit($variables: OrbitCreateParams!) {
  createOrbit(orbit: $variables) {
    id
    eH
    name
    parentHash
    sphereHash
    scale
    frequency
    metadata {
      description
      timeframe {
        startTime
        endTime
      }
    }
  }
}
    `;
function gp(t) {
  const e = { ...Ne, ...t };
  return ct(Ll, e);
}
const Fl = ye`
    mutation deleteOrbit($id: ID!) {
  deleteOrbit(orbitHash: $id)
}
    `;
function Ep(t) {
  const e = { ...Ne, ...t };
  return ct(Fl, e);
}
const Pl = ye`
    mutation updateOrbit($orbitFields: OrbitUpdateParams!) {
  updateOrbit(orbit: $orbitFields) {
    id
    eH
    name
    parentHash
    sphereHash
    scale
    frequency
    metadata {
      description
      timeframe {
        startTime
        endTime
      }
    }
  }
}
    `;
function Op(t) {
  const e = { ...Ne, ...t };
  return ct(Pl, e);
}
const Vl = ye`
    mutation createSphere($variables: SphereCreateParams!) {
  createSphere(sphere: $variables) {
    actionHash
    entryHash
    name
  }
}
    `;
function wp(t) {
  const e = { ...Ne, ...t };
  return ct(Vl, e);
}
const Ul = ye`
    mutation updateSphere($sphere: SphereUpdateParams!) {
  updateSphere(sphere: $sphere) {
    actionHash
    entryHash
  }
}
    `;
function bp(t) {
  const e = { ...Ne, ...t };
  return ct(Ul, e);
}
const $l = ye`
    mutation deleteSphere($id: ID!) {
  deleteSphere(sphereHash: $id)
}
    `;
function Tp(t) {
  const e = { ...Ne, ...t };
  return ct($l, e);
}
const Wl = ye`
    mutation createWinRecord($winRecord: WinRecordCreateParams!) {
  createWinRecord(winRecord: $winRecord) {
    id
    eH
    winData {
      date
      value {
        ... on SingleWin {
          single
        }
        ... on MultipleWins {
          multiple
        }
      }
    }
  }
}
    `;
function Sp(t) {
  const e = { ...Ne, ...t };
  return ct(Wl, e);
}
const Hl = ye`
    query getOrbit($id: ID!) {
  orbit(id: $id) {
    id
    eH
    name
    sphereHash
    frequency
    scale
    parentHash
    metadata {
      description
      timeframe {
        startTime
        endTime
      }
    }
  }
}
    `;
function _p(t) {
  const e = { ...Ne, ...t };
  return qt(Hl, e);
}
ye`
    mutation updateWinRecord($winRecord: WinRecordUpdateParams!) {
  updateWinRecord(winRecord: $winRecord) {
    id
    eH
    orbitId
    winData {
      date
      value {
        ... on SingleWin {
          single
        }
        ... on MultipleWins {
          multiple
        }
      }
    }
  }
}
    `;
const jl = ye`
    query getOrbitHierarchy($params: OrbitHierarchyQueryParams!) {
  getOrbitHierarchy(params: $params)
}
    `;
function Ip(t) {
  const e = { ...Ne, ...t };
  return es(jl, e);
}
const Fa = ye`
    query getOrbits($sphereEntryHashB64: String) {
  orbits(sphereEntryHashB64: $sphereEntryHashB64) {
    edges {
      node {
        id
        eH
        name
        sphereHash
        parentHash
        frequency
        scale
        metadata {
          description
          timeframe {
            startTime
            endTime
          }
        }
      }
    }
  }
}
    `;
function Np(t) {
  const e = { ...Ne, ...t };
  return qt(Fa, e);
}
function kp(t) {
  const e = { ...Ne, ...t };
  return es(Fa, e);
}
const zl = ye`
    query getLowestSphereHierarchyLevel($sphereEntryHashB64: String!) {
  getLowestSphereHierarchyLevel(sphereEntryHashB64: $sphereEntryHashB64)
}
    `;
function Dp(t) {
  const e = { ...Ne, ...t };
  return qt(zl, e);
}
const Yl = ye`
    query getSphere($id: ID!) {
  sphere(id: $id) {
    id
    eH
    name
    metadata {
      description
      image
    }
  }
}
    `;
function Cp(t) {
  const e = { ...Ne, ...t };
  return qt(Yl, e);
}
const Bl = ye`
    query getSpheres {
  spheres {
    edges {
      node {
        id
        eH
        name
        metadata {
          description
          image
        }
      }
    }
  }
}
    `;
function Ap(t) {
  const e = { ...Ne, ...t };
  return qt(Bl, e);
}
const ql = ye`
    query getWinRecordForOrbitForMonth($params: OrbitWinRecordQueryParams!) {
  getWinRecordForOrbitForMonth(params: $params) {
    id
    eH
    winData {
      date
      value {
        ... on SingleWin {
          single
        }
        ... on MultipleWins {
          multiple
        }
      }
    }
  }
}
    `;
function Rp(t) {
  const e = { ...Ne, ...t };
  return es(ql, e);
}
const Le = { BASE_URL: "/", DEV: !1, MODE: "production", PROD: !0, SSR: !1, VITE_ADMIN_PORT: "9001", VITE_APP_PORT: "9000", VITE_UI_PORT: "8888" };
let Gl = 0;
function M(t, e) {
  const r = `atom${++Gl}`, n = {
    toString() {
      return (Le ? "production" : void 0) !== "production" && this.debugLabel ? r + ":" + this.debugLabel : r;
    }
  };
  return typeof t == "function" ? n.read = t : (n.init = t, n.read = Zl, n.write = Ql), e && (n.write = e), n;
}
function Zl(t) {
  return t(this);
}
function Ql(t, e, r) {
  return e(
    this,
    typeof r == "function" ? r(t(this)) : r
  );
}
const hi = (t, e) => t.unstable_is ? t.unstable_is(e) : e === t, ln = (t) => "init" in t, fn = (t) => !!t.write, Ar = /* @__PURE__ */ new WeakMap(), Un = (t) => {
  var e;
  return $n(t) && !((e = Ar.get(t)) != null && e[1]);
}, Jl = (t, e) => {
  const r = Ar.get(t);
  if (r)
    r[1] = !0, r[0].forEach((n) => n(e));
  else if ((Le ? "production" : void 0) !== "production")
    throw new Error("[Bug] cancelable promise not found");
}, Xl = (t) => {
  if (Ar.has(t))
    return;
  const e = [/* @__PURE__ */ new Set(), !1];
  Ar.set(t, e);
  const r = () => {
    e[1] = !0;
  };
  t.then(r, r), t.onCancel = (n) => {
    e[0].add(n);
  };
}, $n = (t) => typeof t?.then == "function", pi = (t) => "v" in t || "e" in t, mr = (t) => {
  if ("e" in t)
    throw t.e;
  if ((Le ? "production" : void 0) !== "production" && !("v" in t))
    throw new Error("[Bug] atom state is not initialized");
  return t.v;
}, Pa = (t, e, r) => {
  r.p.has(t) || (r.p.add(t), e.then(
    () => {
      r.p.delete(t);
    },
    () => {
      r.p.delete(t);
    }
  ));
}, mi = (t, e, r, n, s) => {
  var i;
  if ((Le ? "production" : void 0) !== "production" && n === e)
    throw new Error("[Bug] atom cannot depend on itself");
  r.d.set(n, s.n), Un(r.v) && Pa(e, r.v, s), (i = s.m) == null || i.t.add(e), t && Kl(t, n, e);
}, mt = () => [/* @__PURE__ */ new Map(), /* @__PURE__ */ new Map(), /* @__PURE__ */ new Set()], dn = (t, e, r) => {
  t[0].has(e) || t[0].set(e, /* @__PURE__ */ new Set()), t[1].set(e, r);
}, Kl = (t, e, r) => {
  const n = t[0].get(e);
  n && n.add(r);
}, ef = (t, e) => t[0].get(e), yi = (t, e) => {
  t[2].add(e);
}, et = (t) => {
  for (; t[1].size || t[2].size; ) {
    t[0].clear();
    const e = new Set(t[1].values());
    t[1].clear();
    const r = new Set(t[2]);
    t[2].clear(), e.forEach((n) => {
      var s;
      return (s = n.m) == null ? void 0 : s.l.forEach((i) => i());
    }), r.forEach((n) => n());
  }
}, Va = (t) => {
  let e;
  (Le ? "production" : void 0) !== "production" && (e = /* @__PURE__ */ new Set());
  const r = (_, E, y) => {
    const b = "v" in E, A = E.v, R = Un(E.v) ? E.v : null;
    if ($n(y)) {
      Xl(y);
      for (const $ of E.d.keys())
        Pa(
          _,
          y,
          t($, E)
        );
      E.v = y, delete E.e;
    } else
      E.v = y, delete E.e;
    (!b || !Object.is(A, E.v)) && (++E.n, R && Jl(R, y));
  }, n = (_, E, y, b) => {
    var A;
    if (pi(y) && (y.m && !b?.has(E) || Array.from(y.d).every(
      ([C, q]) => (
        // Recursively, read the atom state of the dependency, and
        // check if the atom epoch number is unchanged
        n(_, C, t(C, y), b).n === q
      )
    )))
      return y;
    y.d.clear();
    let R = !0;
    const $ = (C) => {
      if (hi(E, C)) {
        const te = t(C, y);
        if (!pi(te))
          if (ln(C))
            r(C, te, C.init);
          else
            throw new Error("no atom init");
        return mr(te);
      }
      const q = n(
        _,
        C,
        t(C, y),
        b
      );
      if (R)
        mi(_, E, y, C, q);
      else {
        const te = mt();
        mi(te, E, y, C, q), l(te, E, y), et(te);
      }
      return mr(q);
    };
    let D, j;
    const V = {
      get signal() {
        return D || (D = new AbortController()), D.signal;
      },
      get setSelf() {
        return (Le ? "production" : void 0) !== "production" && !fn(E) && console.warn("setSelf function cannot be used with read-only atom"), !j && fn(E) && (j = (...C) => {
          if ((Le ? "production" : void 0) !== "production" && R && console.warn("setSelf function cannot be called in sync"), !R)
            return c(E, ...C);
        }), j;
      }
    };
    try {
      const C = E.read($, V);
      if (r(E, y, C), $n(C)) {
        (A = C.onCancel) == null || A.call(C, () => D?.abort());
        const q = () => {
          if (y.m) {
            const te = mt();
            l(te, E, y), et(te);
          }
        };
        C.then(q, q);
      }
      return y;
    } catch (C) {
      return delete y.v, y.e = C, ++y.n, y;
    } finally {
      R = !1;
    }
  }, s = (_) => mr(n(void 0, _, t(_))), i = (_, E, y) => {
    var b, A;
    const R = /* @__PURE__ */ new Map();
    for (const $ of ((b = y.m) == null ? void 0 : b.t) || [])
      R.set($, t($, y));
    for (const $ of y.p)
      R.set(
        $,
        t($, y)
      );
    return (A = ef(_, E)) == null || A.forEach(($) => {
      R.set($, t($, y));
    }), R;
  }, a = (_, E, y) => {
    const b = [], A = /* @__PURE__ */ new Set(), R = (D, j) => {
      if (!A.has(D)) {
        A.add(D);
        for (const [V, C] of i(_, D, j))
          D !== V && R(V, C);
        b.push([D, j, j.n]);
      }
    };
    R(E, y);
    const $ = /* @__PURE__ */ new Set([E]);
    for (let D = b.length - 1; D >= 0; --D) {
      const [j, V, C] = b[D];
      let q = !1;
      for (const te of V.d.keys())
        if (te !== j && $.has(te)) {
          q = !0;
          break;
        }
      q && (n(_, j, V, A), l(_, j, V), C !== V.n && (dn(_, j, V), $.add(j))), A.delete(j);
    }
  }, u = (_, E, y, ...b) => {
    const A = (D) => mr(n(_, D, t(D, y))), R = (D, ...j) => {
      const V = t(D, y);
      let C;
      if (hi(E, D)) {
        if (!ln(D))
          throw new Error("atom not writable");
        const q = "v" in V, te = V.v, je = j[0];
        r(D, V, je), l(_, D, V), (!q || !Object.is(te, V.v)) && (dn(_, D, V), a(_, D, V));
      } else
        C = u(_, D, V, ...j);
      return et(_), C;
    };
    return E.write(A, R, ...b);
  }, c = (_, ...E) => {
    const y = mt(), b = u(y, _, t(_), ...E);
    return et(y), b;
  }, l = (_, E, y) => {
    if (y.m && !Un(y.v)) {
      for (const b of y.d.keys())
        y.m.d.has(b) || (d(_, b, t(b, y)).t.add(E), y.m.d.add(b));
      for (const b of y.m.d || [])
        if (!y.d.has(b)) {
          y.m.d.delete(b);
          const A = v(_, b, t(b, y));
          A?.t.delete(E);
        }
    }
  }, d = (_, E, y) => {
    if (!y.m) {
      n(_, E, y);
      for (const b of y.d.keys())
        d(_, b, t(b, y)).t.add(E);
      if (y.m = {
        l: /* @__PURE__ */ new Set(),
        d: new Set(y.d.keys()),
        t: /* @__PURE__ */ new Set()
      }, (Le ? "production" : void 0) !== "production" && e.add(E), fn(E) && E.onMount) {
        const b = y.m, { onMount: A } = E;
        yi(_, () => {
          const R = A(
            (...$) => u(_, E, y, ...$)
          );
          R && (b.u = R);
        });
      }
    }
    return y.m;
  }, v = (_, E, y) => {
    if (y.m && !y.m.l.size && !Array.from(y.m.t).some(
      (b) => {
        var A;
        return (A = t(b, y).m) == null ? void 0 : A.d.has(E);
      }
    )) {
      const b = y.m.u;
      b && yi(_, b), delete y.m, (Le ? "production" : void 0) !== "production" && e.delete(E);
      for (const A of y.d.keys()) {
        const R = v(_, A, t(A, y));
        R?.t.delete(E);
      }
      return;
    }
    return y.m;
  }, I = {
    get: s,
    set: c,
    sub: (_, E) => {
      const y = mt(), b = t(_), A = d(y, _, b);
      et(y);
      const R = A.l;
      return R.add(E), () => {
        R.delete(E);
        const $ = mt();
        v($, _, b), et($);
      };
    },
    unstable_derive: (_) => Va(..._(t))
  };
  return (Le ? "production" : void 0) !== "production" && Object.assign(I, {
    // store dev methods (these are tentative and subject to change without notice)
    dev4_get_internal_weak_map: () => ({
      get: (E) => {
        const y = t(E);
        if (y.n !== 0)
          return y;
      }
    }),
    dev4_get_mounted_atoms: () => e,
    dev4_restore_atoms: (E) => {
      const y = mt();
      for (const [b, A] of E)
        if (ln(b)) {
          const R = t(b), $ = "v" in R, D = R.v;
          r(b, R, A), l(y, b, R), (!$ || !Object.is(D, R.v)) && (dn(y, b, R), a(y, b, R));
        }
      et(y);
    }
  }), I;
}, Ua = () => {
  const t = /* @__PURE__ */ new WeakMap();
  return Va((r) => {
    let n = t.get(r);
    return n || (n = { d: /* @__PURE__ */ new Map(), p: /* @__PURE__ */ new Set(), n: 0 }, t.set(r, n)), n;
  });
};
let Lt;
const xp = () => (Lt || (Lt = Ua(), (Le ? "production" : void 0) !== "production" && (globalThis.__JOTAI_DEFAULT_STORE__ || (globalThis.__JOTAI_DEFAULT_STORE__ = Lt), globalThis.__JOTAI_DEFAULT_STORE__ !== Lt && console.warn(
  "Detected multiple Jotai instances. It may cause unexpected behavior with the default store. https://github.com/pmndrs/jotai/discussions/2044"
))), Lt), ts = { BASE_URL: "/", DEV: !1, MODE: "production", PROD: !0, SSR: !1, VITE_ADMIN_PORT: "9001", VITE_APP_PORT: "9000", VITE_UI_PORT: "8888" }, tf = Symbol(
  (ts ? "production" : void 0) !== "production" ? "RESET" : ""
);
function rf(t, e) {
  let r = null;
  const n = /* @__PURE__ */ new Map(), s = /* @__PURE__ */ new Set(), i = (u) => {
    let c;
    if (c = n.get(u), c !== void 0)
      if (r?.(c[1], u))
        i.remove(u);
      else
        return c[0];
    const l = t(u);
    return n.set(u, [l, Date.now()]), a("CREATE", u, l), l;
  };
  function a(u, c, l) {
    for (const d of s)
      d({ type: u, param: c, atom: l });
  }
  return i.unstable_listen = (u) => (s.add(u), () => {
    s.delete(u);
  }), i.getParams = () => n.keys(), i.remove = (u) => {
    {
      if (!n.has(u)) return;
      const [c] = n.get(u);
      n.delete(u), a("REMOVE", u, c);
    }
  }, i.setShouldRemove = (u) => {
    if (r = u, !!r)
      for (const [c, [l, d]] of n)
        r(d, c) && (n.delete(c), a("REMOVE", c, l));
  }, i;
}
const nf = (t) => typeof t?.then == "function";
function sf(t = () => {
  try {
    return window.localStorage;
  } catch (r) {
    (ts ? "production" : void 0) !== "production" && typeof window < "u" && console.warn(r);
    return;
  }
}, e) {
  var r;
  let n, s;
  const i = {
    getItem: (c, l) => {
      var d, v;
      const T = (I) => {
        if (I = I || "", n !== I) {
          try {
            s = JSON.parse(I, e?.reviver);
          } catch {
            return l;
          }
          n = I;
        }
        return s;
      }, O = (v = (d = t()) == null ? void 0 : d.getItem(c)) != null ? v : null;
      return nf(O) ? O.then(T) : T(O);
    },
    setItem: (c, l) => {
      var d;
      return (d = t()) == null ? void 0 : d.setItem(
        c,
        JSON.stringify(l, void 0)
      );
    },
    removeItem: (c) => {
      var l;
      return (l = t()) == null ? void 0 : l.removeItem(c);
    }
  }, a = (c) => (l, d, v) => c(l, (T) => {
    let O;
    try {
      O = JSON.parse(T || "");
    } catch {
      O = v;
    }
    d(O);
  });
  let u;
  try {
    u = (r = t()) == null ? void 0 : r.subscribe;
  } catch {
  }
  return !u && typeof window < "u" && typeof window.addEventListener == "function" && window.Storage && (u = (c, l) => {
    if (!(t() instanceof window.Storage))
      return () => {
      };
    const d = (v) => {
      v.storageArea === t() && v.key === c && l(v.newValue);
    };
    return window.addEventListener("storage", d), () => {
      window.removeEventListener("storage", d);
    };
  }), u && (i.subscribe = a(u)), i;
}
const af = sf();
function of(t, e, r = af, n) {
  const s = M(
    e
  );
  return (ts ? "production" : void 0) !== "production" && (s.debugPrivate = !0), s.onMount = (a) => {
    a(r.getItem(t, e));
    let u;
    return r.subscribe && (u = r.subscribe(t, a, e)), u;
  }, M(
    (a) => a(s),
    (a, u, c) => {
      const l = typeof c == "function" ? c(a(s)) : c;
      return l === tf ? (u(s, e), r.removeItem(t)) : l instanceof Promise ? l.then((d) => (u(s, d), r.setItem(t, d))) : (u(s, l), r.setItem(t, l));
    }
  );
}
var uf = Object.defineProperty, cf = (t, e, r) => e in t ? uf(t, e, { enumerable: !0, configurable: !0, writable: !0, value: r }) : t[e] = r, ve = (t, e, r) => (cf(t, typeof e != "symbol" ? e + "" : e, r), r);
function Re(t) {
  return new Promise((e, r) => {
    t.oncomplete = t.onsuccess = () => e(t.result), t.onabort = t.onerror = () => r(t.error);
  });
}
function lf(t, e) {
  const r = indexedDB.open(t);
  r.onupgradeneeded = () => r.result.createObjectStore(e);
  const n = Re(r);
  return (s, i) => n.then((a) => i(a.transaction(e, s).objectStore(e)));
}
let hn;
function Gt() {
  return hn || (hn = lf("keyval-store", "keyval")), hn;
}
function ff(t, e, r = Gt()) {
  return r("readwrite", (n) => (n.put(e, t), Re(n.transaction)));
}
function vi(t, e = Gt()) {
  return e("readwrite", (r) => (t.forEach((n) => r.put(n[1], n[0])), Re(r.transaction)));
}
function df(t, e = Gt()) {
  return e("readwrite", (r) => (r.delete(t), Re(r.transaction)));
}
function hf(t = Gt()) {
  return t("readwrite", (e) => (e.clear(), Re(e.transaction)));
}
function pf(t, e) {
  return t.openCursor().onsuccess = function() {
    this.result && (e(this.result), this.result.continue());
  }, Re(t.transaction);
}
function pn(t = Gt()) {
  return t("readonly", (e) => {
    if (e.getAll && e.getAllKeys)
      return Promise.all([
        Re(e.getAllKeys()),
        Re(e.getAll())
      ]).then(([n, s]) => n.map((i, a) => [i, s[a]]));
    const r = [];
    return t("readonly", (n) => pf(n, (s) => r.push([s.key, s.value])).then(() => r));
  });
}
const mf = "jotai-minidb", yf = {
  name: mf,
  version: 0,
  migrations: {},
  onMigrationCompleted: () => {
    alert("Data has been migrated. Page will be reloaded"), window.location.reload();
  },
  onVersionMissmatch: () => {
  }
};
class vf {
  constructor(e = {}) {
    ve(this, "channel"), ve(this, "cache", M(void 0)), ve(this, "idbStorage"), ve(this, "metaStorage"), ve(this, "config"), ve(this, "initStarted", M(!1)), ve(this, "initialDataThenable", gf()), ve(this, "suspendBeforeInit", M(async (s) => {
      s(this.items), await s(this.initialDataThenable).promise;
    })), ve(this, "isInitialized", M(!1)), ve(this, "items", M(
      (s, { setSelf: i }) => (s(this.initStarted) || Promise.resolve().then(i), s(this.cache)),
      async (s, i) => {
        s(this.initStarted) || (i(this.initStarted, !0), this.preloadData().then((a) => {
          i(this.cache, a), s(this.initialDataThenable).resolve();
        }), this.channel.onmessage = async (a) => {
          const u = a.data;
          u.type === "UPDATE" ? i(this.cache, (c) => ({
            ...c,
            [u.id]: u.item
          })) : u.type === "DELETE" ? i(this.cache, (c) => {
            const l = { ...c };
            return delete l[u.id], l;
          }) : u.type === "UPDATE_MANY" ? i(
            this.cache,
            Object.fromEntries(await pn(this.idbStorage))
          ) : u.type === "MIGRATION_COMPLETED" && this.config.onMigrationCompleted();
        });
      }
    )), ve(this, "entries", M((s) => Object.entries(s(this.items) || {}))), ve(this, "keys", M((s) => Object.keys(s(this.items) || {}))), ve(this, "values", M((s) => Object.values(s(this.items) || {}))), ve(this, "item", rf(
      (s) => M(
        (i) => {
          var a;
          return (a = i(this.items)) == null ? void 0 : a[s];
        },
        async (i, a, u) => {
          await a(this.set, s, u);
        }
      )
    )), ve(this, "set", M(
      null,
      async (s, i, a, u) => {
        s(this.cache) || await s(this.suspendBeforeInit);
        const c = s(this.cache);
        if (!c)
          throw new Error("Cache was not initialized");
        const l = Of(u) ? u(c[a]) : u;
        i(this.cache, (d) => ({ ...d, [a]: l })), await ff(a, l, this.idbStorage), this.channel.postMessage({ type: "UPDATE", id: a, item: l });
      }
    )), ve(this, "setMany", M(null, async (s, i, a) => {
      s(this.cache) || await s(this.suspendBeforeInit);
      const u = { ...s(this.cache) };
      for (const [c, l] of a)
        u[c] = l;
      i(this.cache, u), await vi(a, this.idbStorage), this.channel.postMessage({ type: "UPDATE_MANY" });
    })), ve(this, "delete", M(null, async (s, i, a) => {
      s(this.cache) || await s(this.suspendBeforeInit), i(this.cache, (u) => {
        const c = { ...u };
        return delete c[a], c;
      }), await df(a, this.idbStorage), this.channel.postMessage({ type: "DELETE", id: a });
    })), ve(this, "clear", M(null, async (s, i) => {
      s(this.cache) || await s(this.suspendBeforeInit), i(this.cache, {}), await hf(this.idbStorage), this.channel.postMessage({ type: "UPDATE_MANY" });
    })), this.config = { ...yf, initialData: {}, ...e };
    const { keyvalStorage: r, metaStorage: n } = Ef(
      this.config.name,
      "key-value",
      this.config.initialData
    );
    this.idbStorage = r, this.metaStorage = n, this.channel = new BroadcastChannel(
      `jotai-minidb-broadcast:${this.config.name}`
    );
  }
  async preloadData() {
    return await this.migrate(), Object.fromEntries(await pn(this.idbStorage));
  }
  async migrate() {
    const e = await this.metaStorage(
      "readonly",
      (r) => Re(r.get("version"))
    ) || 0;
    if (this.config.version > e) {
      let r = await pn(this.idbStorage);
      for (let n = e + 1; n <= this.config.version; n++) {
        const s = this.config.migrations[n];
        if (!s)
          throw new Error(
            `Migrate function for version ${n} is not provided`
          );
        r = await Promise.all(
          r.map(
            async ([i, a]) => [i, await s(a)]
          )
        );
      }
      await vi(r, this.idbStorage), await this.metaStorage(
        "readwrite",
        (n) => Re(n.put(this.config.version, "version"))
      ), this.channel.postMessage({ type: "MIGRATION_COMPLETED" });
    } else if (this.config.version < e)
      throw this.config.onVersionMissmatch(), new Error(
        `[jotai-minidb] Minimal client version is ${this.config.version} but indexeddb database version is ${e}`
      );
  }
}
function gf() {
  return M(() => {
    let t, e;
    return {
      promise: new Promise((r, n) => {
        t = r, e = n;
      }),
      resolve: t,
      reject: e
    };
  });
}
function Ef(t, e, r) {
  const n = indexedDB.open(t), s = [];
  n.onupgradeneeded = (a) => {
    const u = n.result.createObjectStore(e);
    n.result.createObjectStore("_meta");
    for (const [c, l] of Object.entries(r))
      s.push(
        Re(u.add(l, c))
      );
  };
  const i = Re(n);
  return {
    keyvalStorage: async (a, u) => {
      const c = await i;
      return await Promise.all(s), u(c.transaction(e, a).objectStore(e));
    },
    metaStorage: (a, u) => i.then(
      (c) => u(c.transaction("_meta", a).objectStore("_meta"))
    )
  };
}
function Of(t) {
  return typeof t == "function";
}
const Ur = new vf(), Mp = Ua(), gi = of("appState", {
  spheres: {
    currentSphereHash: "",
    byHash: { default: {} }
  },
  hierarchies: {
    byRootOrbitEntryHash: {}
  },
  orbitNodes: {
    currentOrbitHash: null,
    byHash: { default: {} }
  },
  wins: {},
  ui: {
    listSortFilter: {
      sortCriteria: "name",
      sortOrder: "lowestToGreatest"
    },
    currentDay: (/* @__PURE__ */ new Date()).toISOString()
  }
}), oe = M(
  (t) => t(gi),
  (t, e, r) => {
    e(gi, r);
  }
);
var Oe;
((t) => {
  t.LESS_THAN_DAILY = {
    WEEKLY: 0.143,
    // 1/7 rounded to 3 decimal places
    MONTHLY: 0.032,
    // 1/31 rounded to 3 decimal places
    QUARTERLY: 0.011
    // 1/91 rounded to 3 decimal places
  }, t.ONE_SHOT = 0, t.DAILY_OR_MORE = {
    DAILY: 1,
    TWO: 2,
    THREE: 3,
    FOUR: 4,
    FIVE: 5,
    SIX: 6,
    SEVEN: 7,
    EIGHT: 8,
    NINE: 9,
    TEN: 10,
    ELEVEN: 11,
    TWELVE: 12,
    THIRTEEN: 13,
    FOURTEEN: 14,
    FIFTEEN: 15,
    SIXTEEN: 16,
    SEVENTEEN: 17,
    EIGHTEEN: 18,
    NINETEEN: 19,
    TWENTY: 20,
    TWENTY_ONE: 21,
    TWENTY_TWO: 22,
    TWENTY_THREE: 23,
    HOURLY: 24
  };
})(Oe || (Oe = {}));
function wf(t) {
  var e = 0, r = t.children, n = r && r.length;
  if (!n) e = 1;
  else for (; --n >= 0; ) e += r[n].value;
  t.value = e;
}
function bf() {
  return this.eachAfter(wf);
}
function Tf(t, e) {
  let r = -1;
  for (const n of this)
    t.call(e, n, ++r, this);
  return this;
}
function Sf(t, e) {
  for (var r = this, n = [r], s, i, a = -1; r = n.pop(); )
    if (t.call(e, r, ++a, this), s = r.children)
      for (i = s.length - 1; i >= 0; --i)
        n.push(s[i]);
  return this;
}
function _f(t, e) {
  for (var r = this, n = [r], s = [], i, a, u, c = -1; r = n.pop(); )
    if (s.push(r), i = r.children)
      for (a = 0, u = i.length; a < u; ++a)
        n.push(i[a]);
  for (; r = s.pop(); )
    t.call(e, r, ++c, this);
  return this;
}
function If(t, e) {
  let r = -1;
  for (const n of this)
    if (t.call(e, n, ++r, this))
      return n;
}
function Nf(t) {
  return this.eachAfter(function(e) {
    for (var r = +t(e.data) || 0, n = e.children, s = n && n.length; --s >= 0; ) r += n[s].value;
    e.value = r;
  });
}
function kf(t) {
  return this.eachBefore(function(e) {
    e.children && e.children.sort(t);
  });
}
function Df(t) {
  for (var e = this, r = Cf(e, t), n = [e]; e !== r; )
    e = e.parent, n.push(e);
  for (var s = n.length; t !== r; )
    n.splice(s, 0, t), t = t.parent;
  return n;
}
function Cf(t, e) {
  if (t === e) return t;
  var r = t.ancestors(), n = e.ancestors(), s = null;
  for (t = r.pop(), e = n.pop(); t === e; )
    s = t, t = r.pop(), e = n.pop();
  return s;
}
function Af() {
  for (var t = this, e = [t]; t = t.parent; )
    e.push(t);
  return e;
}
function Rf() {
  return Array.from(this);
}
function xf() {
  var t = [];
  return this.eachBefore(function(e) {
    e.children || t.push(e);
  }), t;
}
function Mf() {
  var t = this, e = [];
  return t.each(function(r) {
    r !== t && e.push({ source: r.parent, target: r });
  }), e;
}
function* Lf() {
  var t = this, e, r = [t], n, s, i;
  do
    for (e = r.reverse(), r = []; t = e.pop(); )
      if (yield t, n = t.children)
        for (s = 0, i = n.length; s < i; ++s)
          r.push(n[s]);
  while (r.length);
}
function rs(t, e) {
  t instanceof Map ? (t = [void 0, t], e === void 0 && (e = Vf)) : e === void 0 && (e = Pf);
  for (var r = new Rr(t), n, s = [r], i, a, u, c; n = s.pop(); )
    if ((a = e(n.data)) && (c = (a = Array.from(a)).length))
      for (n.children = a, u = c - 1; u >= 0; --u)
        s.push(i = a[u] = new Rr(a[u])), i.parent = n, i.depth = n.depth + 1;
  return r.eachBefore($f);
}
function Ff() {
  return rs(this).eachBefore(Uf);
}
function Pf(t) {
  return t.children;
}
function Vf(t) {
  return Array.isArray(t) ? t[1] : null;
}
function Uf(t) {
  t.data.value !== void 0 && (t.value = t.data.value), t.data = t.data.data;
}
function $f(t) {
  var e = 0;
  do
    t.height = e;
  while ((t = t.parent) && t.height < ++e);
}
function Rr(t) {
  this.data = t, this.depth = this.height = 0, this.parent = null;
}
Rr.prototype = rs.prototype = {
  constructor: Rr,
  count: bf,
  each: Tf,
  eachAfter: _f,
  eachBefore: Sf,
  find: If,
  sum: Nf,
  sort: kf,
  path: Df,
  ancestors: Af,
  descendants: Rf,
  leaves: xf,
  links: Mf,
  copy: Ff,
  [Symbol.iterator]: Lf
};
const Wf = M(
  (t) => {
    const e = t(oe), r = e.spheres.currentSphereHash, n = e.spheres.byHash[r];
    return n ? {
      entryHash: n.details.entryHash,
      actionHash: r
    } : null;
  },
  (t, e, r) => {
    const n = t(oe), s = r.actionHash || "", i = {
      ...n,
      spheres: {
        ...n.spheres,
        currentSphereHash: s,
        byHash: {
          ...n.spheres.byHash,
          [s]: {
            ...n.spheres.byHash[s],
            details: {
              ...n.spheres.byHash[s]?.details,
              entryHash: r.entryHash
            }
          }
        }
      }
    };
    e(oe, i);
  }
);
Wf.testId = "currentSphereHashes";
const Hf = M((t) => {
  const e = t(oe), r = e.spheres.currentSphereHash;
  return e.spheres.byHash[r]?.details || null;
});
Hf.testId = "currentSphereDetailsAtom";
const jf = (t) => M((e) => {
  const r = e(oe), n = Object.entries(r.spheres.byHash).find(
    ([s, i]) => i.details.entryHash == t
  );
  return n && n[0] || null;
}), Lp = M((t) => {
  const r = t(oe).spheres.currentSphereHash;
  return r ? t(zf(r)) : !1;
}), zf = (t) => M((e) => {
  const n = e(oe).spheres.byHash[t];
  if (!n) return null;
  const s = n.hierarchyRootOrbitEntryHashes;
  return !s || s.length == 0 || !e(Ur.item(t)) ? null : s.every((a) => !!e(Zt(a)));
}), zt = M({});
zt.testId = "currentSphereHierarchyBounds";
const Yt = M({
  x: 0,
  y: 0
});
Yt.testId = "currentSphereHierarchyIndices";
const Fp = M(null, (t, e, r) => {
  const n = t(Yt);
  e(Yt, { ...n, x: r });
}), Pp = M(null, (t, e, r) => {
  const n = t(Yt);
  e(Yt, { ...n, x: r });
}), Vp = M(
  null,
  (t, e, r, [n, s]) => {
    const i = t(zt);
    e(zt, {
      ...i,
      [r]: { ...i[r], minDepth: n, maxDepth: s }
    });
  }
), Up = M(
  null,
  (t, e, r, [n, s]) => {
    const i = t(zt);
    e(zt, {
      ...i,
      [r]: { ...i[r], minBreadth: n, maxBreadth: s }
    });
  }
), Yf = M({
  id: null
});
Yf.testId = "newTraversalLevelIndexId";
const $p = (t) => M((r) => r(oe).hierarchies.byRootOrbitEntryHash[t] || null), Wp = M(
  null,
  (t, e, r) => {
    if (!r?.rootData) return null;
    const n = t(oe), s = r.rootData.data.content, i = [], a = [];
    let u;
    const c = Object.keys(n.orbitNodes.byHash);
    r.rootData.each((d) => {
      const v = d.data.content, T = c.find(
        (O) => n.orbitNodes.byHash[O].eH === v
      );
      T && (n.orbitNodes.currentOrbitHash == T && (u = T), i.push(T), d.data?.children && d.data.children.length == 0 && a.push(T));
    });
    const l = {
      rootNode: s,
      json: r?._json,
      bounds: void 0,
      // TODO: decide whether to keep this as a primitive atom and remove from appstate
      indices: void 0,
      // TODO: decide whether to keep this as a primitive atom and remove from appstate
      currentNode: u,
      nodeHashes: i,
      leafNodeHashes: a
    };
    e(oe, {
      ...n,
      hierarchies: {
        ...n.hierarchies,
        byRootOrbitEntryHash: {
          ...n.hierarchies.byRootOrbitEntryHash,
          [s]: l
        }
      }
    });
  }
), Bf = (t) => M((e) => {
  const n = e(oe).hierarchies.byRootOrbitEntryHash;
  for (const s in n)
    if (n[s]?.leafNodeHashes?.includes(t))
      return !0;
  return !1;
}), Hp = (t) => M((e) => {
  const r = e(oe), n = e(
    Zt(t)
  );
  if (!n) return null;
  const s = n.id;
  let i = null, a = null;
  for (const [d, v] of Object.entries(
    r.hierarchies.byRootOrbitEntryHash
  ))
    if (v.nodeHashes.includes(s)) {
      i = v.json, a = d;
      break;
    }
  if (!i || !a) return null;
  const u = JSON.parse(i);
  return (rs(u[0]).find((d) => d.data.content === n.eH)?.leaves() || []).map((d) => d.data);
}), jp = (t) => M((r) => {
  const n = r(oe), s = n.hierarchies.byRootOrbitEntryHash[t], i = n.orbitNodes.byHash[t].sphereHash, a = r(jf(i));
  return null;
}), qf = (t) => {
  switch (t) {
    case _e.OneShot:
      return Oe.ONE_SHOT;
    case _e.DailyOrMore_1d:
      return Oe.DAILY_OR_MORE.DAILY;
    case _e.DailyOrMore_2d:
      return Oe.DAILY_OR_MORE.TWO;
    case _e.DailyOrMore_3d:
      return Oe.DAILY_OR_MORE.THREE;
    case _e.DailyOrMore_4d:
      return Oe.DAILY_OR_MORE.FOUR;
    case _e.DailyOrMore_5d:
      return Oe.DAILY_OR_MORE.FIVE;
    case _e.DailyOrMore_6d:
      return Oe.DAILY_OR_MORE.SIX;
    case _e.DailyOrMore_7d:
      return Oe.DAILY_OR_MORE.SEVEN;
    case _e.DailyOrMore_8d:
      return Oe.DAILY_OR_MORE.EIGHT;
    case _e.DailyOrMore_9d:
      return Oe.DAILY_OR_MORE.NINE;
    case _e.DailyOrMore_10d:
      return Oe.DAILY_OR_MORE.TEN;
    case _e.LessThanDaily_1w:
      return Oe.LESS_THAN_DAILY.WEEKLY;
    case _e.LessThanDaily_1m:
      return Oe.LESS_THAN_DAILY.MONTHLY;
    case _e.LessThanDaily_1q:
      return Oe.LESS_THAN_DAILY.QUARTERLY;
    default:
      throw new Error(`Unsupported GraphQL frequency: ${t}`);
  }
}, zp = (t) => {
  const e = qf(t.frequency);
  return {
    id: t.id,
    eH: t.eH,
    parentEh: t.parentHash || void 0,
    name: t.name,
    scale: t.scale,
    sphereHash: t.sphereHash,
    frequency: e,
    description: t.metadata?.description || "",
    startTime: t.metadata?.timeframe.startTime,
    endTime: t.metadata?.timeframe.endTime || void 0
  };
}, Gf = M((t) => {
  const r = t(oe).spheres.currentSphereHash;
  return r && t(Ur.item(r)) || null;
});
Gf.testId = "currentSphereOrbitNodeDetailsAtom";
const Zt = (t) => M((e) => {
  const r = e(Ur.entries)?.map(
    //@ts-ignore
    ([i, a]) => a
  ), n = r?.find(
    (i) => i[t]
  );
  return !r || !n ? null : n[t] || null;
});
Zt.testId = "getOrbitNodeDetailsFromEhAtom";
const $a = M((t) => {
  const e = t(Ha)?.id;
  if (!e) return null;
  let r = e;
  if (!r.startsWith("uhCE")) {
    const n = t(ja(e));
    if (!n) return null;
    r = n;
  }
  return t(Zt(r));
});
$a.testId = "currentOrbitDetailsAtom";
const Wa = (t) => M((e) => {
  const r = e(ja(t));
  return !r || typeof r != "string" ? null : e(Zt(r));
});
Wa.testId = "getOrbitNodeDetailsFromIdAtom";
const Zf = (t) => M((e) => {
  const r = e(oe), n = r.spheres.currentSphereHash;
  if (!r.spheres.byHash[n]) return null;
  const i = e(
    Ur.item(n)
  );
  return i && i[t] || null;
}), Yp = M(
  (t) => (e) => t(Zf(e))?.startTime || null
), Bp = M(
  null,
  (t, e, {
    orbitEh: r,
    update: n
  }) => {
    const s = t(oe), i = Object.keys(s.orbitNodes.byHash).find(
      (u) => s.orbitNodes.byHash[u].eH === r
    );
    if (!i) return;
    const a = {
      ...s,
      orbitNodes: {
        ...s.orbitNodes,
        byHash: {
          ...s.orbitNodes.byHash,
          [i]: {
            ...s.orbitNodes.byHash[i],
            ...n
          }
        }
      }
    };
    e(oe, a);
  }
), Qf = M((t) => {
  const e = t($a)?.id;
  return e ? t(Bf(e)) : null;
});
Qf.testId = "currentOrbitIsLeafAtom";
const qp = (t) => M((r) => r(Wa(t))?.frequency || null), Gp = M(
  (t) => {
    const e = t(oe), r = e.spheres.currentSphereHash, n = e.spheres.byHash[r];
    if (!n) return null;
    const s = {};
    return Object.entries(e.orbitNodes.byHash).forEach(([i, a]) => {
      a.sphereHash === n.details.entryHash && (s[i] = a);
    }), Object.keys(s).length > 0 ? s : null;
  }
), Ha = M(
  (t) => {
    const e = t(oe);
    return e.orbitNodes.currentOrbitHash ? { id: e.orbitNodes.currentOrbitHash } : null;
  },
  (t, e, r) => {
    const n = t(oe), s = {
      ...n,
      orbitNodes: {
        ...n.orbitNodes,
        currentOrbitHash: r
      }
    };
    console.log("Setting orbit id :>> ", s), e(oe, s);
  }
);
Ha.testId = "currentOrbitIdAtom";
const Jf = (t) => M((e) => {
  const r = e(oe);
  return Object.keys(r.orbitNodes.byHash).find(
    (s) => r.orbitNodes.byHash[s].eH === t
  ) || null;
});
Jf.testId = "getOrbitIdFromEh";
const ja = (t) => M((e) => e(oe).orbitNodes.byHash[t]?.eH || null), Zp = (t) => M((r) => r(oe).wins[t] || {});
class lt extends Error {
}
class Xf extends lt {
  constructor(e) {
    super(`Invalid DateTime: ${e.toMessage()}`);
  }
}
class Kf extends lt {
  constructor(e) {
    super(`Invalid Interval: ${e.toMessage()}`);
  }
}
class ed extends lt {
  constructor(e) {
    super(`Invalid Duration: ${e.toMessage()}`);
  }
}
class wt extends lt {
}
class za extends lt {
  constructor(e) {
    super(`Invalid unit ${e}`);
  }
}
class we extends lt {
}
class Ge extends lt {
  constructor() {
    super("Zone is an abstract class");
  }
}
const N = "numeric", Pe = "short", ke = "long", xr = {
  year: N,
  month: N,
  day: N
}, Ya = {
  year: N,
  month: Pe,
  day: N
}, td = {
  year: N,
  month: Pe,
  day: N,
  weekday: Pe
}, Ba = {
  year: N,
  month: ke,
  day: N
}, qa = {
  year: N,
  month: ke,
  day: N,
  weekday: ke
}, Ga = {
  hour: N,
  minute: N
}, Za = {
  hour: N,
  minute: N,
  second: N
}, Qa = {
  hour: N,
  minute: N,
  second: N,
  timeZoneName: Pe
}, Ja = {
  hour: N,
  minute: N,
  second: N,
  timeZoneName: ke
}, Xa = {
  hour: N,
  minute: N,
  hourCycle: "h23"
}, Ka = {
  hour: N,
  minute: N,
  second: N,
  hourCycle: "h23"
}, eo = {
  hour: N,
  minute: N,
  second: N,
  hourCycle: "h23",
  timeZoneName: Pe
}, to = {
  hour: N,
  minute: N,
  second: N,
  hourCycle: "h23",
  timeZoneName: ke
}, ro = {
  year: N,
  month: N,
  day: N,
  hour: N,
  minute: N
}, no = {
  year: N,
  month: N,
  day: N,
  hour: N,
  minute: N,
  second: N
}, so = {
  year: N,
  month: Pe,
  day: N,
  hour: N,
  minute: N
}, io = {
  year: N,
  month: Pe,
  day: N,
  hour: N,
  minute: N,
  second: N
}, rd = {
  year: N,
  month: Pe,
  day: N,
  weekday: Pe,
  hour: N,
  minute: N
}, ao = {
  year: N,
  month: ke,
  day: N,
  hour: N,
  minute: N,
  timeZoneName: Pe
}, oo = {
  year: N,
  month: ke,
  day: N,
  hour: N,
  minute: N,
  second: N,
  timeZoneName: Pe
}, uo = {
  year: N,
  month: ke,
  day: N,
  weekday: ke,
  hour: N,
  minute: N,
  timeZoneName: ke
}, co = {
  year: N,
  month: ke,
  day: N,
  weekday: ke,
  hour: N,
  minute: N,
  second: N,
  timeZoneName: ke
};
class Qt {
  /**
   * The type of zone
   * @abstract
   * @type {string}
   */
  get type() {
    throw new Ge();
  }
  /**
   * The name of this zone.
   * @abstract
   * @type {string}
   */
  get name() {
    throw new Ge();
  }
  /**
   * The IANA name of this zone.
   * Defaults to `name` if not overwritten by a subclass.
   * @abstract
   * @type {string}
   */
  get ianaName() {
    return this.name;
  }
  /**
   * Returns whether the offset is known to be fixed for the whole year.
   * @abstract
   * @type {boolean}
   */
  get isUniversal() {
    throw new Ge();
  }
  /**
   * Returns the offset's common name (such as EST) at the specified timestamp
   * @abstract
   * @param {number} ts - Epoch milliseconds for which to get the name
   * @param {Object} opts - Options to affect the format
   * @param {string} opts.format - What style of offset to return. Accepts 'long' or 'short'.
   * @param {string} opts.locale - What locale to return the offset name in.
   * @return {string}
   */
  offsetName(e, r) {
    throw new Ge();
  }
  /**
   * Returns the offset's value as a string
   * @abstract
   * @param {number} ts - Epoch milliseconds for which to get the offset
   * @param {string} format - What style of offset to return.
   *                          Accepts 'narrow', 'short', or 'techie'. Returning '+6', '+06:00', or '+0600' respectively
   * @return {string}
   */
  formatOffset(e, r) {
    throw new Ge();
  }
  /**
   * Return the offset in minutes for this zone at the specified timestamp.
   * @abstract
   * @param {number} ts - Epoch milliseconds for which to compute the offset
   * @return {number}
   */
  offset(e) {
    throw new Ge();
  }
  /**
   * Return whether this Zone is equal to another zone
   * @abstract
   * @param {Zone} otherZone - the zone to compare
   * @return {boolean}
   */
  equals(e) {
    throw new Ge();
  }
  /**
   * Return whether this Zone is valid.
   * @abstract
   * @type {boolean}
   */
  get isValid() {
    throw new Ge();
  }
}
let mn = null;
class $r extends Qt {
  /**
   * Get a singleton instance of the local zone
   * @return {SystemZone}
   */
  static get instance() {
    return mn === null && (mn = new $r()), mn;
  }
  /** @override **/
  get type() {
    return "system";
  }
  /** @override **/
  get name() {
    return new Intl.DateTimeFormat().resolvedOptions().timeZone;
  }
  /** @override **/
  get isUniversal() {
    return !1;
  }
  /** @override **/
  offsetName(e, { format: r, locale: n }) {
    return Eo(e, r, n);
  }
  /** @override **/
  formatOffset(e, r) {
    return Wt(this.offset(e), r);
  }
  /** @override **/
  offset(e) {
    return -new Date(e).getTimezoneOffset();
  }
  /** @override **/
  equals(e) {
    return e.type === "system";
  }
  /** @override **/
  get isValid() {
    return !0;
  }
}
let Sr = {};
function nd(t) {
  return Sr[t] || (Sr[t] = new Intl.DateTimeFormat("en-US", {
    hour12: !1,
    timeZone: t,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    era: "short"
  })), Sr[t];
}
const sd = {
  year: 0,
  month: 1,
  day: 2,
  era: 3,
  hour: 4,
  minute: 5,
  second: 6
};
function id(t, e) {
  const r = t.format(e).replace(/\u200E/g, ""), n = /(\d+)\/(\d+)\/(\d+) (AD|BC),? (\d+):(\d+):(\d+)/.exec(r), [, s, i, a, u, c, l, d] = n;
  return [a, s, i, u, c, l, d];
}
function ad(t, e) {
  const r = t.formatToParts(e), n = [];
  for (let s = 0; s < r.length; s++) {
    const { type: i, value: a } = r[s], u = sd[i];
    i === "era" ? n[u] = a : P(u) || (n[u] = parseInt(a, 10));
  }
  return n;
}
let yr = {};
class He extends Qt {
  /**
   * @param {string} name - Zone name
   * @return {IANAZone}
   */
  static create(e) {
    return yr[e] || (yr[e] = new He(e)), yr[e];
  }
  /**
   * Reset local caches. Should only be necessary in testing scenarios.
   * @return {void}
   */
  static resetCache() {
    yr = {}, Sr = {};
  }
  /**
   * Returns whether the provided string is a valid specifier. This only checks the string's format, not that the specifier identifies a known zone; see isValidZone for that.
   * @param {string} s - The string to check validity on
   * @example IANAZone.isValidSpecifier("America/New_York") //=> true
   * @example IANAZone.isValidSpecifier("Sport~~blorp") //=> false
   * @deprecated For backward compatibility, this forwards to isValidZone, better use `isValidZone()` directly instead.
   * @return {boolean}
   */
  static isValidSpecifier(e) {
    return this.isValidZone(e);
  }
  /**
   * Returns whether the provided string identifies a real zone
   * @param {string} zone - The string to check
   * @example IANAZone.isValidZone("America/New_York") //=> true
   * @example IANAZone.isValidZone("Fantasia/Castle") //=> false
   * @example IANAZone.isValidZone("Sport~~blorp") //=> false
   * @return {boolean}
   */
  static isValidZone(e) {
    if (!e)
      return !1;
    try {
      return new Intl.DateTimeFormat("en-US", { timeZone: e }).format(), !0;
    } catch {
      return !1;
    }
  }
  constructor(e) {
    super(), this.zoneName = e, this.valid = He.isValidZone(e);
  }
  /**
   * The type of zone. `iana` for all instances of `IANAZone`.
   * @override
   * @type {string}
   */
  get type() {
    return "iana";
  }
  /**
   * The name of this zone (i.e. the IANA zone name).
   * @override
   * @type {string}
   */
  get name() {
    return this.zoneName;
  }
  /**
   * Returns whether the offset is known to be fixed for the whole year:
   * Always returns false for all IANA zones.
   * @override
   * @type {boolean}
   */
  get isUniversal() {
    return !1;
  }
  /**
   * Returns the offset's common name (such as EST) at the specified timestamp
   * @override
   * @param {number} ts - Epoch milliseconds for which to get the name
   * @param {Object} opts - Options to affect the format
   * @param {string} opts.format - What style of offset to return. Accepts 'long' or 'short'.
   * @param {string} opts.locale - What locale to return the offset name in.
   * @return {string}
   */
  offsetName(e, { format: r, locale: n }) {
    return Eo(e, r, n, this.name);
  }
  /**
   * Returns the offset's value as a string
   * @override
   * @param {number} ts - Epoch milliseconds for which to get the offset
   * @param {string} format - What style of offset to return.
   *                          Accepts 'narrow', 'short', or 'techie'. Returning '+6', '+06:00', or '+0600' respectively
   * @return {string}
   */
  formatOffset(e, r) {
    return Wt(this.offset(e), r);
  }
  /**
   * Return the offset in minutes for this zone at the specified timestamp.
   * @override
   * @param {number} ts - Epoch milliseconds for which to compute the offset
   * @return {number}
   */
  offset(e) {
    const r = new Date(e);
    if (isNaN(r)) return NaN;
    const n = nd(this.name);
    let [s, i, a, u, c, l, d] = n.formatToParts ? ad(n, r) : id(n, r);
    u === "BC" && (s = -Math.abs(s) + 1);
    const T = Hr({
      year: s,
      month: i,
      day: a,
      hour: c === 24 ? 0 : c,
      minute: l,
      second: d,
      millisecond: 0
    });
    let O = +r;
    const I = O % 1e3;
    return O -= I >= 0 ? I : 1e3 + I, (T - O) / (60 * 1e3);
  }
  /**
   * Return whether this Zone is equal to another zone
   * @override
   * @param {Zone} otherZone - the zone to compare
   * @return {boolean}
   */
  equals(e) {
    return e.type === "iana" && e.name === this.name;
  }
  /**
   * Return whether this Zone is valid.
   * @override
   * @type {boolean}
   */
  get isValid() {
    return this.valid;
  }
}
let Ei = {};
function od(t, e = {}) {
  const r = JSON.stringify([t, e]);
  let n = Ei[r];
  return n || (n = new Intl.ListFormat(t, e), Ei[r] = n), n;
}
let Wn = {};
function Hn(t, e = {}) {
  const r = JSON.stringify([t, e]);
  let n = Wn[r];
  return n || (n = new Intl.DateTimeFormat(t, e), Wn[r] = n), n;
}
let jn = {};
function ud(t, e = {}) {
  const r = JSON.stringify([t, e]);
  let n = jn[r];
  return n || (n = new Intl.NumberFormat(t, e), jn[r] = n), n;
}
let zn = {};
function cd(t, e = {}) {
  const { base: r, ...n } = e, s = JSON.stringify([t, n]);
  let i = zn[s];
  return i || (i = new Intl.RelativeTimeFormat(t, e), zn[s] = i), i;
}
let Ut = null;
function ld() {
  return Ut || (Ut = new Intl.DateTimeFormat().resolvedOptions().locale, Ut);
}
let Oi = {};
function fd(t) {
  let e = Oi[t];
  if (!e) {
    const r = new Intl.Locale(t);
    e = "getWeekInfo" in r ? r.getWeekInfo() : r.weekInfo, Oi[t] = e;
  }
  return e;
}
function dd(t) {
  const e = t.indexOf("-x-");
  e !== -1 && (t = t.substring(0, e));
  const r = t.indexOf("-u-");
  if (r === -1)
    return [t];
  {
    let n, s;
    try {
      n = Hn(t).resolvedOptions(), s = t;
    } catch {
      const c = t.substring(0, r);
      n = Hn(c).resolvedOptions(), s = c;
    }
    const { numberingSystem: i, calendar: a } = n;
    return [s, i, a];
  }
}
function hd(t, e, r) {
  return (r || e) && (t.includes("-u-") || (t += "-u"), r && (t += `-ca-${r}`), e && (t += `-nu-${e}`)), t;
}
function pd(t) {
  const e = [];
  for (let r = 1; r <= 12; r++) {
    const n = F.utc(2009, r, 1);
    e.push(t(n));
  }
  return e;
}
function md(t) {
  const e = [];
  for (let r = 1; r <= 7; r++) {
    const n = F.utc(2016, 11, 13 + r);
    e.push(t(n));
  }
  return e;
}
function vr(t, e, r, n) {
  const s = t.listingMode();
  return s === "error" ? null : s === "en" ? r(e) : n(e);
}
function yd(t) {
  return t.numberingSystem && t.numberingSystem !== "latn" ? !1 : t.numberingSystem === "latn" || !t.locale || t.locale.startsWith("en") || new Intl.DateTimeFormat(t.intl).resolvedOptions().numberingSystem === "latn";
}
class vd {
  constructor(e, r, n) {
    this.padTo = n.padTo || 0, this.floor = n.floor || !1;
    const { padTo: s, floor: i, ...a } = n;
    if (!r || Object.keys(a).length > 0) {
      const u = { useGrouping: !1, ...n };
      n.padTo > 0 && (u.minimumIntegerDigits = n.padTo), this.inf = ud(e, u);
    }
  }
  format(e) {
    if (this.inf) {
      const r = this.floor ? Math.floor(e) : e;
      return this.inf.format(r);
    } else {
      const r = this.floor ? Math.floor(e) : os(e, 3);
      return me(r, this.padTo);
    }
  }
}
class gd {
  constructor(e, r, n) {
    this.opts = n, this.originalZone = void 0;
    let s;
    if (this.opts.timeZone)
      this.dt = e;
    else if (e.zone.type === "fixed") {
      const a = -1 * (e.offset / 60), u = a >= 0 ? `Etc/GMT+${a}` : `Etc/GMT${a}`;
      e.offset !== 0 && He.create(u).valid ? (s = u, this.dt = e) : (s = "UTC", this.dt = e.offset === 0 ? e : e.setZone("UTC").plus({ minutes: e.offset }), this.originalZone = e.zone);
    } else e.zone.type === "system" ? this.dt = e : e.zone.type === "iana" ? (this.dt = e, s = e.zone.name) : (s = "UTC", this.dt = e.setZone("UTC").plus({ minutes: e.offset }), this.originalZone = e.zone);
    const i = { ...this.opts };
    i.timeZone = i.timeZone || s, this.dtf = Hn(r, i);
  }
  format() {
    return this.originalZone ? this.formatToParts().map(({ value: e }) => e).join("") : this.dtf.format(this.dt.toJSDate());
  }
  formatToParts() {
    const e = this.dtf.formatToParts(this.dt.toJSDate());
    return this.originalZone ? e.map((r) => {
      if (r.type === "timeZoneName") {
        const n = this.originalZone.offsetName(this.dt.ts, {
          locale: this.dt.locale,
          format: this.opts.timeZoneName
        });
        return {
          ...r,
          value: n
        };
      } else
        return r;
    }) : e;
  }
  resolvedOptions() {
    return this.dtf.resolvedOptions();
  }
}
class Ed {
  constructor(e, r, n) {
    this.opts = { style: "long", ...n }, !r && vo() && (this.rtf = cd(e, n));
  }
  format(e, r) {
    return this.rtf ? this.rtf.format(e, r) : Hd(r, e, this.opts.numeric, this.opts.style !== "long");
  }
  formatToParts(e, r) {
    return this.rtf ? this.rtf.formatToParts(e, r) : [];
  }
}
const Od = {
  firstDay: 1,
  minimalDays: 4,
  weekend: [6, 7]
};
class X {
  static fromOpts(e) {
    return X.create(
      e.locale,
      e.numberingSystem,
      e.outputCalendar,
      e.weekSettings,
      e.defaultToEN
    );
  }
  static create(e, r, n, s, i = !1) {
    const a = e || fe.defaultLocale, u = a || (i ? "en-US" : ld()), c = r || fe.defaultNumberingSystem, l = n || fe.defaultOutputCalendar, d = Yn(s) || fe.defaultWeekSettings;
    return new X(u, c, l, d, a);
  }
  static resetCache() {
    Ut = null, Wn = {}, jn = {}, zn = {};
  }
  static fromObject({ locale: e, numberingSystem: r, outputCalendar: n, weekSettings: s } = {}) {
    return X.create(e, r, n, s);
  }
  constructor(e, r, n, s, i) {
    const [a, u, c] = dd(e);
    this.locale = a, this.numberingSystem = r || u || null, this.outputCalendar = n || c || null, this.weekSettings = s, this.intl = hd(this.locale, this.numberingSystem, this.outputCalendar), this.weekdaysCache = { format: {}, standalone: {} }, this.monthsCache = { format: {}, standalone: {} }, this.meridiemCache = null, this.eraCache = {}, this.specifiedLocale = i, this.fastNumbersCached = null;
  }
  get fastNumbers() {
    return this.fastNumbersCached == null && (this.fastNumbersCached = yd(this)), this.fastNumbersCached;
  }
  listingMode() {
    const e = this.isEnglish(), r = (this.numberingSystem === null || this.numberingSystem === "latn") && (this.outputCalendar === null || this.outputCalendar === "gregory");
    return e && r ? "en" : "intl";
  }
  clone(e) {
    return !e || Object.getOwnPropertyNames(e).length === 0 ? this : X.create(
      e.locale || this.specifiedLocale,
      e.numberingSystem || this.numberingSystem,
      e.outputCalendar || this.outputCalendar,
      Yn(e.weekSettings) || this.weekSettings,
      e.defaultToEN || !1
    );
  }
  redefaultToEN(e = {}) {
    return this.clone({ ...e, defaultToEN: !0 });
  }
  redefaultToSystem(e = {}) {
    return this.clone({ ...e, defaultToEN: !1 });
  }
  months(e, r = !1) {
    return vr(this, e, bo, () => {
      const n = r ? { month: e, day: "numeric" } : { month: e }, s = r ? "format" : "standalone";
      return this.monthsCache[s][e] || (this.monthsCache[s][e] = pd((i) => this.extract(i, n, "month"))), this.monthsCache[s][e];
    });
  }
  weekdays(e, r = !1) {
    return vr(this, e, _o, () => {
      const n = r ? { weekday: e, year: "numeric", month: "long", day: "numeric" } : { weekday: e }, s = r ? "format" : "standalone";
      return this.weekdaysCache[s][e] || (this.weekdaysCache[s][e] = md(
        (i) => this.extract(i, n, "weekday")
      )), this.weekdaysCache[s][e];
    });
  }
  meridiems() {
    return vr(
      this,
      void 0,
      () => Io,
      () => {
        if (!this.meridiemCache) {
          const e = { hour: "numeric", hourCycle: "h12" };
          this.meridiemCache = [F.utc(2016, 11, 13, 9), F.utc(2016, 11, 13, 19)].map(
            (r) => this.extract(r, e, "dayperiod")
          );
        }
        return this.meridiemCache;
      }
    );
  }
  eras(e) {
    return vr(this, e, No, () => {
      const r = { era: e };
      return this.eraCache[e] || (this.eraCache[e] = [F.utc(-40, 1, 1), F.utc(2017, 1, 1)].map(
        (n) => this.extract(n, r, "era")
      )), this.eraCache[e];
    });
  }
  extract(e, r, n) {
    const s = this.dtFormatter(e, r), i = s.formatToParts(), a = i.find((u) => u.type.toLowerCase() === n);
    return a ? a.value : null;
  }
  numberFormatter(e = {}) {
    return new vd(this.intl, e.forceSimple || this.fastNumbers, e);
  }
  dtFormatter(e, r = {}) {
    return new gd(e, this.intl, r);
  }
  relFormatter(e = {}) {
    return new Ed(this.intl, this.isEnglish(), e);
  }
  listFormatter(e = {}) {
    return od(this.intl, e);
  }
  isEnglish() {
    return this.locale === "en" || this.locale.toLowerCase() === "en-us" || new Intl.DateTimeFormat(this.intl).resolvedOptions().locale.startsWith("en-us");
  }
  getWeekSettings() {
    return this.weekSettings ? this.weekSettings : go() ? fd(this.locale) : Od;
  }
  getStartOfWeek() {
    return this.getWeekSettings().firstDay;
  }
  getMinDaysInFirstWeek() {
    return this.getWeekSettings().minimalDays;
  }
  getWeekendDays() {
    return this.getWeekSettings().weekend;
  }
  equals(e) {
    return this.locale === e.locale && this.numberingSystem === e.numberingSystem && this.outputCalendar === e.outputCalendar;
  }
  toString() {
    return `Locale(${this.locale}, ${this.numberingSystem}, ${this.outputCalendar})`;
  }
}
let yn = null;
class Ie extends Qt {
  /**
   * Get a singleton instance of UTC
   * @return {FixedOffsetZone}
   */
  static get utcInstance() {
    return yn === null && (yn = new Ie(0)), yn;
  }
  /**
   * Get an instance with a specified offset
   * @param {number} offset - The offset in minutes
   * @return {FixedOffsetZone}
   */
  static instance(e) {
    return e === 0 ? Ie.utcInstance : new Ie(e);
  }
  /**
   * Get an instance of FixedOffsetZone from a UTC offset string, like "UTC+6"
   * @param {string} s - The offset string to parse
   * @example FixedOffsetZone.parseSpecifier("UTC+6")
   * @example FixedOffsetZone.parseSpecifier("UTC+06")
   * @example FixedOffsetZone.parseSpecifier("UTC-6:00")
   * @return {FixedOffsetZone}
   */
  static parseSpecifier(e) {
    if (e) {
      const r = e.match(/^utc(?:([+-]\d{1,2})(?::(\d{2}))?)?$/i);
      if (r)
        return new Ie(jr(r[1], r[2]));
    }
    return null;
  }
  constructor(e) {
    super(), this.fixed = e;
  }
  /**
   * The type of zone. `fixed` for all instances of `FixedOffsetZone`.
   * @override
   * @type {string}
   */
  get type() {
    return "fixed";
  }
  /**
   * The name of this zone.
   * All fixed zones' names always start with "UTC" (plus optional offset)
   * @override
   * @type {string}
   */
  get name() {
    return this.fixed === 0 ? "UTC" : `UTC${Wt(this.fixed, "narrow")}`;
  }
  /**
   * The IANA name of this zone, i.e. `Etc/UTC` or `Etc/GMT+/-nn`
   *
   * @override
   * @type {string}
   */
  get ianaName() {
    return this.fixed === 0 ? "Etc/UTC" : `Etc/GMT${Wt(-this.fixed, "narrow")}`;
  }
  /**
   * Returns the offset's common name at the specified timestamp.
   *
   * For fixed offset zones this equals to the zone name.
   * @override
   */
  offsetName() {
    return this.name;
  }
  /**
   * Returns the offset's value as a string
   * @override
   * @param {number} ts - Epoch milliseconds for which to get the offset
   * @param {string} format - What style of offset to return.
   *                          Accepts 'narrow', 'short', or 'techie'. Returning '+6', '+06:00', or '+0600' respectively
   * @return {string}
   */
  formatOffset(e, r) {
    return Wt(this.fixed, r);
  }
  /**
   * Returns whether the offset is known to be fixed for the whole year:
   * Always returns true for all fixed offset zones.
   * @override
   * @type {boolean}
   */
  get isUniversal() {
    return !0;
  }
  /**
   * Return the offset in minutes for this zone at the specified timestamp.
   *
   * For fixed offset zones, this is constant and does not depend on a timestamp.
   * @override
   * @return {number}
   */
  offset() {
    return this.fixed;
  }
  /**
   * Return whether this Zone is equal to another zone (i.e. also fixed and same offset)
   * @override
   * @param {Zone} otherZone - the zone to compare
   * @return {boolean}
   */
  equals(e) {
    return e.type === "fixed" && e.fixed === this.fixed;
  }
  /**
   * Return whether this Zone is valid:
   * All fixed offset zones are valid.
   * @override
   * @type {boolean}
   */
  get isValid() {
    return !0;
  }
}
class wd extends Qt {
  constructor(e) {
    super(), this.zoneName = e;
  }
  /** @override **/
  get type() {
    return "invalid";
  }
  /** @override **/
  get name() {
    return this.zoneName;
  }
  /** @override **/
  get isUniversal() {
    return !1;
  }
  /** @override **/
  offsetName() {
    return null;
  }
  /** @override **/
  formatOffset() {
    return "";
  }
  /** @override **/
  offset() {
    return NaN;
  }
  /** @override **/
  equals() {
    return !1;
  }
  /** @override **/
  get isValid() {
    return !1;
  }
}
function Xe(t, e) {
  if (P(t) || t === null)
    return e;
  if (t instanceof Qt)
    return t;
  if (Nd(t)) {
    const r = t.toLowerCase();
    return r === "default" ? e : r === "local" || r === "system" ? $r.instance : r === "utc" || r === "gmt" ? Ie.utcInstance : Ie.parseSpecifier(r) || He.create(t);
  } else return Ke(t) ? Ie.instance(t) : typeof t == "object" && "offset" in t && typeof t.offset == "function" ? t : new wd(t);
}
const ns = {
  arab: "[٠-٩]",
  arabext: "[۰-۹]",
  bali: "[᭐-᭙]",
  beng: "[০-৯]",
  deva: "[०-९]",
  fullwide: "[０-９]",
  gujr: "[૦-૯]",
  hanidec: "[〇|一|二|三|四|五|六|七|八|九]",
  khmr: "[០-៩]",
  knda: "[೦-೯]",
  laoo: "[໐-໙]",
  limb: "[᥆-᥏]",
  mlym: "[൦-൯]",
  mong: "[᠐-᠙]",
  mymr: "[၀-၉]",
  orya: "[୦-୯]",
  tamldec: "[௦-௯]",
  telu: "[౦-౯]",
  thai: "[๐-๙]",
  tibt: "[༠-༩]",
  latn: "\\d"
}, wi = {
  arab: [1632, 1641],
  arabext: [1776, 1785],
  bali: [6992, 7001],
  beng: [2534, 2543],
  deva: [2406, 2415],
  fullwide: [65296, 65303],
  gujr: [2790, 2799],
  khmr: [6112, 6121],
  knda: [3302, 3311],
  laoo: [3792, 3801],
  limb: [6470, 6479],
  mlym: [3430, 3439],
  mong: [6160, 6169],
  mymr: [4160, 4169],
  orya: [2918, 2927],
  tamldec: [3046, 3055],
  telu: [3174, 3183],
  thai: [3664, 3673],
  tibt: [3872, 3881]
}, bd = ns.hanidec.replace(/[\[|\]]/g, "").split("");
function Td(t) {
  let e = parseInt(t, 10);
  if (isNaN(e)) {
    e = "";
    for (let r = 0; r < t.length; r++) {
      const n = t.charCodeAt(r);
      if (t[r].search(ns.hanidec) !== -1)
        e += bd.indexOf(t[r]);
      else
        for (const s in wi) {
          const [i, a] = wi[s];
          n >= i && n <= a && (e += n - i);
        }
    }
    return parseInt(e, 10);
  } else
    return e;
}
let Et = {};
function Sd() {
  Et = {};
}
function xe({ numberingSystem: t }, e = "") {
  const r = t || "latn";
  return Et[r] || (Et[r] = {}), Et[r][e] || (Et[r][e] = new RegExp(`${ns[r]}${e}`)), Et[r][e];
}
let bi = () => Date.now(), Ti = "system", Si = null, _i = null, Ii = null, Ni = 60, ki, Di = null;
class fe {
  /**
   * Get the callback for returning the current timestamp.
   * @type {function}
   */
  static get now() {
    return bi;
  }
  /**
   * Set the callback for returning the current timestamp.
   * The function should return a number, which will be interpreted as an Epoch millisecond count
   * @type {function}
   * @example Settings.now = () => Date.now() + 3000 // pretend it is 3 seconds in the future
   * @example Settings.now = () => 0 // always pretend it's Jan 1, 1970 at midnight in UTC time
   */
  static set now(e) {
    bi = e;
  }
  /**
   * Set the default time zone to create DateTimes in. Does not affect existing instances.
   * Use the value "system" to reset this value to the system's time zone.
   * @type {string}
   */
  static set defaultZone(e) {
    Ti = e;
  }
  /**
   * Get the default time zone object currently used to create DateTimes. Does not affect existing instances.
   * The default value is the system's time zone (the one set on the machine that runs this code).
   * @type {Zone}
   */
  static get defaultZone() {
    return Xe(Ti, $r.instance);
  }
  /**
   * Get the default locale to create DateTimes with. Does not affect existing instances.
   * @type {string}
   */
  static get defaultLocale() {
    return Si;
  }
  /**
   * Set the default locale to create DateTimes with. Does not affect existing instances.
   * @type {string}
   */
  static set defaultLocale(e) {
    Si = e;
  }
  /**
   * Get the default numbering system to create DateTimes with. Does not affect existing instances.
   * @type {string}
   */
  static get defaultNumberingSystem() {
    return _i;
  }
  /**
   * Set the default numbering system to create DateTimes with. Does not affect existing instances.
   * @type {string}
   */
  static set defaultNumberingSystem(e) {
    _i = e;
  }
  /**
   * Get the default output calendar to create DateTimes with. Does not affect existing instances.
   * @type {string}
   */
  static get defaultOutputCalendar() {
    return Ii;
  }
  /**
   * Set the default output calendar to create DateTimes with. Does not affect existing instances.
   * @type {string}
   */
  static set defaultOutputCalendar(e) {
    Ii = e;
  }
  /**
   * @typedef {Object} WeekSettings
   * @property {number} firstDay
   * @property {number} minimalDays
   * @property {number[]} weekend
   */
  /**
   * @return {WeekSettings|null}
   */
  static get defaultWeekSettings() {
    return Di;
  }
  /**
   * Allows overriding the default locale week settings, i.e. the start of the week, the weekend and
   * how many days are required in the first week of a year.
   * Does not affect existing instances.
   *
   * @param {WeekSettings|null} weekSettings
   */
  static set defaultWeekSettings(e) {
    Di = Yn(e);
  }
  /**
   * Get the cutoff year for whether a 2-digit year string is interpreted in the current or previous century. Numbers higher than the cutoff will be considered to mean 19xx and numbers lower or equal to the cutoff will be considered 20xx.
   * @type {number}
   */
  static get twoDigitCutoffYear() {
    return Ni;
  }
  /**
   * Set the cutoff year for whether a 2-digit year string is interpreted in the current or previous century. Numbers higher than the cutoff will be considered to mean 19xx and numbers lower or equal to the cutoff will be considered 20xx.
   * @type {number}
   * @example Settings.twoDigitCutoffYear = 0 // all 'yy' are interpreted as 20th century
   * @example Settings.twoDigitCutoffYear = 99 // all 'yy' are interpreted as 21st century
   * @example Settings.twoDigitCutoffYear = 50 // '49' -> 2049; '50' -> 1950
   * @example Settings.twoDigitCutoffYear = 1950 // interpreted as 50
   * @example Settings.twoDigitCutoffYear = 2050 // ALSO interpreted as 50
   */
  static set twoDigitCutoffYear(e) {
    Ni = e % 100;
  }
  /**
   * Get whether Luxon will throw when it encounters invalid DateTimes, Durations, or Intervals
   * @type {boolean}
   */
  static get throwOnInvalid() {
    return ki;
  }
  /**
   * Set whether Luxon will throw when it encounters invalid DateTimes, Durations, or Intervals
   * @type {boolean}
   */
  static set throwOnInvalid(e) {
    ki = e;
  }
  /**
   * Reset Luxon's global caches. Should only be necessary in testing scenarios.
   * @return {void}
   */
  static resetCaches() {
    X.resetCache(), He.resetCache(), F.resetCache(), Sd();
  }
}
class Fe {
  constructor(e, r) {
    this.reason = e, this.explanation = r;
  }
  toMessage() {
    return this.explanation ? `${this.reason}: ${this.explanation}` : this.reason;
  }
}
const lo = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334], fo = [0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335];
function Ce(t, e) {
  return new Fe(
    "unit out of range",
    `you specified ${e} (of type ${typeof e}) as a ${t}, which is invalid`
  );
}
function ss(t, e, r) {
  const n = new Date(Date.UTC(t, e - 1, r));
  t < 100 && t >= 0 && n.setUTCFullYear(n.getUTCFullYear() - 1900);
  const s = n.getUTCDay();
  return s === 0 ? 7 : s;
}
function ho(t, e, r) {
  return r + (Jt(t) ? fo : lo)[e - 1];
}
function po(t, e) {
  const r = Jt(t) ? fo : lo, n = r.findIndex((i) => i < e), s = e - r[n];
  return { month: n + 1, day: s };
}
function is(t, e) {
  return (t - e + 7) % 7 + 1;
}
function Mr(t, e = 4, r = 1) {
  const { year: n, month: s, day: i } = t, a = ho(n, s, i), u = is(ss(n, s, i), r);
  let c = Math.floor((a - u + 14 - e) / 7), l;
  return c < 1 ? (l = n - 1, c = Bt(l, e, r)) : c > Bt(n, e, r) ? (l = n + 1, c = 1) : l = n, { weekYear: l, weekNumber: c, weekday: u, ...zr(t) };
}
function Ci(t, e = 4, r = 1) {
  const { weekYear: n, weekNumber: s, weekday: i } = t, a = is(ss(n, 1, e), r), u = bt(n);
  let c = s * 7 + i - a - 7 + e, l;
  c < 1 ? (l = n - 1, c += bt(l)) : c > u ? (l = n + 1, c -= bt(n)) : l = n;
  const { month: d, day: v } = po(l, c);
  return { year: l, month: d, day: v, ...zr(t) };
}
function vn(t) {
  const { year: e, month: r, day: n } = t, s = ho(e, r, n);
  return { year: e, ordinal: s, ...zr(t) };
}
function Ai(t) {
  const { year: e, ordinal: r } = t, { month: n, day: s } = po(e, r);
  return { year: e, month: n, day: s, ...zr(t) };
}
function Ri(t, e) {
  if (!P(t.localWeekday) || !P(t.localWeekNumber) || !P(t.localWeekYear)) {
    if (!P(t.weekday) || !P(t.weekNumber) || !P(t.weekYear))
      throw new wt(
        "Cannot mix locale-based week fields with ISO-based week fields"
      );
    return P(t.localWeekday) || (t.weekday = t.localWeekday), P(t.localWeekNumber) || (t.weekNumber = t.localWeekNumber), P(t.localWeekYear) || (t.weekYear = t.localWeekYear), delete t.localWeekday, delete t.localWeekNumber, delete t.localWeekYear, {
      minDaysInFirstWeek: e.getMinDaysInFirstWeek(),
      startOfWeek: e.getStartOfWeek()
    };
  } else
    return { minDaysInFirstWeek: 4, startOfWeek: 1 };
}
function _d(t, e = 4, r = 1) {
  const n = Wr(t.weekYear), s = Ae(
    t.weekNumber,
    1,
    Bt(t.weekYear, e, r)
  ), i = Ae(t.weekday, 1, 7);
  return n ? s ? i ? !1 : Ce("weekday", t.weekday) : Ce("week", t.weekNumber) : Ce("weekYear", t.weekYear);
}
function Id(t) {
  const e = Wr(t.year), r = Ae(t.ordinal, 1, bt(t.year));
  return e ? r ? !1 : Ce("ordinal", t.ordinal) : Ce("year", t.year);
}
function mo(t) {
  const e = Wr(t.year), r = Ae(t.month, 1, 12), n = Ae(t.day, 1, Lr(t.year, t.month));
  return e ? r ? n ? !1 : Ce("day", t.day) : Ce("month", t.month) : Ce("year", t.year);
}
function yo(t) {
  const { hour: e, minute: r, second: n, millisecond: s } = t, i = Ae(e, 0, 23) || e === 24 && r === 0 && n === 0 && s === 0, a = Ae(r, 0, 59), u = Ae(n, 0, 59), c = Ae(s, 0, 999);
  return i ? a ? u ? c ? !1 : Ce("millisecond", s) : Ce("second", n) : Ce("minute", r) : Ce("hour", e);
}
function P(t) {
  return typeof t > "u";
}
function Ke(t) {
  return typeof t == "number";
}
function Wr(t) {
  return typeof t == "number" && t % 1 === 0;
}
function Nd(t) {
  return typeof t == "string";
}
function kd(t) {
  return Object.prototype.toString.call(t) === "[object Date]";
}
function vo() {
  try {
    return typeof Intl < "u" && !!Intl.RelativeTimeFormat;
  } catch {
    return !1;
  }
}
function go() {
  try {
    return typeof Intl < "u" && !!Intl.Locale && ("weekInfo" in Intl.Locale.prototype || "getWeekInfo" in Intl.Locale.prototype);
  } catch {
    return !1;
  }
}
function Dd(t) {
  return Array.isArray(t) ? t : [t];
}
function xi(t, e, r) {
  if (t.length !== 0)
    return t.reduce((n, s) => {
      const i = [e(s), s];
      return n && r(n[0], i[0]) === n[0] ? n : i;
    }, null)[1];
}
function Cd(t, e) {
  return e.reduce((r, n) => (r[n] = t[n], r), {});
}
function St(t, e) {
  return Object.prototype.hasOwnProperty.call(t, e);
}
function Yn(t) {
  if (t == null)
    return null;
  if (typeof t != "object")
    throw new we("Week settings must be an object");
  if (!Ae(t.firstDay, 1, 7) || !Ae(t.minimalDays, 1, 7) || !Array.isArray(t.weekend) || t.weekend.some((e) => !Ae(e, 1, 7)))
    throw new we("Invalid week settings");
  return {
    firstDay: t.firstDay,
    minimalDays: t.minimalDays,
    weekend: Array.from(t.weekend)
  };
}
function Ae(t, e, r) {
  return Wr(t) && t >= e && t <= r;
}
function Ad(t, e) {
  return t - e * Math.floor(t / e);
}
function me(t, e = 2) {
  const r = t < 0;
  let n;
  return r ? n = "-" + ("" + -t).padStart(e, "0") : n = ("" + t).padStart(e, "0"), n;
}
function Je(t) {
  if (!(P(t) || t === null || t === ""))
    return parseInt(t, 10);
}
function tt(t) {
  if (!(P(t) || t === null || t === ""))
    return parseFloat(t);
}
function as(t) {
  if (!(P(t) || t === null || t === "")) {
    const e = parseFloat("0." + t) * 1e3;
    return Math.floor(e);
  }
}
function os(t, e, r = !1) {
  const n = 10 ** e;
  return (r ? Math.trunc : Math.round)(t * n) / n;
}
function Jt(t) {
  return t % 4 === 0 && (t % 100 !== 0 || t % 400 === 0);
}
function bt(t) {
  return Jt(t) ? 366 : 365;
}
function Lr(t, e) {
  const r = Ad(e - 1, 12) + 1, n = t + (e - r) / 12;
  return r === 2 ? Jt(n) ? 29 : 28 : [31, null, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][r - 1];
}
function Hr(t) {
  let e = Date.UTC(
    t.year,
    t.month - 1,
    t.day,
    t.hour,
    t.minute,
    t.second,
    t.millisecond
  );
  return t.year < 100 && t.year >= 0 && (e = new Date(e), e.setUTCFullYear(t.year, t.month - 1, t.day)), +e;
}
function Mi(t, e, r) {
  return -is(ss(t, 1, e), r) + e - 1;
}
function Bt(t, e = 4, r = 1) {
  const n = Mi(t, e, r), s = Mi(t + 1, e, r);
  return (bt(t) - n + s) / 7;
}
function Bn(t) {
  return t > 99 ? t : t > fe.twoDigitCutoffYear ? 1900 + t : 2e3 + t;
}
function Eo(t, e, r, n = null) {
  const s = new Date(t), i = {
    hourCycle: "h23",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit"
  };
  n && (i.timeZone = n);
  const a = { timeZoneName: e, ...i }, u = new Intl.DateTimeFormat(r, a).formatToParts(s).find((c) => c.type.toLowerCase() === "timezonename");
  return u ? u.value : null;
}
function jr(t, e) {
  let r = parseInt(t, 10);
  Number.isNaN(r) && (r = 0);
  const n = parseInt(e, 10) || 0, s = r < 0 || Object.is(r, -0) ? -n : n;
  return r * 60 + s;
}
function Oo(t) {
  const e = Number(t);
  if (typeof t == "boolean" || t === "" || Number.isNaN(e))
    throw new we(`Invalid unit value ${t}`);
  return e;
}
function Fr(t, e) {
  const r = {};
  for (const n in t)
    if (St(t, n)) {
      const s = t[n];
      if (s == null) continue;
      r[e(n)] = Oo(s);
    }
  return r;
}
function Wt(t, e) {
  const r = Math.trunc(Math.abs(t / 60)), n = Math.trunc(Math.abs(t % 60)), s = t >= 0 ? "+" : "-";
  switch (e) {
    case "short":
      return `${s}${me(r, 2)}:${me(n, 2)}`;
    case "narrow":
      return `${s}${r}${n > 0 ? `:${n}` : ""}`;
    case "techie":
      return `${s}${me(r, 2)}${me(n, 2)}`;
    default:
      throw new RangeError(`Value format ${e} is out of range for property format`);
  }
}
function zr(t) {
  return Cd(t, ["hour", "minute", "second", "millisecond"]);
}
const Rd = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December"
], wo = [
  "Jan",
  "Feb",
  "Mar",
  "Apr",
  "May",
  "Jun",
  "Jul",
  "Aug",
  "Sep",
  "Oct",
  "Nov",
  "Dec"
], xd = ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"];
function bo(t) {
  switch (t) {
    case "narrow":
      return [...xd];
    case "short":
      return [...wo];
    case "long":
      return [...Rd];
    case "numeric":
      return ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"];
    case "2-digit":
      return ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"];
    default:
      return null;
  }
}
const To = [
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
  "Sunday"
], So = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"], Md = ["M", "T", "W", "T", "F", "S", "S"];
function _o(t) {
  switch (t) {
    case "narrow":
      return [...Md];
    case "short":
      return [...So];
    case "long":
      return [...To];
    case "numeric":
      return ["1", "2", "3", "4", "5", "6", "7"];
    default:
      return null;
  }
}
const Io = ["AM", "PM"], Ld = ["Before Christ", "Anno Domini"], Fd = ["BC", "AD"], Pd = ["B", "A"];
function No(t) {
  switch (t) {
    case "narrow":
      return [...Pd];
    case "short":
      return [...Fd];
    case "long":
      return [...Ld];
    default:
      return null;
  }
}
function Vd(t) {
  return Io[t.hour < 12 ? 0 : 1];
}
function Ud(t, e) {
  return _o(e)[t.weekday - 1];
}
function $d(t, e) {
  return bo(e)[t.month - 1];
}
function Wd(t, e) {
  return No(e)[t.year < 0 ? 0 : 1];
}
function Hd(t, e, r = "always", n = !1) {
  const s = {
    years: ["year", "yr."],
    quarters: ["quarter", "qtr."],
    months: ["month", "mo."],
    weeks: ["week", "wk."],
    days: ["day", "day", "days"],
    hours: ["hour", "hr."],
    minutes: ["minute", "min."],
    seconds: ["second", "sec."]
  }, i = ["hours", "minutes", "seconds"].indexOf(t) === -1;
  if (r === "auto" && i) {
    const v = t === "days";
    switch (e) {
      case 1:
        return v ? "tomorrow" : `next ${s[t][0]}`;
      case -1:
        return v ? "yesterday" : `last ${s[t][0]}`;
      case 0:
        return v ? "today" : `this ${s[t][0]}`;
    }
  }
  const a = Object.is(e, -0) || e < 0, u = Math.abs(e), c = u === 1, l = s[t], d = n ? c ? l[1] : l[2] || l[1] : c ? s[t][0] : t;
  return a ? `${u} ${d} ago` : `in ${u} ${d}`;
}
function Li(t, e) {
  let r = "";
  for (const n of t)
    n.literal ? r += n.val : r += e(n.val);
  return r;
}
const jd = {
  D: xr,
  DD: Ya,
  DDD: Ba,
  DDDD: qa,
  t: Ga,
  tt: Za,
  ttt: Qa,
  tttt: Ja,
  T: Xa,
  TT: Ka,
  TTT: eo,
  TTTT: to,
  f: ro,
  ff: so,
  fff: ao,
  ffff: uo,
  F: no,
  FF: io,
  FFF: oo,
  FFFF: co
};
class be {
  static create(e, r = {}) {
    return new be(e, r);
  }
  static parseFormat(e) {
    let r = null, n = "", s = !1;
    const i = [];
    for (let a = 0; a < e.length; a++) {
      const u = e.charAt(a);
      u === "'" ? (n.length > 0 && i.push({ literal: s || /^\s+$/.test(n), val: n }), r = null, n = "", s = !s) : s || u === r ? n += u : (n.length > 0 && i.push({ literal: /^\s+$/.test(n), val: n }), n = u, r = u);
    }
    return n.length > 0 && i.push({ literal: s || /^\s+$/.test(n), val: n }), i;
  }
  static macroTokenToFormatOpts(e) {
    return jd[e];
  }
  constructor(e, r) {
    this.opts = r, this.loc = e, this.systemLoc = null;
  }
  formatWithSystemDefault(e, r) {
    return this.systemLoc === null && (this.systemLoc = this.loc.redefaultToSystem()), this.systemLoc.dtFormatter(e, { ...this.opts, ...r }).format();
  }
  dtFormatter(e, r = {}) {
    return this.loc.dtFormatter(e, { ...this.opts, ...r });
  }
  formatDateTime(e, r) {
    return this.dtFormatter(e, r).format();
  }
  formatDateTimeParts(e, r) {
    return this.dtFormatter(e, r).formatToParts();
  }
  formatInterval(e, r) {
    return this.dtFormatter(e.start, r).dtf.formatRange(e.start.toJSDate(), e.end.toJSDate());
  }
  resolvedOptions(e, r) {
    return this.dtFormatter(e, r).resolvedOptions();
  }
  num(e, r = 0) {
    if (this.opts.forceSimple)
      return me(e, r);
    const n = { ...this.opts };
    return r > 0 && (n.padTo = r), this.loc.numberFormatter(n).format(e);
  }
  formatDateTimeFromString(e, r) {
    const n = this.loc.listingMode() === "en", s = this.loc.outputCalendar && this.loc.outputCalendar !== "gregory", i = (O, I) => this.loc.extract(e, O, I), a = (O) => e.isOffsetFixed && e.offset === 0 && O.allowZ ? "Z" : e.isValid ? e.zone.formatOffset(e.ts, O.format) : "", u = () => n ? Vd(e) : i({ hour: "numeric", hourCycle: "h12" }, "dayperiod"), c = (O, I) => n ? $d(e, O) : i(I ? { month: O } : { month: O, day: "numeric" }, "month"), l = (O, I) => n ? Ud(e, O) : i(
      I ? { weekday: O } : { weekday: O, month: "long", day: "numeric" },
      "weekday"
    ), d = (O) => {
      const I = be.macroTokenToFormatOpts(O);
      return I ? this.formatWithSystemDefault(e, I) : O;
    }, v = (O) => n ? Wd(e, O) : i({ era: O }, "era"), T = (O) => {
      switch (O) {
        case "S":
          return this.num(e.millisecond);
        case "u":
        case "SSS":
          return this.num(e.millisecond, 3);
        case "s":
          return this.num(e.second);
        case "ss":
          return this.num(e.second, 2);
        case "uu":
          return this.num(Math.floor(e.millisecond / 10), 2);
        case "uuu":
          return this.num(Math.floor(e.millisecond / 100));
        case "m":
          return this.num(e.minute);
        case "mm":
          return this.num(e.minute, 2);
        case "h":
          return this.num(e.hour % 12 === 0 ? 12 : e.hour % 12);
        case "hh":
          return this.num(e.hour % 12 === 0 ? 12 : e.hour % 12, 2);
        case "H":
          return this.num(e.hour);
        case "HH":
          return this.num(e.hour, 2);
        case "Z":
          return a({ format: "narrow", allowZ: this.opts.allowZ });
        case "ZZ":
          return a({ format: "short", allowZ: this.opts.allowZ });
        case "ZZZ":
          return a({ format: "techie", allowZ: this.opts.allowZ });
        case "ZZZZ":
          return e.zone.offsetName(e.ts, { format: "short", locale: this.loc.locale });
        case "ZZZZZ":
          return e.zone.offsetName(e.ts, { format: "long", locale: this.loc.locale });
        case "z":
          return e.zoneName;
        case "a":
          return u();
        case "d":
          return s ? i({ day: "numeric" }, "day") : this.num(e.day);
        case "dd":
          return s ? i({ day: "2-digit" }, "day") : this.num(e.day, 2);
        case "c":
          return this.num(e.weekday);
        case "ccc":
          return l("short", !0);
        case "cccc":
          return l("long", !0);
        case "ccccc":
          return l("narrow", !0);
        case "E":
          return this.num(e.weekday);
        case "EEE":
          return l("short", !1);
        case "EEEE":
          return l("long", !1);
        case "EEEEE":
          return l("narrow", !1);
        case "L":
          return s ? i({ month: "numeric", day: "numeric" }, "month") : this.num(e.month);
        case "LL":
          return s ? i({ month: "2-digit", day: "numeric" }, "month") : this.num(e.month, 2);
        case "LLL":
          return c("short", !0);
        case "LLLL":
          return c("long", !0);
        case "LLLLL":
          return c("narrow", !0);
        case "M":
          return s ? i({ month: "numeric" }, "month") : this.num(e.month);
        case "MM":
          return s ? i({ month: "2-digit" }, "month") : this.num(e.month, 2);
        case "MMM":
          return c("short", !1);
        case "MMMM":
          return c("long", !1);
        case "MMMMM":
          return c("narrow", !1);
        case "y":
          return s ? i({ year: "numeric" }, "year") : this.num(e.year);
        case "yy":
          return s ? i({ year: "2-digit" }, "year") : this.num(e.year.toString().slice(-2), 2);
        case "yyyy":
          return s ? i({ year: "numeric" }, "year") : this.num(e.year, 4);
        case "yyyyyy":
          return s ? i({ year: "numeric" }, "year") : this.num(e.year, 6);
        case "G":
          return v("short");
        case "GG":
          return v("long");
        case "GGGGG":
          return v("narrow");
        case "kk":
          return this.num(e.weekYear.toString().slice(-2), 2);
        case "kkkk":
          return this.num(e.weekYear, 4);
        case "W":
          return this.num(e.weekNumber);
        case "WW":
          return this.num(e.weekNumber, 2);
        case "n":
          return this.num(e.localWeekNumber);
        case "nn":
          return this.num(e.localWeekNumber, 2);
        case "ii":
          return this.num(e.localWeekYear.toString().slice(-2), 2);
        case "iiii":
          return this.num(e.localWeekYear, 4);
        case "o":
          return this.num(e.ordinal);
        case "ooo":
          return this.num(e.ordinal, 3);
        case "q":
          return this.num(e.quarter);
        case "qq":
          return this.num(e.quarter, 2);
        case "X":
          return this.num(Math.floor(e.ts / 1e3));
        case "x":
          return this.num(e.ts);
        default:
          return d(O);
      }
    };
    return Li(be.parseFormat(r), T);
  }
  formatDurationFromString(e, r) {
    const n = (c) => {
      switch (c[0]) {
        case "S":
          return "millisecond";
        case "s":
          return "second";
        case "m":
          return "minute";
        case "h":
          return "hour";
        case "d":
          return "day";
        case "w":
          return "week";
        case "M":
          return "month";
        case "y":
          return "year";
        default:
          return null;
      }
    }, s = (c) => (l) => {
      const d = n(l);
      return d ? this.num(c.get(d), l.length) : l;
    }, i = be.parseFormat(r), a = i.reduce(
      (c, { literal: l, val: d }) => l ? c : c.concat(d),
      []
    ), u = e.shiftTo(...a.map(n).filter((c) => c));
    return Li(i, s(u));
  }
}
const ko = /[A-Za-z_+-]{1,256}(?::?\/[A-Za-z0-9_+-]{1,256}(?:\/[A-Za-z0-9_+-]{1,256})?)?/;
function It(...t) {
  const e = t.reduce((r, n) => r + n.source, "");
  return RegExp(`^${e}$`);
}
function Nt(...t) {
  return (e) => t.reduce(
    ([r, n, s], i) => {
      const [a, u, c] = i(e, s);
      return [{ ...r, ...a }, u || n, c];
    },
    [{}, null, 1]
  ).slice(0, 2);
}
function kt(t, ...e) {
  if (t == null)
    return [null, null];
  for (const [r, n] of e) {
    const s = r.exec(t);
    if (s)
      return n(s);
  }
  return [null, null];
}
function Do(...t) {
  return (e, r) => {
    const n = {};
    let s;
    for (s = 0; s < t.length; s++)
      n[t[s]] = Je(e[r + s]);
    return [n, null, r + s];
  };
}
const Co = /(?:(Z)|([+-]\d\d)(?::?(\d\d))?)/, zd = `(?:${Co.source}?(?:\\[(${ko.source})\\])?)?`, us = /(\d\d)(?::?(\d\d)(?::?(\d\d)(?:[.,](\d{1,30}))?)?)?/, Ao = RegExp(`${us.source}${zd}`), cs = RegExp(`(?:T${Ao.source})?`), Yd = /([+-]\d{6}|\d{4})(?:-?(\d\d)(?:-?(\d\d))?)?/, Bd = /(\d{4})-?W(\d\d)(?:-?(\d))?/, qd = /(\d{4})-?(\d{3})/, Gd = Do("weekYear", "weekNumber", "weekDay"), Zd = Do("year", "ordinal"), Qd = /(\d{4})-(\d\d)-(\d\d)/, Ro = RegExp(
  `${us.source} ?(?:${Co.source}|(${ko.source}))?`
), Jd = RegExp(`(?: ${Ro.source})?`);
function Tt(t, e, r) {
  const n = t[e];
  return P(n) ? r : Je(n);
}
function Xd(t, e) {
  return [{
    year: Tt(t, e),
    month: Tt(t, e + 1, 1),
    day: Tt(t, e + 2, 1)
  }, null, e + 3];
}
function Dt(t, e) {
  return [{
    hours: Tt(t, e, 0),
    minutes: Tt(t, e + 1, 0),
    seconds: Tt(t, e + 2, 0),
    milliseconds: as(t[e + 3])
  }, null, e + 4];
}
function Xt(t, e) {
  const r = !t[e] && !t[e + 1], n = jr(t[e + 1], t[e + 2]), s = r ? null : Ie.instance(n);
  return [{}, s, e + 3];
}
function Kt(t, e) {
  const r = t[e] ? He.create(t[e]) : null;
  return [{}, r, e + 1];
}
const Kd = RegExp(`^T?${us.source}$`), eh = /^-?P(?:(?:(-?\d{1,20}(?:\.\d{1,20})?)Y)?(?:(-?\d{1,20}(?:\.\d{1,20})?)M)?(?:(-?\d{1,20}(?:\.\d{1,20})?)W)?(?:(-?\d{1,20}(?:\.\d{1,20})?)D)?(?:T(?:(-?\d{1,20}(?:\.\d{1,20})?)H)?(?:(-?\d{1,20}(?:\.\d{1,20})?)M)?(?:(-?\d{1,20})(?:[.,](-?\d{1,20}))?S)?)?)$/;
function th(t) {
  const [e, r, n, s, i, a, u, c, l] = t, d = e[0] === "-", v = c && c[0] === "-", T = (O, I = !1) => O !== void 0 && (I || O && d) ? -O : O;
  return [
    {
      years: T(tt(r)),
      months: T(tt(n)),
      weeks: T(tt(s)),
      days: T(tt(i)),
      hours: T(tt(a)),
      minutes: T(tt(u)),
      seconds: T(tt(c), c === "-0"),
      milliseconds: T(as(l), v)
    }
  ];
}
const rh = {
  GMT: 0,
  EDT: -4 * 60,
  EST: -5 * 60,
  CDT: -5 * 60,
  CST: -6 * 60,
  MDT: -6 * 60,
  MST: -7 * 60,
  PDT: -7 * 60,
  PST: -8 * 60
};
function ls(t, e, r, n, s, i, a) {
  const u = {
    year: e.length === 2 ? Bn(Je(e)) : Je(e),
    month: wo.indexOf(r) + 1,
    day: Je(n),
    hour: Je(s),
    minute: Je(i)
  };
  return a && (u.second = Je(a)), t && (u.weekday = t.length > 3 ? To.indexOf(t) + 1 : So.indexOf(t) + 1), u;
}
const nh = /^(?:(Mon|Tue|Wed|Thu|Fri|Sat|Sun),\s)?(\d{1,2})\s(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s(\d{2,4})\s(\d\d):(\d\d)(?::(\d\d))?\s(?:(UT|GMT|[ECMP][SD]T)|([Zz])|(?:([+-]\d\d)(\d\d)))$/;
function sh(t) {
  const [
    ,
    e,
    r,
    n,
    s,
    i,
    a,
    u,
    c,
    l,
    d,
    v
  ] = t, T = ls(e, s, n, r, i, a, u);
  let O;
  return c ? O = rh[c] : l ? O = 0 : O = jr(d, v), [T, new Ie(O)];
}
function ih(t) {
  return t.replace(/\([^()]*\)|[\n\t]/g, " ").replace(/(\s\s+)/g, " ").trim();
}
const ah = /^(Mon|Tue|Wed|Thu|Fri|Sat|Sun), (\d\d) (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) (\d{4}) (\d\d):(\d\d):(\d\d) GMT$/, oh = /^(Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday), (\d\d)-(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)-(\d\d) (\d\d):(\d\d):(\d\d) GMT$/, uh = /^(Mon|Tue|Wed|Thu|Fri|Sat|Sun) (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) ( \d|\d\d) (\d\d):(\d\d):(\d\d) (\d{4})$/;
function Fi(t) {
  const [, e, r, n, s, i, a, u] = t;
  return [ls(e, s, n, r, i, a, u), Ie.utcInstance];
}
function ch(t) {
  const [, e, r, n, s, i, a, u] = t;
  return [ls(e, u, r, n, s, i, a), Ie.utcInstance];
}
const lh = It(Yd, cs), fh = It(Bd, cs), dh = It(qd, cs), hh = It(Ao), xo = Nt(
  Xd,
  Dt,
  Xt,
  Kt
), ph = Nt(
  Gd,
  Dt,
  Xt,
  Kt
), mh = Nt(
  Zd,
  Dt,
  Xt,
  Kt
), yh = Nt(
  Dt,
  Xt,
  Kt
);
function vh(t) {
  return kt(
    t,
    [lh, xo],
    [fh, ph],
    [dh, mh],
    [hh, yh]
  );
}
function gh(t) {
  return kt(ih(t), [nh, sh]);
}
function Eh(t) {
  return kt(
    t,
    [ah, Fi],
    [oh, Fi],
    [uh, ch]
  );
}
function Oh(t) {
  return kt(t, [eh, th]);
}
const wh = Nt(Dt);
function bh(t) {
  return kt(t, [Kd, wh]);
}
const Th = It(Qd, Jd), Sh = It(Ro), _h = Nt(
  Dt,
  Xt,
  Kt
);
function Ih(t) {
  return kt(
    t,
    [Th, xo],
    [Sh, _h]
  );
}
const Pi = "Invalid Duration", Mo = {
  weeks: {
    days: 7,
    hours: 7 * 24,
    minutes: 7 * 24 * 60,
    seconds: 7 * 24 * 60 * 60,
    milliseconds: 7 * 24 * 60 * 60 * 1e3
  },
  days: {
    hours: 24,
    minutes: 24 * 60,
    seconds: 24 * 60 * 60,
    milliseconds: 24 * 60 * 60 * 1e3
  },
  hours: { minutes: 60, seconds: 60 * 60, milliseconds: 60 * 60 * 1e3 },
  minutes: { seconds: 60, milliseconds: 60 * 1e3 },
  seconds: { milliseconds: 1e3 }
}, Nh = {
  years: {
    quarters: 4,
    months: 12,
    weeks: 52,
    days: 365,
    hours: 365 * 24,
    minutes: 365 * 24 * 60,
    seconds: 365 * 24 * 60 * 60,
    milliseconds: 365 * 24 * 60 * 60 * 1e3
  },
  quarters: {
    months: 3,
    weeks: 13,
    days: 91,
    hours: 91 * 24,
    minutes: 91 * 24 * 60,
    seconds: 91 * 24 * 60 * 60,
    milliseconds: 91 * 24 * 60 * 60 * 1e3
  },
  months: {
    weeks: 4,
    days: 30,
    hours: 30 * 24,
    minutes: 30 * 24 * 60,
    seconds: 30 * 24 * 60 * 60,
    milliseconds: 30 * 24 * 60 * 60 * 1e3
  },
  ...Mo
}, De = 146097 / 400, yt = 146097 / 4800, kh = {
  years: {
    quarters: 4,
    months: 12,
    weeks: De / 7,
    days: De,
    hours: De * 24,
    minutes: De * 24 * 60,
    seconds: De * 24 * 60 * 60,
    milliseconds: De * 24 * 60 * 60 * 1e3
  },
  quarters: {
    months: 3,
    weeks: De / 28,
    days: De / 4,
    hours: De * 24 / 4,
    minutes: De * 24 * 60 / 4,
    seconds: De * 24 * 60 * 60 / 4,
    milliseconds: De * 24 * 60 * 60 * 1e3 / 4
  },
  months: {
    weeks: yt / 7,
    days: yt,
    hours: yt * 24,
    minutes: yt * 24 * 60,
    seconds: yt * 24 * 60 * 60,
    milliseconds: yt * 24 * 60 * 60 * 1e3
  },
  ...Mo
}, at = [
  "years",
  "quarters",
  "months",
  "weeks",
  "days",
  "hours",
  "minutes",
  "seconds",
  "milliseconds"
], Dh = at.slice(0).reverse();
function Ze(t, e, r = !1) {
  const n = {
    values: r ? e.values : { ...t.values, ...e.values || {} },
    loc: t.loc.clone(e.loc),
    conversionAccuracy: e.conversionAccuracy || t.conversionAccuracy,
    matrix: e.matrix || t.matrix
  };
  return new G(n);
}
function Lo(t, e) {
  let r = e.milliseconds ?? 0;
  for (const n of Dh.slice(1))
    e[n] && (r += e[n] * t[n].milliseconds);
  return r;
}
function Vi(t, e) {
  const r = Lo(t, e) < 0 ? -1 : 1;
  at.reduceRight((n, s) => {
    if (P(e[s]))
      return n;
    if (n) {
      const i = e[n] * r, a = t[s][n], u = Math.floor(i / a);
      e[s] += u * r, e[n] -= u * a * r;
    }
    return s;
  }, null), at.reduce((n, s) => {
    if (P(e[s]))
      return n;
    if (n) {
      const i = e[n] % 1;
      e[n] -= i, e[s] += i * t[n][s];
    }
    return s;
  }, null);
}
function Ch(t) {
  const e = {};
  for (const [r, n] of Object.entries(t))
    n !== 0 && (e[r] = n);
  return e;
}
class G {
  /**
   * @private
   */
  constructor(e) {
    const r = e.conversionAccuracy === "longterm" || !1;
    let n = r ? kh : Nh;
    e.matrix && (n = e.matrix), this.values = e.values, this.loc = e.loc || X.create(), this.conversionAccuracy = r ? "longterm" : "casual", this.invalid = e.invalid || null, this.matrix = n, this.isLuxonDuration = !0;
  }
  /**
   * Create Duration from a number of milliseconds.
   * @param {number} count of milliseconds
   * @param {Object} opts - options for parsing
   * @param {string} [opts.locale='en-US'] - the locale to use
   * @param {string} opts.numberingSystem - the numbering system to use
   * @param {string} [opts.conversionAccuracy='casual'] - the conversion system to use
   * @return {Duration}
   */
  static fromMillis(e, r) {
    return G.fromObject({ milliseconds: e }, r);
  }
  /**
   * Create a Duration from a JavaScript object with keys like 'years' and 'hours'.
   * If this object is empty then a zero milliseconds duration is returned.
   * @param {Object} obj - the object to create the DateTime from
   * @param {number} obj.years
   * @param {number} obj.quarters
   * @param {number} obj.months
   * @param {number} obj.weeks
   * @param {number} obj.days
   * @param {number} obj.hours
   * @param {number} obj.minutes
   * @param {number} obj.seconds
   * @param {number} obj.milliseconds
   * @param {Object} [opts=[]] - options for creating this Duration
   * @param {string} [opts.locale='en-US'] - the locale to use
   * @param {string} opts.numberingSystem - the numbering system to use
   * @param {string} [opts.conversionAccuracy='casual'] - the preset conversion system to use
   * @param {string} [opts.matrix=Object] - the custom conversion system to use
   * @return {Duration}
   */
  static fromObject(e, r = {}) {
    if (e == null || typeof e != "object")
      throw new we(
        `Duration.fromObject: argument expected to be an object, got ${e === null ? "null" : typeof e}`
      );
    return new G({
      values: Fr(e, G.normalizeUnit),
      loc: X.fromObject(r),
      conversionAccuracy: r.conversionAccuracy,
      matrix: r.matrix
    });
  }
  /**
   * Create a Duration from DurationLike.
   *
   * @param {Object | number | Duration} durationLike
   * One of:
   * - object with keys like 'years' and 'hours'.
   * - number representing milliseconds
   * - Duration instance
   * @return {Duration}
   */
  static fromDurationLike(e) {
    if (Ke(e))
      return G.fromMillis(e);
    if (G.isDuration(e))
      return e;
    if (typeof e == "object")
      return G.fromObject(e);
    throw new we(
      `Unknown duration argument ${e} of type ${typeof e}`
    );
  }
  /**
   * Create a Duration from an ISO 8601 duration string.
   * @param {string} text - text to parse
   * @param {Object} opts - options for parsing
   * @param {string} [opts.locale='en-US'] - the locale to use
   * @param {string} opts.numberingSystem - the numbering system to use
   * @param {string} [opts.conversionAccuracy='casual'] - the preset conversion system to use
   * @param {string} [opts.matrix=Object] - the preset conversion system to use
   * @see https://en.wikipedia.org/wiki/ISO_8601#Durations
   * @example Duration.fromISO('P3Y6M1W4DT12H30M5S').toObject() //=> { years: 3, months: 6, weeks: 1, days: 4, hours: 12, minutes: 30, seconds: 5 }
   * @example Duration.fromISO('PT23H').toObject() //=> { hours: 23 }
   * @example Duration.fromISO('P5Y3M').toObject() //=> { years: 5, months: 3 }
   * @return {Duration}
   */
  static fromISO(e, r) {
    const [n] = Oh(e);
    return n ? G.fromObject(n, r) : G.invalid("unparsable", `the input "${e}" can't be parsed as ISO 8601`);
  }
  /**
   * Create a Duration from an ISO 8601 time string.
   * @param {string} text - text to parse
   * @param {Object} opts - options for parsing
   * @param {string} [opts.locale='en-US'] - the locale to use
   * @param {string} opts.numberingSystem - the numbering system to use
   * @param {string} [opts.conversionAccuracy='casual'] - the preset conversion system to use
   * @param {string} [opts.matrix=Object] - the conversion system to use
   * @see https://en.wikipedia.org/wiki/ISO_8601#Times
   * @example Duration.fromISOTime('11:22:33.444').toObject() //=> { hours: 11, minutes: 22, seconds: 33, milliseconds: 444 }
   * @example Duration.fromISOTime('11:00').toObject() //=> { hours: 11, minutes: 0, seconds: 0 }
   * @example Duration.fromISOTime('T11:00').toObject() //=> { hours: 11, minutes: 0, seconds: 0 }
   * @example Duration.fromISOTime('1100').toObject() //=> { hours: 11, minutes: 0, seconds: 0 }
   * @example Duration.fromISOTime('T1100').toObject() //=> { hours: 11, minutes: 0, seconds: 0 }
   * @return {Duration}
   */
  static fromISOTime(e, r) {
    const [n] = bh(e);
    return n ? G.fromObject(n, r) : G.invalid("unparsable", `the input "${e}" can't be parsed as ISO 8601`);
  }
  /**
   * Create an invalid Duration.
   * @param {string} reason - simple string of why this datetime is invalid. Should not contain parameters or anything else data-dependent
   * @param {string} [explanation=null] - longer explanation, may include parameters and other useful debugging information
   * @return {Duration}
   */
  static invalid(e, r = null) {
    if (!e)
      throw new we("need to specify a reason the Duration is invalid");
    const n = e instanceof Fe ? e : new Fe(e, r);
    if (fe.throwOnInvalid)
      throw new ed(n);
    return new G({ invalid: n });
  }
  /**
   * @private
   */
  static normalizeUnit(e) {
    const r = {
      year: "years",
      years: "years",
      quarter: "quarters",
      quarters: "quarters",
      month: "months",
      months: "months",
      week: "weeks",
      weeks: "weeks",
      day: "days",
      days: "days",
      hour: "hours",
      hours: "hours",
      minute: "minutes",
      minutes: "minutes",
      second: "seconds",
      seconds: "seconds",
      millisecond: "milliseconds",
      milliseconds: "milliseconds"
    }[e && e.toLowerCase()];
    if (!r) throw new za(e);
    return r;
  }
  /**
   * Check if an object is a Duration. Works across context boundaries
   * @param {object} o
   * @return {boolean}
   */
  static isDuration(e) {
    return e && e.isLuxonDuration || !1;
  }
  /**
   * Get  the locale of a Duration, such 'en-GB'
   * @type {string}
   */
  get locale() {
    return this.isValid ? this.loc.locale : null;
  }
  /**
   * Get the numbering system of a Duration, such 'beng'. The numbering system is used when formatting the Duration
   *
   * @type {string}
   */
  get numberingSystem() {
    return this.isValid ? this.loc.numberingSystem : null;
  }
  /**
   * Returns a string representation of this Duration formatted according to the specified format string. You may use these tokens:
   * * `S` for milliseconds
   * * `s` for seconds
   * * `m` for minutes
   * * `h` for hours
   * * `d` for days
   * * `w` for weeks
   * * `M` for months
   * * `y` for years
   * Notes:
   * * Add padding by repeating the token, e.g. "yy" pads the years to two digits, "hhhh" pads the hours out to four digits
   * * Tokens can be escaped by wrapping with single quotes.
   * * The duration will be converted to the set of units in the format string using {@link Duration#shiftTo} and the Durations's conversion accuracy setting.
   * @param {string} fmt - the format string
   * @param {Object} opts - options
   * @param {boolean} [opts.floor=true] - floor numerical values
   * @example Duration.fromObject({ years: 1, days: 6, seconds: 2 }).toFormat("y d s") //=> "1 6 2"
   * @example Duration.fromObject({ years: 1, days: 6, seconds: 2 }).toFormat("yy dd sss") //=> "01 06 002"
   * @example Duration.fromObject({ years: 1, days: 6, seconds: 2 }).toFormat("M S") //=> "12 518402000"
   * @return {string}
   */
  toFormat(e, r = {}) {
    const n = {
      ...r,
      floor: r.round !== !1 && r.floor !== !1
    };
    return this.isValid ? be.create(this.loc, n).formatDurationFromString(this, e) : Pi;
  }
  /**
   * Returns a string representation of a Duration with all units included.
   * To modify its behavior, use `listStyle` and any Intl.NumberFormat option, though `unitDisplay` is especially relevant.
   * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Intl/NumberFormat/NumberFormat#options
   * @param {Object} opts - Formatting options. Accepts the same keys as the options parameter of the native `Intl.NumberFormat` constructor, as well as `listStyle`.
   * @param {string} [opts.listStyle='narrow'] - How to format the merged list. Corresponds to the `style` property of the options parameter of the native `Intl.ListFormat` constructor.
   * @example
   * ```js
   * var dur = Duration.fromObject({ days: 1, hours: 5, minutes: 6 })
   * dur.toHuman() //=> '1 day, 5 hours, 6 minutes'
   * dur.toHuman({ listStyle: "long" }) //=> '1 day, 5 hours, and 6 minutes'
   * dur.toHuman({ unitDisplay: "short" }) //=> '1 day, 5 hr, 6 min'
   * ```
   */
  toHuman(e = {}) {
    if (!this.isValid) return Pi;
    const r = at.map((n) => {
      const s = this.values[n];
      return P(s) ? null : this.loc.numberFormatter({ style: "unit", unitDisplay: "long", ...e, unit: n.slice(0, -1) }).format(s);
    }).filter((n) => n);
    return this.loc.listFormatter({ type: "conjunction", style: e.listStyle || "narrow", ...e }).format(r);
  }
  /**
   * Returns a JavaScript object with this Duration's values.
   * @example Duration.fromObject({ years: 1, days: 6, seconds: 2 }).toObject() //=> { years: 1, days: 6, seconds: 2 }
   * @return {Object}
   */
  toObject() {
    return this.isValid ? { ...this.values } : {};
  }
  /**
   * Returns an ISO 8601-compliant string representation of this Duration.
   * @see https://en.wikipedia.org/wiki/ISO_8601#Durations
   * @example Duration.fromObject({ years: 3, seconds: 45 }).toISO() //=> 'P3YT45S'
   * @example Duration.fromObject({ months: 4, seconds: 45 }).toISO() //=> 'P4MT45S'
   * @example Duration.fromObject({ months: 5 }).toISO() //=> 'P5M'
   * @example Duration.fromObject({ minutes: 5 }).toISO() //=> 'PT5M'
   * @example Duration.fromObject({ milliseconds: 6 }).toISO() //=> 'PT0.006S'
   * @return {string}
   */
  toISO() {
    if (!this.isValid) return null;
    let e = "P";
    return this.years !== 0 && (e += this.years + "Y"), (this.months !== 0 || this.quarters !== 0) && (e += this.months + this.quarters * 3 + "M"), this.weeks !== 0 && (e += this.weeks + "W"), this.days !== 0 && (e += this.days + "D"), (this.hours !== 0 || this.minutes !== 0 || this.seconds !== 0 || this.milliseconds !== 0) && (e += "T"), this.hours !== 0 && (e += this.hours + "H"), this.minutes !== 0 && (e += this.minutes + "M"), (this.seconds !== 0 || this.milliseconds !== 0) && (e += os(this.seconds + this.milliseconds / 1e3, 3) + "S"), e === "P" && (e += "T0S"), e;
  }
  /**
   * Returns an ISO 8601-compliant string representation of this Duration, formatted as a time of day.
   * Note that this will return null if the duration is invalid, negative, or equal to or greater than 24 hours.
   * @see https://en.wikipedia.org/wiki/ISO_8601#Times
   * @param {Object} opts - options
   * @param {boolean} [opts.suppressMilliseconds=false] - exclude milliseconds from the format if they're 0
   * @param {boolean} [opts.suppressSeconds=false] - exclude seconds from the format if they're 0
   * @param {boolean} [opts.includePrefix=false] - include the `T` prefix
   * @param {string} [opts.format='extended'] - choose between the basic and extended format
   * @example Duration.fromObject({ hours: 11 }).toISOTime() //=> '11:00:00.000'
   * @example Duration.fromObject({ hours: 11 }).toISOTime({ suppressMilliseconds: true }) //=> '11:00:00'
   * @example Duration.fromObject({ hours: 11 }).toISOTime({ suppressSeconds: true }) //=> '11:00'
   * @example Duration.fromObject({ hours: 11 }).toISOTime({ includePrefix: true }) //=> 'T11:00:00.000'
   * @example Duration.fromObject({ hours: 11 }).toISOTime({ format: 'basic' }) //=> '110000.000'
   * @return {string}
   */
  toISOTime(e = {}) {
    if (!this.isValid) return null;
    const r = this.toMillis();
    return r < 0 || r >= 864e5 ? null : (e = {
      suppressMilliseconds: !1,
      suppressSeconds: !1,
      includePrefix: !1,
      format: "extended",
      ...e,
      includeOffset: !1
    }, F.fromMillis(r, { zone: "UTC" }).toISOTime(e));
  }
  /**
   * Returns an ISO 8601 representation of this Duration appropriate for use in JSON.
   * @return {string}
   */
  toJSON() {
    return this.toISO();
  }
  /**
   * Returns an ISO 8601 representation of this Duration appropriate for use in debugging.
   * @return {string}
   */
  toString() {
    return this.toISO();
  }
  /**
   * Returns a string representation of this Duration appropriate for the REPL.
   * @return {string}
   */
  [Symbol.for("nodejs.util.inspect.custom")]() {
    return this.isValid ? `Duration { values: ${JSON.stringify(this.values)} }` : `Duration { Invalid, reason: ${this.invalidReason} }`;
  }
  /**
   * Returns an milliseconds value of this Duration.
   * @return {number}
   */
  toMillis() {
    return this.isValid ? Lo(this.matrix, this.values) : NaN;
  }
  /**
   * Returns an milliseconds value of this Duration. Alias of {@link toMillis}
   * @return {number}
   */
  valueOf() {
    return this.toMillis();
  }
  /**
   * Make this Duration longer by the specified amount. Return a newly-constructed Duration.
   * @param {Duration|Object|number} duration - The amount to add. Either a Luxon Duration, a number of milliseconds, the object argument to Duration.fromObject()
   * @return {Duration}
   */
  plus(e) {
    if (!this.isValid) return this;
    const r = G.fromDurationLike(e), n = {};
    for (const s of at)
      (St(r.values, s) || St(this.values, s)) && (n[s] = r.get(s) + this.get(s));
    return Ze(this, { values: n }, !0);
  }
  /**
   * Make this Duration shorter by the specified amount. Return a newly-constructed Duration.
   * @param {Duration|Object|number} duration - The amount to subtract. Either a Luxon Duration, a number of milliseconds, the object argument to Duration.fromObject()
   * @return {Duration}
   */
  minus(e) {
    if (!this.isValid) return this;
    const r = G.fromDurationLike(e);
    return this.plus(r.negate());
  }
  /**
   * Scale this Duration by the specified amount. Return a newly-constructed Duration.
   * @param {function} fn - The function to apply to each unit. Arity is 1 or 2: the value of the unit and, optionally, the unit name. Must return a number.
   * @example Duration.fromObject({ hours: 1, minutes: 30 }).mapUnits(x => x * 2) //=> { hours: 2, minutes: 60 }
   * @example Duration.fromObject({ hours: 1, minutes: 30 }).mapUnits((x, u) => u === "hours" ? x * 2 : x) //=> { hours: 2, minutes: 30 }
   * @return {Duration}
   */
  mapUnits(e) {
    if (!this.isValid) return this;
    const r = {};
    for (const n of Object.keys(this.values))
      r[n] = Oo(e(this.values[n], n));
    return Ze(this, { values: r }, !0);
  }
  /**
   * Get the value of unit.
   * @param {string} unit - a unit such as 'minute' or 'day'
   * @example Duration.fromObject({years: 2, days: 3}).get('years') //=> 2
   * @example Duration.fromObject({years: 2, days: 3}).get('months') //=> 0
   * @example Duration.fromObject({years: 2, days: 3}).get('days') //=> 3
   * @return {number}
   */
  get(e) {
    return this[G.normalizeUnit(e)];
  }
  /**
   * "Set" the values of specified units. Return a newly-constructed Duration.
   * @param {Object} values - a mapping of units to numbers
   * @example dur.set({ years: 2017 })
   * @example dur.set({ hours: 8, minutes: 30 })
   * @return {Duration}
   */
  set(e) {
    if (!this.isValid) return this;
    const r = { ...this.values, ...Fr(e, G.normalizeUnit) };
    return Ze(this, { values: r });
  }
  /**
   * "Set" the locale and/or numberingSystem.  Returns a newly-constructed Duration.
   * @example dur.reconfigure({ locale: 'en-GB' })
   * @return {Duration}
   */
  reconfigure({ locale: e, numberingSystem: r, conversionAccuracy: n, matrix: s } = {}) {
    const a = { loc: this.loc.clone({ locale: e, numberingSystem: r }), matrix: s, conversionAccuracy: n };
    return Ze(this, a);
  }
  /**
   * Return the length of the duration in the specified unit.
   * @param {string} unit - a unit such as 'minutes' or 'days'
   * @example Duration.fromObject({years: 1}).as('days') //=> 365
   * @example Duration.fromObject({years: 1}).as('months') //=> 12
   * @example Duration.fromObject({hours: 60}).as('days') //=> 2.5
   * @return {number}
   */
  as(e) {
    return this.isValid ? this.shiftTo(e).get(e) : NaN;
  }
  /**
   * Reduce this Duration to its canonical representation in its current units.
   * Assuming the overall value of the Duration is positive, this means:
   * - excessive values for lower-order units are converted to higher-order units (if possible, see first and second example)
   * - negative lower-order units are converted to higher order units (there must be such a higher order unit, otherwise
   *   the overall value would be negative, see third example)
   * - fractional values for higher-order units are converted to lower-order units (if possible, see fourth example)
   *
   * If the overall value is negative, the result of this method is equivalent to `this.negate().normalize().negate()`.
   * @example Duration.fromObject({ years: 2, days: 5000 }).normalize().toObject() //=> { years: 15, days: 255 }
   * @example Duration.fromObject({ days: 5000 }).normalize().toObject() //=> { days: 5000 }
   * @example Duration.fromObject({ hours: 12, minutes: -45 }).normalize().toObject() //=> { hours: 11, minutes: 15 }
   * @example Duration.fromObject({ years: 2.5, days: 0, hours: 0 }).normalize().toObject() //=> { years: 2, days: 182, hours: 12 }
   * @return {Duration}
   */
  normalize() {
    if (!this.isValid) return this;
    const e = this.toObject();
    return Vi(this.matrix, e), Ze(this, { values: e }, !0);
  }
  /**
   * Rescale units to its largest representation
   * @example Duration.fromObject({ milliseconds: 90000 }).rescale().toObject() //=> { minutes: 1, seconds: 30 }
   * @return {Duration}
   */
  rescale() {
    if (!this.isValid) return this;
    const e = Ch(this.normalize().shiftToAll().toObject());
    return Ze(this, { values: e }, !0);
  }
  /**
   * Convert this Duration into its representation in a different set of units.
   * @example Duration.fromObject({ hours: 1, seconds: 30 }).shiftTo('minutes', 'milliseconds').toObject() //=> { minutes: 60, milliseconds: 30000 }
   * @return {Duration}
   */
  shiftTo(...e) {
    if (!this.isValid) return this;
    if (e.length === 0)
      return this;
    e = e.map((a) => G.normalizeUnit(a));
    const r = {}, n = {}, s = this.toObject();
    let i;
    for (const a of at)
      if (e.indexOf(a) >= 0) {
        i = a;
        let u = 0;
        for (const l in n)
          u += this.matrix[l][a] * n[l], n[l] = 0;
        Ke(s[a]) && (u += s[a]);
        const c = Math.trunc(u);
        r[a] = c, n[a] = (u * 1e3 - c * 1e3) / 1e3;
      } else Ke(s[a]) && (n[a] = s[a]);
    for (const a in n)
      n[a] !== 0 && (r[i] += a === i ? n[a] : n[a] / this.matrix[i][a]);
    return Vi(this.matrix, r), Ze(this, { values: r }, !0);
  }
  /**
   * Shift this Duration to all available units.
   * Same as shiftTo("years", "months", "weeks", "days", "hours", "minutes", "seconds", "milliseconds")
   * @return {Duration}
   */
  shiftToAll() {
    return this.isValid ? this.shiftTo(
      "years",
      "months",
      "weeks",
      "days",
      "hours",
      "minutes",
      "seconds",
      "milliseconds"
    ) : this;
  }
  /**
   * Return the negative of this Duration.
   * @example Duration.fromObject({ hours: 1, seconds: 30 }).negate().toObject() //=> { hours: -1, seconds: -30 }
   * @return {Duration}
   */
  negate() {
    if (!this.isValid) return this;
    const e = {};
    for (const r of Object.keys(this.values))
      e[r] = this.values[r] === 0 ? 0 : -this.values[r];
    return Ze(this, { values: e }, !0);
  }
  /**
   * Get the years.
   * @type {number}
   */
  get years() {
    return this.isValid ? this.values.years || 0 : NaN;
  }
  /**
   * Get the quarters.
   * @type {number}
   */
  get quarters() {
    return this.isValid ? this.values.quarters || 0 : NaN;
  }
  /**
   * Get the months.
   * @type {number}
   */
  get months() {
    return this.isValid ? this.values.months || 0 : NaN;
  }
  /**
   * Get the weeks
   * @type {number}
   */
  get weeks() {
    return this.isValid ? this.values.weeks || 0 : NaN;
  }
  /**
   * Get the days.
   * @type {number}
   */
  get days() {
    return this.isValid ? this.values.days || 0 : NaN;
  }
  /**
   * Get the hours.
   * @type {number}
   */
  get hours() {
    return this.isValid ? this.values.hours || 0 : NaN;
  }
  /**
   * Get the minutes.
   * @type {number}
   */
  get minutes() {
    return this.isValid ? this.values.minutes || 0 : NaN;
  }
  /**
   * Get the seconds.
   * @return {number}
   */
  get seconds() {
    return this.isValid ? this.values.seconds || 0 : NaN;
  }
  /**
   * Get the milliseconds.
   * @return {number}
   */
  get milliseconds() {
    return this.isValid ? this.values.milliseconds || 0 : NaN;
  }
  /**
   * Returns whether the Duration is invalid. Invalid durations are returned by diff operations
   * on invalid DateTimes or Intervals.
   * @return {boolean}
   */
  get isValid() {
    return this.invalid === null;
  }
  /**
   * Returns an error code if this Duration became invalid, or null if the Duration is valid
   * @return {string}
   */
  get invalidReason() {
    return this.invalid ? this.invalid.reason : null;
  }
  /**
   * Returns an explanation of why this Duration became invalid, or null if the Duration is valid
   * @type {string}
   */
  get invalidExplanation() {
    return this.invalid ? this.invalid.explanation : null;
  }
  /**
   * Equality check
   * Two Durations are equal iff they have the same units and the same values for each unit.
   * @param {Duration} other
   * @return {boolean}
   */
  equals(e) {
    if (!this.isValid || !e.isValid || !this.loc.equals(e.loc))
      return !1;
    function r(n, s) {
      return n === void 0 || n === 0 ? s === void 0 || s === 0 : n === s;
    }
    for (const n of at)
      if (!r(this.values[n], e.values[n]))
        return !1;
    return !0;
  }
}
const vt = "Invalid Interval";
function Ah(t, e) {
  return !t || !t.isValid ? le.invalid("missing or invalid start") : !e || !e.isValid ? le.invalid("missing or invalid end") : e < t ? le.invalid(
    "end before start",
    `The end of an interval must be after its start, but you had start=${t.toISO()} and end=${e.toISO()}`
  ) : null;
}
class le {
  /**
   * @private
   */
  constructor(e) {
    this.s = e.start, this.e = e.end, this.invalid = e.invalid || null, this.isLuxonInterval = !0;
  }
  /**
   * Create an invalid Interval.
   * @param {string} reason - simple string of why this Interval is invalid. Should not contain parameters or anything else data-dependent
   * @param {string} [explanation=null] - longer explanation, may include parameters and other useful debugging information
   * @return {Interval}
   */
  static invalid(e, r = null) {
    if (!e)
      throw new we("need to specify a reason the Interval is invalid");
    const n = e instanceof Fe ? e : new Fe(e, r);
    if (fe.throwOnInvalid)
      throw new Kf(n);
    return new le({ invalid: n });
  }
  /**
   * Create an Interval from a start DateTime and an end DateTime. Inclusive of the start but not the end.
   * @param {DateTime|Date|Object} start
   * @param {DateTime|Date|Object} end
   * @return {Interval}
   */
  static fromDateTimes(e, r) {
    const n = Ft(e), s = Ft(r), i = Ah(n, s);
    return i ?? new le({
      start: n,
      end: s
    });
  }
  /**
   * Create an Interval from a start DateTime and a Duration to extend to.
   * @param {DateTime|Date|Object} start
   * @param {Duration|Object|number} duration - the length of the Interval.
   * @return {Interval}
   */
  static after(e, r) {
    const n = G.fromDurationLike(r), s = Ft(e);
    return le.fromDateTimes(s, s.plus(n));
  }
  /**
   * Create an Interval from an end DateTime and a Duration to extend backwards to.
   * @param {DateTime|Date|Object} end
   * @param {Duration|Object|number} duration - the length of the Interval.
   * @return {Interval}
   */
  static before(e, r) {
    const n = G.fromDurationLike(r), s = Ft(e);
    return le.fromDateTimes(s.minus(n), s);
  }
  /**
   * Create an Interval from an ISO 8601 string.
   * Accepts `<start>/<end>`, `<start>/<duration>`, and `<duration>/<end>` formats.
   * @param {string} text - the ISO string to parse
   * @param {Object} [opts] - options to pass {@link DateTime#fromISO} and optionally {@link Duration#fromISO}
   * @see https://en.wikipedia.org/wiki/ISO_8601#Time_intervals
   * @return {Interval}
   */
  static fromISO(e, r) {
    const [n, s] = (e || "").split("/", 2);
    if (n && s) {
      let i, a;
      try {
        i = F.fromISO(n, r), a = i.isValid;
      } catch {
        a = !1;
      }
      let u, c;
      try {
        u = F.fromISO(s, r), c = u.isValid;
      } catch {
        c = !1;
      }
      if (a && c)
        return le.fromDateTimes(i, u);
      if (a) {
        const l = G.fromISO(s, r);
        if (l.isValid)
          return le.after(i, l);
      } else if (c) {
        const l = G.fromISO(n, r);
        if (l.isValid)
          return le.before(u, l);
      }
    }
    return le.invalid("unparsable", `the input "${e}" can't be parsed as ISO 8601`);
  }
  /**
   * Check if an object is an Interval. Works across context boundaries
   * @param {object} o
   * @return {boolean}
   */
  static isInterval(e) {
    return e && e.isLuxonInterval || !1;
  }
  /**
   * Returns the start of the Interval
   * @type {DateTime}
   */
  get start() {
    return this.isValid ? this.s : null;
  }
  /**
   * Returns the end of the Interval
   * @type {DateTime}
   */
  get end() {
    return this.isValid ? this.e : null;
  }
  /**
   * Returns whether this Interval's end is at least its start, meaning that the Interval isn't 'backwards'.
   * @type {boolean}
   */
  get isValid() {
    return this.invalidReason === null;
  }
  /**
   * Returns an error code if this Interval is invalid, or null if the Interval is valid
   * @type {string}
   */
  get invalidReason() {
    return this.invalid ? this.invalid.reason : null;
  }
  /**
   * Returns an explanation of why this Interval became invalid, or null if the Interval is valid
   * @type {string}
   */
  get invalidExplanation() {
    return this.invalid ? this.invalid.explanation : null;
  }
  /**
   * Returns the length of the Interval in the specified unit.
   * @param {string} unit - the unit (such as 'hours' or 'days') to return the length in.
   * @return {number}
   */
  length(e = "milliseconds") {
    return this.isValid ? this.toDuration(e).get(e) : NaN;
  }
  /**
   * Returns the count of minutes, hours, days, months, or years included in the Interval, even in part.
   * Unlike {@link Interval#length} this counts sections of the calendar, not periods of time, e.g. specifying 'day'
   * asks 'what dates are included in this interval?', not 'how many days long is this interval?'
   * @param {string} [unit='milliseconds'] - the unit of time to count.
   * @param {Object} opts - options
   * @param {boolean} [opts.useLocaleWeeks=false] - If true, use weeks based on the locale, i.e. use the locale-dependent start of the week; this operation will always use the locale of the start DateTime
   * @return {number}
   */
  count(e = "milliseconds", r) {
    if (!this.isValid) return NaN;
    const n = this.start.startOf(e, r);
    let s;
    return r?.useLocaleWeeks ? s = this.end.reconfigure({ locale: n.locale }) : s = this.end, s = s.startOf(e, r), Math.floor(s.diff(n, e).get(e)) + (s.valueOf() !== this.end.valueOf());
  }
  /**
   * Returns whether this Interval's start and end are both in the same unit of time
   * @param {string} unit - the unit of time to check sameness on
   * @return {boolean}
   */
  hasSame(e) {
    return this.isValid ? this.isEmpty() || this.e.minus(1).hasSame(this.s, e) : !1;
  }
  /**
   * Return whether this Interval has the same start and end DateTimes.
   * @return {boolean}
   */
  isEmpty() {
    return this.s.valueOf() === this.e.valueOf();
  }
  /**
   * Return whether this Interval's start is after the specified DateTime.
   * @param {DateTime} dateTime
   * @return {boolean}
   */
  isAfter(e) {
    return this.isValid ? this.s > e : !1;
  }
  /**
   * Return whether this Interval's end is before the specified DateTime.
   * @param {DateTime} dateTime
   * @return {boolean}
   */
  isBefore(e) {
    return this.isValid ? this.e <= e : !1;
  }
  /**
   * Return whether this Interval contains the specified DateTime.
   * @param {DateTime} dateTime
   * @return {boolean}
   */
  contains(e) {
    return this.isValid ? this.s <= e && this.e > e : !1;
  }
  /**
   * "Sets" the start and/or end dates. Returns a newly-constructed Interval.
   * @param {Object} values - the values to set
   * @param {DateTime} values.start - the starting DateTime
   * @param {DateTime} values.end - the ending DateTime
   * @return {Interval}
   */
  set({ start: e, end: r } = {}) {
    return this.isValid ? le.fromDateTimes(e || this.s, r || this.e) : this;
  }
  /**
   * Split this Interval at each of the specified DateTimes
   * @param {...DateTime} dateTimes - the unit of time to count.
   * @return {Array}
   */
  splitAt(...e) {
    if (!this.isValid) return [];
    const r = e.map(Ft).filter((a) => this.contains(a)).sort((a, u) => a.toMillis() - u.toMillis()), n = [];
    let { s } = this, i = 0;
    for (; s < this.e; ) {
      const a = r[i] || this.e, u = +a > +this.e ? this.e : a;
      n.push(le.fromDateTimes(s, u)), s = u, i += 1;
    }
    return n;
  }
  /**
   * Split this Interval into smaller Intervals, each of the specified length.
   * Left over time is grouped into a smaller interval
   * @param {Duration|Object|number} duration - The length of each resulting interval.
   * @return {Array}
   */
  splitBy(e) {
    const r = G.fromDurationLike(e);
    if (!this.isValid || !r.isValid || r.as("milliseconds") === 0)
      return [];
    let { s: n } = this, s = 1, i;
    const a = [];
    for (; n < this.e; ) {
      const u = this.start.plus(r.mapUnits((c) => c * s));
      i = +u > +this.e ? this.e : u, a.push(le.fromDateTimes(n, i)), n = i, s += 1;
    }
    return a;
  }
  /**
   * Split this Interval into the specified number of smaller intervals.
   * @param {number} numberOfParts - The number of Intervals to divide the Interval into.
   * @return {Array}
   */
  divideEqually(e) {
    return this.isValid ? this.splitBy(this.length() / e).slice(0, e) : [];
  }
  /**
   * Return whether this Interval overlaps with the specified Interval
   * @param {Interval} other
   * @return {boolean}
   */
  overlaps(e) {
    return this.e > e.s && this.s < e.e;
  }
  /**
   * Return whether this Interval's end is adjacent to the specified Interval's start.
   * @param {Interval} other
   * @return {boolean}
   */
  abutsStart(e) {
    return this.isValid ? +this.e == +e.s : !1;
  }
  /**
   * Return whether this Interval's start is adjacent to the specified Interval's end.
   * @param {Interval} other
   * @return {boolean}
   */
  abutsEnd(e) {
    return this.isValid ? +e.e == +this.s : !1;
  }
  /**
   * Returns true if this Interval fully contains the specified Interval, specifically if the intersect (of this Interval and the other Interval) is equal to the other Interval; false otherwise.
   * @param {Interval} other
   * @return {boolean}
   */
  engulfs(e) {
    return this.isValid ? this.s <= e.s && this.e >= e.e : !1;
  }
  /**
   * Return whether this Interval has the same start and end as the specified Interval.
   * @param {Interval} other
   * @return {boolean}
   */
  equals(e) {
    return !this.isValid || !e.isValid ? !1 : this.s.equals(e.s) && this.e.equals(e.e);
  }
  /**
   * Return an Interval representing the intersection of this Interval and the specified Interval.
   * Specifically, the resulting Interval has the maximum start time and the minimum end time of the two Intervals.
   * Returns null if the intersection is empty, meaning, the intervals don't intersect.
   * @param {Interval} other
   * @return {Interval}
   */
  intersection(e) {
    if (!this.isValid) return this;
    const r = this.s > e.s ? this.s : e.s, n = this.e < e.e ? this.e : e.e;
    return r >= n ? null : le.fromDateTimes(r, n);
  }
  /**
   * Return an Interval representing the union of this Interval and the specified Interval.
   * Specifically, the resulting Interval has the minimum start time and the maximum end time of the two Intervals.
   * @param {Interval} other
   * @return {Interval}
   */
  union(e) {
    if (!this.isValid) return this;
    const r = this.s < e.s ? this.s : e.s, n = this.e > e.e ? this.e : e.e;
    return le.fromDateTimes(r, n);
  }
  /**
   * Merge an array of Intervals into a equivalent minimal set of Intervals.
   * Combines overlapping and adjacent Intervals.
   * @param {Array} intervals
   * @return {Array}
   */
  static merge(e) {
    const [r, n] = e.sort((s, i) => s.s - i.s).reduce(
      ([s, i], a) => i ? i.overlaps(a) || i.abutsStart(a) ? [s, i.union(a)] : [s.concat([i]), a] : [s, a],
      [[], null]
    );
    return n && r.push(n), r;
  }
  /**
   * Return an array of Intervals representing the spans of time that only appear in one of the specified Intervals.
   * @param {Array} intervals
   * @return {Array}
   */
  static xor(e) {
    let r = null, n = 0;
    const s = [], i = e.map((c) => [
      { time: c.s, type: "s" },
      { time: c.e, type: "e" }
    ]), a = Array.prototype.concat(...i), u = a.sort((c, l) => c.time - l.time);
    for (const c of u)
      n += c.type === "s" ? 1 : -1, n === 1 ? r = c.time : (r && +r != +c.time && s.push(le.fromDateTimes(r, c.time)), r = null);
    return le.merge(s);
  }
  /**
   * Return an Interval representing the span of time in this Interval that doesn't overlap with any of the specified Intervals.
   * @param {...Interval} intervals
   * @return {Array}
   */
  difference(...e) {
    return le.xor([this].concat(e)).map((r) => this.intersection(r)).filter((r) => r && !r.isEmpty());
  }
  /**
   * Returns a string representation of this Interval appropriate for debugging.
   * @return {string}
   */
  toString() {
    return this.isValid ? `[${this.s.toISO()} – ${this.e.toISO()})` : vt;
  }
  /**
   * Returns a string representation of this Interval appropriate for the REPL.
   * @return {string}
   */
  [Symbol.for("nodejs.util.inspect.custom")]() {
    return this.isValid ? `Interval { start: ${this.s.toISO()}, end: ${this.e.toISO()} }` : `Interval { Invalid, reason: ${this.invalidReason} }`;
  }
  /**
   * Returns a localized string representing this Interval. Accepts the same options as the
   * Intl.DateTimeFormat constructor and any presets defined by Luxon, such as
   * {@link DateTime.DATE_FULL} or {@link DateTime.TIME_SIMPLE}. The exact behavior of this method
   * is browser-specific, but in general it will return an appropriate representation of the
   * Interval in the assigned locale. Defaults to the system's locale if no locale has been
   * specified.
   * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DateTimeFormat
   * @param {Object} [formatOpts=DateTime.DATE_SHORT] - Either a DateTime preset or
   * Intl.DateTimeFormat constructor options.
   * @param {Object} opts - Options to override the configuration of the start DateTime.
   * @example Interval.fromISO('2022-11-07T09:00Z/2022-11-08T09:00Z').toLocaleString(); //=> 11/7/2022 – 11/8/2022
   * @example Interval.fromISO('2022-11-07T09:00Z/2022-11-08T09:00Z').toLocaleString(DateTime.DATE_FULL); //=> November 7 – 8, 2022
   * @example Interval.fromISO('2022-11-07T09:00Z/2022-11-08T09:00Z').toLocaleString(DateTime.DATE_FULL, { locale: 'fr-FR' }); //=> 7–8 novembre 2022
   * @example Interval.fromISO('2022-11-07T17:00Z/2022-11-07T19:00Z').toLocaleString(DateTime.TIME_SIMPLE); //=> 6:00 – 8:00 PM
   * @example Interval.fromISO('2022-11-07T17:00Z/2022-11-07T19:00Z').toLocaleString({ weekday: 'short', month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit' }); //=> Mon, Nov 07, 6:00 – 8:00 p
   * @return {string}
   */
  toLocaleString(e = xr, r = {}) {
    return this.isValid ? be.create(this.s.loc.clone(r), e).formatInterval(this) : vt;
  }
  /**
   * Returns an ISO 8601-compliant string representation of this Interval.
   * @see https://en.wikipedia.org/wiki/ISO_8601#Time_intervals
   * @param {Object} opts - The same options as {@link DateTime#toISO}
   * @return {string}
   */
  toISO(e) {
    return this.isValid ? `${this.s.toISO(e)}/${this.e.toISO(e)}` : vt;
  }
  /**
   * Returns an ISO 8601-compliant string representation of date of this Interval.
   * The time components are ignored.
   * @see https://en.wikipedia.org/wiki/ISO_8601#Time_intervals
   * @return {string}
   */
  toISODate() {
    return this.isValid ? `${this.s.toISODate()}/${this.e.toISODate()}` : vt;
  }
  /**
   * Returns an ISO 8601-compliant string representation of time of this Interval.
   * The date components are ignored.
   * @see https://en.wikipedia.org/wiki/ISO_8601#Time_intervals
   * @param {Object} opts - The same options as {@link DateTime#toISO}
   * @return {string}
   */
  toISOTime(e) {
    return this.isValid ? `${this.s.toISOTime(e)}/${this.e.toISOTime(e)}` : vt;
  }
  /**
   * Returns a string representation of this Interval formatted according to the specified format
   * string. **You may not want this.** See {@link Interval#toLocaleString} for a more flexible
   * formatting tool.
   * @param {string} dateFormat - The format string. This string formats the start and end time.
   * See {@link DateTime#toFormat} for details.
   * @param {Object} opts - Options.
   * @param {string} [opts.separator =  ' – '] - A separator to place between the start and end
   * representations.
   * @return {string}
   */
  toFormat(e, { separator: r = " – " } = {}) {
    return this.isValid ? `${this.s.toFormat(e)}${r}${this.e.toFormat(e)}` : vt;
  }
  /**
   * Return a Duration representing the time spanned by this interval.
   * @param {string|string[]} [unit=['milliseconds']] - the unit or units (such as 'hours' or 'days') to include in the duration.
   * @param {Object} opts - options that affect the creation of the Duration
   * @param {string} [opts.conversionAccuracy='casual'] - the conversion system to use
   * @example Interval.fromDateTimes(dt1, dt2).toDuration().toObject() //=> { milliseconds: 88489257 }
   * @example Interval.fromDateTimes(dt1, dt2).toDuration('days').toObject() //=> { days: 1.0241812152777778 }
   * @example Interval.fromDateTimes(dt1, dt2).toDuration(['hours', 'minutes']).toObject() //=> { hours: 24, minutes: 34.82095 }
   * @example Interval.fromDateTimes(dt1, dt2).toDuration(['hours', 'minutes', 'seconds']).toObject() //=> { hours: 24, minutes: 34, seconds: 49.257 }
   * @example Interval.fromDateTimes(dt1, dt2).toDuration('seconds').toObject() //=> { seconds: 88489.257 }
   * @return {Duration}
   */
  toDuration(e, r) {
    return this.isValid ? this.e.diff(this.s, e, r) : G.invalid(this.invalidReason);
  }
  /**
   * Run mapFn on the interval start and end, returning a new Interval from the resulting DateTimes
   * @param {function} mapFn
   * @return {Interval}
   * @example Interval.fromDateTimes(dt1, dt2).mapEndpoints(endpoint => endpoint.toUTC())
   * @example Interval.fromDateTimes(dt1, dt2).mapEndpoints(endpoint => endpoint.plus({ hours: 2 }))
   */
  mapEndpoints(e) {
    return le.fromDateTimes(e(this.s), e(this.e));
  }
}
class gr {
  /**
   * Return whether the specified zone contains a DST.
   * @param {string|Zone} [zone='local'] - Zone to check. Defaults to the environment's local zone.
   * @return {boolean}
   */
  static hasDST(e = fe.defaultZone) {
    const r = F.now().setZone(e).set({ month: 12 });
    return !e.isUniversal && r.offset !== r.set({ month: 6 }).offset;
  }
  /**
   * Return whether the specified zone is a valid IANA specifier.
   * @param {string} zone - Zone to check
   * @return {boolean}
   */
  static isValidIANAZone(e) {
    return He.isValidZone(e);
  }
  /**
   * Converts the input into a {@link Zone} instance.
   *
   * * If `input` is already a Zone instance, it is returned unchanged.
   * * If `input` is a string containing a valid time zone name, a Zone instance
   *   with that name is returned.
   * * If `input` is a string that doesn't refer to a known time zone, a Zone
   *   instance with {@link Zone#isValid} == false is returned.
   * * If `input is a number, a Zone instance with the specified fixed offset
   *   in minutes is returned.
   * * If `input` is `null` or `undefined`, the default zone is returned.
   * @param {string|Zone|number} [input] - the value to be converted
   * @return {Zone}
   */
  static normalizeZone(e) {
    return Xe(e, fe.defaultZone);
  }
  /**
   * Get the weekday on which the week starts according to the given locale.
   * @param {Object} opts - options
   * @param {string} [opts.locale] - the locale code
   * @param {string} [opts.locObj=null] - an existing locale object to use
   * @returns {number} the start of the week, 1 for Monday through 7 for Sunday
   */
  static getStartOfWeek({ locale: e = null, locObj: r = null } = {}) {
    return (r || X.create(e)).getStartOfWeek();
  }
  /**
   * Get the minimum number of days necessary in a week before it is considered part of the next year according
   * to the given locale.
   * @param {Object} opts - options
   * @param {string} [opts.locale] - the locale code
   * @param {string} [opts.locObj=null] - an existing locale object to use
   * @returns {number}
   */
  static getMinimumDaysInFirstWeek({ locale: e = null, locObj: r = null } = {}) {
    return (r || X.create(e)).getMinDaysInFirstWeek();
  }
  /**
   * Get the weekdays, which are considered the weekend according to the given locale
   * @param {Object} opts - options
   * @param {string} [opts.locale] - the locale code
   * @param {string} [opts.locObj=null] - an existing locale object to use
   * @returns {number[]} an array of weekdays, 1 for Monday through 7 for Sunday
   */
  static getWeekendWeekdays({ locale: e = null, locObj: r = null } = {}) {
    return (r || X.create(e)).getWeekendDays().slice();
  }
  /**
   * Return an array of standalone month names.
   * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DateTimeFormat
   * @param {string} [length='long'] - the length of the month representation, such as "numeric", "2-digit", "narrow", "short", "long"
   * @param {Object} opts - options
   * @param {string} [opts.locale] - the locale code
   * @param {string} [opts.numberingSystem=null] - the numbering system
   * @param {string} [opts.locObj=null] - an existing locale object to use
   * @param {string} [opts.outputCalendar='gregory'] - the calendar
   * @example Info.months()[0] //=> 'January'
   * @example Info.months('short')[0] //=> 'Jan'
   * @example Info.months('numeric')[0] //=> '1'
   * @example Info.months('short', { locale: 'fr-CA' } )[0] //=> 'janv.'
   * @example Info.months('numeric', { locale: 'ar' })[0] //=> '١'
   * @example Info.months('long', { outputCalendar: 'islamic' })[0] //=> 'Rabiʻ I'
   * @return {Array}
   */
  static months(e = "long", { locale: r = null, numberingSystem: n = null, locObj: s = null, outputCalendar: i = "gregory" } = {}) {
    return (s || X.create(r, n, i)).months(e);
  }
  /**
   * Return an array of format month names.
   * Format months differ from standalone months in that they're meant to appear next to the day of the month. In some languages, that
   * changes the string.
   * See {@link Info#months}
   * @param {string} [length='long'] - the length of the month representation, such as "numeric", "2-digit", "narrow", "short", "long"
   * @param {Object} opts - options
   * @param {string} [opts.locale] - the locale code
   * @param {string} [opts.numberingSystem=null] - the numbering system
   * @param {string} [opts.locObj=null] - an existing locale object to use
   * @param {string} [opts.outputCalendar='gregory'] - the calendar
   * @return {Array}
   */
  static monthsFormat(e = "long", { locale: r = null, numberingSystem: n = null, locObj: s = null, outputCalendar: i = "gregory" } = {}) {
    return (s || X.create(r, n, i)).months(e, !0);
  }
  /**
   * Return an array of standalone week names.
   * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DateTimeFormat
   * @param {string} [length='long'] - the length of the weekday representation, such as "narrow", "short", "long".
   * @param {Object} opts - options
   * @param {string} [opts.locale] - the locale code
   * @param {string} [opts.numberingSystem=null] - the numbering system
   * @param {string} [opts.locObj=null] - an existing locale object to use
   * @example Info.weekdays()[0] //=> 'Monday'
   * @example Info.weekdays('short')[0] //=> 'Mon'
   * @example Info.weekdays('short', { locale: 'fr-CA' })[0] //=> 'lun.'
   * @example Info.weekdays('short', { locale: 'ar' })[0] //=> 'الاثنين'
   * @return {Array}
   */
  static weekdays(e = "long", { locale: r = null, numberingSystem: n = null, locObj: s = null } = {}) {
    return (s || X.create(r, n, null)).weekdays(e);
  }
  /**
   * Return an array of format week names.
   * Format weekdays differ from standalone weekdays in that they're meant to appear next to more date information. In some languages, that
   * changes the string.
   * See {@link Info#weekdays}
   * @param {string} [length='long'] - the length of the month representation, such as "narrow", "short", "long".
   * @param {Object} opts - options
   * @param {string} [opts.locale=null] - the locale code
   * @param {string} [opts.numberingSystem=null] - the numbering system
   * @param {string} [opts.locObj=null] - an existing locale object to use
   * @return {Array}
   */
  static weekdaysFormat(e = "long", { locale: r = null, numberingSystem: n = null, locObj: s = null } = {}) {
    return (s || X.create(r, n, null)).weekdays(e, !0);
  }
  /**
   * Return an array of meridiems.
   * @param {Object} opts - options
   * @param {string} [opts.locale] - the locale code
   * @example Info.meridiems() //=> [ 'AM', 'PM' ]
   * @example Info.meridiems({ locale: 'my' }) //=> [ 'နံနက်', 'ညနေ' ]
   * @return {Array}
   */
  static meridiems({ locale: e = null } = {}) {
    return X.create(e).meridiems();
  }
  /**
   * Return an array of eras, such as ['BC', 'AD']. The locale can be specified, but the calendar system is always Gregorian.
   * @param {string} [length='short'] - the length of the era representation, such as "short" or "long".
   * @param {Object} opts - options
   * @param {string} [opts.locale] - the locale code
   * @example Info.eras() //=> [ 'BC', 'AD' ]
   * @example Info.eras('long') //=> [ 'Before Christ', 'Anno Domini' ]
   * @example Info.eras('long', { locale: 'fr' }) //=> [ 'avant Jésus-Christ', 'après Jésus-Christ' ]
   * @return {Array}
   */
  static eras(e = "short", { locale: r = null } = {}) {
    return X.create(r, null, "gregory").eras(e);
  }
  /**
   * Return the set of available features in this environment.
   * Some features of Luxon are not available in all environments. For example, on older browsers, relative time formatting support is not available. Use this function to figure out if that's the case.
   * Keys:
   * * `relative`: whether this environment supports relative time formatting
   * * `localeWeek`: whether this environment supports different weekdays for the start of the week based on the locale
   * @example Info.features() //=> { relative: false, localeWeek: true }
   * @return {Object}
   */
  static features() {
    return { relative: vo(), localeWeek: go() };
  }
}
function Ui(t, e) {
  const r = (s) => s.toUTC(0, { keepLocalTime: !0 }).startOf("day").valueOf(), n = r(e) - r(t);
  return Math.floor(G.fromMillis(n).as("days"));
}
function Rh(t, e, r) {
  const n = [
    ["years", (c, l) => l.year - c.year],
    ["quarters", (c, l) => l.quarter - c.quarter + (l.year - c.year) * 4],
    ["months", (c, l) => l.month - c.month + (l.year - c.year) * 12],
    [
      "weeks",
      (c, l) => {
        const d = Ui(c, l);
        return (d - d % 7) / 7;
      }
    ],
    ["days", Ui]
  ], s = {}, i = t;
  let a, u;
  for (const [c, l] of n)
    r.indexOf(c) >= 0 && (a = c, s[c] = l(t, e), u = i.plus(s), u > e ? (s[c]--, t = i.plus(s), t > e && (u = t, s[c]--, t = i.plus(s))) : t = u);
  return [t, s, u, a];
}
function xh(t, e, r, n) {
  let [s, i, a, u] = Rh(t, e, r);
  const c = e - s, l = r.filter(
    (v) => ["hours", "minutes", "seconds", "milliseconds"].indexOf(v) >= 0
  );
  l.length === 0 && (a < e && (a = s.plus({ [u]: 1 })), a !== s && (i[u] = (i[u] || 0) + c / (a - s)));
  const d = G.fromObject(i, n);
  return l.length > 0 ? G.fromMillis(c, n).shiftTo(...l).plus(d) : d;
}
const Mh = "missing Intl.DateTimeFormat.formatToParts support";
function Q(t, e = (r) => r) {
  return { regex: t, deser: ([r]) => e(Td(r)) };
}
const Lh = " ", Fo = `[ ${Lh}]`, Po = new RegExp(Fo, "g");
function Fh(t) {
  return t.replace(/\./g, "\\.?").replace(Po, Fo);
}
function $i(t) {
  return t.replace(/\./g, "").replace(Po, " ").toLowerCase();
}
function Me(t, e) {
  return t === null ? null : {
    regex: RegExp(t.map(Fh).join("|")),
    deser: ([r]) => t.findIndex((n) => $i(r) === $i(n)) + e
  };
}
function Wi(t, e) {
  return { regex: t, deser: ([, r, n]) => jr(r, n), groups: e };
}
function Er(t) {
  return { regex: t, deser: ([e]) => e };
}
function Ph(t) {
  return t.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g, "\\$&");
}
function Vh(t, e) {
  const r = xe(e), n = xe(e, "{2}"), s = xe(e, "{3}"), i = xe(e, "{4}"), a = xe(e, "{6}"), u = xe(e, "{1,2}"), c = xe(e, "{1,3}"), l = xe(e, "{1,6}"), d = xe(e, "{1,9}"), v = xe(e, "{2,4}"), T = xe(e, "{4,6}"), O = (E) => ({ regex: RegExp(Ph(E.val)), deser: ([y]) => y, literal: !0 }), _ = ((E) => {
    if (t.literal)
      return O(E);
    switch (E.val) {
      case "G":
        return Me(e.eras("short"), 0);
      case "GG":
        return Me(e.eras("long"), 0);
      case "y":
        return Q(l);
      case "yy":
        return Q(v, Bn);
      case "yyyy":
        return Q(i);
      case "yyyyy":
        return Q(T);
      case "yyyyyy":
        return Q(a);
      case "M":
        return Q(u);
      case "MM":
        return Q(n);
      case "MMM":
        return Me(e.months("short", !0), 1);
      case "MMMM":
        return Me(e.months("long", !0), 1);
      case "L":
        return Q(u);
      case "LL":
        return Q(n);
      case "LLL":
        return Me(e.months("short", !1), 1);
      case "LLLL":
        return Me(e.months("long", !1), 1);
      case "d":
        return Q(u);
      case "dd":
        return Q(n);
      case "o":
        return Q(c);
      case "ooo":
        return Q(s);
      case "HH":
        return Q(n);
      case "H":
        return Q(u);
      case "hh":
        return Q(n);
      case "h":
        return Q(u);
      case "mm":
        return Q(n);
      case "m":
        return Q(u);
      case "q":
        return Q(u);
      case "qq":
        return Q(n);
      case "s":
        return Q(u);
      case "ss":
        return Q(n);
      case "S":
        return Q(c);
      case "SSS":
        return Q(s);
      case "u":
        return Er(d);
      case "uu":
        return Er(u);
      case "uuu":
        return Q(r);
      case "a":
        return Me(e.meridiems(), 0);
      case "kkkk":
        return Q(i);
      case "kk":
        return Q(v, Bn);
      case "W":
        return Q(u);
      case "WW":
        return Q(n);
      case "E":
      case "c":
        return Q(r);
      case "EEE":
        return Me(e.weekdays("short", !1), 1);
      case "EEEE":
        return Me(e.weekdays("long", !1), 1);
      case "ccc":
        return Me(e.weekdays("short", !0), 1);
      case "cccc":
        return Me(e.weekdays("long", !0), 1);
      case "Z":
      case "ZZ":
        return Wi(new RegExp(`([+-]${u.source})(?::(${n.source}))?`), 2);
      case "ZZZ":
        return Wi(new RegExp(`([+-]${u.source})(${n.source})?`), 2);
      case "z":
        return Er(/[a-z_+-/]{1,256}?/i);
      case " ":
        return Er(/[^\S\n\r]/);
      default:
        return O(E);
    }
  })(t) || {
    invalidReason: Mh
  };
  return _.token = t, _;
}
const Uh = {
  year: {
    "2-digit": "yy",
    numeric: "yyyyy"
  },
  month: {
    numeric: "M",
    "2-digit": "MM",
    short: "MMM",
    long: "MMMM"
  },
  day: {
    numeric: "d",
    "2-digit": "dd"
  },
  weekday: {
    short: "EEE",
    long: "EEEE"
  },
  dayperiod: "a",
  dayPeriod: "a",
  hour12: {
    numeric: "h",
    "2-digit": "hh"
  },
  hour24: {
    numeric: "H",
    "2-digit": "HH"
  },
  minute: {
    numeric: "m",
    "2-digit": "mm"
  },
  second: {
    numeric: "s",
    "2-digit": "ss"
  },
  timeZoneName: {
    long: "ZZZZZ",
    short: "ZZZ"
  }
};
function $h(t, e, r) {
  const { type: n, value: s } = t;
  if (n === "literal") {
    const c = /^\s+$/.test(s);
    return {
      literal: !c,
      val: c ? " " : s
    };
  }
  const i = e[n];
  let a = n;
  n === "hour" && (e.hour12 != null ? a = e.hour12 ? "hour12" : "hour24" : e.hourCycle != null ? e.hourCycle === "h11" || e.hourCycle === "h12" ? a = "hour12" : a = "hour24" : a = r.hour12 ? "hour12" : "hour24");
  let u = Uh[a];
  if (typeof u == "object" && (u = u[i]), u)
    return {
      literal: !1,
      val: u
    };
}
function Wh(t) {
  return [`^${t.map((r) => r.regex).reduce((r, n) => `${r}(${n.source})`, "")}$`, t];
}
function Hh(t, e, r) {
  const n = t.match(e);
  if (n) {
    const s = {};
    let i = 1;
    for (const a in r)
      if (St(r, a)) {
        const u = r[a], c = u.groups ? u.groups + 1 : 1;
        !u.literal && u.token && (s[u.token.val[0]] = u.deser(n.slice(i, i + c))), i += c;
      }
    return [n, s];
  } else
    return [n, {}];
}
function jh(t) {
  const e = (i) => {
    switch (i) {
      case "S":
        return "millisecond";
      case "s":
        return "second";
      case "m":
        return "minute";
      case "h":
      case "H":
        return "hour";
      case "d":
        return "day";
      case "o":
        return "ordinal";
      case "L":
      case "M":
        return "month";
      case "y":
        return "year";
      case "E":
      case "c":
        return "weekday";
      case "W":
        return "weekNumber";
      case "k":
        return "weekYear";
      case "q":
        return "quarter";
      default:
        return null;
    }
  };
  let r = null, n;
  return P(t.z) || (r = He.create(t.z)), P(t.Z) || (r || (r = new Ie(t.Z)), n = t.Z), P(t.q) || (t.M = (t.q - 1) * 3 + 1), P(t.h) || (t.h < 12 && t.a === 1 ? t.h += 12 : t.h === 12 && t.a === 0 && (t.h = 0)), t.G === 0 && t.y && (t.y = -t.y), P(t.u) || (t.S = as(t.u)), [Object.keys(t).reduce((i, a) => {
    const u = e(a);
    return u && (i[u] = t[a]), i;
  }, {}), r, n];
}
let gn = null;
function zh() {
  return gn || (gn = F.fromMillis(1555555555555)), gn;
}
function Yh(t, e) {
  if (t.literal)
    return t;
  const r = be.macroTokenToFormatOpts(t.val), n = Wo(r, e);
  return n == null || n.includes(void 0) ? t : n;
}
function Vo(t, e) {
  return Array.prototype.concat(...t.map((r) => Yh(r, e)));
}
class Uo {
  constructor(e, r) {
    if (this.locale = e, this.format = r, this.tokens = Vo(be.parseFormat(r), e), this.units = this.tokens.map((n) => Vh(n, e)), this.disqualifyingUnit = this.units.find((n) => n.invalidReason), !this.disqualifyingUnit) {
      const [n, s] = Wh(this.units);
      this.regex = RegExp(n, "i"), this.handlers = s;
    }
  }
  explainFromTokens(e) {
    if (this.isValid) {
      const [r, n] = Hh(e, this.regex, this.handlers), [s, i, a] = n ? jh(n) : [null, null, void 0];
      if (St(n, "a") && St(n, "H"))
        throw new wt(
          "Can't include meridiem when specifying 24-hour format"
        );
      return {
        input: e,
        tokens: this.tokens,
        regex: this.regex,
        rawMatches: r,
        matches: n,
        result: s,
        zone: i,
        specificOffset: a
      };
    } else
      return { input: e, tokens: this.tokens, invalidReason: this.invalidReason };
  }
  get isValid() {
    return !this.disqualifyingUnit;
  }
  get invalidReason() {
    return this.disqualifyingUnit ? this.disqualifyingUnit.invalidReason : null;
  }
}
function $o(t, e, r) {
  return new Uo(t, r).explainFromTokens(e);
}
function Bh(t, e, r) {
  const { result: n, zone: s, specificOffset: i, invalidReason: a } = $o(t, e, r);
  return [n, s, i, a];
}
function Wo(t, e) {
  if (!t)
    return null;
  const n = be.create(e, t).dtFormatter(zh()), s = n.formatToParts(), i = n.resolvedOptions();
  return s.map((a) => $h(a, t, i));
}
const En = "Invalid DateTime", Hi = 864e13;
function $t(t) {
  return new Fe("unsupported zone", `the zone "${t.name}" is not supported`);
}
function On(t) {
  return t.weekData === null && (t.weekData = Mr(t.c)), t.weekData;
}
function wn(t) {
  return t.localWeekData === null && (t.localWeekData = Mr(
    t.c,
    t.loc.getMinDaysInFirstWeek(),
    t.loc.getStartOfWeek()
  )), t.localWeekData;
}
function rt(t, e) {
  const r = {
    ts: t.ts,
    zone: t.zone,
    c: t.c,
    o: t.o,
    loc: t.loc,
    invalid: t.invalid
  };
  return new F({ ...r, ...e, old: r });
}
function Ho(t, e, r) {
  let n = t - e * 60 * 1e3;
  const s = r.offset(n);
  if (e === s)
    return [n, e];
  n -= (s - e) * 60 * 1e3;
  const i = r.offset(n);
  return s === i ? [n, s] : [t - Math.min(s, i) * 60 * 1e3, Math.max(s, i)];
}
function Or(t, e) {
  t += e * 60 * 1e3;
  const r = new Date(t);
  return {
    year: r.getUTCFullYear(),
    month: r.getUTCMonth() + 1,
    day: r.getUTCDate(),
    hour: r.getUTCHours(),
    minute: r.getUTCMinutes(),
    second: r.getUTCSeconds(),
    millisecond: r.getUTCMilliseconds()
  };
}
function _r(t, e, r) {
  return Ho(Hr(t), e, r);
}
function ji(t, e) {
  const r = t.o, n = t.c.year + Math.trunc(e.years), s = t.c.month + Math.trunc(e.months) + Math.trunc(e.quarters) * 3, i = {
    ...t.c,
    year: n,
    month: s,
    day: Math.min(t.c.day, Lr(n, s)) + Math.trunc(e.days) + Math.trunc(e.weeks) * 7
  }, a = G.fromObject({
    years: e.years - Math.trunc(e.years),
    quarters: e.quarters - Math.trunc(e.quarters),
    months: e.months - Math.trunc(e.months),
    weeks: e.weeks - Math.trunc(e.weeks),
    days: e.days - Math.trunc(e.days),
    hours: e.hours,
    minutes: e.minutes,
    seconds: e.seconds,
    milliseconds: e.milliseconds
  }).as("milliseconds"), u = Hr(i);
  let [c, l] = Ho(u, r, t.zone);
  return a !== 0 && (c += a, l = t.zone.offset(c)), { ts: c, o: l };
}
function gt(t, e, r, n, s, i) {
  const { setZone: a, zone: u } = r;
  if (t && Object.keys(t).length !== 0 || e) {
    const c = e || u, l = F.fromObject(t, {
      ...r,
      zone: c,
      specificOffset: i
    });
    return a ? l : l.setZone(u);
  } else
    return F.invalid(
      new Fe("unparsable", `the input "${s}" can't be parsed as ${n}`)
    );
}
function wr(t, e, r = !0) {
  return t.isValid ? be.create(X.create("en-US"), {
    allowZ: r,
    forceSimple: !0
  }).formatDateTimeFromString(t, e) : null;
}
function bn(t, e) {
  const r = t.c.year > 9999 || t.c.year < 0;
  let n = "";
  return r && t.c.year >= 0 && (n += "+"), n += me(t.c.year, r ? 6 : 4), e ? (n += "-", n += me(t.c.month), n += "-", n += me(t.c.day)) : (n += me(t.c.month), n += me(t.c.day)), n;
}
function zi(t, e, r, n, s, i) {
  let a = me(t.c.hour);
  return e ? (a += ":", a += me(t.c.minute), (t.c.millisecond !== 0 || t.c.second !== 0 || !r) && (a += ":")) : a += me(t.c.minute), (t.c.millisecond !== 0 || t.c.second !== 0 || !r) && (a += me(t.c.second), (t.c.millisecond !== 0 || !n) && (a += ".", a += me(t.c.millisecond, 3))), s && (t.isOffsetFixed && t.offset === 0 && !i ? a += "Z" : t.o < 0 ? (a += "-", a += me(Math.trunc(-t.o / 60)), a += ":", a += me(Math.trunc(-t.o % 60))) : (a += "+", a += me(Math.trunc(t.o / 60)), a += ":", a += me(Math.trunc(t.o % 60)))), i && (a += "[" + t.zone.ianaName + "]"), a;
}
const jo = {
  month: 1,
  day: 1,
  hour: 0,
  minute: 0,
  second: 0,
  millisecond: 0
}, qh = {
  weekNumber: 1,
  weekday: 1,
  hour: 0,
  minute: 0,
  second: 0,
  millisecond: 0
}, Gh = {
  ordinal: 1,
  hour: 0,
  minute: 0,
  second: 0,
  millisecond: 0
}, zo = ["year", "month", "day", "hour", "minute", "second", "millisecond"], Zh = [
  "weekYear",
  "weekNumber",
  "weekday",
  "hour",
  "minute",
  "second",
  "millisecond"
], Qh = ["year", "ordinal", "hour", "minute", "second", "millisecond"];
function Jh(t) {
  const e = {
    year: "year",
    years: "year",
    month: "month",
    months: "month",
    day: "day",
    days: "day",
    hour: "hour",
    hours: "hour",
    minute: "minute",
    minutes: "minute",
    quarter: "quarter",
    quarters: "quarter",
    second: "second",
    seconds: "second",
    millisecond: "millisecond",
    milliseconds: "millisecond",
    weekday: "weekday",
    weekdays: "weekday",
    weeknumber: "weekNumber",
    weeksnumber: "weekNumber",
    weeknumbers: "weekNumber",
    weekyear: "weekYear",
    weekyears: "weekYear",
    ordinal: "ordinal"
  }[t.toLowerCase()];
  if (!e) throw new za(t);
  return e;
}
function Yi(t) {
  switch (t.toLowerCase()) {
    case "localweekday":
    case "localweekdays":
      return "localWeekday";
    case "localweeknumber":
    case "localweeknumbers":
      return "localWeekNumber";
    case "localweekyear":
    case "localweekyears":
      return "localWeekYear";
    default:
      return Jh(t);
  }
}
function Xh(t) {
  return Nr[t] || (Ir === void 0 && (Ir = fe.now()), Nr[t] = t.offset(Ir)), Nr[t];
}
function Bi(t, e) {
  const r = Xe(e.zone, fe.defaultZone);
  if (!r.isValid)
    return F.invalid($t(r));
  const n = X.fromObject(e);
  let s, i;
  if (P(t.year))
    s = fe.now();
  else {
    for (const c of zo)
      P(t[c]) && (t[c] = jo[c]);
    const a = mo(t) || yo(t);
    if (a)
      return F.invalid(a);
    const u = Xh(r);
    [s, i] = _r(t, u, r);
  }
  return new F({ ts: s, zone: r, loc: n, o: i });
}
function qi(t, e, r) {
  const n = P(r.round) ? !0 : r.round, s = (a, u) => (a = os(a, n || r.calendary ? 0 : 2, !0), e.loc.clone(r).relFormatter(r).format(a, u)), i = (a) => r.calendary ? e.hasSame(t, a) ? 0 : e.startOf(a).diff(t.startOf(a), a).get(a) : e.diff(t, a).get(a);
  if (r.unit)
    return s(i(r.unit), r.unit);
  for (const a of r.units) {
    const u = i(a);
    if (Math.abs(u) >= 1)
      return s(u, a);
  }
  return s(t > e ? -0 : 0, r.units[r.units.length - 1]);
}
function Gi(t) {
  let e = {}, r;
  return t.length > 0 && typeof t[t.length - 1] == "object" ? (e = t[t.length - 1], r = Array.from(t).slice(0, t.length - 1)) : r = Array.from(t), [e, r];
}
let Ir, Nr = {};
class F {
  /**
   * @access private
   */
  constructor(e) {
    const r = e.zone || fe.defaultZone;
    let n = e.invalid || (Number.isNaN(e.ts) ? new Fe("invalid input") : null) || (r.isValid ? null : $t(r));
    this.ts = P(e.ts) ? fe.now() : e.ts;
    let s = null, i = null;
    if (!n)
      if (e.old && e.old.ts === this.ts && e.old.zone.equals(r))
        [s, i] = [e.old.c, e.old.o];
      else {
        const u = Ke(e.o) && !e.old ? e.o : r.offset(this.ts);
        s = Or(this.ts, u), n = Number.isNaN(s.year) ? new Fe("invalid input") : null, s = n ? null : s, i = n ? null : u;
      }
    this._zone = r, this.loc = e.loc || X.create(), this.invalid = n, this.weekData = null, this.localWeekData = null, this.c = s, this.o = i, this.isLuxonDateTime = !0;
  }
  // CONSTRUCT
  /**
   * Create a DateTime for the current instant, in the system's time zone.
   *
   * Use Settings to override these default values if needed.
   * @example DateTime.now().toISO() //~> now in the ISO format
   * @return {DateTime}
   */
  static now() {
    return new F({});
  }
  /**
   * Create a local DateTime
   * @param {number} [year] - The calendar year. If omitted (as in, call `local()` with no arguments), the current time will be used
   * @param {number} [month=1] - The month, 1-indexed
   * @param {number} [day=1] - The day of the month, 1-indexed
   * @param {number} [hour=0] - The hour of the day, in 24-hour time
   * @param {number} [minute=0] - The minute of the hour, meaning a number between 0 and 59
   * @param {number} [second=0] - The second of the minute, meaning a number between 0 and 59
   * @param {number} [millisecond=0] - The millisecond of the second, meaning a number between 0 and 999
   * @example DateTime.local()                                  //~> now
   * @example DateTime.local({ zone: "America/New_York" })      //~> now, in US east coast time
   * @example DateTime.local(2017)                              //~> 2017-01-01T00:00:00
   * @example DateTime.local(2017, 3)                           //~> 2017-03-01T00:00:00
   * @example DateTime.local(2017, 3, 12, { locale: "fr" })     //~> 2017-03-12T00:00:00, with a French locale
   * @example DateTime.local(2017, 3, 12, 5)                    //~> 2017-03-12T05:00:00
   * @example DateTime.local(2017, 3, 12, 5, { zone: "utc" })   //~> 2017-03-12T05:00:00, in UTC
   * @example DateTime.local(2017, 3, 12, 5, 45)                //~> 2017-03-12T05:45:00
   * @example DateTime.local(2017, 3, 12, 5, 45, 10)            //~> 2017-03-12T05:45:10
   * @example DateTime.local(2017, 3, 12, 5, 45, 10, 765)       //~> 2017-03-12T05:45:10.765
   * @return {DateTime}
   */
  static local() {
    const [e, r] = Gi(arguments), [n, s, i, a, u, c, l] = r;
    return Bi({ year: n, month: s, day: i, hour: a, minute: u, second: c, millisecond: l }, e);
  }
  /**
   * Create a DateTime in UTC
   * @param {number} [year] - The calendar year. If omitted (as in, call `utc()` with no arguments), the current time will be used
   * @param {number} [month=1] - The month, 1-indexed
   * @param {number} [day=1] - The day of the month
   * @param {number} [hour=0] - The hour of the day, in 24-hour time
   * @param {number} [minute=0] - The minute of the hour, meaning a number between 0 and 59
   * @param {number} [second=0] - The second of the minute, meaning a number between 0 and 59
   * @param {number} [millisecond=0] - The millisecond of the second, meaning a number between 0 and 999
   * @param {Object} options - configuration options for the DateTime
   * @param {string} [options.locale] - a locale to set on the resulting DateTime instance
   * @param {string} [options.outputCalendar] - the output calendar to set on the resulting DateTime instance
   * @param {string} [options.numberingSystem] - the numbering system to set on the resulting DateTime instance
   * @param {string} [options.weekSettings] - the week settings to set on the resulting DateTime instance
   * @example DateTime.utc()                                              //~> now
   * @example DateTime.utc(2017)                                          //~> 2017-01-01T00:00:00Z
   * @example DateTime.utc(2017, 3)                                       //~> 2017-03-01T00:00:00Z
   * @example DateTime.utc(2017, 3, 12)                                   //~> 2017-03-12T00:00:00Z
   * @example DateTime.utc(2017, 3, 12, 5)                                //~> 2017-03-12T05:00:00Z
   * @example DateTime.utc(2017, 3, 12, 5, 45)                            //~> 2017-03-12T05:45:00Z
   * @example DateTime.utc(2017, 3, 12, 5, 45, { locale: "fr" })          //~> 2017-03-12T05:45:00Z with a French locale
   * @example DateTime.utc(2017, 3, 12, 5, 45, 10)                        //~> 2017-03-12T05:45:10Z
   * @example DateTime.utc(2017, 3, 12, 5, 45, 10, 765, { locale: "fr" }) //~> 2017-03-12T05:45:10.765Z with a French locale
   * @return {DateTime}
   */
  static utc() {
    const [e, r] = Gi(arguments), [n, s, i, a, u, c, l] = r;
    return e.zone = Ie.utcInstance, Bi({ year: n, month: s, day: i, hour: a, minute: u, second: c, millisecond: l }, e);
  }
  /**
   * Create a DateTime from a JavaScript Date object. Uses the default zone.
   * @param {Date} date - a JavaScript Date object
   * @param {Object} options - configuration options for the DateTime
   * @param {string|Zone} [options.zone='local'] - the zone to place the DateTime into
   * @return {DateTime}
   */
  static fromJSDate(e, r = {}) {
    const n = kd(e) ? e.valueOf() : NaN;
    if (Number.isNaN(n))
      return F.invalid("invalid input");
    const s = Xe(r.zone, fe.defaultZone);
    return s.isValid ? new F({
      ts: n,
      zone: s,
      loc: X.fromObject(r)
    }) : F.invalid($t(s));
  }
  /**
   * Create a DateTime from a number of milliseconds since the epoch (meaning since 1 January 1970 00:00:00 UTC). Uses the default zone.
   * @param {number} milliseconds - a number of milliseconds since 1970 UTC
   * @param {Object} options - configuration options for the DateTime
   * @param {string|Zone} [options.zone='local'] - the zone to place the DateTime into
   * @param {string} [options.locale] - a locale to set on the resulting DateTime instance
   * @param {string} options.outputCalendar - the output calendar to set on the resulting DateTime instance
   * @param {string} options.numberingSystem - the numbering system to set on the resulting DateTime instance
   * @param {string} options.weekSettings - the week settings to set on the resulting DateTime instance
   * @return {DateTime}
   */
  static fromMillis(e, r = {}) {
    if (Ke(e))
      return e < -Hi || e > Hi ? F.invalid("Timestamp out of range") : new F({
        ts: e,
        zone: Xe(r.zone, fe.defaultZone),
        loc: X.fromObject(r)
      });
    throw new we(
      `fromMillis requires a numerical input, but received a ${typeof e} with value ${e}`
    );
  }
  /**
   * Create a DateTime from a number of seconds since the epoch (meaning since 1 January 1970 00:00:00 UTC). Uses the default zone.
   * @param {number} seconds - a number of seconds since 1970 UTC
   * @param {Object} options - configuration options for the DateTime
   * @param {string|Zone} [options.zone='local'] - the zone to place the DateTime into
   * @param {string} [options.locale] - a locale to set on the resulting DateTime instance
   * @param {string} options.outputCalendar - the output calendar to set on the resulting DateTime instance
   * @param {string} options.numberingSystem - the numbering system to set on the resulting DateTime instance
   * @param {string} options.weekSettings - the week settings to set on the resulting DateTime instance
   * @return {DateTime}
   */
  static fromSeconds(e, r = {}) {
    if (Ke(e))
      return new F({
        ts: e * 1e3,
        zone: Xe(r.zone, fe.defaultZone),
        loc: X.fromObject(r)
      });
    throw new we("fromSeconds requires a numerical input");
  }
  /**
   * Create a DateTime from a JavaScript object with keys like 'year' and 'hour' with reasonable defaults.
   * @param {Object} obj - the object to create the DateTime from
   * @param {number} obj.year - a year, such as 1987
   * @param {number} obj.month - a month, 1-12
   * @param {number} obj.day - a day of the month, 1-31, depending on the month
   * @param {number} obj.ordinal - day of the year, 1-365 or 366
   * @param {number} obj.weekYear - an ISO week year
   * @param {number} obj.weekNumber - an ISO week number, between 1 and 52 or 53, depending on the year
   * @param {number} obj.weekday - an ISO weekday, 1-7, where 1 is Monday and 7 is Sunday
   * @param {number} obj.localWeekYear - a week year, according to the locale
   * @param {number} obj.localWeekNumber - a week number, between 1 and 52 or 53, depending on the year, according to the locale
   * @param {number} obj.localWeekday - a weekday, 1-7, where 1 is the first and 7 is the last day of the week, according to the locale
   * @param {number} obj.hour - hour of the day, 0-23
   * @param {number} obj.minute - minute of the hour, 0-59
   * @param {number} obj.second - second of the minute, 0-59
   * @param {number} obj.millisecond - millisecond of the second, 0-999
   * @param {Object} opts - options for creating this DateTime
   * @param {string|Zone} [opts.zone='local'] - interpret the numbers in the context of a particular zone. Can take any value taken as the first argument to setZone()
   * @param {string} [opts.locale='system\'s locale'] - a locale to set on the resulting DateTime instance
   * @param {string} opts.outputCalendar - the output calendar to set on the resulting DateTime instance
   * @param {string} opts.numberingSystem - the numbering system to set on the resulting DateTime instance
   * @param {string} opts.weekSettings - the week settings to set on the resulting DateTime instance
   * @example DateTime.fromObject({ year: 1982, month: 5, day: 25}).toISODate() //=> '1982-05-25'
   * @example DateTime.fromObject({ year: 1982 }).toISODate() //=> '1982-01-01'
   * @example DateTime.fromObject({ hour: 10, minute: 26, second: 6 }) //~> today at 10:26:06
   * @example DateTime.fromObject({ hour: 10, minute: 26, second: 6 }, { zone: 'utc' }),
   * @example DateTime.fromObject({ hour: 10, minute: 26, second: 6 }, { zone: 'local' })
   * @example DateTime.fromObject({ hour: 10, minute: 26, second: 6 }, { zone: 'America/New_York' })
   * @example DateTime.fromObject({ weekYear: 2016, weekNumber: 2, weekday: 3 }).toISODate() //=> '2016-01-13'
   * @example DateTime.fromObject({ localWeekYear: 2022, localWeekNumber: 1, localWeekday: 1 }, { locale: "en-US" }).toISODate() //=> '2021-12-26'
   * @return {DateTime}
   */
  static fromObject(e, r = {}) {
    e = e || {};
    const n = Xe(r.zone, fe.defaultZone);
    if (!n.isValid)
      return F.invalid($t(n));
    const s = X.fromObject(r), i = Fr(e, Yi), { minDaysInFirstWeek: a, startOfWeek: u } = Ri(i, s), c = fe.now(), l = P(r.specificOffset) ? n.offset(c) : r.specificOffset, d = !P(i.ordinal), v = !P(i.year), T = !P(i.month) || !P(i.day), O = v || T, I = i.weekYear || i.weekNumber;
    if ((O || d) && I)
      throw new wt(
        "Can't mix weekYear/weekNumber units with year/month/day or ordinals"
      );
    if (T && d)
      throw new wt("Can't mix ordinal dates with month/day");
    const _ = I || i.weekday && !O;
    let E, y, b = Or(c, l);
    _ ? (E = Zh, y = qh, b = Mr(b, a, u)) : d ? (E = Qh, y = Gh, b = vn(b)) : (E = zo, y = jo);
    let A = !1;
    for (const q of E) {
      const te = i[q];
      P(te) ? A ? i[q] = y[q] : i[q] = b[q] : A = !0;
    }
    const R = _ ? _d(i, a, u) : d ? Id(i) : mo(i), $ = R || yo(i);
    if ($)
      return F.invalid($);
    const D = _ ? Ci(i, a, u) : d ? Ai(i) : i, [j, V] = _r(D, l, n), C = new F({
      ts: j,
      zone: n,
      o: V,
      loc: s
    });
    return i.weekday && O && e.weekday !== C.weekday ? F.invalid(
      "mismatched weekday",
      `you can't specify both a weekday of ${i.weekday} and a date of ${C.toISO()}`
    ) : C.isValid ? C : F.invalid(C.invalid);
  }
  /**
   * Create a DateTime from an ISO 8601 string
   * @param {string} text - the ISO string
   * @param {Object} opts - options to affect the creation
   * @param {string|Zone} [opts.zone='local'] - use this zone if no offset is specified in the input string itself. Will also convert the time to this zone
   * @param {boolean} [opts.setZone=false] - override the zone with a fixed-offset zone specified in the string itself, if it specifies one
   * @param {string} [opts.locale='system's locale'] - a locale to set on the resulting DateTime instance
   * @param {string} [opts.outputCalendar] - the output calendar to set on the resulting DateTime instance
   * @param {string} [opts.numberingSystem] - the numbering system to set on the resulting DateTime instance
   * @param {string} [opts.weekSettings] - the week settings to set on the resulting DateTime instance
   * @example DateTime.fromISO('2016-05-25T09:08:34.123')
   * @example DateTime.fromISO('2016-05-25T09:08:34.123+06:00')
   * @example DateTime.fromISO('2016-05-25T09:08:34.123+06:00', {setZone: true})
   * @example DateTime.fromISO('2016-05-25T09:08:34.123', {zone: 'utc'})
   * @example DateTime.fromISO('2016-W05-4')
   * @return {DateTime}
   */
  static fromISO(e, r = {}) {
    const [n, s] = vh(e);
    return gt(n, s, r, "ISO 8601", e);
  }
  /**
   * Create a DateTime from an RFC 2822 string
   * @param {string} text - the RFC 2822 string
   * @param {Object} opts - options to affect the creation
   * @param {string|Zone} [opts.zone='local'] - convert the time to this zone. Since the offset is always specified in the string itself, this has no effect on the interpretation of string, merely the zone the resulting DateTime is expressed in.
   * @param {boolean} [opts.setZone=false] - override the zone with a fixed-offset zone specified in the string itself, if it specifies one
   * @param {string} [opts.locale='system's locale'] - a locale to set on the resulting DateTime instance
   * @param {string} opts.outputCalendar - the output calendar to set on the resulting DateTime instance
   * @param {string} opts.numberingSystem - the numbering system to set on the resulting DateTime instance
   * @param {string} opts.weekSettings - the week settings to set on the resulting DateTime instance
   * @example DateTime.fromRFC2822('25 Nov 2016 13:23:12 GMT')
   * @example DateTime.fromRFC2822('Fri, 25 Nov 2016 13:23:12 +0600')
   * @example DateTime.fromRFC2822('25 Nov 2016 13:23 Z')
   * @return {DateTime}
   */
  static fromRFC2822(e, r = {}) {
    const [n, s] = gh(e);
    return gt(n, s, r, "RFC 2822", e);
  }
  /**
   * Create a DateTime from an HTTP header date
   * @see https://www.w3.org/Protocols/rfc2616/rfc2616-sec3.html#sec3.3.1
   * @param {string} text - the HTTP header date
   * @param {Object} opts - options to affect the creation
   * @param {string|Zone} [opts.zone='local'] - convert the time to this zone. Since HTTP dates are always in UTC, this has no effect on the interpretation of string, merely the zone the resulting DateTime is expressed in.
   * @param {boolean} [opts.setZone=false] - override the zone with the fixed-offset zone specified in the string. For HTTP dates, this is always UTC, so this option is equivalent to setting the `zone` option to 'utc', but this option is included for consistency with similar methods.
   * @param {string} [opts.locale='system's locale'] - a locale to set on the resulting DateTime instance
   * @param {string} opts.outputCalendar - the output calendar to set on the resulting DateTime instance
   * @param {string} opts.numberingSystem - the numbering system to set on the resulting DateTime instance
   * @param {string} opts.weekSettings - the week settings to set on the resulting DateTime instance
   * @example DateTime.fromHTTP('Sun, 06 Nov 1994 08:49:37 GMT')
   * @example DateTime.fromHTTP('Sunday, 06-Nov-94 08:49:37 GMT')
   * @example DateTime.fromHTTP('Sun Nov  6 08:49:37 1994')
   * @return {DateTime}
   */
  static fromHTTP(e, r = {}) {
    const [n, s] = Eh(e);
    return gt(n, s, r, "HTTP", r);
  }
  /**
   * Create a DateTime from an input string and format string.
   * Defaults to en-US if no locale has been specified, regardless of the system's locale. For a table of tokens and their interpretations, see [here](https://moment.github.io/luxon/#/parsing?id=table-of-tokens).
   * @param {string} text - the string to parse
   * @param {string} fmt - the format the string is expected to be in (see the link below for the formats)
   * @param {Object} opts - options to affect the creation
   * @param {string|Zone} [opts.zone='local'] - use this zone if no offset is specified in the input string itself. Will also convert the DateTime to this zone
   * @param {boolean} [opts.setZone=false] - override the zone with a zone specified in the string itself, if it specifies one
   * @param {string} [opts.locale='en-US'] - a locale string to use when parsing. Will also set the DateTime to this locale
   * @param {string} opts.numberingSystem - the numbering system to use when parsing. Will also set the resulting DateTime to this numbering system
   * @param {string} opts.weekSettings - the week settings to set on the resulting DateTime instance
   * @param {string} opts.outputCalendar - the output calendar to set on the resulting DateTime instance
   * @return {DateTime}
   */
  static fromFormat(e, r, n = {}) {
    if (P(e) || P(r))
      throw new we("fromFormat requires an input string and a format");
    const { locale: s = null, numberingSystem: i = null } = n, a = X.fromOpts({
      locale: s,
      numberingSystem: i,
      defaultToEN: !0
    }), [u, c, l, d] = Bh(a, e, r);
    return d ? F.invalid(d) : gt(u, c, n, `format ${r}`, e, l);
  }
  /**
   * @deprecated use fromFormat instead
   */
  static fromString(e, r, n = {}) {
    return F.fromFormat(e, r, n);
  }
  /**
   * Create a DateTime from a SQL date, time, or datetime
   * Defaults to en-US if no locale has been specified, regardless of the system's locale
   * @param {string} text - the string to parse
   * @param {Object} opts - options to affect the creation
   * @param {string|Zone} [opts.zone='local'] - use this zone if no offset is specified in the input string itself. Will also convert the DateTime to this zone
   * @param {boolean} [opts.setZone=false] - override the zone with a zone specified in the string itself, if it specifies one
   * @param {string} [opts.locale='en-US'] - a locale string to use when parsing. Will also set the DateTime to this locale
   * @param {string} opts.numberingSystem - the numbering system to use when parsing. Will also set the resulting DateTime to this numbering system
   * @param {string} opts.weekSettings - the week settings to set on the resulting DateTime instance
   * @param {string} opts.outputCalendar - the output calendar to set on the resulting DateTime instance
   * @example DateTime.fromSQL('2017-05-15')
   * @example DateTime.fromSQL('2017-05-15 09:12:34')
   * @example DateTime.fromSQL('2017-05-15 09:12:34.342')
   * @example DateTime.fromSQL('2017-05-15 09:12:34.342+06:00')
   * @example DateTime.fromSQL('2017-05-15 09:12:34.342 America/Los_Angeles')
   * @example DateTime.fromSQL('2017-05-15 09:12:34.342 America/Los_Angeles', { setZone: true })
   * @example DateTime.fromSQL('2017-05-15 09:12:34.342', { zone: 'America/Los_Angeles' })
   * @example DateTime.fromSQL('09:12:34.342')
   * @return {DateTime}
   */
  static fromSQL(e, r = {}) {
    const [n, s] = Ih(e);
    return gt(n, s, r, "SQL", e);
  }
  /**
   * Create an invalid DateTime.
   * @param {string} reason - simple string of why this DateTime is invalid. Should not contain parameters or anything else data-dependent.
   * @param {string} [explanation=null] - longer explanation, may include parameters and other useful debugging information
   * @return {DateTime}
   */
  static invalid(e, r = null) {
    if (!e)
      throw new we("need to specify a reason the DateTime is invalid");
    const n = e instanceof Fe ? e : new Fe(e, r);
    if (fe.throwOnInvalid)
      throw new Xf(n);
    return new F({ invalid: n });
  }
  /**
   * Check if an object is an instance of DateTime. Works across context boundaries
   * @param {object} o
   * @return {boolean}
   */
  static isDateTime(e) {
    return e && e.isLuxonDateTime || !1;
  }
  /**
   * Produce the format string for a set of options
   * @param formatOpts
   * @param localeOpts
   * @returns {string}
   */
  static parseFormatForOpts(e, r = {}) {
    const n = Wo(e, X.fromObject(r));
    return n ? n.map((s) => s ? s.val : null).join("") : null;
  }
  /**
   * Produce the the fully expanded format token for the locale
   * Does NOT quote characters, so quoted tokens will not round trip correctly
   * @param fmt
   * @param localeOpts
   * @returns {string}
   */
  static expandFormat(e, r = {}) {
    return Vo(be.parseFormat(e), X.fromObject(r)).map((s) => s.val).join("");
  }
  static resetCache() {
    Ir = void 0, Nr = {};
  }
  // INFO
  /**
   * Get the value of unit.
   * @param {string} unit - a unit such as 'minute' or 'day'
   * @example DateTime.local(2017, 7, 4).get('month'); //=> 7
   * @example DateTime.local(2017, 7, 4).get('day'); //=> 4
   * @return {number}
   */
  get(e) {
    return this[e];
  }
  /**
   * Returns whether the DateTime is valid. Invalid DateTimes occur when:
   * * The DateTime was created from invalid calendar information, such as the 13th month or February 30
   * * The DateTime was created by an operation on another invalid date
   * @type {boolean}
   */
  get isValid() {
    return this.invalid === null;
  }
  /**
   * Returns an error code if this DateTime is invalid, or null if the DateTime is valid
   * @type {string}
   */
  get invalidReason() {
    return this.invalid ? this.invalid.reason : null;
  }
  /**
   * Returns an explanation of why this DateTime became invalid, or null if the DateTime is valid
   * @type {string}
   */
  get invalidExplanation() {
    return this.invalid ? this.invalid.explanation : null;
  }
  /**
   * Get the locale of a DateTime, such 'en-GB'. The locale is used when formatting the DateTime
   *
   * @type {string}
   */
  get locale() {
    return this.isValid ? this.loc.locale : null;
  }
  /**
   * Get the numbering system of a DateTime, such 'beng'. The numbering system is used when formatting the DateTime
   *
   * @type {string}
   */
  get numberingSystem() {
    return this.isValid ? this.loc.numberingSystem : null;
  }
  /**
   * Get the output calendar of a DateTime, such 'islamic'. The output calendar is used when formatting the DateTime
   *
   * @type {string}
   */
  get outputCalendar() {
    return this.isValid ? this.loc.outputCalendar : null;
  }
  /**
   * Get the time zone associated with this DateTime.
   * @type {Zone}
   */
  get zone() {
    return this._zone;
  }
  /**
   * Get the name of the time zone.
   * @type {string}
   */
  get zoneName() {
    return this.isValid ? this.zone.name : null;
  }
  /**
   * Get the year
   * @example DateTime.local(2017, 5, 25).year //=> 2017
   * @type {number}
   */
  get year() {
    return this.isValid ? this.c.year : NaN;
  }
  /**
   * Get the quarter
   * @example DateTime.local(2017, 5, 25).quarter //=> 2
   * @type {number}
   */
  get quarter() {
    return this.isValid ? Math.ceil(this.c.month / 3) : NaN;
  }
  /**
   * Get the month (1-12).
   * @example DateTime.local(2017, 5, 25).month //=> 5
   * @type {number}
   */
  get month() {
    return this.isValid ? this.c.month : NaN;
  }
  /**
   * Get the day of the month (1-30ish).
   * @example DateTime.local(2017, 5, 25).day //=> 25
   * @type {number}
   */
  get day() {
    return this.isValid ? this.c.day : NaN;
  }
  /**
   * Get the hour of the day (0-23).
   * @example DateTime.local(2017, 5, 25, 9).hour //=> 9
   * @type {number}
   */
  get hour() {
    return this.isValid ? this.c.hour : NaN;
  }
  /**
   * Get the minute of the hour (0-59).
   * @example DateTime.local(2017, 5, 25, 9, 30).minute //=> 30
   * @type {number}
   */
  get minute() {
    return this.isValid ? this.c.minute : NaN;
  }
  /**
   * Get the second of the minute (0-59).
   * @example DateTime.local(2017, 5, 25, 9, 30, 52).second //=> 52
   * @type {number}
   */
  get second() {
    return this.isValid ? this.c.second : NaN;
  }
  /**
   * Get the millisecond of the second (0-999).
   * @example DateTime.local(2017, 5, 25, 9, 30, 52, 654).millisecond //=> 654
   * @type {number}
   */
  get millisecond() {
    return this.isValid ? this.c.millisecond : NaN;
  }
  /**
   * Get the week year
   * @see https://en.wikipedia.org/wiki/ISO_week_date
   * @example DateTime.local(2014, 12, 31).weekYear //=> 2015
   * @type {number}
   */
  get weekYear() {
    return this.isValid ? On(this).weekYear : NaN;
  }
  /**
   * Get the week number of the week year (1-52ish).
   * @see https://en.wikipedia.org/wiki/ISO_week_date
   * @example DateTime.local(2017, 5, 25).weekNumber //=> 21
   * @type {number}
   */
  get weekNumber() {
    return this.isValid ? On(this).weekNumber : NaN;
  }
  /**
   * Get the day of the week.
   * 1 is Monday and 7 is Sunday
   * @see https://en.wikipedia.org/wiki/ISO_week_date
   * @example DateTime.local(2014, 11, 31).weekday //=> 4
   * @type {number}
   */
  get weekday() {
    return this.isValid ? On(this).weekday : NaN;
  }
  /**
   * Returns true if this date is on a weekend according to the locale, false otherwise
   * @returns {boolean}
   */
  get isWeekend() {
    return this.isValid && this.loc.getWeekendDays().includes(this.weekday);
  }
  /**
   * Get the day of the week according to the locale.
   * 1 is the first day of the week and 7 is the last day of the week.
   * If the locale assigns Sunday as the first day of the week, then a date which is a Sunday will return 1,
   * @returns {number}
   */
  get localWeekday() {
    return this.isValid ? wn(this).weekday : NaN;
  }
  /**
   * Get the week number of the week year according to the locale. Different locales assign week numbers differently,
   * because the week can start on different days of the week (see localWeekday) and because a different number of days
   * is required for a week to count as the first week of a year.
   * @returns {number}
   */
  get localWeekNumber() {
    return this.isValid ? wn(this).weekNumber : NaN;
  }
  /**
   * Get the week year according to the locale. Different locales assign week numbers (and therefor week years)
   * differently, see localWeekNumber.
   * @returns {number}
   */
  get localWeekYear() {
    return this.isValid ? wn(this).weekYear : NaN;
  }
  /**
   * Get the ordinal (meaning the day of the year)
   * @example DateTime.local(2017, 5, 25).ordinal //=> 145
   * @type {number|DateTime}
   */
  get ordinal() {
    return this.isValid ? vn(this.c).ordinal : NaN;
  }
  /**
   * Get the human readable short month name, such as 'Oct'.
   * Defaults to the system's locale if no locale has been specified
   * @example DateTime.local(2017, 10, 30).monthShort //=> Oct
   * @type {string}
   */
  get monthShort() {
    return this.isValid ? gr.months("short", { locObj: this.loc })[this.month - 1] : null;
  }
  /**
   * Get the human readable long month name, such as 'October'.
   * Defaults to the system's locale if no locale has been specified
   * @example DateTime.local(2017, 10, 30).monthLong //=> October
   * @type {string}
   */
  get monthLong() {
    return this.isValid ? gr.months("long", { locObj: this.loc })[this.month - 1] : null;
  }
  /**
   * Get the human readable short weekday, such as 'Mon'.
   * Defaults to the system's locale if no locale has been specified
   * @example DateTime.local(2017, 10, 30).weekdayShort //=> Mon
   * @type {string}
   */
  get weekdayShort() {
    return this.isValid ? gr.weekdays("short", { locObj: this.loc })[this.weekday - 1] : null;
  }
  /**
   * Get the human readable long weekday, such as 'Monday'.
   * Defaults to the system's locale if no locale has been specified
   * @example DateTime.local(2017, 10, 30).weekdayLong //=> Monday
   * @type {string}
   */
  get weekdayLong() {
    return this.isValid ? gr.weekdays("long", { locObj: this.loc })[this.weekday - 1] : null;
  }
  /**
   * Get the UTC offset of this DateTime in minutes
   * @example DateTime.now().offset //=> -240
   * @example DateTime.utc().offset //=> 0
   * @type {number}
   */
  get offset() {
    return this.isValid ? +this.o : NaN;
  }
  /**
   * Get the short human name for the zone's current offset, for example "EST" or "EDT".
   * Defaults to the system's locale if no locale has been specified
   * @type {string}
   */
  get offsetNameShort() {
    return this.isValid ? this.zone.offsetName(this.ts, {
      format: "short",
      locale: this.locale
    }) : null;
  }
  /**
   * Get the long human name for the zone's current offset, for example "Eastern Standard Time" or "Eastern Daylight Time".
   * Defaults to the system's locale if no locale has been specified
   * @type {string}
   */
  get offsetNameLong() {
    return this.isValid ? this.zone.offsetName(this.ts, {
      format: "long",
      locale: this.locale
    }) : null;
  }
  /**
   * Get whether this zone's offset ever changes, as in a DST.
   * @type {boolean}
   */
  get isOffsetFixed() {
    return this.isValid ? this.zone.isUniversal : null;
  }
  /**
   * Get whether the DateTime is in a DST.
   * @type {boolean}
   */
  get isInDST() {
    return this.isOffsetFixed ? !1 : this.offset > this.set({ month: 1, day: 1 }).offset || this.offset > this.set({ month: 5 }).offset;
  }
  /**
   * Get those DateTimes which have the same local time as this DateTime, but a different offset from UTC
   * in this DateTime's zone. During DST changes local time can be ambiguous, for example
   * `2023-10-29T02:30:00` in `Europe/Berlin` can have offset `+01:00` or `+02:00`.
   * This method will return both possible DateTimes if this DateTime's local time is ambiguous.
   * @returns {DateTime[]}
   */
  getPossibleOffsets() {
    if (!this.isValid || this.isOffsetFixed)
      return [this];
    const e = 864e5, r = 6e4, n = Hr(this.c), s = this.zone.offset(n - e), i = this.zone.offset(n + e), a = this.zone.offset(n - s * r), u = this.zone.offset(n - i * r);
    if (a === u)
      return [this];
    const c = n - a * r, l = n - u * r, d = Or(c, a), v = Or(l, u);
    return d.hour === v.hour && d.minute === v.minute && d.second === v.second && d.millisecond === v.millisecond ? [rt(this, { ts: c }), rt(this, { ts: l })] : [this];
  }
  /**
   * Returns true if this DateTime is in a leap year, false otherwise
   * @example DateTime.local(2016).isInLeapYear //=> true
   * @example DateTime.local(2013).isInLeapYear //=> false
   * @type {boolean}
   */
  get isInLeapYear() {
    return Jt(this.year);
  }
  /**
   * Returns the number of days in this DateTime's month
   * @example DateTime.local(2016, 2).daysInMonth //=> 29
   * @example DateTime.local(2016, 3).daysInMonth //=> 31
   * @type {number}
   */
  get daysInMonth() {
    return Lr(this.year, this.month);
  }
  /**
   * Returns the number of days in this DateTime's year
   * @example DateTime.local(2016).daysInYear //=> 366
   * @example DateTime.local(2013).daysInYear //=> 365
   * @type {number}
   */
  get daysInYear() {
    return this.isValid ? bt(this.year) : NaN;
  }
  /**
   * Returns the number of weeks in this DateTime's year
   * @see https://en.wikipedia.org/wiki/ISO_week_date
   * @example DateTime.local(2004).weeksInWeekYear //=> 53
   * @example DateTime.local(2013).weeksInWeekYear //=> 52
   * @type {number}
   */
  get weeksInWeekYear() {
    return this.isValid ? Bt(this.weekYear) : NaN;
  }
  /**
   * Returns the number of weeks in this DateTime's local week year
   * @example DateTime.local(2020, 6, {locale: 'en-US'}).weeksInLocalWeekYear //=> 52
   * @example DateTime.local(2020, 6, {locale: 'de-DE'}).weeksInLocalWeekYear //=> 53
   * @type {number}
   */
  get weeksInLocalWeekYear() {
    return this.isValid ? Bt(
      this.localWeekYear,
      this.loc.getMinDaysInFirstWeek(),
      this.loc.getStartOfWeek()
    ) : NaN;
  }
  /**
   * Returns the resolved Intl options for this DateTime.
   * This is useful in understanding the behavior of formatting methods
   * @param {Object} opts - the same options as toLocaleString
   * @return {Object}
   */
  resolvedLocaleOptions(e = {}) {
    const { locale: r, numberingSystem: n, calendar: s } = be.create(
      this.loc.clone(e),
      e
    ).resolvedOptions(this);
    return { locale: r, numberingSystem: n, outputCalendar: s };
  }
  // TRANSFORM
  /**
   * "Set" the DateTime's zone to UTC. Returns a newly-constructed DateTime.
   *
   * Equivalent to {@link DateTime#setZone}('utc')
   * @param {number} [offset=0] - optionally, an offset from UTC in minutes
   * @param {Object} [opts={}] - options to pass to `setZone()`
   * @return {DateTime}
   */
  toUTC(e = 0, r = {}) {
    return this.setZone(Ie.instance(e), r);
  }
  /**
   * "Set" the DateTime's zone to the host's local zone. Returns a newly-constructed DateTime.
   *
   * Equivalent to `setZone('local')`
   * @return {DateTime}
   */
  toLocal() {
    return this.setZone(fe.defaultZone);
  }
  /**
   * "Set" the DateTime's zone to specified zone. Returns a newly-constructed DateTime.
   *
   * By default, the setter keeps the underlying time the same (as in, the same timestamp), but the new instance will report different local times and consider DSTs when making computations, as with {@link DateTime#plus}. You may wish to use {@link DateTime#toLocal} and {@link DateTime#toUTC} which provide simple convenience wrappers for commonly used zones.
   * @param {string|Zone} [zone='local'] - a zone identifier. As a string, that can be any IANA zone supported by the host environment, or a fixed-offset name of the form 'UTC+3', or the strings 'local' or 'utc'. You may also supply an instance of a {@link DateTime#Zone} class.
   * @param {Object} opts - options
   * @param {boolean} [opts.keepLocalTime=false] - If true, adjust the underlying time so that the local time stays the same, but in the target zone. You should rarely need this.
   * @return {DateTime}
   */
  setZone(e, { keepLocalTime: r = !1, keepCalendarTime: n = !1 } = {}) {
    if (e = Xe(e, fe.defaultZone), e.equals(this.zone))
      return this;
    if (e.isValid) {
      let s = this.ts;
      if (r || n) {
        const i = e.offset(this.ts), a = this.toObject();
        [s] = _r(a, i, e);
      }
      return rt(this, { ts: s, zone: e });
    } else
      return F.invalid($t(e));
  }
  /**
   * "Set" the locale, numberingSystem, or outputCalendar. Returns a newly-constructed DateTime.
   * @param {Object} properties - the properties to set
   * @example DateTime.local(2017, 5, 25).reconfigure({ locale: 'en-GB' })
   * @return {DateTime}
   */
  reconfigure({ locale: e, numberingSystem: r, outputCalendar: n } = {}) {
    const s = this.loc.clone({ locale: e, numberingSystem: r, outputCalendar: n });
    return rt(this, { loc: s });
  }
  /**
   * "Set" the locale. Returns a newly-constructed DateTime.
   * Just a convenient alias for reconfigure({ locale })
   * @example DateTime.local(2017, 5, 25).setLocale('en-GB')
   * @return {DateTime}
   */
  setLocale(e) {
    return this.reconfigure({ locale: e });
  }
  /**
   * "Set" the values of specified units. Returns a newly-constructed DateTime.
   * You can only set units with this method; for "setting" metadata, see {@link DateTime#reconfigure} and {@link DateTime#setZone}.
   *
   * This method also supports setting locale-based week units, i.e. `localWeekday`, `localWeekNumber` and `localWeekYear`.
   * They cannot be mixed with ISO-week units like `weekday`.
   * @param {Object} values - a mapping of units to numbers
   * @example dt.set({ year: 2017 })
   * @example dt.set({ hour: 8, minute: 30 })
   * @example dt.set({ weekday: 5 })
   * @example dt.set({ year: 2005, ordinal: 234 })
   * @return {DateTime}
   */
  set(e) {
    if (!this.isValid) return this;
    const r = Fr(e, Yi), { minDaysInFirstWeek: n, startOfWeek: s } = Ri(r, this.loc), i = !P(r.weekYear) || !P(r.weekNumber) || !P(r.weekday), a = !P(r.ordinal), u = !P(r.year), c = !P(r.month) || !P(r.day), l = u || c, d = r.weekYear || r.weekNumber;
    if ((l || a) && d)
      throw new wt(
        "Can't mix weekYear/weekNumber units with year/month/day or ordinals"
      );
    if (c && a)
      throw new wt("Can't mix ordinal dates with month/day");
    let v;
    i ? v = Ci(
      { ...Mr(this.c, n, s), ...r },
      n,
      s
    ) : P(r.ordinal) ? (v = { ...this.toObject(), ...r }, P(r.day) && (v.day = Math.min(Lr(v.year, v.month), v.day))) : v = Ai({ ...vn(this.c), ...r });
    const [T, O] = _r(v, this.o, this.zone);
    return rt(this, { ts: T, o: O });
  }
  /**
   * Add a period of time to this DateTime and return the resulting DateTime
   *
   * Adding hours, minutes, seconds, or milliseconds increases the timestamp by the right number of milliseconds. Adding days, months, or years shifts the calendar, accounting for DSTs and leap years along the way. Thus, `dt.plus({ hours: 24 })` may result in a different time than `dt.plus({ days: 1 })` if there's a DST shift in between.
   * @param {Duration|Object|number} duration - The amount to add. Either a Luxon Duration, a number of milliseconds, the object argument to Duration.fromObject()
   * @example DateTime.now().plus(123) //~> in 123 milliseconds
   * @example DateTime.now().plus({ minutes: 15 }) //~> in 15 minutes
   * @example DateTime.now().plus({ days: 1 }) //~> this time tomorrow
   * @example DateTime.now().plus({ days: -1 }) //~> this time yesterday
   * @example DateTime.now().plus({ hours: 3, minutes: 13 }) //~> in 3 hr, 13 min
   * @example DateTime.now().plus(Duration.fromObject({ hours: 3, minutes: 13 })) //~> in 3 hr, 13 min
   * @return {DateTime}
   */
  plus(e) {
    if (!this.isValid) return this;
    const r = G.fromDurationLike(e);
    return rt(this, ji(this, r));
  }
  /**
   * Subtract a period of time to this DateTime and return the resulting DateTime
   * See {@link DateTime#plus}
   * @param {Duration|Object|number} duration - The amount to subtract. Either a Luxon Duration, a number of milliseconds, the object argument to Duration.fromObject()
   @return {DateTime}
   */
  minus(e) {
    if (!this.isValid) return this;
    const r = G.fromDurationLike(e).negate();
    return rt(this, ji(this, r));
  }
  /**
   * "Set" this DateTime to the beginning of a unit of time.
   * @param {string} unit - The unit to go to the beginning of. Can be 'year', 'quarter', 'month', 'week', 'day', 'hour', 'minute', 'second', or 'millisecond'.
   * @param {Object} opts - options
   * @param {boolean} [opts.useLocaleWeeks=false] - If true, use weeks based on the locale, i.e. use the locale-dependent start of the week
   * @example DateTime.local(2014, 3, 3).startOf('month').toISODate(); //=> '2014-03-01'
   * @example DateTime.local(2014, 3, 3).startOf('year').toISODate(); //=> '2014-01-01'
   * @example DateTime.local(2014, 3, 3).startOf('week').toISODate(); //=> '2014-03-03', weeks always start on Mondays
   * @example DateTime.local(2014, 3, 3, 5, 30).startOf('day').toISOTime(); //=> '00:00.000-05:00'
   * @example DateTime.local(2014, 3, 3, 5, 30).startOf('hour').toISOTime(); //=> '05:00:00.000-05:00'
   * @return {DateTime}
   */
  startOf(e, { useLocaleWeeks: r = !1 } = {}) {
    if (!this.isValid) return this;
    const n = {}, s = G.normalizeUnit(e);
    switch (s) {
      case "years":
        n.month = 1;
      case "quarters":
      case "months":
        n.day = 1;
      case "weeks":
      case "days":
        n.hour = 0;
      case "hours":
        n.minute = 0;
      case "minutes":
        n.second = 0;
      case "seconds":
        n.millisecond = 0;
        break;
    }
    if (s === "weeks")
      if (r) {
        const i = this.loc.getStartOfWeek(), { weekday: a } = this;
        a < i && (n.weekNumber = this.weekNumber - 1), n.weekday = i;
      } else
        n.weekday = 1;
    if (s === "quarters") {
      const i = Math.ceil(this.month / 3);
      n.month = (i - 1) * 3 + 1;
    }
    return this.set(n);
  }
  /**
   * "Set" this DateTime to the end (meaning the last millisecond) of a unit of time
   * @param {string} unit - The unit to go to the end of. Can be 'year', 'quarter', 'month', 'week', 'day', 'hour', 'minute', 'second', or 'millisecond'.
   * @param {Object} opts - options
   * @param {boolean} [opts.useLocaleWeeks=false] - If true, use weeks based on the locale, i.e. use the locale-dependent start of the week
   * @example DateTime.local(2014, 3, 3).endOf('month').toISO(); //=> '2014-03-31T23:59:59.999-05:00'
   * @example DateTime.local(2014, 3, 3).endOf('year').toISO(); //=> '2014-12-31T23:59:59.999-05:00'
   * @example DateTime.local(2014, 3, 3).endOf('week').toISO(); // => '2014-03-09T23:59:59.999-05:00', weeks start on Mondays
   * @example DateTime.local(2014, 3, 3, 5, 30).endOf('day').toISO(); //=> '2014-03-03T23:59:59.999-05:00'
   * @example DateTime.local(2014, 3, 3, 5, 30).endOf('hour').toISO(); //=> '2014-03-03T05:59:59.999-05:00'
   * @return {DateTime}
   */
  endOf(e, r) {
    return this.isValid ? this.plus({ [e]: 1 }).startOf(e, r).minus(1) : this;
  }
  // OUTPUT
  /**
   * Returns a string representation of this DateTime formatted according to the specified format string.
   * **You may not want this.** See {@link DateTime#toLocaleString} for a more flexible formatting tool. For a table of tokens and their interpretations, see [here](https://moment.github.io/luxon/#/formatting?id=table-of-tokens).
   * Defaults to en-US if no locale has been specified, regardless of the system's locale.
   * @param {string} fmt - the format string
   * @param {Object} opts - opts to override the configuration options on this DateTime
   * @example DateTime.now().toFormat('yyyy LLL dd') //=> '2017 Apr 22'
   * @example DateTime.now().setLocale('fr').toFormat('yyyy LLL dd') //=> '2017 avr. 22'
   * @example DateTime.now().toFormat('yyyy LLL dd', { locale: "fr" }) //=> '2017 avr. 22'
   * @example DateTime.now().toFormat("HH 'hours and' mm 'minutes'") //=> '20 hours and 55 minutes'
   * @return {string}
   */
  toFormat(e, r = {}) {
    return this.isValid ? be.create(this.loc.redefaultToEN(r)).formatDateTimeFromString(this, e) : En;
  }
  /**
   * Returns a localized string representing this date. Accepts the same options as the Intl.DateTimeFormat constructor and any presets defined by Luxon, such as `DateTime.DATE_FULL` or `DateTime.TIME_SIMPLE`.
   * The exact behavior of this method is browser-specific, but in general it will return an appropriate representation
   * of the DateTime in the assigned locale.
   * Defaults to the system's locale if no locale has been specified
   * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DateTimeFormat
   * @param formatOpts {Object} - Intl.DateTimeFormat constructor options and configuration options
   * @param {Object} opts - opts to override the configuration options on this DateTime
   * @example DateTime.now().toLocaleString(); //=> 4/20/2017
   * @example DateTime.now().setLocale('en-gb').toLocaleString(); //=> '20/04/2017'
   * @example DateTime.now().toLocaleString(DateTime.DATE_FULL); //=> 'April 20, 2017'
   * @example DateTime.now().toLocaleString(DateTime.DATE_FULL, { locale: 'fr' }); //=> '28 août 2022'
   * @example DateTime.now().toLocaleString(DateTime.TIME_SIMPLE); //=> '11:32 AM'
   * @example DateTime.now().toLocaleString(DateTime.DATETIME_SHORT); //=> '4/20/2017, 11:32 AM'
   * @example DateTime.now().toLocaleString({ weekday: 'long', month: 'long', day: '2-digit' }); //=> 'Thursday, April 20'
   * @example DateTime.now().toLocaleString({ weekday: 'short', month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit' }); //=> 'Thu, Apr 20, 11:27 AM'
   * @example DateTime.now().toLocaleString({ hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }); //=> '11:32'
   * @return {string}
   */
  toLocaleString(e = xr, r = {}) {
    return this.isValid ? be.create(this.loc.clone(r), e).formatDateTime(this) : En;
  }
  /**
   * Returns an array of format "parts", meaning individual tokens along with metadata. This is allows callers to post-process individual sections of the formatted output.
   * Defaults to the system's locale if no locale has been specified
   * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DateTimeFormat/formatToParts
   * @param opts {Object} - Intl.DateTimeFormat constructor options, same as `toLocaleString`.
   * @example DateTime.now().toLocaleParts(); //=> [
   *                                   //=>   { type: 'day', value: '25' },
   *                                   //=>   { type: 'literal', value: '/' },
   *                                   //=>   { type: 'month', value: '05' },
   *                                   //=>   { type: 'literal', value: '/' },
   *                                   //=>   { type: 'year', value: '1982' }
   *                                   //=> ]
   */
  toLocaleParts(e = {}) {
    return this.isValid ? be.create(this.loc.clone(e), e).formatDateTimeParts(this) : [];
  }
  /**
   * Returns an ISO 8601-compliant string representation of this DateTime
   * @param {Object} opts - options
   * @param {boolean} [opts.suppressMilliseconds=false] - exclude milliseconds from the format if they're 0
   * @param {boolean} [opts.suppressSeconds=false] - exclude seconds from the format if they're 0
   * @param {boolean} [opts.includeOffset=true] - include the offset, such as 'Z' or '-04:00'
   * @param {boolean} [opts.extendedZone=false] - add the time zone format extension
   * @param {string} [opts.format='extended'] - choose between the basic and extended format
   * @example DateTime.utc(1983, 5, 25).toISO() //=> '1982-05-25T00:00:00.000Z'
   * @example DateTime.now().toISO() //=> '2017-04-22T20:47:05.335-04:00'
   * @example DateTime.now().toISO({ includeOffset: false }) //=> '2017-04-22T20:47:05.335'
   * @example DateTime.now().toISO({ format: 'basic' }) //=> '20170422T204705.335-0400'
   * @return {string}
   */
  toISO({
    format: e = "extended",
    suppressSeconds: r = !1,
    suppressMilliseconds: n = !1,
    includeOffset: s = !0,
    extendedZone: i = !1
  } = {}) {
    if (!this.isValid)
      return null;
    const a = e === "extended";
    let u = bn(this, a);
    return u += "T", u += zi(this, a, r, n, s, i), u;
  }
  /**
   * Returns an ISO 8601-compliant string representation of this DateTime's date component
   * @param {Object} opts - options
   * @param {string} [opts.format='extended'] - choose between the basic and extended format
   * @example DateTime.utc(1982, 5, 25).toISODate() //=> '1982-05-25'
   * @example DateTime.utc(1982, 5, 25).toISODate({ format: 'basic' }) //=> '19820525'
   * @return {string}
   */
  toISODate({ format: e = "extended" } = {}) {
    return this.isValid ? bn(this, e === "extended") : null;
  }
  /**
   * Returns an ISO 8601-compliant string representation of this DateTime's week date
   * @example DateTime.utc(1982, 5, 25).toISOWeekDate() //=> '1982-W21-2'
   * @return {string}
   */
  toISOWeekDate() {
    return wr(this, "kkkk-'W'WW-c");
  }
  /**
   * Returns an ISO 8601-compliant string representation of this DateTime's time component
   * @param {Object} opts - options
   * @param {boolean} [opts.suppressMilliseconds=false] - exclude milliseconds from the format if they're 0
   * @param {boolean} [opts.suppressSeconds=false] - exclude seconds from the format if they're 0
   * @param {boolean} [opts.includeOffset=true] - include the offset, such as 'Z' or '-04:00'
   * @param {boolean} [opts.extendedZone=true] - add the time zone format extension
   * @param {boolean} [opts.includePrefix=false] - include the `T` prefix
   * @param {string} [opts.format='extended'] - choose between the basic and extended format
   * @example DateTime.utc().set({ hour: 7, minute: 34 }).toISOTime() //=> '07:34:19.361Z'
   * @example DateTime.utc().set({ hour: 7, minute: 34, seconds: 0, milliseconds: 0 }).toISOTime({ suppressSeconds: true }) //=> '07:34Z'
   * @example DateTime.utc().set({ hour: 7, minute: 34 }).toISOTime({ format: 'basic' }) //=> '073419.361Z'
   * @example DateTime.utc().set({ hour: 7, minute: 34 }).toISOTime({ includePrefix: true }) //=> 'T07:34:19.361Z'
   * @return {string}
   */
  toISOTime({
    suppressMilliseconds: e = !1,
    suppressSeconds: r = !1,
    includeOffset: n = !0,
    includePrefix: s = !1,
    extendedZone: i = !1,
    format: a = "extended"
  } = {}) {
    return this.isValid ? (s ? "T" : "") + zi(
      this,
      a === "extended",
      r,
      e,
      n,
      i
    ) : null;
  }
  /**
   * Returns an RFC 2822-compatible string representation of this DateTime
   * @example DateTime.utc(2014, 7, 13).toRFC2822() //=> 'Sun, 13 Jul 2014 00:00:00 +0000'
   * @example DateTime.local(2014, 7, 13).toRFC2822() //=> 'Sun, 13 Jul 2014 00:00:00 -0400'
   * @return {string}
   */
  toRFC2822() {
    return wr(this, "EEE, dd LLL yyyy HH:mm:ss ZZZ", !1);
  }
  /**
   * Returns a string representation of this DateTime appropriate for use in HTTP headers. The output is always expressed in GMT.
   * Specifically, the string conforms to RFC 1123.
   * @see https://www.w3.org/Protocols/rfc2616/rfc2616-sec3.html#sec3.3.1
   * @example DateTime.utc(2014, 7, 13).toHTTP() //=> 'Sun, 13 Jul 2014 00:00:00 GMT'
   * @example DateTime.utc(2014, 7, 13, 19).toHTTP() //=> 'Sun, 13 Jul 2014 19:00:00 GMT'
   * @return {string}
   */
  toHTTP() {
    return wr(this.toUTC(), "EEE, dd LLL yyyy HH:mm:ss 'GMT'");
  }
  /**
   * Returns a string representation of this DateTime appropriate for use in SQL Date
   * @example DateTime.utc(2014, 7, 13).toSQLDate() //=> '2014-07-13'
   * @return {string}
   */
  toSQLDate() {
    return this.isValid ? bn(this, !0) : null;
  }
  /**
   * Returns a string representation of this DateTime appropriate for use in SQL Time
   * @param {Object} opts - options
   * @param {boolean} [opts.includeZone=false] - include the zone, such as 'America/New_York'. Overrides includeOffset.
   * @param {boolean} [opts.includeOffset=true] - include the offset, such as 'Z' or '-04:00'
   * @param {boolean} [opts.includeOffsetSpace=true] - include the space between the time and the offset, such as '05:15:16.345 -04:00'
   * @example DateTime.utc().toSQL() //=> '05:15:16.345'
   * @example DateTime.now().toSQL() //=> '05:15:16.345 -04:00'
   * @example DateTime.now().toSQL({ includeOffset: false }) //=> '05:15:16.345'
   * @example DateTime.now().toSQL({ includeZone: false }) //=> '05:15:16.345 America/New_York'
   * @return {string}
   */
  toSQLTime({ includeOffset: e = !0, includeZone: r = !1, includeOffsetSpace: n = !0 } = {}) {
    let s = "HH:mm:ss.SSS";
    return (r || e) && (n && (s += " "), r ? s += "z" : e && (s += "ZZ")), wr(this, s, !0);
  }
  /**
   * Returns a string representation of this DateTime appropriate for use in SQL DateTime
   * @param {Object} opts - options
   * @param {boolean} [opts.includeZone=false] - include the zone, such as 'America/New_York'. Overrides includeOffset.
   * @param {boolean} [opts.includeOffset=true] - include the offset, such as 'Z' or '-04:00'
   * @param {boolean} [opts.includeOffsetSpace=true] - include the space between the time and the offset, such as '05:15:16.345 -04:00'
   * @example DateTime.utc(2014, 7, 13).toSQL() //=> '2014-07-13 00:00:00.000 Z'
   * @example DateTime.local(2014, 7, 13).toSQL() //=> '2014-07-13 00:00:00.000 -04:00'
   * @example DateTime.local(2014, 7, 13).toSQL({ includeOffset: false }) //=> '2014-07-13 00:00:00.000'
   * @example DateTime.local(2014, 7, 13).toSQL({ includeZone: true }) //=> '2014-07-13 00:00:00.000 America/New_York'
   * @return {string}
   */
  toSQL(e = {}) {
    return this.isValid ? `${this.toSQLDate()} ${this.toSQLTime(e)}` : null;
  }
  /**
   * Returns a string representation of this DateTime appropriate for debugging
   * @return {string}
   */
  toString() {
    return this.isValid ? this.toISO() : En;
  }
  /**
   * Returns a string representation of this DateTime appropriate for the REPL.
   * @return {string}
   */
  [Symbol.for("nodejs.util.inspect.custom")]() {
    return this.isValid ? `DateTime { ts: ${this.toISO()}, zone: ${this.zone.name}, locale: ${this.locale} }` : `DateTime { Invalid, reason: ${this.invalidReason} }`;
  }
  /**
   * Returns the epoch milliseconds of this DateTime. Alias of {@link DateTime#toMillis}
   * @return {number}
   */
  valueOf() {
    return this.toMillis();
  }
  /**
   * Returns the epoch milliseconds of this DateTime.
   * @return {number}
   */
  toMillis() {
    return this.isValid ? this.ts : NaN;
  }
  /**
   * Returns the epoch seconds of this DateTime.
   * @return {number}
   */
  toSeconds() {
    return this.isValid ? this.ts / 1e3 : NaN;
  }
  /**
   * Returns the epoch seconds (as a whole number) of this DateTime.
   * @return {number}
   */
  toUnixInteger() {
    return this.isValid ? Math.floor(this.ts / 1e3) : NaN;
  }
  /**
   * Returns an ISO 8601 representation of this DateTime appropriate for use in JSON.
   * @return {string}
   */
  toJSON() {
    return this.toISO();
  }
  /**
   * Returns a BSON serializable equivalent to this DateTime.
   * @return {Date}
   */
  toBSON() {
    return this.toJSDate();
  }
  /**
   * Returns a JavaScript object with this DateTime's year, month, day, and so on.
   * @param opts - options for generating the object
   * @param {boolean} [opts.includeConfig=false] - include configuration attributes in the output
   * @example DateTime.now().toObject() //=> { year: 2017, month: 4, day: 22, hour: 20, minute: 49, second: 42, millisecond: 268 }
   * @return {Object}
   */
  toObject(e = {}) {
    if (!this.isValid) return {};
    const r = { ...this.c };
    return e.includeConfig && (r.outputCalendar = this.outputCalendar, r.numberingSystem = this.loc.numberingSystem, r.locale = this.loc.locale), r;
  }
  /**
   * Returns a JavaScript Date equivalent to this DateTime.
   * @return {Date}
   */
  toJSDate() {
    return new Date(this.isValid ? this.ts : NaN);
  }
  // COMPARE
  /**
   * Return the difference between two DateTimes as a Duration.
   * @param {DateTime} otherDateTime - the DateTime to compare this one to
   * @param {string|string[]} [unit=['milliseconds']] - the unit or array of units (such as 'hours' or 'days') to include in the duration.
   * @param {Object} opts - options that affect the creation of the Duration
   * @param {string} [opts.conversionAccuracy='casual'] - the conversion system to use
   * @example
   * var i1 = DateTime.fromISO('1982-05-25T09:45'),
   *     i2 = DateTime.fromISO('1983-10-14T10:30');
   * i2.diff(i1).toObject() //=> { milliseconds: 43807500000 }
   * i2.diff(i1, 'hours').toObject() //=> { hours: 12168.75 }
   * i2.diff(i1, ['months', 'days']).toObject() //=> { months: 16, days: 19.03125 }
   * i2.diff(i1, ['months', 'days', 'hours']).toObject() //=> { months: 16, days: 19, hours: 0.75 }
   * @return {Duration}
   */
  diff(e, r = "milliseconds", n = {}) {
    if (!this.isValid || !e.isValid)
      return G.invalid("created by diffing an invalid DateTime");
    const s = { locale: this.locale, numberingSystem: this.numberingSystem, ...n }, i = Dd(r).map(G.normalizeUnit), a = e.valueOf() > this.valueOf(), u = a ? this : e, c = a ? e : this, l = xh(u, c, i, s);
    return a ? l.negate() : l;
  }
  /**
   * Return the difference between this DateTime and right now.
   * See {@link DateTime#diff}
   * @param {string|string[]} [unit=['milliseconds']] - the unit or units units (such as 'hours' or 'days') to include in the duration
   * @param {Object} opts - options that affect the creation of the Duration
   * @param {string} [opts.conversionAccuracy='casual'] - the conversion system to use
   * @return {Duration}
   */
  diffNow(e = "milliseconds", r = {}) {
    return this.diff(F.now(), e, r);
  }
  /**
   * Return an Interval spanning between this DateTime and another DateTime
   * @param {DateTime} otherDateTime - the other end point of the Interval
   * @return {Interval}
   */
  until(e) {
    return this.isValid ? le.fromDateTimes(this, e) : this;
  }
  /**
   * Return whether this DateTime is in the same unit of time as another DateTime.
   * Higher-order units must also be identical for this function to return `true`.
   * Note that time zones are **ignored** in this comparison, which compares the **local** calendar time. Use {@link DateTime#setZone} to convert one of the dates if needed.
   * @param {DateTime} otherDateTime - the other DateTime
   * @param {string} unit - the unit of time to check sameness on
   * @param {Object} opts - options
   * @param {boolean} [opts.useLocaleWeeks=false] - If true, use weeks based on the locale, i.e. use the locale-dependent start of the week; only the locale of this DateTime is used
   * @example DateTime.now().hasSame(otherDT, 'day'); //~> true if otherDT is in the same current calendar day
   * @return {boolean}
   */
  hasSame(e, r, n) {
    if (!this.isValid) return !1;
    const s = e.valueOf(), i = this.setZone(e.zone, { keepLocalTime: !0 });
    return i.startOf(r, n) <= s && s <= i.endOf(r, n);
  }
  /**
   * Equality check
   * Two DateTimes are equal if and only if they represent the same millisecond, have the same zone and location, and are both valid.
   * To compare just the millisecond values, use `+dt1 === +dt2`.
   * @param {DateTime} other - the other DateTime
   * @return {boolean}
   */
  equals(e) {
    return this.isValid && e.isValid && this.valueOf() === e.valueOf() && this.zone.equals(e.zone) && this.loc.equals(e.loc);
  }
  /**
   * Returns a string representation of a this time relative to now, such as "in two days". Can only internationalize if your
   * platform supports Intl.RelativeTimeFormat. Rounds down by default.
   * @param {Object} options - options that affect the output
   * @param {DateTime} [options.base=DateTime.now()] - the DateTime to use as the basis to which this time is compared. Defaults to now.
   * @param {string} [options.style="long"] - the style of units, must be "long", "short", or "narrow"
   * @param {string|string[]} options.unit - use a specific unit or array of units; if omitted, or an array, the method will pick the best unit. Use an array or one of "years", "quarters", "months", "weeks", "days", "hours", "minutes", or "seconds"
   * @param {boolean} [options.round=true] - whether to round the numbers in the output.
   * @param {number} [options.padding=0] - padding in milliseconds. This allows you to round up the result if it fits inside the threshold. Don't use in combination with {round: false} because the decimal output will include the padding.
   * @param {string} options.locale - override the locale of this DateTime
   * @param {string} options.numberingSystem - override the numberingSystem of this DateTime. The Intl system may choose not to honor this
   * @example DateTime.now().plus({ days: 1 }).toRelative() //=> "in 1 day"
   * @example DateTime.now().setLocale("es").toRelative({ days: 1 }) //=> "dentro de 1 día"
   * @example DateTime.now().plus({ days: 1 }).toRelative({ locale: "fr" }) //=> "dans 23 heures"
   * @example DateTime.now().minus({ days: 2 }).toRelative() //=> "2 days ago"
   * @example DateTime.now().minus({ days: 2 }).toRelative({ unit: "hours" }) //=> "48 hours ago"
   * @example DateTime.now().minus({ hours: 36 }).toRelative({ round: false }) //=> "1.5 days ago"
   */
  toRelative(e = {}) {
    if (!this.isValid) return null;
    const r = e.base || F.fromObject({}, { zone: this.zone }), n = e.padding ? this < r ? -e.padding : e.padding : 0;
    let s = ["years", "months", "days", "hours", "minutes", "seconds"], i = e.unit;
    return Array.isArray(e.unit) && (s = e.unit, i = void 0), qi(r, this.plus(n), {
      ...e,
      numeric: "always",
      units: s,
      unit: i
    });
  }
  /**
   * Returns a string representation of this date relative to today, such as "yesterday" or "next month".
   * Only internationalizes on platforms that supports Intl.RelativeTimeFormat.
   * @param {Object} options - options that affect the output
   * @param {DateTime} [options.base=DateTime.now()] - the DateTime to use as the basis to which this time is compared. Defaults to now.
   * @param {string} options.locale - override the locale of this DateTime
   * @param {string} options.unit - use a specific unit; if omitted, the method will pick the unit. Use one of "years", "quarters", "months", "weeks", or "days"
   * @param {string} options.numberingSystem - override the numberingSystem of this DateTime. The Intl system may choose not to honor this
   * @example DateTime.now().plus({ days: 1 }).toRelativeCalendar() //=> "tomorrow"
   * @example DateTime.now().setLocale("es").plus({ days: 1 }).toRelative() //=> ""mañana"
   * @example DateTime.now().plus({ days: 1 }).toRelativeCalendar({ locale: "fr" }) //=> "demain"
   * @example DateTime.now().minus({ days: 2 }).toRelativeCalendar() //=> "2 days ago"
   */
  toRelativeCalendar(e = {}) {
    return this.isValid ? qi(e.base || F.fromObject({}, { zone: this.zone }), this, {
      ...e,
      numeric: "auto",
      units: ["years", "months", "days"],
      calendary: !0
    }) : null;
  }
  /**
   * Return the min of several date times
   * @param {...DateTime} dateTimes - the DateTimes from which to choose the minimum
   * @return {DateTime} the min DateTime, or undefined if called with no argument
   */
  static min(...e) {
    if (!e.every(F.isDateTime))
      throw new we("min requires all arguments be DateTimes");
    return xi(e, (r) => r.valueOf(), Math.min);
  }
  /**
   * Return the max of several date times
   * @param {...DateTime} dateTimes - the DateTimes from which to choose the maximum
   * @return {DateTime} the max DateTime, or undefined if called with no argument
   */
  static max(...e) {
    if (!e.every(F.isDateTime))
      throw new we("max requires all arguments be DateTimes");
    return xi(e, (r) => r.valueOf(), Math.max);
  }
  // MISC
  /**
   * Explain how a string would be parsed by fromFormat()
   * @param {string} text - the string to parse
   * @param {string} fmt - the format the string is expected to be in (see description)
   * @param {Object} options - options taken by fromFormat()
   * @return {Object}
   */
  static fromFormatExplain(e, r, n = {}) {
    const { locale: s = null, numberingSystem: i = null } = n, a = X.fromOpts({
      locale: s,
      numberingSystem: i,
      defaultToEN: !0
    });
    return $o(a, e, r);
  }
  /**
   * @deprecated use fromFormatExplain instead
   */
  static fromStringExplain(e, r, n = {}) {
    return F.fromFormatExplain(e, r, n);
  }
  /**
   * Build a parser for `fmt` using the given locale. This parser can be passed
   * to {@link DateTime.fromFormatParser} to a parse a date in this format. This
   * can be used to optimize cases where many dates need to be parsed in a
   * specific format.
   *
   * @param {String} fmt - the format the string is expected to be in (see
   * description)
   * @param {Object} options - options used to set locale and numberingSystem
   * for parser
   * @returns {TokenParser} - opaque object to be used
   */
  static buildFormatParser(e, r = {}) {
    const { locale: n = null, numberingSystem: s = null } = r, i = X.fromOpts({
      locale: n,
      numberingSystem: s,
      defaultToEN: !0
    });
    return new Uo(i, e);
  }
  /**
   * Create a DateTime from an input string and format parser.
   *
   * The format parser must have been created with the same locale as this call.
   *
   * @param {String} text - the string to parse
   * @param {TokenParser} formatParser - parser from {@link DateTime.buildFormatParser}
   * @param {Object} opts - options taken by fromFormat()
   * @returns {DateTime}
   */
  static fromFormatParser(e, r, n = {}) {
    if (P(e) || P(r))
      throw new we(
        "fromFormatParser requires an input string and a format parser"
      );
    const { locale: s = null, numberingSystem: i = null } = n, a = X.fromOpts({
      locale: s,
      numberingSystem: i,
      defaultToEN: !0
    });
    if (!a.equals(r.locale))
      throw new we(
        `fromFormatParser called with a locale of ${a}, but the format parser was created for ${r.locale}`
      );
    const { result: u, zone: c, specificOffset: l, invalidReason: d } = r.explainFromTokens(e);
    return d ? F.invalid(d) : gt(
      u,
      c,
      n,
      `format ${r.format}`,
      e,
      l
    );
  }
  // FORMAT PRESETS
  /**
   * {@link DateTime#toLocaleString} format like 10/14/1983
   * @type {Object}
   */
  static get DATE_SHORT() {
    return xr;
  }
  /**
   * {@link DateTime#toLocaleString} format like 'Oct 14, 1983'
   * @type {Object}
   */
  static get DATE_MED() {
    return Ya;
  }
  /**
   * {@link DateTime#toLocaleString} format like 'Fri, Oct 14, 1983'
   * @type {Object}
   */
  static get DATE_MED_WITH_WEEKDAY() {
    return td;
  }
  /**
   * {@link DateTime#toLocaleString} format like 'October 14, 1983'
   * @type {Object}
   */
  static get DATE_FULL() {
    return Ba;
  }
  /**
   * {@link DateTime#toLocaleString} format like 'Tuesday, October 14, 1983'
   * @type {Object}
   */
  static get DATE_HUGE() {
    return qa;
  }
  /**
   * {@link DateTime#toLocaleString} format like '09:30 AM'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get TIME_SIMPLE() {
    return Ga;
  }
  /**
   * {@link DateTime#toLocaleString} format like '09:30:23 AM'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get TIME_WITH_SECONDS() {
    return Za;
  }
  /**
   * {@link DateTime#toLocaleString} format like '09:30:23 AM EDT'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get TIME_WITH_SHORT_OFFSET() {
    return Qa;
  }
  /**
   * {@link DateTime#toLocaleString} format like '09:30:23 AM Eastern Daylight Time'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get TIME_WITH_LONG_OFFSET() {
    return Ja;
  }
  /**
   * {@link DateTime#toLocaleString} format like '09:30', always 24-hour.
   * @type {Object}
   */
  static get TIME_24_SIMPLE() {
    return Xa;
  }
  /**
   * {@link DateTime#toLocaleString} format like '09:30:23', always 24-hour.
   * @type {Object}
   */
  static get TIME_24_WITH_SECONDS() {
    return Ka;
  }
  /**
   * {@link DateTime#toLocaleString} format like '09:30:23 EDT', always 24-hour.
   * @type {Object}
   */
  static get TIME_24_WITH_SHORT_OFFSET() {
    return eo;
  }
  /**
   * {@link DateTime#toLocaleString} format like '09:30:23 Eastern Daylight Time', always 24-hour.
   * @type {Object}
   */
  static get TIME_24_WITH_LONG_OFFSET() {
    return to;
  }
  /**
   * {@link DateTime#toLocaleString} format like '10/14/1983, 9:30 AM'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get DATETIME_SHORT() {
    return ro;
  }
  /**
   * {@link DateTime#toLocaleString} format like '10/14/1983, 9:30:33 AM'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get DATETIME_SHORT_WITH_SECONDS() {
    return no;
  }
  /**
   * {@link DateTime#toLocaleString} format like 'Oct 14, 1983, 9:30 AM'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get DATETIME_MED() {
    return so;
  }
  /**
   * {@link DateTime#toLocaleString} format like 'Oct 14, 1983, 9:30:33 AM'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get DATETIME_MED_WITH_SECONDS() {
    return io;
  }
  /**
   * {@link DateTime#toLocaleString} format like 'Fri, 14 Oct 1983, 9:30 AM'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get DATETIME_MED_WITH_WEEKDAY() {
    return rd;
  }
  /**
   * {@link DateTime#toLocaleString} format like 'October 14, 1983, 9:30 AM EDT'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get DATETIME_FULL() {
    return ao;
  }
  /**
   * {@link DateTime#toLocaleString} format like 'October 14, 1983, 9:30:33 AM EDT'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get DATETIME_FULL_WITH_SECONDS() {
    return oo;
  }
  /**
   * {@link DateTime#toLocaleString} format like 'Friday, October 14, 1983, 9:30 AM Eastern Daylight Time'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get DATETIME_HUGE() {
    return uo;
  }
  /**
   * {@link DateTime#toLocaleString} format like 'Friday, October 14, 1983, 9:30:33 AM Eastern Daylight Time'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get DATETIME_HUGE_WITH_SECONDS() {
    return co;
  }
}
function Ft(t) {
  if (F.isDateTime(t))
    return t;
  if (t && t.valueOf && Ke(t.valueOf()))
    return F.fromJSDate(t);
  if (t && typeof t == "object")
    return F.fromObject(t);
  throw new we(
    `Unknown datetime argument: ${t}, of type ${typeof t}`
  );
}
const Qp = M(F.local());
export {
  ut as $,
  lp as A,
  pp as B,
  ba as C,
  Nn as D,
  ma as E,
  Xi as F,
  Qn as G,
  cp as H,
  rp as I,
  np as J,
  L as K,
  $e as L,
  Ki as M,
  Rr as N,
  Ot as O,
  rl as P,
  fc as Q,
  ec as R,
  ri as S,
  jt as T,
  hp as U,
  xn as V,
  ni as W,
  Ta as X,
  sc as Y,
  dp as Z,
  J as _,
  Ji as a,
  Vp as a$,
  vp as a0,
  yp as a1,
  Jn as a2,
  nc as a3,
  mp as a4,
  kr as a5,
  fp as a6,
  ra as a7,
  ka as a8,
  Z as a9,
  Bf as aA,
  Hp as aB,
  ja as aC,
  Wa as aD,
  F as aE,
  Ha as aF,
  $a as aG,
  Qp as aH,
  Yf as aI,
  Jf as aJ,
  jl as aK,
  Rp as aL,
  Sp as aM,
  zt as aN,
  Qf as aO,
  Yp as aP,
  ye as aQ,
  g as aR,
  da as aS,
  gp as aT,
  qf as aU,
  Op as aV,
  _e as aW,
  Np as aX,
  Hf as aY,
  Fa as aZ,
  Up as a_,
  Ua as aa,
  xp as ab,
  Ap as ac,
  Wf as ad,
  Mp as ae,
  Gp as af,
  zf as ag,
  Lp as ah,
  Yt as ai,
  ep as aj,
  Pp as ak,
  Fp as al,
  M as am,
  Cp as an,
  kp as ao,
  zp as ap,
  Ur as aq,
  Ep as ar,
  Tp as as,
  _p as at,
  Ml as au,
  oe as av,
  wp as aw,
  bp as ax,
  Gf as ay,
  Zt as az,
  tp as b,
  Ip as b0,
  Dp as b1,
  Wp as b2,
  $p as b3,
  jp as b4,
  gi as b5,
  Zf as b6,
  Bp as b7,
  qp as b8,
  Zp as b9,
  jf as ba,
  Oe as bb,
  $f as c,
  Kh as d,
  an as e,
  fa as f,
  Qi as g,
  rs as h,
  ip as i,
  hc as j,
  oa as k,
  Lc as l,
  ic as m,
  ac as n,
  Pc as o,
  ap as p,
  We as q,
  qn as r,
  sp as s,
  Ve as t,
  ga as u,
  Zc as v,
  Dn as w,
  up as x,
  op as y,
  qc as z
};
