function Ji(t, e) {
  for (var n = 0; n < e.length; n++) {
    const r = e[n];
    if (typeof r != "string" && !Array.isArray(r)) {
      for (const s in r)
        if (s !== "default" && !(s in t)) {
          const i = Object.getOwnPropertyDescriptor(r, s);
          i && Object.defineProperty(t, s, i.get ? i : {
            enumerable: !0,
            get: () => r[s]
          });
        }
    }
  }
  return Object.freeze(Object.defineProperty(t, Symbol.toStringTag, { value: "Module" }));
}
var ap = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};
function Xi(t) {
  return t && t.__esModule && Object.prototype.hasOwnProperty.call(t, "default") ? t.default : t;
}
function op(t) {
  if (t.__esModule) return t;
  var e = t.default;
  if (typeof e == "function") {
    var n = function r() {
      return this instanceof r ? Reflect.construct(e, arguments, this.constructor) : e.apply(this, arguments);
    };
    n.prototype = e.prototype;
  } else n = {};
  return Object.defineProperty(n, "__esModule", { value: !0 }), Object.keys(t).forEach(function(r) {
    var s = Object.getOwnPropertyDescriptor(t, r);
    Object.defineProperty(n, r, s.get ? s : {
      enumerable: !0,
      get: function() {
        return t[r];
      }
    });
  }), n;
}
var Tr = { exports: {} }, H = {};
/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var Zs;
function Ku() {
  if (Zs) return H;
  Zs = 1;
  var t = Symbol.for("react.element"), e = Symbol.for("react.portal"), n = Symbol.for("react.fragment"), r = Symbol.for("react.strict_mode"), s = Symbol.for("react.profiler"), i = Symbol.for("react.provider"), a = Symbol.for("react.context"), u = Symbol.for("react.forward_ref"), c = Symbol.for("react.suspense"), l = Symbol.for("react.memo"), d = Symbol.for("react.lazy"), m = Symbol.iterator;
  function T(h) {
    return h === null || typeof h != "object" ? null : (h = m && h[m] || h["@@iterator"], typeof h == "function" ? h : null);
  }
  var E = { isMounted: function() {
    return !1;
  }, enqueueForceUpdate: function() {
  }, enqueueReplaceState: function() {
  }, enqueueSetState: function() {
  } }, S = Object.assign, _ = {};
  function w(h, k, $) {
    this.props = h, this.context = k, this.refs = _, this.updater = $ || E;
  }
  w.prototype.isReactComponent = {}, w.prototype.setState = function(h, k) {
    if (typeof h != "object" && typeof h != "function" && h != null) throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");
    this.updater.enqueueSetState(this, h, k, "setState");
  }, w.prototype.forceUpdate = function(h) {
    this.updater.enqueueForceUpdate(this, h, "forceUpdate");
  };
  function v() {
  }
  v.prototype = w.prototype;
  function O(h, k, $) {
    this.props = h, this.context = k, this.refs = _, this.updater = $ || E;
  }
  var R = O.prototype = new v();
  R.constructor = O, S(R, w.prototype), R.isPureReactComponent = !0;
  var M = Array.isArray, U = Object.prototype.hasOwnProperty, D = { current: null }, j = { key: !0, ref: !0, __self: !0, __source: !0 };
  function V(h, k, $) {
    var ee, B = {}, re = null, de = null;
    if (k != null) for (ee in k.ref !== void 0 && (de = k.ref), k.key !== void 0 && (re = "" + k.key), k) U.call(k, ee) && !j.hasOwnProperty(ee) && (B[ee] = k[ee]);
    var se = arguments.length - 2;
    if (se === 1) B.children = $;
    else if (1 < se) {
      for (var ie = Array(se), Oe = 0; Oe < se; Oe++) ie[Oe] = arguments[Oe + 2];
      B.children = ie;
    }
    if (h && h.defaultProps) for (ee in se = h.defaultProps, se) B[ee] === void 0 && (B[ee] = se[ee]);
    return { $$typeof: t, type: h, key: re, ref: de, props: B, _owner: D.current };
  }
  function A(h, k) {
    return { $$typeof: t, type: h.type, key: k, ref: h.ref, props: h.props, _owner: h._owner };
  }
  function q(h) {
    return typeof h == "object" && h !== null && h.$$typeof === t;
  }
  function ne(h) {
    var k = { "=": "=0", ":": "=2" };
    return "$" + h.replace(/[=:]/g, function($) {
      return k[$];
    });
  }
  var je = /\/+/g;
  function ze(h, k) {
    return typeof h == "object" && h !== null && h.key != null ? ne("" + h.key) : k.toString(36);
  }
  function Be(h, k, $, ee, B) {
    var re = typeof h;
    (re === "undefined" || re === "boolean") && (h = null);
    var de = !1;
    if (h === null) de = !0;
    else switch (re) {
      case "string":
      case "number":
        de = !0;
        break;
      case "object":
        switch (h.$$typeof) {
          case t:
          case e:
            de = !0;
        }
    }
    if (de) return de = h, B = B(de), h = ee === "" ? "." + ze(de, 0) : ee, M(B) ? ($ = "", h != null && ($ = h.replace(je, "$&/") + "/"), Be(B, k, $, "", function(Oe) {
      return Oe;
    })) : B != null && (q(B) && (B = A(B, $ + (!B.key || de && de.key === B.key ? "" : ("" + B.key).replace(je, "$&/") + "/") + h)), k.push(B)), 1;
    if (de = 0, ee = ee === "" ? "." : ee + ":", M(h)) for (var se = 0; se < h.length; se++) {
      re = h[se];
      var ie = ee + ze(re, se);
      de += Be(re, k, $, ie, B);
    }
    else if (ie = T(h), typeof ie == "function") for (h = ie.call(h), se = 0; !(re = h.next()).done; ) re = re.value, ie = ee + ze(re, se++), de += Be(re, k, $, ie, B);
    else if (re === "object") throw k = String(h), Error("Objects are not valid as a React child (found: " + (k === "[object Object]" ? "object with keys {" + Object.keys(h).join(", ") + "}" : k) + "). If you meant to render a collection of children, use an array instead.");
    return de;
  }
  function dt(h, k, $) {
    if (h == null) return h;
    var ee = [], B = 0;
    return Be(h, ee, "", "", function(re) {
      return k.call($, re, B++);
    }), ee;
  }
  function Ye(h) {
    if (h._status === -1) {
      var k = h._result;
      k = k(), k.then(function($) {
        (h._status === 0 || h._status === -1) && (h._status = 1, h._result = $);
      }, function($) {
        (h._status === 0 || h._status === -1) && (h._status = 2, h._result = $);
      }), h._status === -1 && (h._status = 0, h._result = k);
    }
    if (h._status === 1) return h._result.default;
    throw h._result;
  }
  var ce = { current: null }, z = { transition: null }, en = { ReactCurrentDispatcher: ce, ReactCurrentBatchConfig: z, ReactCurrentOwner: D };
  function At() {
    throw Error("act(...) is not supported in production builds of React.");
  }
  return H.Children = { map: dt, forEach: function(h, k, $) {
    dt(h, function() {
      k.apply(this, arguments);
    }, $);
  }, count: function(h) {
    var k = 0;
    return dt(h, function() {
      k++;
    }), k;
  }, toArray: function(h) {
    return dt(h, function(k) {
      return k;
    }) || [];
  }, only: function(h) {
    if (!q(h)) throw Error("React.Children.only expected to receive a single React element child.");
    return h;
  } }, H.Component = w, H.Fragment = n, H.Profiler = s, H.PureComponent = O, H.StrictMode = r, H.Suspense = c, H.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = en, H.act = At, H.cloneElement = function(h, k, $) {
    if (h == null) throw Error("React.cloneElement(...): The argument must be a React element, but you passed " + h + ".");
    var ee = S({}, h.props), B = h.key, re = h.ref, de = h._owner;
    if (k != null) {
      if (k.ref !== void 0 && (re = k.ref, de = D.current), k.key !== void 0 && (B = "" + k.key), h.type && h.type.defaultProps) var se = h.type.defaultProps;
      for (ie in k) U.call(k, ie) && !j.hasOwnProperty(ie) && (ee[ie] = k[ie] === void 0 && se !== void 0 ? se[ie] : k[ie]);
    }
    var ie = arguments.length - 2;
    if (ie === 1) ee.children = $;
    else if (1 < ie) {
      se = Array(ie);
      for (var Oe = 0; Oe < ie; Oe++) se[Oe] = arguments[Oe + 2];
      ee.children = se;
    }
    return { $$typeof: t, type: h.type, key: B, ref: re, props: ee, _owner: de };
  }, H.createContext = function(h) {
    return h = { $$typeof: a, _currentValue: h, _currentValue2: h, _threadCount: 0, Provider: null, Consumer: null, _defaultValue: null, _globalName: null }, h.Provider = { $$typeof: i, _context: h }, h.Consumer = h;
  }, H.createElement = V, H.createFactory = function(h) {
    var k = V.bind(null, h);
    return k.type = h, k;
  }, H.createRef = function() {
    return { current: null };
  }, H.forwardRef = function(h) {
    return { $$typeof: u, render: h };
  }, H.isValidElement = q, H.lazy = function(h) {
    return { $$typeof: d, _payload: { _status: -1, _result: h }, _init: Ye };
  }, H.memo = function(h, k) {
    return { $$typeof: l, type: h, compare: k === void 0 ? null : k };
  }, H.startTransition = function(h) {
    var k = z.transition;
    z.transition = {};
    try {
      h();
    } finally {
      z.transition = k;
    }
  }, H.unstable_act = At, H.useCallback = function(h, k) {
    return ce.current.useCallback(h, k);
  }, H.useContext = function(h) {
    return ce.current.useContext(h);
  }, H.useDebugValue = function() {
  }, H.useDeferredValue = function(h) {
    return ce.current.useDeferredValue(h);
  }, H.useEffect = function(h, k) {
    return ce.current.useEffect(h, k);
  }, H.useId = function() {
    return ce.current.useId();
  }, H.useImperativeHandle = function(h, k, $) {
    return ce.current.useImperativeHandle(h, k, $);
  }, H.useInsertionEffect = function(h, k) {
    return ce.current.useInsertionEffect(h, k);
  }, H.useLayoutEffect = function(h, k) {
    return ce.current.useLayoutEffect(h, k);
  }, H.useMemo = function(h, k) {
    return ce.current.useMemo(h, k);
  }, H.useReducer = function(h, k, $) {
    return ce.current.useReducer(h, k, $);
  }, H.useRef = function(h) {
    return ce.current.useRef(h);
  }, H.useState = function(h) {
    return ce.current.useState(h);
  }, H.useSyncExternalStore = function(h, k, $) {
    return ce.current.useSyncExternalStore(h, k, $);
  }, H.useTransition = function() {
    return ce.current.useTransition();
  }, H.version = "18.3.1", H;
}
var Vt = { exports: {} };
Vt.exports;
var Qs;
function ec() {
  return Qs || (Qs = 1, function(t, e) {
    var n = {};
    /**
     * @license React
     * react.development.js
     *
     * Copyright (c) Facebook, Inc. and its affiliates.
     *
     * This source code is licensed under the MIT license found in the
     * LICENSE file in the root directory of this source tree.
     */
    n.NODE_ENV !== "production" && function() {
      typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u" && typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart == "function" && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(new Error());
      var r = "18.3.1", s = Symbol.for("react.element"), i = Symbol.for("react.portal"), a = Symbol.for("react.fragment"), u = Symbol.for("react.strict_mode"), c = Symbol.for("react.profiler"), l = Symbol.for("react.provider"), d = Symbol.for("react.context"), m = Symbol.for("react.forward_ref"), T = Symbol.for("react.suspense"), E = Symbol.for("react.suspense_list"), S = Symbol.for("react.memo"), _ = Symbol.for("react.lazy"), w = Symbol.for("react.offscreen"), v = Symbol.iterator, O = "@@iterator";
      function R(o) {
        if (o === null || typeof o != "object")
          return null;
        var f = v && o[v] || o[O];
        return typeof f == "function" ? f : null;
      }
      var M = {
        /**
         * @internal
         * @type {ReactComponent}
         */
        current: null
      }, U = {
        transition: null
      }, D = {
        current: null,
        // Used to reproduce behavior of `batchedUpdates` in legacy mode.
        isBatchingLegacy: !1,
        didScheduleLegacyUpdate: !1
      }, j = {
        /**
         * @internal
         * @type {ReactComponent}
         */
        current: null
      }, V = {}, A = null;
      function q(o) {
        A = o;
      }
      V.setExtraStackFrame = function(o) {
        A = o;
      }, V.getCurrentStack = null, V.getStackAddendum = function() {
        var o = "";
        A && (o += A);
        var f = V.getCurrentStack;
        return f && (o += f() || ""), o;
      };
      var ne = !1, je = !1, ze = !1, Be = !1, dt = !1, Ye = {
        ReactCurrentDispatcher: M,
        ReactCurrentBatchConfig: U,
        ReactCurrentOwner: j
      };
      Ye.ReactDebugCurrentFrame = V, Ye.ReactCurrentActQueue = D;
      function ce(o) {
        {
          for (var f = arguments.length, p = new Array(f > 1 ? f - 1 : 0), y = 1; y < f; y++)
            p[y - 1] = arguments[y];
          en("warn", o, p);
        }
      }
      function z(o) {
        {
          for (var f = arguments.length, p = new Array(f > 1 ? f - 1 : 0), y = 1; y < f; y++)
            p[y - 1] = arguments[y];
          en("error", o, p);
        }
      }
      function en(o, f, p) {
        {
          var y = Ye.ReactDebugCurrentFrame, b = y.getStackAddendum();
          b !== "" && (f += "%s", p = p.concat([b]));
          var F = p.map(function(I) {
            return String(I);
          });
          F.unshift("Warning: " + f), Function.prototype.apply.call(console[o], console, F);
        }
      }
      var At = {};
      function h(o, f) {
        {
          var p = o.constructor, y = p && (p.displayName || p.name) || "ReactClass", b = y + "." + f;
          if (At[b])
            return;
          z("Can't call %s on a component that is not yet mounted. This is a no-op, but it might indicate a bug in your application. Instead, assign to `this.state` directly or define a `state = {};` class property with the desired state in the %s component.", f, y), At[b] = !0;
        }
      }
      var k = {
        /**
         * Checks whether or not this composite component is mounted.
         * @param {ReactClass} publicInstance The instance we want to test.
         * @return {boolean} True if mounted, false otherwise.
         * @protected
         * @final
         */
        isMounted: function(o) {
          return !1;
        },
        /**
         * Forces an update. This should only be invoked when it is known with
         * certainty that we are **not** in a DOM transaction.
         *
         * You may want to call this when you know that some deeper aspect of the
         * component's state has changed but `setState` was not called.
         *
         * This will not invoke `shouldComponentUpdate`, but it will invoke
         * `componentWillUpdate` and `componentDidUpdate`.
         *
         * @param {ReactClass} publicInstance The instance that should rerender.
         * @param {?function} callback Called after component is updated.
         * @param {?string} callerName name of the calling function in the public API.
         * @internal
         */
        enqueueForceUpdate: function(o, f, p) {
          h(o, "forceUpdate");
        },
        /**
         * Replaces all of the state. Always use this or `setState` to mutate state.
         * You should treat `this.state` as immutable.
         *
         * There is no guarantee that `this.state` will be immediately updated, so
         * accessing `this.state` after calling this method may return the old value.
         *
         * @param {ReactClass} publicInstance The instance that should rerender.
         * @param {object} completeState Next state.
         * @param {?function} callback Called after component is updated.
         * @param {?string} callerName name of the calling function in the public API.
         * @internal
         */
        enqueueReplaceState: function(o, f, p, y) {
          h(o, "replaceState");
        },
        /**
         * Sets a subset of the state. This only exists because _pendingState is
         * internal. This provides a merging strategy that is not available to deep
         * properties which is confusing. TODO: Expose pendingState or don't use it
         * during the merge.
         *
         * @param {ReactClass} publicInstance The instance that should rerender.
         * @param {object} partialState Next partial state to be merged with state.
         * @param {?function} callback Called after component is updated.
         * @param {?string} Name of the calling function in the public API.
         * @internal
         */
        enqueueSetState: function(o, f, p, y) {
          h(o, "setState");
        }
      }, $ = Object.assign, ee = {};
      Object.freeze(ee);
      function B(o, f, p) {
        this.props = o, this.context = f, this.refs = ee, this.updater = p || k;
      }
      B.prototype.isReactComponent = {}, B.prototype.setState = function(o, f) {
        if (typeof o != "object" && typeof o != "function" && o != null)
          throw new Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");
        this.updater.enqueueSetState(this, o, f, "setState");
      }, B.prototype.forceUpdate = function(o) {
        this.updater.enqueueForceUpdate(this, o, "forceUpdate");
      };
      {
        var re = {
          isMounted: ["isMounted", "Instead, make sure to clean up subscriptions and pending requests in componentWillUnmount to prevent memory leaks."],
          replaceState: ["replaceState", "Refactor your code to use setState instead (see https://github.com/facebook/react/issues/3236)."]
        }, de = function(o, f) {
          Object.defineProperty(B.prototype, o, {
            get: function() {
              ce("%s(...) is deprecated in plain JavaScript React classes. %s", f[0], f[1]);
            }
          });
        };
        for (var se in re)
          re.hasOwnProperty(se) && de(se, re[se]);
      }
      function ie() {
      }
      ie.prototype = B.prototype;
      function Oe(o, f, p) {
        this.props = o, this.context = f, this.refs = ee, this.updater = p || k;
      }
      var Yn = Oe.prototype = new ie();
      Yn.constructor = Oe, $(Yn, B.prototype), Yn.isPureReactComponent = !0;
      function qo() {
        var o = {
          current: null
        };
        return Object.seal(o), o;
      }
      var Go = Array.isArray;
      function tn(o) {
        return Go(o);
      }
      function Zo(o) {
        {
          var f = typeof Symbol == "function" && Symbol.toStringTag, p = f && o[Symbol.toStringTag] || o.constructor.name || "Object";
          return p;
        }
      }
      function Qo(o) {
        try {
          return ds(o), !1;
        } catch {
          return !0;
        }
      }
      function ds(o) {
        return "" + o;
      }
      function nn(o) {
        if (Qo(o))
          return z("The provided key is an unsupported type %s. This value must be coerced to a string before before using it here.", Zo(o)), ds(o);
      }
      function Jo(o, f, p) {
        var y = o.displayName;
        if (y)
          return y;
        var b = f.displayName || f.name || "";
        return b !== "" ? p + "(" + b + ")" : p;
      }
      function hs(o) {
        return o.displayName || "Context";
      }
      function qe(o) {
        if (o == null)
          return null;
        if (typeof o.tag == "number" && z("Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."), typeof o == "function")
          return o.displayName || o.name || null;
        if (typeof o == "string")
          return o;
        switch (o) {
          case a:
            return "Fragment";
          case i:
            return "Portal";
          case c:
            return "Profiler";
          case u:
            return "StrictMode";
          case T:
            return "Suspense";
          case E:
            return "SuspenseList";
        }
        if (typeof o == "object")
          switch (o.$$typeof) {
            case d:
              var f = o;
              return hs(f) + ".Consumer";
            case l:
              var p = o;
              return hs(p._context) + ".Provider";
            case m:
              return Jo(o, o.render, "ForwardRef");
            case S:
              var y = o.displayName || null;
              return y !== null ? y : qe(o.type) || "Memo";
            case _: {
              var b = o, F = b._payload, I = b._init;
              try {
                return qe(I(F));
              } catch {
                return null;
              }
            }
          }
        return null;
      }
      var xt = Object.prototype.hasOwnProperty, ps = {
        key: !0,
        ref: !0,
        __self: !0,
        __source: !0
      }, ms, ys, qn;
      qn = {};
      function vs(o) {
        if (xt.call(o, "ref")) {
          var f = Object.getOwnPropertyDescriptor(o, "ref").get;
          if (f && f.isReactWarning)
            return !1;
        }
        return o.ref !== void 0;
      }
      function gs(o) {
        if (xt.call(o, "key")) {
          var f = Object.getOwnPropertyDescriptor(o, "key").get;
          if (f && f.isReactWarning)
            return !1;
        }
        return o.key !== void 0;
      }
      function Xo(o, f) {
        var p = function() {
          ms || (ms = !0, z("%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://reactjs.org/link/special-props)", f));
        };
        p.isReactWarning = !0, Object.defineProperty(o, "key", {
          get: p,
          configurable: !0
        });
      }
      function Ko(o, f) {
        var p = function() {
          ys || (ys = !0, z("%s: `ref` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://reactjs.org/link/special-props)", f));
        };
        p.isReactWarning = !0, Object.defineProperty(o, "ref", {
          get: p,
          configurable: !0
        });
      }
      function eu(o) {
        if (typeof o.ref == "string" && j.current && o.__self && j.current.stateNode !== o.__self) {
          var f = qe(j.current.type);
          qn[f] || (z('Component "%s" contains the string ref "%s". Support for string refs will be removed in a future major release. This case cannot be automatically converted to an arrow function. We ask you to manually fix this case by using useRef() or createRef() instead. Learn more about using refs safely here: https://reactjs.org/link/strict-mode-string-ref', f, o.ref), qn[f] = !0);
        }
      }
      var Gn = function(o, f, p, y, b, F, I) {
        var W = {
          // This tag allows us to uniquely identify this as a React Element
          $$typeof: s,
          // Built-in properties that belong on the element
          type: o,
          key: f,
          ref: p,
          props: I,
          // Record the component responsible for creating this element.
          _owner: F
        };
        return W._store = {}, Object.defineProperty(W._store, "validated", {
          configurable: !1,
          enumerable: !1,
          writable: !0,
          value: !1
        }), Object.defineProperty(W, "_self", {
          configurable: !1,
          enumerable: !1,
          writable: !1,
          value: y
        }), Object.defineProperty(W, "_source", {
          configurable: !1,
          enumerable: !1,
          writable: !1,
          value: b
        }), Object.freeze && (Object.freeze(W.props), Object.freeze(W)), W;
      };
      function tu(o, f, p) {
        var y, b = {}, F = null, I = null, W = null, Y = null;
        if (f != null) {
          vs(f) && (I = f.ref, eu(f)), gs(f) && (nn(f.key), F = "" + f.key), W = f.__self === void 0 ? null : f.__self, Y = f.__source === void 0 ? null : f.__source;
          for (y in f)
            xt.call(f, y) && !ps.hasOwnProperty(y) && (b[y] = f[y]);
        }
        var te = arguments.length - 2;
        if (te === 1)
          b.children = p;
        else if (te > 1) {
          for (var ae = Array(te), oe = 0; oe < te; oe++)
            ae[oe] = arguments[oe + 2];
          Object.freeze && Object.freeze(ae), b.children = ae;
        }
        if (o && o.defaultProps) {
          var ue = o.defaultProps;
          for (y in ue)
            b[y] === void 0 && (b[y] = ue[y]);
        }
        if (F || I) {
          var he = typeof o == "function" ? o.displayName || o.name || "Unknown" : o;
          F && Xo(b, he), I && Ko(b, he);
        }
        return Gn(o, F, I, W, Y, j.current, b);
      }
      function nu(o, f) {
        var p = Gn(o.type, f, o.ref, o._self, o._source, o._owner, o.props);
        return p;
      }
      function ru(o, f, p) {
        if (o == null)
          throw new Error("React.cloneElement(...): The argument must be a React element, but you passed " + o + ".");
        var y, b = $({}, o.props), F = o.key, I = o.ref, W = o._self, Y = o._source, te = o._owner;
        if (f != null) {
          vs(f) && (I = f.ref, te = j.current), gs(f) && (nn(f.key), F = "" + f.key);
          var ae;
          o.type && o.type.defaultProps && (ae = o.type.defaultProps);
          for (y in f)
            xt.call(f, y) && !ps.hasOwnProperty(y) && (f[y] === void 0 && ae !== void 0 ? b[y] = ae[y] : b[y] = f[y]);
        }
        var oe = arguments.length - 2;
        if (oe === 1)
          b.children = p;
        else if (oe > 1) {
          for (var ue = Array(oe), he = 0; he < oe; he++)
            ue[he] = arguments[he + 2];
          b.children = ue;
        }
        return Gn(o.type, F, I, W, Y, te, b);
      }
      function ht(o) {
        return typeof o == "object" && o !== null && o.$$typeof === s;
      }
      var Es = ".", su = ":";
      function iu(o) {
        var f = /[=:]/g, p = {
          "=": "=0",
          ":": "=2"
        }, y = o.replace(f, function(b) {
          return p[b];
        });
        return "$" + y;
      }
      var ws = !1, au = /\/+/g;
      function bs(o) {
        return o.replace(au, "$&/");
      }
      function Zn(o, f) {
        return typeof o == "object" && o !== null && o.key != null ? (nn(o.key), iu("" + o.key)) : f.toString(36);
      }
      function rn(o, f, p, y, b) {
        var F = typeof o;
        (F === "undefined" || F === "boolean") && (o = null);
        var I = !1;
        if (o === null)
          I = !0;
        else
          switch (F) {
            case "string":
            case "number":
              I = !0;
              break;
            case "object":
              switch (o.$$typeof) {
                case s:
                case i:
                  I = !0;
              }
          }
        if (I) {
          var W = o, Y = b(W), te = y === "" ? Es + Zn(W, 0) : y;
          if (tn(Y)) {
            var ae = "";
            te != null && (ae = bs(te) + "/"), rn(Y, f, ae, "", function(Xu) {
              return Xu;
            });
          } else Y != null && (ht(Y) && (Y.key && (!W || W.key !== Y.key) && nn(Y.key), Y = nu(
            Y,
            // Keep both the (mapped) and old keys if they differ, just as
            // traverseAllChildren used to do for objects as children
            p + // $FlowFixMe Flow incorrectly thinks React.Portal doesn't have a key
            (Y.key && (!W || W.key !== Y.key) ? (
              // $FlowFixMe Flow incorrectly thinks existing element's key can be a number
              // eslint-disable-next-line react-internal/safe-string-coercion
              bs("" + Y.key) + "/"
            ) : "") + te
          )), f.push(Y));
          return 1;
        }
        var oe, ue, he = 0, Ee = y === "" ? Es : y + su;
        if (tn(o))
          for (var dn = 0; dn < o.length; dn++)
            oe = o[dn], ue = Ee + Zn(oe, dn), he += rn(oe, f, p, ue, b);
        else {
          var sr = R(o);
          if (typeof sr == "function") {
            var Ys = o;
            sr === Ys.entries && (ws || ce("Using Maps as children is not supported. Use an array of keyed ReactElements instead."), ws = !0);
            for (var Qu = sr.call(Ys), qs, Ju = 0; !(qs = Qu.next()).done; )
              oe = qs.value, ue = Ee + Zn(oe, Ju++), he += rn(oe, f, p, ue, b);
          } else if (F === "object") {
            var Gs = String(o);
            throw new Error("Objects are not valid as a React child (found: " + (Gs === "[object Object]" ? "object with keys {" + Object.keys(o).join(", ") + "}" : Gs) + "). If you meant to render a collection of children, use an array instead.");
          }
        }
        return he;
      }
      function sn(o, f, p) {
        if (o == null)
          return o;
        var y = [], b = 0;
        return rn(o, y, "", "", function(F) {
          return f.call(p, F, b++);
        }), y;
      }
      function ou(o) {
        var f = 0;
        return sn(o, function() {
          f++;
        }), f;
      }
      function uu(o, f, p) {
        sn(o, function() {
          f.apply(this, arguments);
        }, p);
      }
      function cu(o) {
        return sn(o, function(f) {
          return f;
        }) || [];
      }
      function lu(o) {
        if (!ht(o))
          throw new Error("React.Children.only expected to receive a single React element child.");
        return o;
      }
      function fu(o) {
        var f = {
          $$typeof: d,
          // As a workaround to support multiple concurrent renderers, we categorize
          // some renderers as primary and others as secondary. We only expect
          // there to be two concurrent renderers at most: React Native (primary) and
          // Fabric (secondary); React DOM (primary) and React ART (secondary).
          // Secondary renderers store their context values on separate fields.
          _currentValue: o,
          _currentValue2: o,
          // Used to track how many concurrent renderers this context currently
          // supports within in a single renderer. Such as parallel server rendering.
          _threadCount: 0,
          // These are circular
          Provider: null,
          Consumer: null,
          // Add these to use same hidden class in VM as ServerContext
          _defaultValue: null,
          _globalName: null
        };
        f.Provider = {
          $$typeof: l,
          _context: f
        };
        var p = !1, y = !1, b = !1;
        {
          var F = {
            $$typeof: d,
            _context: f
          };
          Object.defineProperties(F, {
            Provider: {
              get: function() {
                return y || (y = !0, z("Rendering <Context.Consumer.Provider> is not supported and will be removed in a future major release. Did you mean to render <Context.Provider> instead?")), f.Provider;
              },
              set: function(I) {
                f.Provider = I;
              }
            },
            _currentValue: {
              get: function() {
                return f._currentValue;
              },
              set: function(I) {
                f._currentValue = I;
              }
            },
            _currentValue2: {
              get: function() {
                return f._currentValue2;
              },
              set: function(I) {
                f._currentValue2 = I;
              }
            },
            _threadCount: {
              get: function() {
                return f._threadCount;
              },
              set: function(I) {
                f._threadCount = I;
              }
            },
            Consumer: {
              get: function() {
                return p || (p = !0, z("Rendering <Context.Consumer.Consumer> is not supported and will be removed in a future major release. Did you mean to render <Context.Consumer> instead?")), f.Consumer;
              }
            },
            displayName: {
              get: function() {
                return f.displayName;
              },
              set: function(I) {
                b || (ce("Setting `displayName` on Context.Consumer has no effect. You should set it directly on the context with Context.displayName = '%s'.", I), b = !0);
              }
            }
          }), f.Consumer = F;
        }
        return f._currentRenderer = null, f._currentRenderer2 = null, f;
      }
      var Rt = -1, Qn = 0, Os = 1, du = 2;
      function hu(o) {
        if (o._status === Rt) {
          var f = o._result, p = f();
          if (p.then(function(F) {
            if (o._status === Qn || o._status === Rt) {
              var I = o;
              I._status = Os, I._result = F;
            }
          }, function(F) {
            if (o._status === Qn || o._status === Rt) {
              var I = o;
              I._status = du, I._result = F;
            }
          }), o._status === Rt) {
            var y = o;
            y._status = Qn, y._result = p;
          }
        }
        if (o._status === Os) {
          var b = o._result;
          return b === void 0 && z(`lazy: Expected the result of a dynamic import() call. Instead received: %s

Your code should look like: 
  const MyComponent = lazy(() => import('./MyComponent'))

Did you accidentally put curly braces around the import?`, b), "default" in b || z(`lazy: Expected the result of a dynamic import() call. Instead received: %s

Your code should look like: 
  const MyComponent = lazy(() => import('./MyComponent'))`, b), b.default;
        } else
          throw o._result;
      }
      function pu(o) {
        var f = {
          // We use these fields to store the result.
          _status: Rt,
          _result: o
        }, p = {
          $$typeof: _,
          _payload: f,
          _init: hu
        };
        {
          var y, b;
          Object.defineProperties(p, {
            defaultProps: {
              configurable: !0,
              get: function() {
                return y;
              },
              set: function(F) {
                z("React.lazy(...): It is not supported to assign `defaultProps` to a lazy component import. Either specify them where the component is defined, or create a wrapping component around it."), y = F, Object.defineProperty(p, "defaultProps", {
                  enumerable: !0
                });
              }
            },
            propTypes: {
              configurable: !0,
              get: function() {
                return b;
              },
              set: function(F) {
                z("React.lazy(...): It is not supported to assign `propTypes` to a lazy component import. Either specify them where the component is defined, or create a wrapping component around it."), b = F, Object.defineProperty(p, "propTypes", {
                  enumerable: !0
                });
              }
            }
          });
        }
        return p;
      }
      function mu(o) {
        o != null && o.$$typeof === S ? z("forwardRef requires a render function but received a `memo` component. Instead of forwardRef(memo(...)), use memo(forwardRef(...)).") : typeof o != "function" ? z("forwardRef requires a render function but was given %s.", o === null ? "null" : typeof o) : o.length !== 0 && o.length !== 2 && z("forwardRef render functions accept exactly two parameters: props and ref. %s", o.length === 1 ? "Did you forget to use the ref parameter?" : "Any additional parameter will be undefined."), o != null && (o.defaultProps != null || o.propTypes != null) && z("forwardRef render functions do not support propTypes or defaultProps. Did you accidentally pass a React component?");
        var f = {
          $$typeof: m,
          render: o
        };
        {
          var p;
          Object.defineProperty(f, "displayName", {
            enumerable: !1,
            configurable: !0,
            get: function() {
              return p;
            },
            set: function(y) {
              p = y, !o.name && !o.displayName && (o.displayName = y);
            }
          });
        }
        return f;
      }
      var Ts;
      Ts = Symbol.for("react.module.reference");
      function Ss(o) {
        return !!(typeof o == "string" || typeof o == "function" || o === a || o === c || dt || o === u || o === T || o === E || Be || o === w || ne || je || ze || typeof o == "object" && o !== null && (o.$$typeof === _ || o.$$typeof === S || o.$$typeof === l || o.$$typeof === d || o.$$typeof === m || // This needs to include all possible module reference object
        // types supported by any Flight configuration anywhere since
        // we don't know which Flight build this will end up being used
        // with.
        o.$$typeof === Ts || o.getModuleId !== void 0));
      }
      function yu(o, f) {
        Ss(o) || z("memo: The first argument must be a component. Instead received: %s", o === null ? "null" : typeof o);
        var p = {
          $$typeof: S,
          type: o,
          compare: f === void 0 ? null : f
        };
        {
          var y;
          Object.defineProperty(p, "displayName", {
            enumerable: !1,
            configurable: !0,
            get: function() {
              return y;
            },
            set: function(b) {
              y = b, !o.name && !o.displayName && (o.displayName = b);
            }
          });
        }
        return p;
      }
      function Te() {
        var o = M.current;
        return o === null && z(`Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for one of the following reasons:
1. You might have mismatching versions of React and the renderer (such as React DOM)
2. You might be breaking the Rules of Hooks
3. You might have more than one copy of React in the same app
See https://reactjs.org/link/invalid-hook-call for tips about how to debug and fix this problem.`), o;
      }
      function vu(o) {
        var f = Te();
        if (o._context !== void 0) {
          var p = o._context;
          p.Consumer === o ? z("Calling useContext(Context.Consumer) is not supported, may cause bugs, and will be removed in a future major release. Did you mean to call useContext(Context) instead?") : p.Provider === o && z("Calling useContext(Context.Provider) is not supported. Did you mean to call useContext(Context) instead?");
        }
        return f.useContext(o);
      }
      function gu(o) {
        var f = Te();
        return f.useState(o);
      }
      function Eu(o, f, p) {
        var y = Te();
        return y.useReducer(o, f, p);
      }
      function wu(o) {
        var f = Te();
        return f.useRef(o);
      }
      function bu(o, f) {
        var p = Te();
        return p.useEffect(o, f);
      }
      function Ou(o, f) {
        var p = Te();
        return p.useInsertionEffect(o, f);
      }
      function Tu(o, f) {
        var p = Te();
        return p.useLayoutEffect(o, f);
      }
      function Su(o, f) {
        var p = Te();
        return p.useCallback(o, f);
      }
      function _u(o, f) {
        var p = Te();
        return p.useMemo(o, f);
      }
      function ku(o, f, p) {
        var y = Te();
        return y.useImperativeHandle(o, f, p);
      }
      function Nu(o, f) {
        {
          var p = Te();
          return p.useDebugValue(o, f);
        }
      }
      function Iu() {
        var o = Te();
        return o.useTransition();
      }
      function Du(o) {
        var f = Te();
        return f.useDeferredValue(o);
      }
      function Cu() {
        var o = Te();
        return o.useId();
      }
      function Au(o, f, p) {
        var y = Te();
        return y.useSyncExternalStore(o, f, p);
      }
      var Mt = 0, _s, ks, Ns, Is, Ds, Cs, As;
      function xs() {
      }
      xs.__reactDisabledLog = !0;
      function xu() {
        {
          if (Mt === 0) {
            _s = console.log, ks = console.info, Ns = console.warn, Is = console.error, Ds = console.group, Cs = console.groupCollapsed, As = console.groupEnd;
            var o = {
              configurable: !0,
              enumerable: !0,
              value: xs,
              writable: !0
            };
            Object.defineProperties(console, {
              info: o,
              log: o,
              warn: o,
              error: o,
              group: o,
              groupCollapsed: o,
              groupEnd: o
            });
          }
          Mt++;
        }
      }
      function Ru() {
        {
          if (Mt--, Mt === 0) {
            var o = {
              configurable: !0,
              enumerable: !0,
              writable: !0
            };
            Object.defineProperties(console, {
              log: $({}, o, {
                value: _s
              }),
              info: $({}, o, {
                value: ks
              }),
              warn: $({}, o, {
                value: Ns
              }),
              error: $({}, o, {
                value: Is
              }),
              group: $({}, o, {
                value: Ds
              }),
              groupCollapsed: $({}, o, {
                value: Cs
              }),
              groupEnd: $({}, o, {
                value: As
              })
            });
          }
          Mt < 0 && z("disabledDepth fell below zero. This is a bug in React. Please file an issue.");
        }
      }
      var Jn = Ye.ReactCurrentDispatcher, Xn;
      function an(o, f, p) {
        {
          if (Xn === void 0)
            try {
              throw Error();
            } catch (b) {
              var y = b.stack.trim().match(/\n( *(at )?)/);
              Xn = y && y[1] || "";
            }
          return `
` + Xn + o;
        }
      }
      var Kn = !1, on;
      {
        var Mu = typeof WeakMap == "function" ? WeakMap : Map;
        on = new Mu();
      }
      function Rs(o, f) {
        if (!o || Kn)
          return "";
        {
          var p = on.get(o);
          if (p !== void 0)
            return p;
        }
        var y;
        Kn = !0;
        var b = Error.prepareStackTrace;
        Error.prepareStackTrace = void 0;
        var F;
        F = Jn.current, Jn.current = null, xu();
        try {
          if (f) {
            var I = function() {
              throw Error();
            };
            if (Object.defineProperty(I.prototype, "props", {
              set: function() {
                throw Error();
              }
            }), typeof Reflect == "object" && Reflect.construct) {
              try {
                Reflect.construct(I, []);
              } catch (Ee) {
                y = Ee;
              }
              Reflect.construct(o, [], I);
            } else {
              try {
                I.call();
              } catch (Ee) {
                y = Ee;
              }
              o.call(I.prototype);
            }
          } else {
            try {
              throw Error();
            } catch (Ee) {
              y = Ee;
            }
            o();
          }
        } catch (Ee) {
          if (Ee && y && typeof Ee.stack == "string") {
            for (var W = Ee.stack.split(`
`), Y = y.stack.split(`
`), te = W.length - 1, ae = Y.length - 1; te >= 1 && ae >= 0 && W[te] !== Y[ae]; )
              ae--;
            for (; te >= 1 && ae >= 0; te--, ae--)
              if (W[te] !== Y[ae]) {
                if (te !== 1 || ae !== 1)
                  do
                    if (te--, ae--, ae < 0 || W[te] !== Y[ae]) {
                      var oe = `
` + W[te].replace(" at new ", " at ");
                      return o.displayName && oe.includes("<anonymous>") && (oe = oe.replace("<anonymous>", o.displayName)), typeof o == "function" && on.set(o, oe), oe;
                    }
                  while (te >= 1 && ae >= 0);
                break;
              }
          }
        } finally {
          Kn = !1, Jn.current = F, Ru(), Error.prepareStackTrace = b;
        }
        var ue = o ? o.displayName || o.name : "", he = ue ? an(ue) : "";
        return typeof o == "function" && on.set(o, he), he;
      }
      function Fu(o, f, p) {
        return Rs(o, !1);
      }
      function Lu(o) {
        var f = o.prototype;
        return !!(f && f.isReactComponent);
      }
      function un(o, f, p) {
        if (o == null)
          return "";
        if (typeof o == "function")
          return Rs(o, Lu(o));
        if (typeof o == "string")
          return an(o);
        switch (o) {
          case T:
            return an("Suspense");
          case E:
            return an("SuspenseList");
        }
        if (typeof o == "object")
          switch (o.$$typeof) {
            case m:
              return Fu(o.render);
            case S:
              return un(o.type, f, p);
            case _: {
              var y = o, b = y._payload, F = y._init;
              try {
                return un(F(b), f, p);
              } catch {
              }
            }
          }
        return "";
      }
      var Ms = {}, Fs = Ye.ReactDebugCurrentFrame;
      function cn(o) {
        if (o) {
          var f = o._owner, p = un(o.type, o._source, f ? f.type : null);
          Fs.setExtraStackFrame(p);
        } else
          Fs.setExtraStackFrame(null);
      }
      function Pu(o, f, p, y, b) {
        {
          var F = Function.call.bind(xt);
          for (var I in o)
            if (F(o, I)) {
              var W = void 0;
              try {
                if (typeof o[I] != "function") {
                  var Y = Error((y || "React class") + ": " + p + " type `" + I + "` is invalid; it must be a function, usually from the `prop-types` package, but received `" + typeof o[I] + "`.This often happens because of typos such as `PropTypes.function` instead of `PropTypes.func`.");
                  throw Y.name = "Invariant Violation", Y;
                }
                W = o[I](f, I, y, p, null, "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED");
              } catch (te) {
                W = te;
              }
              W && !(W instanceof Error) && (cn(b), z("%s: type specification of %s `%s` is invalid; the type checker function must return `null` or an `Error` but returned a %s. You may have forgotten to pass an argument to the type checker creator (arrayOf, instanceOf, objectOf, oneOf, oneOfType, and shape all require an argument).", y || "React class", p, I, typeof W), cn(null)), W instanceof Error && !(W.message in Ms) && (Ms[W.message] = !0, cn(b), z("Failed %s type: %s", p, W.message), cn(null));
            }
        }
      }
      function pt(o) {
        if (o) {
          var f = o._owner, p = un(o.type, o._source, f ? f.type : null);
          q(p);
        } else
          q(null);
      }
      var er;
      er = !1;
      function Ls() {
        if (j.current) {
          var o = qe(j.current.type);
          if (o)
            return `

Check the render method of \`` + o + "`.";
        }
        return "";
      }
      function Vu(o) {
        if (o !== void 0) {
          var f = o.fileName.replace(/^.*[\\\/]/, ""), p = o.lineNumber;
          return `

Check your code at ` + f + ":" + p + ".";
        }
        return "";
      }
      function Wu(o) {
        return o != null ? Vu(o.__source) : "";
      }
      var Ps = {};
      function Uu(o) {
        var f = Ls();
        if (!f) {
          var p = typeof o == "string" ? o : o.displayName || o.name;
          p && (f = `

Check the top-level render call using <` + p + ">.");
        }
        return f;
      }
      function Vs(o, f) {
        if (!(!o._store || o._store.validated || o.key != null)) {
          o._store.validated = !0;
          var p = Uu(f);
          if (!Ps[p]) {
            Ps[p] = !0;
            var y = "";
            o && o._owner && o._owner !== j.current && (y = " It was passed a child from " + qe(o._owner.type) + "."), pt(o), z('Each child in a list should have a unique "key" prop.%s%s See https://reactjs.org/link/warning-keys for more information.', p, y), pt(null);
          }
        }
      }
      function Ws(o, f) {
        if (typeof o == "object") {
          if (tn(o))
            for (var p = 0; p < o.length; p++) {
              var y = o[p];
              ht(y) && Vs(y, f);
            }
          else if (ht(o))
            o._store && (o._store.validated = !0);
          else if (o) {
            var b = R(o);
            if (typeof b == "function" && b !== o.entries)
              for (var F = b.call(o), I; !(I = F.next()).done; )
                ht(I.value) && Vs(I.value, f);
          }
        }
      }
      function Us(o) {
        {
          var f = o.type;
          if (f == null || typeof f == "string")
            return;
          var p;
          if (typeof f == "function")
            p = f.propTypes;
          else if (typeof f == "object" && (f.$$typeof === m || // Note: Memo only checks outer props here.
          // Inner props are checked in the reconciler.
          f.$$typeof === S))
            p = f.propTypes;
          else
            return;
          if (p) {
            var y = qe(f);
            Pu(p, o.props, "prop", y, o);
          } else if (f.PropTypes !== void 0 && !er) {
            er = !0;
            var b = qe(f);
            z("Component %s declared `PropTypes` instead of `propTypes`. Did you misspell the property assignment?", b || "Unknown");
          }
          typeof f.getDefaultProps == "function" && !f.getDefaultProps.isReactClassApproved && z("getDefaultProps is only used on classic React.createClass definitions. Use a static property named `defaultProps` instead.");
        }
      }
      function $u(o) {
        {
          for (var f = Object.keys(o.props), p = 0; p < f.length; p++) {
            var y = f[p];
            if (y !== "children" && y !== "key") {
              pt(o), z("Invalid prop `%s` supplied to `React.Fragment`. React.Fragment can only have `key` and `children` props.", y), pt(null);
              break;
            }
          }
          o.ref !== null && (pt(o), z("Invalid attribute `ref` supplied to `React.Fragment`."), pt(null));
        }
      }
      function $s(o, f, p) {
        var y = Ss(o);
        if (!y) {
          var b = "";
          (o === void 0 || typeof o == "object" && o !== null && Object.keys(o).length === 0) && (b += " You likely forgot to export your component from the file it's defined in, or you might have mixed up default and named imports.");
          var F = Wu(f);
          F ? b += F : b += Ls();
          var I;
          o === null ? I = "null" : tn(o) ? I = "array" : o !== void 0 && o.$$typeof === s ? (I = "<" + (qe(o.type) || "Unknown") + " />", b = " Did you accidentally export a JSX literal instead of a component?") : I = typeof o, z("React.createElement: type is invalid -- expected a string (for built-in components) or a class/function (for composite components) but got: %s.%s", I, b);
        }
        var W = tu.apply(this, arguments);
        if (W == null)
          return W;
        if (y)
          for (var Y = 2; Y < arguments.length; Y++)
            Ws(arguments[Y], o);
        return o === a ? $u(W) : Us(W), W;
      }
      var Hs = !1;
      function Hu(o) {
        var f = $s.bind(null, o);
        return f.type = o, Hs || (Hs = !0, ce("React.createFactory() is deprecated and will be removed in a future major release. Consider using JSX or use React.createElement() directly instead.")), Object.defineProperty(f, "type", {
          enumerable: !1,
          get: function() {
            return ce("Factory.type is deprecated. Access the class directly before passing it to createFactory."), Object.defineProperty(this, "type", {
              value: o
            }), o;
          }
        }), f;
      }
      function ju(o, f, p) {
        for (var y = ru.apply(this, arguments), b = 2; b < arguments.length; b++)
          Ws(arguments[b], y.type);
        return Us(y), y;
      }
      function zu(o, f) {
        var p = U.transition;
        U.transition = {};
        var y = U.transition;
        U.transition._updatedFibers = /* @__PURE__ */ new Set();
        try {
          o();
        } finally {
          if (U.transition = p, p === null && y._updatedFibers) {
            var b = y._updatedFibers.size;
            b > 10 && ce("Detected a large number of updates inside startTransition. If this is due to a subscription please re-write it to use React provided hooks. Otherwise concurrent mode guarantees are off the table."), y._updatedFibers.clear();
          }
        }
      }
      var js = !1, ln = null;
      function Bu(o) {
        if (ln === null)
          try {
            var f = ("require" + Math.random()).slice(0, 7), p = t && t[f];
            ln = p.call(t, "timers").setImmediate;
          } catch {
            ln = function(b) {
              js === !1 && (js = !0, typeof MessageChannel > "u" && z("This browser does not have a MessageChannel implementation, so enqueuing tasks via await act(async () => ...) will fail. Please file an issue at https://github.com/facebook/react/issues if you encounter this warning."));
              var F = new MessageChannel();
              F.port1.onmessage = b, F.port2.postMessage(void 0);
            };
          }
        return ln(o);
      }
      var mt = 0, zs = !1;
      function Bs(o) {
        {
          var f = mt;
          mt++, D.current === null && (D.current = []);
          var p = D.isBatchingLegacy, y;
          try {
            if (D.isBatchingLegacy = !0, y = o(), !p && D.didScheduleLegacyUpdate) {
              var b = D.current;
              b !== null && (D.didScheduleLegacyUpdate = !1, rr(b));
            }
          } catch (ue) {
            throw fn(f), ue;
          } finally {
            D.isBatchingLegacy = p;
          }
          if (y !== null && typeof y == "object" && typeof y.then == "function") {
            var F = y, I = !1, W = {
              then: function(ue, he) {
                I = !0, F.then(function(Ee) {
                  fn(f), mt === 0 ? tr(Ee, ue, he) : ue(Ee);
                }, function(Ee) {
                  fn(f), he(Ee);
                });
              }
            };
            return !zs && typeof Promise < "u" && Promise.resolve().then(function() {
            }).then(function() {
              I || (zs = !0, z("You called act(async () => ...) without await. This could lead to unexpected testing behaviour, interleaving multiple act calls and mixing their scopes. You should - await act(async () => ...);"));
            }), W;
          } else {
            var Y = y;
            if (fn(f), mt === 0) {
              var te = D.current;
              te !== null && (rr(te), D.current = null);
              var ae = {
                then: function(ue, he) {
                  D.current === null ? (D.current = [], tr(Y, ue, he)) : ue(Y);
                }
              };
              return ae;
            } else {
              var oe = {
                then: function(ue, he) {
                  ue(Y);
                }
              };
              return oe;
            }
          }
        }
      }
      function fn(o) {
        o !== mt - 1 && z("You seem to have overlapping act() calls, this is not supported. Be sure to await previous act() calls before making a new one. "), mt = o;
      }
      function tr(o, f, p) {
        {
          var y = D.current;
          if (y !== null)
            try {
              rr(y), Bu(function() {
                y.length === 0 ? (D.current = null, f(o)) : tr(o, f, p);
              });
            } catch (b) {
              p(b);
            }
          else
            f(o);
        }
      }
      var nr = !1;
      function rr(o) {
        if (!nr) {
          nr = !0;
          var f = 0;
          try {
            for (; f < o.length; f++) {
              var p = o[f];
              do
                p = p(!0);
              while (p !== null);
            }
            o.length = 0;
          } catch (y) {
            throw o = o.slice(f + 1), y;
          } finally {
            nr = !1;
          }
        }
      }
      var Yu = $s, qu = ju, Gu = Hu, Zu = {
        map: sn,
        forEach: uu,
        count: ou,
        toArray: cu,
        only: lu
      };
      e.Children = Zu, e.Component = B, e.Fragment = a, e.Profiler = c, e.PureComponent = Oe, e.StrictMode = u, e.Suspense = T, e.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = Ye, e.act = Bs, e.cloneElement = qu, e.createContext = fu, e.createElement = Yu, e.createFactory = Gu, e.createRef = qo, e.forwardRef = mu, e.isValidElement = ht, e.lazy = pu, e.memo = yu, e.startTransition = zu, e.unstable_act = Bs, e.useCallback = Su, e.useContext = vu, e.useDebugValue = Nu, e.useDeferredValue = Du, e.useEffect = bu, e.useId = Cu, e.useImperativeHandle = ku, e.useInsertionEffect = Ou, e.useLayoutEffect = Tu, e.useMemo = _u, e.useReducer = Eu, e.useRef = wu, e.useState = gu, e.useSyncExternalStore = Au, e.useTransition = Iu, e.version = r, typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u" && typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop == "function" && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(new Error());
    }();
  }(Vt, Vt.exports)), Vt.exports;
}
var tc = {};
tc.NODE_ENV === "production" ? Tr.exports = Ku() : Tr.exports = ec();
var qr = Tr.exports;
const nc = /* @__PURE__ */ Xi(qr), up = /* @__PURE__ */ Ji({
  __proto__: null,
  default: nc
}, [qr]), Ki = globalThis || void 0 || self;
var Sr = function(t, e) {
  return Sr = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(n, r) {
    n.__proto__ = r;
  } || function(n, r) {
    for (var s in r) Object.prototype.hasOwnProperty.call(r, s) && (n[s] = r[s]);
  }, Sr(t, e);
};
function ea(t, e) {
  if (typeof e != "function" && e !== null)
    throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
  Sr(t, e);
  function n() {
    this.constructor = t;
  }
  t.prototype = e === null ? Object.create(e) : (n.prototype = e.prototype, new n());
}
var X = function() {
  return X = Object.assign || function(e) {
    for (var n, r = 1, s = arguments.length; r < s; r++) {
      n = arguments[r];
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (e[i] = n[i]);
    }
    return e;
  }, X.apply(this, arguments);
};
function ta(t, e) {
  var n = {};
  for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && e.indexOf(r) < 0 && (n[r] = t[r]);
  if (t != null && typeof Object.getOwnPropertySymbols == "function")
    for (var s = 0, r = Object.getOwnPropertySymbols(t); s < r.length; s++)
      e.indexOf(r[s]) < 0 && Object.prototype.propertyIsEnumerable.call(t, r[s]) && (n[r[s]] = t[r[s]]);
  return n;
}
function cp(t, e, n, r) {
  function s(i) {
    return i instanceof n ? i : new n(function(a) {
      a(i);
    });
  }
  return new (n || (n = Promise))(function(i, a) {
    function u(d) {
      try {
        l(r.next(d));
      } catch (m) {
        a(m);
      }
    }
    function c(d) {
      try {
        l(r.throw(d));
      } catch (m) {
        a(m);
      }
    }
    function l(d) {
      d.done ? i(d.value) : s(d.value).then(u, c);
    }
    l((r = r.apply(t, e || [])).next());
  });
}
function lp(t, e) {
  var n = { label: 0, sent: function() {
    if (i[0] & 1) throw i[1];
    return i[1];
  }, trys: [], ops: [] }, r, s, i, a = Object.create((typeof Iterator == "function" ? Iterator : Object).prototype);
  return a.next = u(0), a.throw = u(1), a.return = u(2), typeof Symbol == "function" && (a[Symbol.iterator] = function() {
    return this;
  }), a;
  function u(l) {
    return function(d) {
      return c([l, d]);
    };
  }
  function c(l) {
    if (r) throw new TypeError("Generator is already executing.");
    for (; a && (a = 0, l[0] && (n = 0)), n; ) try {
      if (r = 1, s && (i = l[0] & 2 ? s.return : l[0] ? s.throw || ((i = s.return) && i.call(s), 0) : s.next) && !(i = i.call(s, l[1])).done) return i;
      switch (s = 0, i && (l = [l[0] & 2, i.value]), l[0]) {
        case 0:
        case 1:
          i = l;
          break;
        case 4:
          return n.label++, { value: l[1], done: !1 };
        case 5:
          n.label++, s = l[1], l = [0];
          continue;
        case 7:
          l = n.ops.pop(), n.trys.pop();
          continue;
        default:
          if (i = n.trys, !(i = i.length > 0 && i[i.length - 1]) && (l[0] === 6 || l[0] === 2)) {
            n = 0;
            continue;
          }
          if (l[0] === 3 && (!i || l[1] > i[0] && l[1] < i[3])) {
            n.label = l[1];
            break;
          }
          if (l[0] === 6 && n.label < i[1]) {
            n.label = i[1], i = l;
            break;
          }
          if (i && n.label < i[2]) {
            n.label = i[2], n.ops.push(l);
            break;
          }
          i[2] && n.ops.pop(), n.trys.pop();
          continue;
      }
      l = e.call(t, n);
    } catch (d) {
      l = [6, d], s = 0;
    } finally {
      r = i = 0;
    }
    if (l[0] & 5) throw l[1];
    return { value: l[0] ? l[1] : void 0, done: !0 };
  }
}
function Le(t, e, n) {
  if (n || arguments.length === 2) for (var r = 0, s = e.length, i; r < s; r++)
    (i || !(r in e)) && (i || (i = Array.prototype.slice.call(e, 0, r)), i[r] = e[r]);
  return t.concat(i || Array.prototype.slice.call(e));
}
var ir = "Invariant Violation", Js = Object.setPrototypeOf, rc = Js === void 0 ? function(t, e) {
  return t.__proto__ = e, t;
} : Js, na = (
  /** @class */
  function(t) {
    ea(e, t);
    function e(n) {
      n === void 0 && (n = ir);
      var r = t.call(this, typeof n == "number" ? ir + ": " + n + " (see https://github.com/apollographql/invariant-packages)" : n) || this;
      return r.framesToPop = 1, r.name = ir, rc(r, e.prototype), r;
    }
    return e;
  }(Error)
);
function it(t, e) {
  if (!t)
    throw new na(e);
}
var ra = ["debug", "log", "warn", "error", "silent"], sc = ra.indexOf("log");
function hn(t) {
  return function() {
    if (ra.indexOf(t) >= sc) {
      var e = console[t] || console.log;
      return e.apply(console, arguments);
    }
  };
}
(function(t) {
  t.debug = hn("debug"), t.log = hn("log"), t.warn = hn("warn"), t.error = hn("error");
})(it || (it = {}));
var sa = "3.11.8";
function We(t) {
  try {
    return t();
  } catch {
  }
}
const _r = We(function() {
  return globalThis;
}) || We(function() {
  return window;
}) || We(function() {
  return self;
}) || We(function() {
  return Ki;
}) || // We don't expect the Function constructor ever to be invoked at runtime, as
// long as at least one of globalThis, window, self, or global is defined, so
// we are under no obligation to make it easy for static analysis tools to
// detect syntactic usage of the Function constructor. If you think you can
// improve your static analysis to detect this obfuscation, think again. This
// is an arms race you cannot win, at least not in JavaScript.
We(function() {
  return We.constructor("return this")();
});
var Xs = /* @__PURE__ */ new Map();
function ic(t) {
  var e = Xs.get(t) || 1;
  return Xs.set(t, e + 1), "".concat(t, ":").concat(e, ":").concat(Math.random().toString(36).slice(2));
}
function ac(t, e) {
  e === void 0 && (e = 0);
  var n = ic("stringifyForDisplay");
  return JSON.stringify(t, function(r, s) {
    return s === void 0 ? n : s;
  }, e).split(JSON.stringify(n)).join("<undefined>");
}
function pn(t) {
  return function(e) {
    for (var n = [], r = 1; r < arguments.length; r++)
      n[r - 1] = arguments[r];
    if (typeof e == "number") {
      var s = e;
      e = Gr(s), e || (e = Zr(s, n), n = []);
    }
    t.apply(void 0, [e].concat(n));
  };
}
var Ue = Object.assign(function(e, n) {
  for (var r = [], s = 2; s < arguments.length; s++)
    r[s - 2] = arguments[s];
  e || it(e, Gr(n, r) || Zr(n, r));
}, {
  debug: pn(it.debug),
  log: pn(it.log),
  warn: pn(it.warn),
  error: pn(it.error)
});
function fp(t) {
  for (var e = [], n = 1; n < arguments.length; n++)
    e[n - 1] = arguments[n];
  return new na(Gr(t, e) || Zr(t, e));
}
var Ks = Symbol.for("ApolloErrorMessageHandler_" + sa);
function ia(t) {
  if (typeof t == "string")
    return t;
  try {
    return ac(t, 2).slice(0, 1e3);
  } catch {
    return "<non-serializable>";
  }
}
function Gr(t, e) {
  if (e === void 0 && (e = []), !!t)
    return _r[Ks] && _r[Ks](t, e.map(ia));
}
function Zr(t, e) {
  if (e === void 0 && (e = []), !!t)
    return "An error occurred! For more details, see the full error text at https://go.apollo.dev/c/err#".concat(encodeURIComponent(JSON.stringify({
      version: sa,
      message: t,
      args: e.map(ia)
    })));
}
function ar(t, e) {
  if (!!!t)
    throw new Error(e);
}
function oc(t) {
  return typeof t == "object" && t !== null;
}
function uc(t, e) {
  if (!!!t)
    throw new Error(
      e ?? "Unexpected invariant triggered."
    );
}
const cc = /\r\n|[\n\r]/g;
function kr(t, e) {
  let n = 0, r = 1;
  for (const s of t.body.matchAll(cc)) {
    if (typeof s.index == "number" || uc(!1), s.index >= e)
      break;
    n = s.index + s[0].length, r += 1;
  }
  return {
    line: r,
    column: e + 1 - n
  };
}
function lc(t) {
  return aa(
    t.source,
    kr(t.source, t.start)
  );
}
function aa(t, e) {
  const n = t.locationOffset.column - 1, r = "".padStart(n) + t.body, s = e.line - 1, i = t.locationOffset.line - 1, a = e.line + i, u = e.line === 1 ? n : 0, c = e.column + u, l = `${t.name}:${a}:${c}
`, d = r.split(/\r\n|[\n\r]/g), m = d[s];
  if (m.length > 120) {
    const T = Math.floor(c / 80), E = c % 80, S = [];
    for (let _ = 0; _ < m.length; _ += 80)
      S.push(m.slice(_, _ + 80));
    return l + ei([
      [`${a} |`, S[0]],
      ...S.slice(1, T + 1).map((_) => ["|", _]),
      ["|", "^".padStart(E)],
      ["|", S[T + 1]]
    ]);
  }
  return l + ei([
    // Lines specified like this: ["prefix", "string"],
    [`${a - 1} |`, d[s - 1]],
    [`${a} |`, m],
    ["|", "^".padStart(c)],
    [`${a + 1} |`, d[s + 1]]
  ]);
}
function ei(t) {
  const e = t.filter(([r, s]) => s !== void 0), n = Math.max(...e.map(([r]) => r.length));
  return e.map(([r, s]) => r.padStart(n) + (s ? " " + s : "")).join(`
`);
}
function fc(t) {
  const e = t[0];
  return e == null || "kind" in e || "length" in e ? {
    nodes: e,
    source: t[1],
    positions: t[2],
    path: t[3],
    originalError: t[4],
    extensions: t[5]
  } : e;
}
class Qr extends Error {
  /**
   * An array of `{ line, column }` locations within the source GraphQL document
   * which correspond to this error.
   *
   * Errors during validation often contain multiple locations, for example to
   * point out two things with the same name. Errors during execution include a
   * single location, the field which produced the error.
   *
   * Enumerable, and appears in the result of JSON.stringify().
   */
  /**
   * An array describing the JSON-path into the execution response which
   * corresponds to this error. Only included for errors during execution.
   *
   * Enumerable, and appears in the result of JSON.stringify().
   */
  /**
   * An array of GraphQL AST Nodes corresponding to this error.
   */
  /**
   * The source GraphQL document for the first location of this error.
   *
   * Note that if this Error represents more than one node, the source may not
   * represent nodes after the first node.
   */
  /**
   * An array of character offsets within the source GraphQL document
   * which correspond to this error.
   */
  /**
   * The original error thrown from a field resolver during execution.
   */
  /**
   * Extension fields to add to the formatted error.
   */
  /**
   * @deprecated Please use the `GraphQLErrorOptions` constructor overload instead.
   */
  constructor(e, ...n) {
    var r, s, i;
    const { nodes: a, source: u, positions: c, path: l, originalError: d, extensions: m } = fc(n);
    super(e), this.name = "GraphQLError", this.path = l ?? void 0, this.originalError = d ?? void 0, this.nodes = ti(
      Array.isArray(a) ? a : a ? [a] : void 0
    );
    const T = ti(
      (r = this.nodes) === null || r === void 0 ? void 0 : r.map((S) => S.loc).filter((S) => S != null)
    );
    this.source = u ?? (T == null || (s = T[0]) === null || s === void 0 ? void 0 : s.source), this.positions = c ?? T?.map((S) => S.start), this.locations = c && u ? c.map((S) => kr(u, S)) : T?.map((S) => kr(S.source, S.start));
    const E = oc(
      d?.extensions
    ) ? d?.extensions : void 0;
    this.extensions = (i = m ?? E) !== null && i !== void 0 ? i : /* @__PURE__ */ Object.create(null), Object.defineProperties(this, {
      message: {
        writable: !0,
        enumerable: !0
      },
      name: {
        enumerable: !1
      },
      nodes: {
        enumerable: !1
      },
      source: {
        enumerable: !1
      },
      positions: {
        enumerable: !1
      },
      originalError: {
        enumerable: !1
      }
    }), d != null && d.stack ? Object.defineProperty(this, "stack", {
      value: d.stack,
      writable: !0,
      configurable: !0
    }) : Error.captureStackTrace ? Error.captureStackTrace(this, Qr) : Object.defineProperty(this, "stack", {
      value: Error().stack,
      writable: !0,
      configurable: !0
    });
  }
  get [Symbol.toStringTag]() {
    return "GraphQLError";
  }
  toString() {
    let e = this.message;
    if (this.nodes)
      for (const n of this.nodes)
        n.loc && (e += `

` + lc(n.loc));
    else if (this.source && this.locations)
      for (const n of this.locations)
        e += `

` + aa(this.source, n);
    return e;
  }
  toJSON() {
    const e = {
      message: this.message
    };
    return this.locations != null && (e.locations = this.locations), this.path != null && (e.path = this.path), this.extensions != null && Object.keys(this.extensions).length > 0 && (e.extensions = this.extensions), e;
  }
}
function ti(t) {
  return t === void 0 || t.length === 0 ? void 0 : t;
}
function ge(t, e, n) {
  return new Qr(`Syntax Error: ${n}`, {
    source: t,
    positions: [e]
  });
}
class dc {
  /**
   * The character offset at which this Node begins.
   */
  /**
   * The character offset at which this Node ends.
   */
  /**
   * The Token at which this Node begins.
   */
  /**
   * The Token at which this Node ends.
   */
  /**
   * The Source document the AST represents.
   */
  constructor(e, n, r) {
    this.start = e.start, this.end = n.end, this.startToken = e, this.endToken = n, this.source = r;
  }
  get [Symbol.toStringTag]() {
    return "Location";
  }
  toJSON() {
    return {
      start: this.start,
      end: this.end
    };
  }
}
class oa {
  /**
   * The kind of Token.
   */
  /**
   * The character offset at which this Node begins.
   */
  /**
   * The character offset at which this Node ends.
   */
  /**
   * The 1-indexed line number on which this Token appears.
   */
  /**
   * The 1-indexed column number at which this Token begins.
   */
  /**
   * For non-punctuation tokens, represents the interpreted value of the token.
   *
   * Note: is undefined for punctuation tokens, but typed as string for
   * convenience in the parser.
   */
  /**
   * Tokens exist as nodes in a double-linked-list amongst all tokens
   * including ignored tokens. <SOF> is always the first node and <EOF>
   * the last.
   */
  constructor(e, n, r, s, i, a) {
    this.kind = e, this.start = n, this.end = r, this.line = s, this.column = i, this.value = a, this.prev = null, this.next = null;
  }
  get [Symbol.toStringTag]() {
    return "Token";
  }
  toJSON() {
    return {
      kind: this.kind,
      value: this.value,
      line: this.line,
      column: this.column
    };
  }
}
const hc = {
  Name: [],
  Document: ["definitions"],
  OperationDefinition: [
    "name",
    "variableDefinitions",
    "directives",
    "selectionSet"
  ],
  VariableDefinition: ["variable", "type", "defaultValue", "directives"],
  Variable: ["name"],
  SelectionSet: ["selections"],
  Field: ["alias", "name", "arguments", "directives", "selectionSet"],
  Argument: ["name", "value"],
  FragmentSpread: ["name", "directives"],
  InlineFragment: ["typeCondition", "directives", "selectionSet"],
  FragmentDefinition: [
    "name",
    // Note: fragment variable definitions are deprecated and will removed in v17.0.0
    "variableDefinitions",
    "typeCondition",
    "directives",
    "selectionSet"
  ],
  IntValue: [],
  FloatValue: [],
  StringValue: [],
  BooleanValue: [],
  NullValue: [],
  EnumValue: [],
  ListValue: ["values"],
  ObjectValue: ["fields"],
  ObjectField: ["name", "value"],
  Directive: ["name", "arguments"],
  NamedType: ["name"],
  ListType: ["type"],
  NonNullType: ["type"],
  SchemaDefinition: ["description", "directives", "operationTypes"],
  OperationTypeDefinition: ["type"],
  ScalarTypeDefinition: ["description", "name", "directives"],
  ObjectTypeDefinition: [
    "description",
    "name",
    "interfaces",
    "directives",
    "fields"
  ],
  FieldDefinition: ["description", "name", "arguments", "type", "directives"],
  InputValueDefinition: [
    "description",
    "name",
    "type",
    "defaultValue",
    "directives"
  ],
  InterfaceTypeDefinition: [
    "description",
    "name",
    "interfaces",
    "directives",
    "fields"
  ],
  UnionTypeDefinition: ["description", "name", "directives", "types"],
  EnumTypeDefinition: ["description", "name", "directives", "values"],
  EnumValueDefinition: ["description", "name", "directives"],
  InputObjectTypeDefinition: ["description", "name", "directives", "fields"],
  DirectiveDefinition: ["description", "name", "arguments", "locations"],
  SchemaExtension: ["directives", "operationTypes"],
  ScalarTypeExtension: ["name", "directives"],
  ObjectTypeExtension: ["name", "interfaces", "directives", "fields"],
  InterfaceTypeExtension: ["name", "interfaces", "directives", "fields"],
  UnionTypeExtension: ["name", "directives", "types"],
  EnumTypeExtension: ["name", "directives", "values"],
  InputObjectTypeExtension: ["name", "directives", "fields"]
}, pc = new Set(Object.keys(hc));
function dp(t) {
  const e = t?.kind;
  return typeof e == "string" && pc.has(e);
}
var bt;
(function(t) {
  t.QUERY = "query", t.MUTATION = "mutation", t.SUBSCRIPTION = "subscription";
})(bt || (bt = {}));
var Nr;
(function(t) {
  t.QUERY = "QUERY", t.MUTATION = "MUTATION", t.SUBSCRIPTION = "SUBSCRIPTION", t.FIELD = "FIELD", t.FRAGMENT_DEFINITION = "FRAGMENT_DEFINITION", t.FRAGMENT_SPREAD = "FRAGMENT_SPREAD", t.INLINE_FRAGMENT = "INLINE_FRAGMENT", t.VARIABLE_DEFINITION = "VARIABLE_DEFINITION", t.SCHEMA = "SCHEMA", t.SCALAR = "SCALAR", t.OBJECT = "OBJECT", t.FIELD_DEFINITION = "FIELD_DEFINITION", t.ARGUMENT_DEFINITION = "ARGUMENT_DEFINITION", t.INTERFACE = "INTERFACE", t.UNION = "UNION", t.ENUM = "ENUM", t.ENUM_VALUE = "ENUM_VALUE", t.INPUT_OBJECT = "INPUT_OBJECT", t.INPUT_FIELD_DEFINITION = "INPUT_FIELD_DEFINITION";
})(Nr || (Nr = {}));
var L;
(function(t) {
  t.NAME = "Name", t.DOCUMENT = "Document", t.OPERATION_DEFINITION = "OperationDefinition", t.VARIABLE_DEFINITION = "VariableDefinition", t.SELECTION_SET = "SelectionSet", t.FIELD = "Field", t.ARGUMENT = "Argument", t.FRAGMENT_SPREAD = "FragmentSpread", t.INLINE_FRAGMENT = "InlineFragment", t.FRAGMENT_DEFINITION = "FragmentDefinition", t.VARIABLE = "Variable", t.INT = "IntValue", t.FLOAT = "FloatValue", t.STRING = "StringValue", t.BOOLEAN = "BooleanValue", t.NULL = "NullValue", t.ENUM = "EnumValue", t.LIST = "ListValue", t.OBJECT = "ObjectValue", t.OBJECT_FIELD = "ObjectField", t.DIRECTIVE = "Directive", t.NAMED_TYPE = "NamedType", t.LIST_TYPE = "ListType", t.NON_NULL_TYPE = "NonNullType", t.SCHEMA_DEFINITION = "SchemaDefinition", t.OPERATION_TYPE_DEFINITION = "OperationTypeDefinition", t.SCALAR_TYPE_DEFINITION = "ScalarTypeDefinition", t.OBJECT_TYPE_DEFINITION = "ObjectTypeDefinition", t.FIELD_DEFINITION = "FieldDefinition", t.INPUT_VALUE_DEFINITION = "InputValueDefinition", t.INTERFACE_TYPE_DEFINITION = "InterfaceTypeDefinition", t.UNION_TYPE_DEFINITION = "UnionTypeDefinition", t.ENUM_TYPE_DEFINITION = "EnumTypeDefinition", t.ENUM_VALUE_DEFINITION = "EnumValueDefinition", t.INPUT_OBJECT_TYPE_DEFINITION = "InputObjectTypeDefinition", t.DIRECTIVE_DEFINITION = "DirectiveDefinition", t.SCHEMA_EXTENSION = "SchemaExtension", t.SCALAR_TYPE_EXTENSION = "ScalarTypeExtension", t.OBJECT_TYPE_EXTENSION = "ObjectTypeExtension", t.INTERFACE_TYPE_EXTENSION = "InterfaceTypeExtension", t.UNION_TYPE_EXTENSION = "UnionTypeExtension", t.ENUM_TYPE_EXTENSION = "EnumTypeExtension", t.INPUT_OBJECT_TYPE_EXTENSION = "InputObjectTypeExtension";
})(L || (L = {}));
function Ir(t) {
  return t === 9 || t === 32;
}
function jt(t) {
  return t >= 48 && t <= 57;
}
function ua(t) {
  return t >= 97 && t <= 122 || // A-Z
  t >= 65 && t <= 90;
}
function ca(t) {
  return ua(t) || t === 95;
}
function mc(t) {
  return ua(t) || jt(t) || t === 95;
}
function yc(t) {
  var e;
  let n = Number.MAX_SAFE_INTEGER, r = null, s = -1;
  for (let a = 0; a < t.length; ++a) {
    var i;
    const u = t[a], c = vc(u);
    c !== u.length && (r = (i = r) !== null && i !== void 0 ? i : a, s = a, a !== 0 && c < n && (n = c));
  }
  return t.map((a, u) => u === 0 ? a : a.slice(n)).slice(
    (e = r) !== null && e !== void 0 ? e : 0,
    s + 1
  );
}
function vc(t) {
  let e = 0;
  for (; e < t.length && Ir(t.charCodeAt(e)); )
    ++e;
  return e;
}
function hp(t, e) {
  const n = t.replace(/"""/g, '\\"""'), r = n.split(/\r\n|[\n\r]/g), s = r.length === 1, i = r.length > 1 && r.slice(1).every((E) => E.length === 0 || Ir(E.charCodeAt(0))), a = n.endsWith('\\"""'), u = t.endsWith('"') && !a, c = t.endsWith("\\"), l = u || c, d = (
    // add leading and trailing new lines only if it improves readability
    !s || t.length > 70 || l || i || a
  );
  let m = "";
  const T = s && Ir(t.charCodeAt(0));
  return (d && !T || i) && (m += `
`), m += n, (d || l) && (m += `
`), '"""' + m + '"""';
}
var g;
(function(t) {
  t.SOF = "<SOF>", t.EOF = "<EOF>", t.BANG = "!", t.DOLLAR = "$", t.AMP = "&", t.PAREN_L = "(", t.PAREN_R = ")", t.SPREAD = "...", t.COLON = ":", t.EQUALS = "=", t.AT = "@", t.BRACKET_L = "[", t.BRACKET_R = "]", t.BRACE_L = "{", t.PIPE = "|", t.BRACE_R = "}", t.NAME = "Name", t.INT = "Int", t.FLOAT = "Float", t.STRING = "String", t.BLOCK_STRING = "BlockString", t.COMMENT = "Comment";
})(g || (g = {}));
class gc {
  /**
   * The previously focused non-ignored token.
   */
  /**
   * The currently focused non-ignored token.
   */
  /**
   * The (1-indexed) line containing the current token.
   */
  /**
   * The character offset at which the current line begins.
   */
  constructor(e) {
    const n = new oa(g.SOF, 0, 0, 0, 0);
    this.source = e, this.lastToken = n, this.token = n, this.line = 1, this.lineStart = 0;
  }
  get [Symbol.toStringTag]() {
    return "Lexer";
  }
  /**
   * Advances the token stream to the next non-ignored token.
   */
  advance() {
    return this.lastToken = this.token, this.token = this.lookahead();
  }
  /**
   * Looks ahead and returns the next non-ignored token, but does not change
   * the state of Lexer.
   */
  lookahead() {
    let e = this.token;
    if (e.kind !== g.EOF)
      do
        if (e.next)
          e = e.next;
        else {
          const n = wc(this, e.end);
          e.next = n, n.prev = e, e = n;
        }
      while (e.kind === g.COMMENT);
    return e;
  }
}
function Ec(t) {
  return t === g.BANG || t === g.DOLLAR || t === g.AMP || t === g.PAREN_L || t === g.PAREN_R || t === g.SPREAD || t === g.COLON || t === g.EQUALS || t === g.AT || t === g.BRACKET_L || t === g.BRACKET_R || t === g.BRACE_L || t === g.PIPE || t === g.BRACE_R;
}
function kt(t) {
  return t >= 0 && t <= 55295 || t >= 57344 && t <= 1114111;
}
function Vn(t, e) {
  return la(t.charCodeAt(e)) && fa(t.charCodeAt(e + 1));
}
function la(t) {
  return t >= 55296 && t <= 56319;
}
function fa(t) {
  return t >= 56320 && t <= 57343;
}
function ut(t, e) {
  const n = t.source.body.codePointAt(e);
  if (n === void 0)
    return g.EOF;
  if (n >= 32 && n <= 126) {
    const r = String.fromCodePoint(n);
    return r === '"' ? `'"'` : `"${r}"`;
  }
  return "U+" + n.toString(16).toUpperCase().padStart(4, "0");
}
function pe(t, e, n, r, s) {
  const i = t.line, a = 1 + n - t.lineStart;
  return new oa(e, n, r, i, a, s);
}
function wc(t, e) {
  const n = t.source.body, r = n.length;
  let s = e;
  for (; s < r; ) {
    const i = n.charCodeAt(s);
    switch (i) {
      case 65279:
      case 9:
      case 32:
      case 44:
        ++s;
        continue;
      case 10:
        ++s, ++t.line, t.lineStart = s;
        continue;
      case 13:
        n.charCodeAt(s + 1) === 10 ? s += 2 : ++s, ++t.line, t.lineStart = s;
        continue;
      case 35:
        return bc(t, s);
      case 33:
        return pe(t, g.BANG, s, s + 1);
      case 36:
        return pe(t, g.DOLLAR, s, s + 1);
      case 38:
        return pe(t, g.AMP, s, s + 1);
      case 40:
        return pe(t, g.PAREN_L, s, s + 1);
      case 41:
        return pe(t, g.PAREN_R, s, s + 1);
      case 46:
        if (n.charCodeAt(s + 1) === 46 && n.charCodeAt(s + 2) === 46)
          return pe(t, g.SPREAD, s, s + 3);
        break;
      case 58:
        return pe(t, g.COLON, s, s + 1);
      case 61:
        return pe(t, g.EQUALS, s, s + 1);
      case 64:
        return pe(t, g.AT, s, s + 1);
      case 91:
        return pe(t, g.BRACKET_L, s, s + 1);
      case 93:
        return pe(t, g.BRACKET_R, s, s + 1);
      case 123:
        return pe(t, g.BRACE_L, s, s + 1);
      case 124:
        return pe(t, g.PIPE, s, s + 1);
      case 125:
        return pe(t, g.BRACE_R, s, s + 1);
      case 34:
        return n.charCodeAt(s + 1) === 34 && n.charCodeAt(s + 2) === 34 ? Nc(t, s) : Tc(t, s);
    }
    if (jt(i) || i === 45)
      return Oc(t, s, i);
    if (ca(i))
      return Ic(t, s);
    throw ge(
      t.source,
      s,
      i === 39 ? `Unexpected single quote character ('), did you mean to use a double quote (")?` : kt(i) || Vn(n, s) ? `Unexpected character: ${ut(t, s)}.` : `Invalid character: ${ut(t, s)}.`
    );
  }
  return pe(t, g.EOF, r, r);
}
function bc(t, e) {
  const n = t.source.body, r = n.length;
  let s = e + 1;
  for (; s < r; ) {
    const i = n.charCodeAt(s);
    if (i === 10 || i === 13)
      break;
    if (kt(i))
      ++s;
    else if (Vn(n, s))
      s += 2;
    else
      break;
  }
  return pe(
    t,
    g.COMMENT,
    e,
    s,
    n.slice(e + 1, s)
  );
}
function Oc(t, e, n) {
  const r = t.source.body;
  let s = e, i = n, a = !1;
  if (i === 45 && (i = r.charCodeAt(++s)), i === 48) {
    if (i = r.charCodeAt(++s), jt(i))
      throw ge(
        t.source,
        s,
        `Invalid number, unexpected digit after 0: ${ut(
          t,
          s
        )}.`
      );
  } else
    s = or(t, s, i), i = r.charCodeAt(s);
  if (i === 46 && (a = !0, i = r.charCodeAt(++s), s = or(t, s, i), i = r.charCodeAt(s)), (i === 69 || i === 101) && (a = !0, i = r.charCodeAt(++s), (i === 43 || i === 45) && (i = r.charCodeAt(++s)), s = or(t, s, i), i = r.charCodeAt(s)), i === 46 || ca(i))
    throw ge(
      t.source,
      s,
      `Invalid number, expected digit but got: ${ut(
        t,
        s
      )}.`
    );
  return pe(
    t,
    a ? g.FLOAT : g.INT,
    e,
    s,
    r.slice(e, s)
  );
}
function or(t, e, n) {
  if (!jt(n))
    throw ge(
      t.source,
      e,
      `Invalid number, expected digit but got: ${ut(
        t,
        e
      )}.`
    );
  const r = t.source.body;
  let s = e + 1;
  for (; jt(r.charCodeAt(s)); )
    ++s;
  return s;
}
function Tc(t, e) {
  const n = t.source.body, r = n.length;
  let s = e + 1, i = s, a = "";
  for (; s < r; ) {
    const u = n.charCodeAt(s);
    if (u === 34)
      return a += n.slice(i, s), pe(t, g.STRING, e, s + 1, a);
    if (u === 92) {
      a += n.slice(i, s);
      const c = n.charCodeAt(s + 1) === 117 ? n.charCodeAt(s + 2) === 123 ? Sc(t, s) : _c(t, s) : kc(t, s);
      a += c.value, s += c.size, i = s;
      continue;
    }
    if (u === 10 || u === 13)
      break;
    if (kt(u))
      ++s;
    else if (Vn(n, s))
      s += 2;
    else
      throw ge(
        t.source,
        s,
        `Invalid character within String: ${ut(
          t,
          s
        )}.`
      );
  }
  throw ge(t.source, s, "Unterminated string.");
}
function Sc(t, e) {
  const n = t.source.body;
  let r = 0, s = 3;
  for (; s < 12; ) {
    const i = n.charCodeAt(e + s++);
    if (i === 125) {
      if (s < 5 || !kt(r))
        break;
      return {
        value: String.fromCodePoint(r),
        size: s
      };
    }
    if (r = r << 4 | Wt(i), r < 0)
      break;
  }
  throw ge(
    t.source,
    e,
    `Invalid Unicode escape sequence: "${n.slice(
      e,
      e + s
    )}".`
  );
}
function _c(t, e) {
  const n = t.source.body, r = ni(n, e + 2);
  if (kt(r))
    return {
      value: String.fromCodePoint(r),
      size: 6
    };
  if (la(r) && n.charCodeAt(e + 6) === 92 && n.charCodeAt(e + 7) === 117) {
    const s = ni(n, e + 8);
    if (fa(s))
      return {
        value: String.fromCodePoint(r, s),
        size: 12
      };
  }
  throw ge(
    t.source,
    e,
    `Invalid Unicode escape sequence: "${n.slice(e, e + 6)}".`
  );
}
function ni(t, e) {
  return Wt(t.charCodeAt(e)) << 12 | Wt(t.charCodeAt(e + 1)) << 8 | Wt(t.charCodeAt(e + 2)) << 4 | Wt(t.charCodeAt(e + 3));
}
function Wt(t) {
  return t >= 48 && t <= 57 ? t - 48 : t >= 65 && t <= 70 ? t - 55 : t >= 97 && t <= 102 ? t - 87 : -1;
}
function kc(t, e) {
  const n = t.source.body;
  switch (n.charCodeAt(e + 1)) {
    case 34:
      return {
        value: '"',
        size: 2
      };
    case 92:
      return {
        value: "\\",
        size: 2
      };
    case 47:
      return {
        value: "/",
        size: 2
      };
    case 98:
      return {
        value: "\b",
        size: 2
      };
    case 102:
      return {
        value: "\f",
        size: 2
      };
    case 110:
      return {
        value: `
`,
        size: 2
      };
    case 114:
      return {
        value: "\r",
        size: 2
      };
    case 116:
      return {
        value: "	",
        size: 2
      };
  }
  throw ge(
    t.source,
    e,
    `Invalid character escape sequence: "${n.slice(
      e,
      e + 2
    )}".`
  );
}
function Nc(t, e) {
  const n = t.source.body, r = n.length;
  let s = t.lineStart, i = e + 3, a = i, u = "";
  const c = [];
  for (; i < r; ) {
    const l = n.charCodeAt(i);
    if (l === 34 && n.charCodeAt(i + 1) === 34 && n.charCodeAt(i + 2) === 34) {
      u += n.slice(a, i), c.push(u);
      const d = pe(
        t,
        g.BLOCK_STRING,
        e,
        i + 3,
        // Return a string of the lines joined with U+000A.
        yc(c).join(`
`)
      );
      return t.line += c.length - 1, t.lineStart = s, d;
    }
    if (l === 92 && n.charCodeAt(i + 1) === 34 && n.charCodeAt(i + 2) === 34 && n.charCodeAt(i + 3) === 34) {
      u += n.slice(a, i), a = i + 1, i += 4;
      continue;
    }
    if (l === 10 || l === 13) {
      u += n.slice(a, i), c.push(u), l === 13 && n.charCodeAt(i + 1) === 10 ? i += 2 : ++i, u = "", a = i, s = i;
      continue;
    }
    if (kt(l))
      ++i;
    else if (Vn(n, i))
      i += 2;
    else
      throw ge(
        t.source,
        i,
        `Invalid character within String: ${ut(
          t,
          i
        )}.`
      );
  }
  throw ge(t.source, i, "Unterminated string.");
}
function Ic(t, e) {
  const n = t.source.body, r = n.length;
  let s = e + 1;
  for (; s < r; ) {
    const i = n.charCodeAt(s);
    if (mc(i))
      ++s;
    else
      break;
  }
  return pe(
    t,
    g.NAME,
    e,
    s,
    n.slice(e, s)
  );
}
const Dc = 10, da = 2;
function ha(t) {
  return Wn(t, []);
}
function Wn(t, e) {
  switch (typeof t) {
    case "string":
      return JSON.stringify(t);
    case "function":
      return t.name ? `[function ${t.name}]` : "[function]";
    case "object":
      return Cc(t, e);
    default:
      return String(t);
  }
}
function Cc(t, e) {
  if (t === null)
    return "null";
  if (e.includes(t))
    return "[Circular]";
  const n = [...e, t];
  if (Ac(t)) {
    const r = t.toJSON();
    if (r !== t)
      return typeof r == "string" ? r : Wn(r, n);
  } else if (Array.isArray(t))
    return Rc(t, n);
  return xc(t, n);
}
function Ac(t) {
  return typeof t.toJSON == "function";
}
function xc(t, e) {
  const n = Object.entries(t);
  return n.length === 0 ? "{}" : e.length > da ? "[" + Mc(t) + "]" : "{ " + n.map(
    ([s, i]) => s + ": " + Wn(i, e)
  ).join(", ") + " }";
}
function Rc(t, e) {
  if (t.length === 0)
    return "[]";
  if (e.length > da)
    return "[Array]";
  const n = Math.min(Dc, t.length), r = t.length - n, s = [];
  for (let i = 0; i < n; ++i)
    s.push(Wn(t[i], e));
  return r === 1 ? s.push("... 1 more item") : r > 1 && s.push(`... ${r} more items`), "[" + s.join(", ") + "]";
}
function Mc(t) {
  const e = Object.prototype.toString.call(t).replace(/^\[object /, "").replace(/]$/, "");
  if (e === "Object" && typeof t.constructor == "function") {
    const n = t.constructor.name;
    if (typeof n == "string" && n !== "")
      return n;
  }
  return e;
}
var Fc = {};
const Lc = globalThis.process && // eslint-disable-next-line no-undef
Fc.NODE_ENV === "production", Pc = (
  /* c8 ignore next 6 */
  // FIXME: https://github.com/graphql/graphql-js/issues/2317
  Lc ? function(e, n) {
    return e instanceof n;
  } : function(e, n) {
    if (e instanceof n)
      return !0;
    if (typeof e == "object" && e !== null) {
      var r;
      const s = n.prototype[Symbol.toStringTag], i = (
        // We still need to support constructor's name to detect conflicts with older versions of this library.
        Symbol.toStringTag in e ? e[Symbol.toStringTag] : (r = e.constructor) === null || r === void 0 ? void 0 : r.name
      );
      if (s === i) {
        const a = ha(e);
        throw new Error(`Cannot use ${s} "${a}" from another module or realm.

Ensure that there is only one instance of "graphql" in the node_modules
directory. If different versions of "graphql" are the dependencies of other
relied on modules, use "resolutions" to ensure only one version is installed.

https://yarnpkg.com/en/docs/selective-version-resolutions

Duplicate "graphql" modules cannot be used at the same time since different
versions may have different capabilities and behavior. The data from one
version used in the function from another could produce confusing and
spurious results.`);
      }
    }
    return !1;
  }
);
class pa {
  constructor(e, n = "GraphQL request", r = {
    line: 1,
    column: 1
  }) {
    typeof e == "string" || ar(!1, `Body must be a string. Received: ${ha(e)}.`), this.body = e, this.name = n, this.locationOffset = r, this.locationOffset.line > 0 || ar(
      !1,
      "line in locationOffset is 1-indexed and must be positive."
    ), this.locationOffset.column > 0 || ar(
      !1,
      "column in locationOffset is 1-indexed and must be positive."
    );
  }
  get [Symbol.toStringTag]() {
    return "Source";
  }
}
function Vc(t) {
  return Pc(t, pa);
}
function Wc(t, e) {
  return new Uc(t, e).parseDocument();
}
class Uc {
  constructor(e, n = {}) {
    const r = Vc(e) ? e : new pa(e);
    this._lexer = new gc(r), this._options = n, this._tokenCounter = 0;
  }
  /**
   * Converts a name lex token into a name parse node.
   */
  parseName() {
    const e = this.expectToken(g.NAME);
    return this.node(e, {
      kind: L.NAME,
      value: e.value
    });
  }
  // Implements the parsing rules in the Document section.
  /**
   * Document : Definition+
   */
  parseDocument() {
    return this.node(this._lexer.token, {
      kind: L.DOCUMENT,
      definitions: this.many(
        g.SOF,
        this.parseDefinition,
        g.EOF
      )
    });
  }
  /**
   * Definition :
   *   - ExecutableDefinition
   *   - TypeSystemDefinition
   *   - TypeSystemExtension
   *
   * ExecutableDefinition :
   *   - OperationDefinition
   *   - FragmentDefinition
   *
   * TypeSystemDefinition :
   *   - SchemaDefinition
   *   - TypeDefinition
   *   - DirectiveDefinition
   *
   * TypeDefinition :
   *   - ScalarTypeDefinition
   *   - ObjectTypeDefinition
   *   - InterfaceTypeDefinition
   *   - UnionTypeDefinition
   *   - EnumTypeDefinition
   *   - InputObjectTypeDefinition
   */
  parseDefinition() {
    if (this.peek(g.BRACE_L))
      return this.parseOperationDefinition();
    const e = this.peekDescription(), n = e ? this._lexer.lookahead() : this._lexer.token;
    if (n.kind === g.NAME) {
      switch (n.value) {
        case "schema":
          return this.parseSchemaDefinition();
        case "scalar":
          return this.parseScalarTypeDefinition();
        case "type":
          return this.parseObjectTypeDefinition();
        case "interface":
          return this.parseInterfaceTypeDefinition();
        case "union":
          return this.parseUnionTypeDefinition();
        case "enum":
          return this.parseEnumTypeDefinition();
        case "input":
          return this.parseInputObjectTypeDefinition();
        case "directive":
          return this.parseDirectiveDefinition();
      }
      if (e)
        throw ge(
          this._lexer.source,
          this._lexer.token.start,
          "Unexpected description, descriptions are supported only on type definitions."
        );
      switch (n.value) {
        case "query":
        case "mutation":
        case "subscription":
          return this.parseOperationDefinition();
        case "fragment":
          return this.parseFragmentDefinition();
        case "extend":
          return this.parseTypeSystemExtension();
      }
    }
    throw this.unexpected(n);
  }
  // Implements the parsing rules in the Operations section.
  /**
   * OperationDefinition :
   *  - SelectionSet
   *  - OperationType Name? VariableDefinitions? Directives? SelectionSet
   */
  parseOperationDefinition() {
    const e = this._lexer.token;
    if (this.peek(g.BRACE_L))
      return this.node(e, {
        kind: L.OPERATION_DEFINITION,
        operation: bt.QUERY,
        name: void 0,
        variableDefinitions: [],
        directives: [],
        selectionSet: this.parseSelectionSet()
      });
    const n = this.parseOperationType();
    let r;
    return this.peek(g.NAME) && (r = this.parseName()), this.node(e, {
      kind: L.OPERATION_DEFINITION,
      operation: n,
      name: r,
      variableDefinitions: this.parseVariableDefinitions(),
      directives: this.parseDirectives(!1),
      selectionSet: this.parseSelectionSet()
    });
  }
  /**
   * OperationType : one of query mutation subscription
   */
  parseOperationType() {
    const e = this.expectToken(g.NAME);
    switch (e.value) {
      case "query":
        return bt.QUERY;
      case "mutation":
        return bt.MUTATION;
      case "subscription":
        return bt.SUBSCRIPTION;
    }
    throw this.unexpected(e);
  }
  /**
   * VariableDefinitions : ( VariableDefinition+ )
   */
  parseVariableDefinitions() {
    return this.optionalMany(
      g.PAREN_L,
      this.parseVariableDefinition,
      g.PAREN_R
    );
  }
  /**
   * VariableDefinition : Variable : Type DefaultValue? Directives[Const]?
   */
  parseVariableDefinition() {
    return this.node(this._lexer.token, {
      kind: L.VARIABLE_DEFINITION,
      variable: this.parseVariable(),
      type: (this.expectToken(g.COLON), this.parseTypeReference()),
      defaultValue: this.expectOptionalToken(g.EQUALS) ? this.parseConstValueLiteral() : void 0,
      directives: this.parseConstDirectives()
    });
  }
  /**
   * Variable : $ Name
   */
  parseVariable() {
    const e = this._lexer.token;
    return this.expectToken(g.DOLLAR), this.node(e, {
      kind: L.VARIABLE,
      name: this.parseName()
    });
  }
  /**
   * ```
   * SelectionSet : { Selection+ }
   * ```
   */
  parseSelectionSet() {
    return this.node(this._lexer.token, {
      kind: L.SELECTION_SET,
      selections: this.many(
        g.BRACE_L,
        this.parseSelection,
        g.BRACE_R
      )
    });
  }
  /**
   * Selection :
   *   - Field
   *   - FragmentSpread
   *   - InlineFragment
   */
  parseSelection() {
    return this.peek(g.SPREAD) ? this.parseFragment() : this.parseField();
  }
  /**
   * Field : Alias? Name Arguments? Directives? SelectionSet?
   *
   * Alias : Name :
   */
  parseField() {
    const e = this._lexer.token, n = this.parseName();
    let r, s;
    return this.expectOptionalToken(g.COLON) ? (r = n, s = this.parseName()) : s = n, this.node(e, {
      kind: L.FIELD,
      alias: r,
      name: s,
      arguments: this.parseArguments(!1),
      directives: this.parseDirectives(!1),
      selectionSet: this.peek(g.BRACE_L) ? this.parseSelectionSet() : void 0
    });
  }
  /**
   * Arguments[Const] : ( Argument[?Const]+ )
   */
  parseArguments(e) {
    const n = e ? this.parseConstArgument : this.parseArgument;
    return this.optionalMany(g.PAREN_L, n, g.PAREN_R);
  }
  /**
   * Argument[Const] : Name : Value[?Const]
   */
  parseArgument(e = !1) {
    const n = this._lexer.token, r = this.parseName();
    return this.expectToken(g.COLON), this.node(n, {
      kind: L.ARGUMENT,
      name: r,
      value: this.parseValueLiteral(e)
    });
  }
  parseConstArgument() {
    return this.parseArgument(!0);
  }
  // Implements the parsing rules in the Fragments section.
  /**
   * Corresponds to both FragmentSpread and InlineFragment in the spec.
   *
   * FragmentSpread : ... FragmentName Directives?
   *
   * InlineFragment : ... TypeCondition? Directives? SelectionSet
   */
  parseFragment() {
    const e = this._lexer.token;
    this.expectToken(g.SPREAD);
    const n = this.expectOptionalKeyword("on");
    return !n && this.peek(g.NAME) ? this.node(e, {
      kind: L.FRAGMENT_SPREAD,
      name: this.parseFragmentName(),
      directives: this.parseDirectives(!1)
    }) : this.node(e, {
      kind: L.INLINE_FRAGMENT,
      typeCondition: n ? this.parseNamedType() : void 0,
      directives: this.parseDirectives(!1),
      selectionSet: this.parseSelectionSet()
    });
  }
  /**
   * FragmentDefinition :
   *   - fragment FragmentName on TypeCondition Directives? SelectionSet
   *
   * TypeCondition : NamedType
   */
  parseFragmentDefinition() {
    const e = this._lexer.token;
    return this.expectKeyword("fragment"), this._options.allowLegacyFragmentVariables === !0 ? this.node(e, {
      kind: L.FRAGMENT_DEFINITION,
      name: this.parseFragmentName(),
      variableDefinitions: this.parseVariableDefinitions(),
      typeCondition: (this.expectKeyword("on"), this.parseNamedType()),
      directives: this.parseDirectives(!1),
      selectionSet: this.parseSelectionSet()
    }) : this.node(e, {
      kind: L.FRAGMENT_DEFINITION,
      name: this.parseFragmentName(),
      typeCondition: (this.expectKeyword("on"), this.parseNamedType()),
      directives: this.parseDirectives(!1),
      selectionSet: this.parseSelectionSet()
    });
  }
  /**
   * FragmentName : Name but not `on`
   */
  parseFragmentName() {
    if (this._lexer.token.value === "on")
      throw this.unexpected();
    return this.parseName();
  }
  // Implements the parsing rules in the Values section.
  /**
   * Value[Const] :
   *   - [~Const] Variable
   *   - IntValue
   *   - FloatValue
   *   - StringValue
   *   - BooleanValue
   *   - NullValue
   *   - EnumValue
   *   - ListValue[?Const]
   *   - ObjectValue[?Const]
   *
   * BooleanValue : one of `true` `false`
   *
   * NullValue : `null`
   *
   * EnumValue : Name but not `true`, `false` or `null`
   */
  parseValueLiteral(e) {
    const n = this._lexer.token;
    switch (n.kind) {
      case g.BRACKET_L:
        return this.parseList(e);
      case g.BRACE_L:
        return this.parseObject(e);
      case g.INT:
        return this.advanceLexer(), this.node(n, {
          kind: L.INT,
          value: n.value
        });
      case g.FLOAT:
        return this.advanceLexer(), this.node(n, {
          kind: L.FLOAT,
          value: n.value
        });
      case g.STRING:
      case g.BLOCK_STRING:
        return this.parseStringLiteral();
      case g.NAME:
        switch (this.advanceLexer(), n.value) {
          case "true":
            return this.node(n, {
              kind: L.BOOLEAN,
              value: !0
            });
          case "false":
            return this.node(n, {
              kind: L.BOOLEAN,
              value: !1
            });
          case "null":
            return this.node(n, {
              kind: L.NULL
            });
          default:
            return this.node(n, {
              kind: L.ENUM,
              value: n.value
            });
        }
      case g.DOLLAR:
        if (e)
          if (this.expectToken(g.DOLLAR), this._lexer.token.kind === g.NAME) {
            const r = this._lexer.token.value;
            throw ge(
              this._lexer.source,
              n.start,
              `Unexpected variable "$${r}" in constant value.`
            );
          } else
            throw this.unexpected(n);
        return this.parseVariable();
      default:
        throw this.unexpected();
    }
  }
  parseConstValueLiteral() {
    return this.parseValueLiteral(!0);
  }
  parseStringLiteral() {
    const e = this._lexer.token;
    return this.advanceLexer(), this.node(e, {
      kind: L.STRING,
      value: e.value,
      block: e.kind === g.BLOCK_STRING
    });
  }
  /**
   * ListValue[Const] :
   *   - [ ]
   *   - [ Value[?Const]+ ]
   */
  parseList(e) {
    const n = () => this.parseValueLiteral(e);
    return this.node(this._lexer.token, {
      kind: L.LIST,
      values: this.any(g.BRACKET_L, n, g.BRACKET_R)
    });
  }
  /**
   * ```
   * ObjectValue[Const] :
   *   - { }
   *   - { ObjectField[?Const]+ }
   * ```
   */
  parseObject(e) {
    const n = () => this.parseObjectField(e);
    return this.node(this._lexer.token, {
      kind: L.OBJECT,
      fields: this.any(g.BRACE_L, n, g.BRACE_R)
    });
  }
  /**
   * ObjectField[Const] : Name : Value[?Const]
   */
  parseObjectField(e) {
    const n = this._lexer.token, r = this.parseName();
    return this.expectToken(g.COLON), this.node(n, {
      kind: L.OBJECT_FIELD,
      name: r,
      value: this.parseValueLiteral(e)
    });
  }
  // Implements the parsing rules in the Directives section.
  /**
   * Directives[Const] : Directive[?Const]+
   */
  parseDirectives(e) {
    const n = [];
    for (; this.peek(g.AT); )
      n.push(this.parseDirective(e));
    return n;
  }
  parseConstDirectives() {
    return this.parseDirectives(!0);
  }
  /**
   * ```
   * Directive[Const] : @ Name Arguments[?Const]?
   * ```
   */
  parseDirective(e) {
    const n = this._lexer.token;
    return this.expectToken(g.AT), this.node(n, {
      kind: L.DIRECTIVE,
      name: this.parseName(),
      arguments: this.parseArguments(e)
    });
  }
  // Implements the parsing rules in the Types section.
  /**
   * Type :
   *   - NamedType
   *   - ListType
   *   - NonNullType
   */
  parseTypeReference() {
    const e = this._lexer.token;
    let n;
    if (this.expectOptionalToken(g.BRACKET_L)) {
      const r = this.parseTypeReference();
      this.expectToken(g.BRACKET_R), n = this.node(e, {
        kind: L.LIST_TYPE,
        type: r
      });
    } else
      n = this.parseNamedType();
    return this.expectOptionalToken(g.BANG) ? this.node(e, {
      kind: L.NON_NULL_TYPE,
      type: n
    }) : n;
  }
  /**
   * NamedType : Name
   */
  parseNamedType() {
    return this.node(this._lexer.token, {
      kind: L.NAMED_TYPE,
      name: this.parseName()
    });
  }
  // Implements the parsing rules in the Type Definition section.
  peekDescription() {
    return this.peek(g.STRING) || this.peek(g.BLOCK_STRING);
  }
  /**
   * Description : StringValue
   */
  parseDescription() {
    if (this.peekDescription())
      return this.parseStringLiteral();
  }
  /**
   * ```
   * SchemaDefinition : Description? schema Directives[Const]? { OperationTypeDefinition+ }
   * ```
   */
  parseSchemaDefinition() {
    const e = this._lexer.token, n = this.parseDescription();
    this.expectKeyword("schema");
    const r = this.parseConstDirectives(), s = this.many(
      g.BRACE_L,
      this.parseOperationTypeDefinition,
      g.BRACE_R
    );
    return this.node(e, {
      kind: L.SCHEMA_DEFINITION,
      description: n,
      directives: r,
      operationTypes: s
    });
  }
  /**
   * OperationTypeDefinition : OperationType : NamedType
   */
  parseOperationTypeDefinition() {
    const e = this._lexer.token, n = this.parseOperationType();
    this.expectToken(g.COLON);
    const r = this.parseNamedType();
    return this.node(e, {
      kind: L.OPERATION_TYPE_DEFINITION,
      operation: n,
      type: r
    });
  }
  /**
   * ScalarTypeDefinition : Description? scalar Name Directives[Const]?
   */
  parseScalarTypeDefinition() {
    const e = this._lexer.token, n = this.parseDescription();
    this.expectKeyword("scalar");
    const r = this.parseName(), s = this.parseConstDirectives();
    return this.node(e, {
      kind: L.SCALAR_TYPE_DEFINITION,
      description: n,
      name: r,
      directives: s
    });
  }
  /**
   * ObjectTypeDefinition :
   *   Description?
   *   type Name ImplementsInterfaces? Directives[Const]? FieldsDefinition?
   */
  parseObjectTypeDefinition() {
    const e = this._lexer.token, n = this.parseDescription();
    this.expectKeyword("type");
    const r = this.parseName(), s = this.parseImplementsInterfaces(), i = this.parseConstDirectives(), a = this.parseFieldsDefinition();
    return this.node(e, {
      kind: L.OBJECT_TYPE_DEFINITION,
      description: n,
      name: r,
      interfaces: s,
      directives: i,
      fields: a
    });
  }
  /**
   * ImplementsInterfaces :
   *   - implements `&`? NamedType
   *   - ImplementsInterfaces & NamedType
   */
  parseImplementsInterfaces() {
    return this.expectOptionalKeyword("implements") ? this.delimitedMany(g.AMP, this.parseNamedType) : [];
  }
  /**
   * ```
   * FieldsDefinition : { FieldDefinition+ }
   * ```
   */
  parseFieldsDefinition() {
    return this.optionalMany(
      g.BRACE_L,
      this.parseFieldDefinition,
      g.BRACE_R
    );
  }
  /**
   * FieldDefinition :
   *   - Description? Name ArgumentsDefinition? : Type Directives[Const]?
   */
  parseFieldDefinition() {
    const e = this._lexer.token, n = this.parseDescription(), r = this.parseName(), s = this.parseArgumentDefs();
    this.expectToken(g.COLON);
    const i = this.parseTypeReference(), a = this.parseConstDirectives();
    return this.node(e, {
      kind: L.FIELD_DEFINITION,
      description: n,
      name: r,
      arguments: s,
      type: i,
      directives: a
    });
  }
  /**
   * ArgumentsDefinition : ( InputValueDefinition+ )
   */
  parseArgumentDefs() {
    return this.optionalMany(
      g.PAREN_L,
      this.parseInputValueDef,
      g.PAREN_R
    );
  }
  /**
   * InputValueDefinition :
   *   - Description? Name : Type DefaultValue? Directives[Const]?
   */
  parseInputValueDef() {
    const e = this._lexer.token, n = this.parseDescription(), r = this.parseName();
    this.expectToken(g.COLON);
    const s = this.parseTypeReference();
    let i;
    this.expectOptionalToken(g.EQUALS) && (i = this.parseConstValueLiteral());
    const a = this.parseConstDirectives();
    return this.node(e, {
      kind: L.INPUT_VALUE_DEFINITION,
      description: n,
      name: r,
      type: s,
      defaultValue: i,
      directives: a
    });
  }
  /**
   * InterfaceTypeDefinition :
   *   - Description? interface Name Directives[Const]? FieldsDefinition?
   */
  parseInterfaceTypeDefinition() {
    const e = this._lexer.token, n = this.parseDescription();
    this.expectKeyword("interface");
    const r = this.parseName(), s = this.parseImplementsInterfaces(), i = this.parseConstDirectives(), a = this.parseFieldsDefinition();
    return this.node(e, {
      kind: L.INTERFACE_TYPE_DEFINITION,
      description: n,
      name: r,
      interfaces: s,
      directives: i,
      fields: a
    });
  }
  /**
   * UnionTypeDefinition :
   *   - Description? union Name Directives[Const]? UnionMemberTypes?
   */
  parseUnionTypeDefinition() {
    const e = this._lexer.token, n = this.parseDescription();
    this.expectKeyword("union");
    const r = this.parseName(), s = this.parseConstDirectives(), i = this.parseUnionMemberTypes();
    return this.node(e, {
      kind: L.UNION_TYPE_DEFINITION,
      description: n,
      name: r,
      directives: s,
      types: i
    });
  }
  /**
   * UnionMemberTypes :
   *   - = `|`? NamedType
   *   - UnionMemberTypes | NamedType
   */
  parseUnionMemberTypes() {
    return this.expectOptionalToken(g.EQUALS) ? this.delimitedMany(g.PIPE, this.parseNamedType) : [];
  }
  /**
   * EnumTypeDefinition :
   *   - Description? enum Name Directives[Const]? EnumValuesDefinition?
   */
  parseEnumTypeDefinition() {
    const e = this._lexer.token, n = this.parseDescription();
    this.expectKeyword("enum");
    const r = this.parseName(), s = this.parseConstDirectives(), i = this.parseEnumValuesDefinition();
    return this.node(e, {
      kind: L.ENUM_TYPE_DEFINITION,
      description: n,
      name: r,
      directives: s,
      values: i
    });
  }
  /**
   * ```
   * EnumValuesDefinition : { EnumValueDefinition+ }
   * ```
   */
  parseEnumValuesDefinition() {
    return this.optionalMany(
      g.BRACE_L,
      this.parseEnumValueDefinition,
      g.BRACE_R
    );
  }
  /**
   * EnumValueDefinition : Description? EnumValue Directives[Const]?
   */
  parseEnumValueDefinition() {
    const e = this._lexer.token, n = this.parseDescription(), r = this.parseEnumValueName(), s = this.parseConstDirectives();
    return this.node(e, {
      kind: L.ENUM_VALUE_DEFINITION,
      description: n,
      name: r,
      directives: s
    });
  }
  /**
   * EnumValue : Name but not `true`, `false` or `null`
   */
  parseEnumValueName() {
    if (this._lexer.token.value === "true" || this._lexer.token.value === "false" || this._lexer.token.value === "null")
      throw ge(
        this._lexer.source,
        this._lexer.token.start,
        `${mn(
          this._lexer.token
        )} is reserved and cannot be used for an enum value.`
      );
    return this.parseName();
  }
  /**
   * InputObjectTypeDefinition :
   *   - Description? input Name Directives[Const]? InputFieldsDefinition?
   */
  parseInputObjectTypeDefinition() {
    const e = this._lexer.token, n = this.parseDescription();
    this.expectKeyword("input");
    const r = this.parseName(), s = this.parseConstDirectives(), i = this.parseInputFieldsDefinition();
    return this.node(e, {
      kind: L.INPUT_OBJECT_TYPE_DEFINITION,
      description: n,
      name: r,
      directives: s,
      fields: i
    });
  }
  /**
   * ```
   * InputFieldsDefinition : { InputValueDefinition+ }
   * ```
   */
  parseInputFieldsDefinition() {
    return this.optionalMany(
      g.BRACE_L,
      this.parseInputValueDef,
      g.BRACE_R
    );
  }
  /**
   * TypeSystemExtension :
   *   - SchemaExtension
   *   - TypeExtension
   *
   * TypeExtension :
   *   - ScalarTypeExtension
   *   - ObjectTypeExtension
   *   - InterfaceTypeExtension
   *   - UnionTypeExtension
   *   - EnumTypeExtension
   *   - InputObjectTypeDefinition
   */
  parseTypeSystemExtension() {
    const e = this._lexer.lookahead();
    if (e.kind === g.NAME)
      switch (e.value) {
        case "schema":
          return this.parseSchemaExtension();
        case "scalar":
          return this.parseScalarTypeExtension();
        case "type":
          return this.parseObjectTypeExtension();
        case "interface":
          return this.parseInterfaceTypeExtension();
        case "union":
          return this.parseUnionTypeExtension();
        case "enum":
          return this.parseEnumTypeExtension();
        case "input":
          return this.parseInputObjectTypeExtension();
      }
    throw this.unexpected(e);
  }
  /**
   * ```
   * SchemaExtension :
   *  - extend schema Directives[Const]? { OperationTypeDefinition+ }
   *  - extend schema Directives[Const]
   * ```
   */
  parseSchemaExtension() {
    const e = this._lexer.token;
    this.expectKeyword("extend"), this.expectKeyword("schema");
    const n = this.parseConstDirectives(), r = this.optionalMany(
      g.BRACE_L,
      this.parseOperationTypeDefinition,
      g.BRACE_R
    );
    if (n.length === 0 && r.length === 0)
      throw this.unexpected();
    return this.node(e, {
      kind: L.SCHEMA_EXTENSION,
      directives: n,
      operationTypes: r
    });
  }
  /**
   * ScalarTypeExtension :
   *   - extend scalar Name Directives[Const]
   */
  parseScalarTypeExtension() {
    const e = this._lexer.token;
    this.expectKeyword("extend"), this.expectKeyword("scalar");
    const n = this.parseName(), r = this.parseConstDirectives();
    if (r.length === 0)
      throw this.unexpected();
    return this.node(e, {
      kind: L.SCALAR_TYPE_EXTENSION,
      name: n,
      directives: r
    });
  }
  /**
   * ObjectTypeExtension :
   *  - extend type Name ImplementsInterfaces? Directives[Const]? FieldsDefinition
   *  - extend type Name ImplementsInterfaces? Directives[Const]
   *  - extend type Name ImplementsInterfaces
   */
  parseObjectTypeExtension() {
    const e = this._lexer.token;
    this.expectKeyword("extend"), this.expectKeyword("type");
    const n = this.parseName(), r = this.parseImplementsInterfaces(), s = this.parseConstDirectives(), i = this.parseFieldsDefinition();
    if (r.length === 0 && s.length === 0 && i.length === 0)
      throw this.unexpected();
    return this.node(e, {
      kind: L.OBJECT_TYPE_EXTENSION,
      name: n,
      interfaces: r,
      directives: s,
      fields: i
    });
  }
  /**
   * InterfaceTypeExtension :
   *  - extend interface Name ImplementsInterfaces? Directives[Const]? FieldsDefinition
   *  - extend interface Name ImplementsInterfaces? Directives[Const]
   *  - extend interface Name ImplementsInterfaces
   */
  parseInterfaceTypeExtension() {
    const e = this._lexer.token;
    this.expectKeyword("extend"), this.expectKeyword("interface");
    const n = this.parseName(), r = this.parseImplementsInterfaces(), s = this.parseConstDirectives(), i = this.parseFieldsDefinition();
    if (r.length === 0 && s.length === 0 && i.length === 0)
      throw this.unexpected();
    return this.node(e, {
      kind: L.INTERFACE_TYPE_EXTENSION,
      name: n,
      interfaces: r,
      directives: s,
      fields: i
    });
  }
  /**
   * UnionTypeExtension :
   *   - extend union Name Directives[Const]? UnionMemberTypes
   *   - extend union Name Directives[Const]
   */
  parseUnionTypeExtension() {
    const e = this._lexer.token;
    this.expectKeyword("extend"), this.expectKeyword("union");
    const n = this.parseName(), r = this.parseConstDirectives(), s = this.parseUnionMemberTypes();
    if (r.length === 0 && s.length === 0)
      throw this.unexpected();
    return this.node(e, {
      kind: L.UNION_TYPE_EXTENSION,
      name: n,
      directives: r,
      types: s
    });
  }
  /**
   * EnumTypeExtension :
   *   - extend enum Name Directives[Const]? EnumValuesDefinition
   *   - extend enum Name Directives[Const]
   */
  parseEnumTypeExtension() {
    const e = this._lexer.token;
    this.expectKeyword("extend"), this.expectKeyword("enum");
    const n = this.parseName(), r = this.parseConstDirectives(), s = this.parseEnumValuesDefinition();
    if (r.length === 0 && s.length === 0)
      throw this.unexpected();
    return this.node(e, {
      kind: L.ENUM_TYPE_EXTENSION,
      name: n,
      directives: r,
      values: s
    });
  }
  /**
   * InputObjectTypeExtension :
   *   - extend input Name Directives[Const]? InputFieldsDefinition
   *   - extend input Name Directives[Const]
   */
  parseInputObjectTypeExtension() {
    const e = this._lexer.token;
    this.expectKeyword("extend"), this.expectKeyword("input");
    const n = this.parseName(), r = this.parseConstDirectives(), s = this.parseInputFieldsDefinition();
    if (r.length === 0 && s.length === 0)
      throw this.unexpected();
    return this.node(e, {
      kind: L.INPUT_OBJECT_TYPE_EXTENSION,
      name: n,
      directives: r,
      fields: s
    });
  }
  /**
   * ```
   * DirectiveDefinition :
   *   - Description? directive @ Name ArgumentsDefinition? `repeatable`? on DirectiveLocations
   * ```
   */
  parseDirectiveDefinition() {
    const e = this._lexer.token, n = this.parseDescription();
    this.expectKeyword("directive"), this.expectToken(g.AT);
    const r = this.parseName(), s = this.parseArgumentDefs(), i = this.expectOptionalKeyword("repeatable");
    this.expectKeyword("on");
    const a = this.parseDirectiveLocations();
    return this.node(e, {
      kind: L.DIRECTIVE_DEFINITION,
      description: n,
      name: r,
      arguments: s,
      repeatable: i,
      locations: a
    });
  }
  /**
   * DirectiveLocations :
   *   - `|`? DirectiveLocation
   *   - DirectiveLocations | DirectiveLocation
   */
  parseDirectiveLocations() {
    return this.delimitedMany(g.PIPE, this.parseDirectiveLocation);
  }
  /*
   * DirectiveLocation :
   *   - ExecutableDirectiveLocation
   *   - TypeSystemDirectiveLocation
   *
   * ExecutableDirectiveLocation : one of
   *   `QUERY`
   *   `MUTATION`
   *   `SUBSCRIPTION`
   *   `FIELD`
   *   `FRAGMENT_DEFINITION`
   *   `FRAGMENT_SPREAD`
   *   `INLINE_FRAGMENT`
   *
   * TypeSystemDirectiveLocation : one of
   *   `SCHEMA`
   *   `SCALAR`
   *   `OBJECT`
   *   `FIELD_DEFINITION`
   *   `ARGUMENT_DEFINITION`
   *   `INTERFACE`
   *   `UNION`
   *   `ENUM`
   *   `ENUM_VALUE`
   *   `INPUT_OBJECT`
   *   `INPUT_FIELD_DEFINITION`
   */
  parseDirectiveLocation() {
    const e = this._lexer.token, n = this.parseName();
    if (Object.prototype.hasOwnProperty.call(Nr, n.value))
      return n;
    throw this.unexpected(e);
  }
  // Core parsing utility functions
  /**
   * Returns a node that, if configured to do so, sets a "loc" field as a
   * location object, used to identify the place in the source that created a
   * given parsed object.
   */
  node(e, n) {
    return this._options.noLocation !== !0 && (n.loc = new dc(
      e,
      this._lexer.lastToken,
      this._lexer.source
    )), n;
  }
  /**
   * Determines if the next token is of a given kind
   */
  peek(e) {
    return this._lexer.token.kind === e;
  }
  /**
   * If the next token is of the given kind, return that token after advancing the lexer.
   * Otherwise, do not change the parser state and throw an error.
   */
  expectToken(e) {
    const n = this._lexer.token;
    if (n.kind === e)
      return this.advanceLexer(), n;
    throw ge(
      this._lexer.source,
      n.start,
      `Expected ${ma(e)}, found ${mn(n)}.`
    );
  }
  /**
   * If the next token is of the given kind, return "true" after advancing the lexer.
   * Otherwise, do not change the parser state and return "false".
   */
  expectOptionalToken(e) {
    return this._lexer.token.kind === e ? (this.advanceLexer(), !0) : !1;
  }
  /**
   * If the next token is a given keyword, advance the lexer.
   * Otherwise, do not change the parser state and throw an error.
   */
  expectKeyword(e) {
    const n = this._lexer.token;
    if (n.kind === g.NAME && n.value === e)
      this.advanceLexer();
    else
      throw ge(
        this._lexer.source,
        n.start,
        `Expected "${e}", found ${mn(n)}.`
      );
  }
  /**
   * If the next token is a given keyword, return "true" after advancing the lexer.
   * Otherwise, do not change the parser state and return "false".
   */
  expectOptionalKeyword(e) {
    const n = this._lexer.token;
    return n.kind === g.NAME && n.value === e ? (this.advanceLexer(), !0) : !1;
  }
  /**
   * Helper function for creating an error when an unexpected lexed token is encountered.
   */
  unexpected(e) {
    const n = e ?? this._lexer.token;
    return ge(
      this._lexer.source,
      n.start,
      `Unexpected ${mn(n)}.`
    );
  }
  /**
   * Returns a possibly empty list of parse nodes, determined by the parseFn.
   * This list begins with a lex token of openKind and ends with a lex token of closeKind.
   * Advances the parser to the next lex token after the closing token.
   */
  any(e, n, r) {
    this.expectToken(e);
    const s = [];
    for (; !this.expectOptionalToken(r); )
      s.push(n.call(this));
    return s;
  }
  /**
   * Returns a list of parse nodes, determined by the parseFn.
   * It can be empty only if open token is missing otherwise it will always return non-empty list
   * that begins with a lex token of openKind and ends with a lex token of closeKind.
   * Advances the parser to the next lex token after the closing token.
   */
  optionalMany(e, n, r) {
    if (this.expectOptionalToken(e)) {
      const s = [];
      do
        s.push(n.call(this));
      while (!this.expectOptionalToken(r));
      return s;
    }
    return [];
  }
  /**
   * Returns a non-empty list of parse nodes, determined by the parseFn.
   * This list begins with a lex token of openKind and ends with a lex token of closeKind.
   * Advances the parser to the next lex token after the closing token.
   */
  many(e, n, r) {
    this.expectToken(e);
    const s = [];
    do
      s.push(n.call(this));
    while (!this.expectOptionalToken(r));
    return s;
  }
  /**
   * Returns a non-empty list of parse nodes, determined by the parseFn.
   * This list may begin with a lex token of delimiterKind followed by items separated by lex tokens of tokenKind.
   * Advances the parser to the next lex token after last item in the list.
   */
  delimitedMany(e, n) {
    this.expectOptionalToken(e);
    const r = [];
    do
      r.push(n.call(this));
    while (this.expectOptionalToken(e));
    return r;
  }
  advanceLexer() {
    const { maxTokens: e } = this._options, n = this._lexer.advance();
    if (e !== void 0 && n.kind !== g.EOF && (++this._tokenCounter, this._tokenCounter > e))
      throw ge(
        this._lexer.source,
        n.start,
        `Document contains more that ${e} tokens. Parsing aborted.`
      );
  }
}
function mn(t) {
  const e = t.value;
  return ma(t.kind) + (e != null ? ` "${e}"` : "");
}
function ma(t) {
  return Ec(t) ? `"${t}"` : t;
}
var ya = We(function() {
  return navigator.product;
}) == "ReactNative", pp = typeof WeakMap == "function" && !(ya && !Ki.HermesInternal), mp = typeof WeakSet == "function", va = typeof Symbol == "function" && typeof Symbol.for == "function", yp = va && Symbol.asyncIterator, ga = typeof We(function() {
  return window.document.createElement;
}) == "function", $c = (
  // Following advice found in this comment from @domenic (maintainer of jsdom):
  // https://github.com/jsdom/jsdom/issues/1537#issuecomment-229405327
  //
  // Since we control the version of Jest and jsdom used when running Apollo
  // Client tests, and that version is recent enought to include " jsdom/x.y.z"
  // at the end of the user agent string, I believe this case is all we need to
  // check. Testing for "Node.js" was recommended for backwards compatibility
  // with older version of jsdom, but we don't have that problem.
  We(function() {
    return navigator.userAgent.indexOf("jsdom") >= 0;
  }) || !1
), Hc = (ga || ya) && !$c;
function Dr(t) {
  return t !== null && typeof t == "object";
}
function jc() {
}
class ri {
  constructor(e = 1 / 0, n = jc) {
    this.max = e, this.dispose = n, this.map = /* @__PURE__ */ new Map(), this.newest = null, this.oldest = null;
  }
  has(e) {
    return this.map.has(e);
  }
  get(e) {
    const n = this.getNode(e);
    return n && n.value;
  }
  get size() {
    return this.map.size;
  }
  getNode(e) {
    const n = this.map.get(e);
    if (n && n !== this.newest) {
      const { older: r, newer: s } = n;
      s && (s.older = r), r && (r.newer = s), n.older = this.newest, n.older.newer = n, n.newer = null, this.newest = n, n === this.oldest && (this.oldest = s);
    }
    return n;
  }
  set(e, n) {
    let r = this.getNode(e);
    return r ? r.value = n : (r = {
      key: e,
      value: n,
      newer: null,
      older: this.newest
    }, this.newest && (this.newest.newer = r), this.newest = r, this.oldest = this.oldest || r, this.map.set(e, r), r.value);
  }
  clean() {
    for (; this.oldest && this.map.size > this.max; )
      this.delete(this.oldest.key);
  }
  delete(e) {
    const n = this.map.get(e);
    return n ? (n === this.newest && (this.newest = n.older), n === this.oldest && (this.oldest = n.newer), n.newer && (n.newer.older = n.older), n.older && (n.older.newer = n.newer), this.map.delete(e), this.dispose(n.value, e), !0) : !1;
  }
}
function Cr() {
}
const zc = Cr, Bc = typeof WeakRef < "u" ? WeakRef : function(t) {
  return { deref: () => t };
}, Yc = typeof WeakMap < "u" ? WeakMap : Map, qc = typeof FinalizationRegistry < "u" ? FinalizationRegistry : function() {
  return {
    register: Cr,
    unregister: Cr
  };
}, Gc = 10024;
class si {
  constructor(e = 1 / 0, n = zc) {
    this.max = e, this.dispose = n, this.map = new Yc(), this.newest = null, this.oldest = null, this.unfinalizedNodes = /* @__PURE__ */ new Set(), this.finalizationScheduled = !1, this.size = 0, this.finalize = () => {
      const r = this.unfinalizedNodes.values();
      for (let s = 0; s < Gc; s++) {
        const i = r.next().value;
        if (!i)
          break;
        this.unfinalizedNodes.delete(i);
        const a = i.key;
        delete i.key, i.keyRef = new Bc(a), this.registry.register(a, i, i);
      }
      this.unfinalizedNodes.size > 0 ? queueMicrotask(this.finalize) : this.finalizationScheduled = !1;
    }, this.registry = new qc(this.deleteNode.bind(this));
  }
  has(e) {
    return this.map.has(e);
  }
  get(e) {
    const n = this.getNode(e);
    return n && n.value;
  }
  getNode(e) {
    const n = this.map.get(e);
    if (n && n !== this.newest) {
      const { older: r, newer: s } = n;
      s && (s.older = r), r && (r.newer = s), n.older = this.newest, n.older.newer = n, n.newer = null, this.newest = n, n === this.oldest && (this.oldest = s);
    }
    return n;
  }
  set(e, n) {
    let r = this.getNode(e);
    return r ? r.value = n : (r = {
      key: e,
      value: n,
      newer: null,
      older: this.newest
    }, this.newest && (this.newest.newer = r), this.newest = r, this.oldest = this.oldest || r, this.scheduleFinalization(r), this.map.set(e, r), this.size++, r.value);
  }
  clean() {
    for (; this.oldest && this.size > this.max; )
      this.deleteNode(this.oldest);
  }
  deleteNode(e) {
    e === this.newest && (this.newest = e.older), e === this.oldest && (this.oldest = e.newer), e.newer && (e.newer.older = e.older), e.older && (e.older.newer = e.newer), this.size--;
    const n = e.key || e.keyRef && e.keyRef.deref();
    this.dispose(e.value, n), e.keyRef ? this.registry.unregister(e) : this.unfinalizedNodes.delete(e), n && this.map.delete(n);
  }
  delete(e) {
    const n = this.map.get(e);
    return n ? (this.deleteNode(n), !0) : !1;
  }
  scheduleFinalization(e) {
    this.unfinalizedNodes.add(e), this.finalizationScheduled || (this.finalizationScheduled = !0, queueMicrotask(this.finalize));
  }
}
var ur = /* @__PURE__ */ new WeakSet();
function Ea(t) {
  t.size <= (t.max || -1) || ur.has(t) || (ur.add(t), setTimeout(function() {
    t.clean(), ur.delete(t);
  }, 100));
}
var Zc = function(t, e) {
  var n = new si(t, e);
  return n.set = function(r, s) {
    var i = si.prototype.set.call(this, r, s);
    return Ea(this), i;
  }, n;
}, vp = function(t, e) {
  var n = new ri(t, e);
  return n.set = function(r, s) {
    var i = ri.prototype.set.call(this, r, s);
    return Ea(this), i;
  }, n;
}, Qc = Symbol.for("apollo.cacheSize"), wa = X({}, _r[Qc]), st = {};
function Jc(t, e) {
  st[t] = e;
}
var gp = globalThis.__DEV__ !== !1 ? Kc : void 0, Ep = globalThis.__DEV__ !== !1 ? el : void 0, wp = globalThis.__DEV__ !== !1 ? ba : void 0;
function Xc() {
  var t = {
    parser: 1e3,
    canonicalStringify: 1e3,
    print: 2e3,
    "documentTransform.cache": 2e3,
    "queryManager.getDocumentInfo": 2e3,
    "PersistedQueryLink.persistedQueryHashes": 2e3,
    "fragmentRegistry.transform": 2e3,
    "fragmentRegistry.lookup": 1e3,
    "fragmentRegistry.findFragmentSpreads": 4e3,
    "cache.fragmentQueryDocuments": 1e3,
    "removeTypenameFromVariables.getVariableDefinitions": 2e3,
    "inMemoryCache.maybeBroadcastWatch": 5e3,
    "inMemoryCache.executeSelectionSet": 5e4,
    "inMemoryCache.executeSubSelectedArray": 1e4
  };
  return Object.fromEntries(Object.entries(t).map(function(e) {
    var n = e[0], r = e[1];
    return [
      n,
      wa[n] || r
    ];
  }));
}
function Kc() {
  var t, e, n, r, s;
  if (globalThis.__DEV__ === !1)
    throw new Error("only supported in development mode");
  return {
    limits: Xc(),
    sizes: X({ print: (t = st.print) === null || t === void 0 ? void 0 : t.call(st), parser: (e = st.parser) === null || e === void 0 ? void 0 : e.call(st), canonicalStringify: (n = st.canonicalStringify) === null || n === void 0 ? void 0 : n.call(st), links: xr(this.link), queryManager: {
      getDocumentInfo: this.queryManager.transformCache.size,
      documentTransforms: Ta(this.queryManager.documentTransform)
    } }, (s = (r = this.cache).getMemoryInternals) === null || s === void 0 ? void 0 : s.call(r))
  };
}
function ba() {
  return {
    cache: {
      fragmentQueryDocuments: Je(this.getFragmentDoc)
    }
  };
}
function el() {
  var t = this.config.fragments;
  return X(X({}, ba.apply(this)), { addTypenameDocumentTransform: Ta(this.addTypenameTransform), inMemoryCache: {
    executeSelectionSet: Je(this.storeReader.executeSelectionSet),
    executeSubSelectedArray: Je(this.storeReader.executeSubSelectedArray),
    maybeBroadcastWatch: Je(this.maybeBroadcastWatch)
  }, fragmentRegistry: {
    findFragmentSpreads: Je(t?.findFragmentSpreads),
    lookup: Je(t?.lookup),
    transform: Je(t?.transform)
  } });
}
function tl(t) {
  return !!t && "dirtyKey" in t;
}
function Je(t) {
  return tl(t) ? t.size : void 0;
}
function Oa(t) {
  return t != null;
}
function Ta(t) {
  return Ar(t).map(function(e) {
    return { cache: e };
  });
}
function Ar(t) {
  return t ? Le(Le([
    Je(t?.performWork)
  ], Ar(t?.left), !0), Ar(t?.right), !0).filter(Oa) : [];
}
function xr(t) {
  var e;
  return t ? Le(Le([
    (e = t?.getMemoryInternals) === null || e === void 0 ? void 0 : e.call(t)
  ], xr(t?.left), !0), xr(t?.right), !0).filter(Oa) : [];
}
var bp = Array.isArray;
function Sa(t) {
  return Array.isArray(t) && t.length > 0;
}
function nl(t) {
  var e = /* @__PURE__ */ new Set([t]);
  return e.forEach(function(n) {
    Dr(n) && rl(n) === n && Object.getOwnPropertyNames(n).forEach(function(r) {
      Dr(n[r]) && e.add(n[r]);
    });
  }), t;
}
function rl(t) {
  if (globalThis.__DEV__ !== !1 && !Object.isFrozen(t))
    try {
      Object.freeze(t);
    } catch (e) {
      if (e instanceof TypeError)
        return null;
      throw e;
    }
  return t;
}
function _a(t) {
  return globalThis.__DEV__ !== !1 && nl(t), t;
}
function Rr() {
  for (var t = [], e = 0; e < arguments.length; e++)
    t[e] = arguments[e];
  var n = /* @__PURE__ */ Object.create(null);
  return t.forEach(function(r) {
    r && Object.keys(r).forEach(function(s) {
      var i = r[s];
      i !== void 0 && (n[s] = i);
    });
  }), n;
}
function Dn(t, e) {
  return Rr(t, e, e.variables && {
    variables: Rr(X(X({}, t && t.variables), e.variables))
  });
}
var sl = Symbol();
function Op(t) {
  return t.extensions ? Array.isArray(t.extensions[sl]) : !1;
}
function Tp(t) {
  return t.hasOwnProperty("graphQLErrors");
}
var il = function(t) {
  var e = Le(Le(Le([], t.graphQLErrors, !0), t.clientErrors, !0), t.protocolErrors, !0);
  return t.networkError && e.push(t.networkError), e.map(function(n) {
    return Dr(n) && n.message || "Error message not found.";
  }).join(`
`);
}, Jr = (
  /** @class */
  function(t) {
    ea(e, t);
    function e(n) {
      var r = n.graphQLErrors, s = n.protocolErrors, i = n.clientErrors, a = n.networkError, u = n.errorMessage, c = n.extraInfo, l = t.call(this, u) || this;
      return l.name = "ApolloError", l.graphQLErrors = r || [], l.protocolErrors = s || [], l.clientErrors = i || [], l.networkError = a || null, l.message = u || il(l), l.extraInfo = c, l.cause = Le(Le(Le([
        a
      ], r || [], !0), s || [], !0), i || [], !0).find(function(d) {
        return !!d;
      }) || null, l.__proto__ = e.prototype, l;
    }
    return e;
  }(Error)
);
const { toString: ii, hasOwnProperty: al } = Object.prototype, ai = Function.prototype.toString, Mr = /* @__PURE__ */ new Map();
function zt(t, e) {
  try {
    return Fr(t, e);
  } finally {
    Mr.clear();
  }
}
function Fr(t, e) {
  if (t === e)
    return !0;
  const n = ii.call(t), r = ii.call(e);
  if (n !== r)
    return !1;
  switch (n) {
    case "[object Array]":
      if (t.length !== e.length)
        return !1;
    case "[object Object]": {
      if (ui(t, e))
        return !0;
      const s = oi(t), i = oi(e), a = s.length;
      if (a !== i.length)
        return !1;
      for (let u = 0; u < a; ++u)
        if (!al.call(e, s[u]))
          return !1;
      for (let u = 0; u < a; ++u) {
        const c = s[u];
        if (!Fr(t[c], e[c]))
          return !1;
      }
      return !0;
    }
    case "[object Error]":
      return t.name === e.name && t.message === e.message;
    case "[object Number]":
      if (t !== t)
        return e !== e;
    case "[object Boolean]":
    case "[object Date]":
      return +t == +e;
    case "[object RegExp]":
    case "[object String]":
      return t == `${e}`;
    case "[object Map]":
    case "[object Set]": {
      if (t.size !== e.size)
        return !1;
      if (ui(t, e))
        return !0;
      const s = t.entries(), i = n === "[object Map]";
      for (; ; ) {
        const a = s.next();
        if (a.done)
          break;
        const [u, c] = a.value;
        if (!e.has(u) || i && !Fr(c, e.get(u)))
          return !1;
      }
      return !0;
    }
    case "[object Uint16Array]":
    case "[object Uint8Array]":
    case "[object Uint32Array]":
    case "[object Int32Array]":
    case "[object Int8Array]":
    case "[object Int16Array]":
    case "[object ArrayBuffer]":
      t = new Uint8Array(t), e = new Uint8Array(e);
    case "[object DataView]": {
      let s = t.byteLength;
      if (s === e.byteLength)
        for (; s-- && t[s] === e[s]; )
          ;
      return s === -1;
    }
    case "[object AsyncFunction]":
    case "[object GeneratorFunction]":
    case "[object AsyncGeneratorFunction]":
    case "[object Function]": {
      const s = ai.call(t);
      return s !== ai.call(e) ? !1 : !cl(s, ul);
    }
  }
  return !1;
}
function oi(t) {
  return Object.keys(t).filter(ol, t);
}
function ol(t) {
  return this[t] !== void 0;
}
const ul = "{ [native code] }";
function cl(t, e) {
  const n = t.length - e.length;
  return n >= 0 && t.indexOf(e, n) === n;
}
function ui(t, e) {
  let n = Mr.get(t);
  if (n) {
    if (n.has(e))
      return !0;
  } else
    Mr.set(t, n = /* @__PURE__ */ new Set());
  return n.add(e), !1;
}
var ct;
(function(t) {
  t[t.loading = 1] = "loading", t[t.setVariables = 2] = "setVariables", t[t.fetchMore = 3] = "fetchMore", t[t.refetch = 4] = "refetch", t[t.poll = 6] = "poll", t[t.ready = 7] = "ready", t[t.error = 8] = "error";
})(ct || (ct = {}));
function Sp(t) {
  return t ? t < 7 : !1;
}
var Tn = /* @__PURE__ */ new Map(), Lr = /* @__PURE__ */ new Map(), ka = !0, Cn = !1;
function Na(t) {
  return t.replace(/[\s,]+/g, " ").trim();
}
function ll(t) {
  return Na(t.source.body.substring(t.start, t.end));
}
function fl(t) {
  var e = /* @__PURE__ */ new Set(), n = [];
  return t.definitions.forEach(function(r) {
    if (r.kind === "FragmentDefinition") {
      var s = r.name.value, i = ll(r.loc), a = Lr.get(s);
      a && !a.has(i) ? ka && console.warn("Warning: fragment with name " + s + ` already exists.
graphql-tag enforces all fragment names across your application to be unique; read more about
this in the docs: http://dev.apollodata.com/core/fragments.html#unique-names`) : a || Lr.set(s, a = /* @__PURE__ */ new Set()), a.add(i), e.has(i) || (e.add(i), n.push(r));
    } else
      n.push(r);
  }), X(X({}, t), { definitions: n });
}
function dl(t) {
  var e = new Set(t.definitions);
  e.forEach(function(r) {
    r.loc && delete r.loc, Object.keys(r).forEach(function(s) {
      var i = r[s];
      i && typeof i == "object" && e.add(i);
    });
  });
  var n = t.loc;
  return n && (delete n.startToken, delete n.endToken), t;
}
function hl(t) {
  var e = Na(t);
  if (!Tn.has(e)) {
    var n = Wc(t, {
      experimentalFragmentVariables: Cn,
      allowLegacyFragmentVariables: Cn
    });
    if (!n || n.kind !== "Document")
      throw new Error("Not a valid GraphQL document.");
    Tn.set(e, dl(fl(n)));
  }
  return Tn.get(e);
}
function ye(t) {
  for (var e = [], n = 1; n < arguments.length; n++)
    e[n - 1] = arguments[n];
  typeof t == "string" && (t = [t]);
  var r = t[0];
  return e.forEach(function(s, i) {
    s && s.kind === "Document" ? r += s.loc.source.body : r += s, r += t[i + 1];
  }), hl(r);
}
function pl() {
  Tn.clear(), Lr.clear();
}
function ml() {
  ka = !1;
}
function yl() {
  Cn = !0;
}
function vl() {
  Cn = !1;
}
var Ft = {
  gql: ye,
  resetCaches: pl,
  disableFragmentWarnings: ml,
  enableExperimentalFragmentVariables: yl,
  disableExperimentalFragmentVariables: vl
};
(function(t) {
  t.gql = Ft.gql, t.resetCaches = Ft.resetCaches, t.disableFragmentWarnings = Ft.disableFragmentWarnings, t.enableExperimentalFragmentVariables = Ft.enableExperimentalFragmentVariables, t.disableExperimentalFragmentVariables = Ft.disableExperimentalFragmentVariables;
})(ye || (ye = {}));
ye.default = ye;
var Ia = { exports: {} };
(function(t) {
  t.exports.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = void 0, t.exports.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = void 0, t.exports.__SERVER_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = void 0, Object.assign(t.exports, qr);
})(Ia);
var Z = Ia.exports;
const gl = /* @__PURE__ */ Xi(Z), Da = /* @__PURE__ */ Ji({
  __proto__: null,
  default: gl
}, [Z]);
var ci = va ? Symbol.for("__APOLLO_CONTEXT__") : "__APOLLO_CONTEXT__";
function Ca() {
  Ue("createContext" in Da, 46);
  var t = Z.createContext[ci];
  return t || (Object.defineProperty(Z.createContext, ci, {
    value: t = Z.createContext({}),
    enumerable: !1,
    writable: !1,
    configurable: !0
  }), t.displayName = "ApolloContext"), t;
}
function Xr(t) {
  var e = Z.useContext(Ca()), n = t || e.client;
  return Ue(!!n, 50), n;
}
var li = !1, El = "useSyncExternalStore", wl = Da[El], bl = wl || function(t, e, n) {
  var r = e();
  // DEVIATION: Using __DEV__
  globalThis.__DEV__ !== !1 && !li && // DEVIATION: Not using Object.is because we know our snapshots will never
  // be exotic primitive values like NaN, which is !== itself.
  r !== e() && (li = !0, globalThis.__DEV__ !== !1 && Ue.error(60));
  var s = Z.useState({
    inst: { value: r, getSnapshot: e }
  }), i = s[0].inst, a = s[1];
  return Hc ? Z.useLayoutEffect(function() {
    Object.assign(i, { value: r, getSnapshot: e }), cr(i) && a({ inst: i });
  }, [t, r, e]) : Object.assign(i, { value: r, getSnapshot: e }), Z.useEffect(function() {
    return cr(i) && a({ inst: i }), t(function() {
      cr(i) && a({ inst: i });
    });
  }, [t]), r;
};
function cr(t) {
  var e = t.value, n = t.getSnapshot;
  try {
    return e !== n();
  } catch {
    return !0;
  }
}
var Pe;
(function(t) {
  t[t.Query = 0] = "Query", t[t.Mutation = 1] = "Mutation", t[t.Subscription = 2] = "Subscription";
})(Pe || (Pe = {}));
var at;
function fi(t) {
  var e;
  switch (t) {
    case Pe.Query:
      e = "Query";
      break;
    case Pe.Mutation:
      e = "Mutation";
      break;
    case Pe.Subscription:
      e = "Subscription";
      break;
  }
  return e;
}
function Aa(t) {
  at || (at = new Zc(
    wa.parser || 1e3
    /* defaultCacheSizes.parser */
  ));
  var e = at.get(t);
  if (e)
    return e;
  var n, r, s;
  Ue(!!t && !!t.kind, 62, t);
  for (var i = [], a = [], u = [], c = [], l = 0, d = t.definitions; l < d.length; l++) {
    var m = d[l];
    if (m.kind === "FragmentDefinition") {
      i.push(m);
      continue;
    }
    if (m.kind === "OperationDefinition")
      switch (m.operation) {
        case "query":
          a.push(m);
          break;
        case "mutation":
          u.push(m);
          break;
        case "subscription":
          c.push(m);
          break;
      }
  }
  Ue(!i.length || a.length || u.length || c.length, 63), Ue(
    a.length + u.length + c.length <= 1,
    64,
    t,
    a.length,
    c.length,
    u.length
  ), r = a.length ? Pe.Query : Pe.Mutation, !a.length && !u.length && (r = Pe.Subscription);
  var T = a.length ? a : u.length ? u : c;
  Ue(T.length === 1, 65, t, T.length);
  var E = T[0];
  n = E.variableDefinitions || [], E.name && E.name.kind === "Name" ? s = E.name.value : s = "data";
  var S = { name: s, type: r, variables: n };
  return at.set(t, S), S;
}
Aa.resetCache = function() {
  at = void 0;
};
globalThis.__DEV__ !== !1 && Jc("parser", function() {
  return at ? at.size : 0;
});
function xa(t, e) {
  var n = Aa(t), r = fi(e), s = fi(n.type);
  Ue(
    n.type === e,
    66,
    r,
    r,
    s
  );
}
var Ra = ga ? Z.useLayoutEffect : Z.useEffect, Ol = Symbol.for("apollo.hook.wrappers");
function Tl(t, e, n) {
  var r = n.queryManager, s = r && r[Ol], i = s && s[t];
  return i ? i(e) : e;
}
var Sl = Object.prototype.hasOwnProperty;
function di() {
}
var Sn = Symbol();
function Gt(t, e) {
  return e === void 0 && (e = /* @__PURE__ */ Object.create(null)), Tl("useQuery", _l, Xr(e && e.client))(t, e);
}
function _l(t, e) {
  var n = Ma(t, e), r = n.result, s = n.obsQueryFields;
  return Z.useMemo(function() {
    return X(X({}, r), s);
  }, [r, s]);
}
function kl(t, e, n, r, s) {
  function i(m) {
    var T;
    xa(e, Pe.Query);
    var E = {
      client: t,
      query: e,
      observable: (
        // See if there is an existing observable that was used to fetch the same
        // data and if so, use it instead since it will contain the proper queryId
        // to fetch the result set. This is used during SSR.
        r && r.getSSRObservable(s()) || t.watchQuery(Kr(void 0, t, n, s()))
      ),
      resultData: {
        // Reuse previousData from previous InternalState (if any) to provide
        // continuity of previousData even if/when the query or client changes.
        previousData: (T = m?.resultData.current) === null || T === void 0 ? void 0 : T.data
      }
    };
    return E;
  }
  var a = Z.useState(i), u = a[0], c = a[1];
  function l(m) {
    var T, E;
    Object.assign(u.observable, (T = {}, T[Sn] = m, T));
    var S = u.resultData;
    c(X(X({}, u), {
      // might be a different query
      query: m.query,
      resultData: Object.assign(S, {
        // We need to modify the previous `resultData` object as we rely on the
        // object reference in other places
        previousData: ((E = S.current) === null || E === void 0 ? void 0 : E.data) || S.previousData,
        current: void 0
      })
    }));
  }
  if (t !== u.client || e !== u.query) {
    var d = i(u);
    return c(d), [d, l];
  }
  return [u, l];
}
function Ma(t, e) {
  var n = Xr(e.client), r = Z.useContext(Ca()).renderPromises, s = !!r, i = n.disableNetworkFetches, a = e.ssr !== !1 && !e.skip, u = e.partialRefetch, c = Fa(n, t, e, s), l = kl(n, t, e, r, c), d = l[0], m = d.observable, T = d.resultData, E = l[1], S = c(m);
  Dl(
    T,
    // might get mutated during render
    m,
    // might get mutated during render
    n,
    e,
    S
  );
  var _ = Z.useMemo(function() {
    return Rl(m);
  }, [m]);
  Il(m, r, a);
  var w = Nl(T, m, n, e, S, i, u, s, {
    onCompleted: e.onCompleted || di,
    onError: e.onError || di
  });
  return {
    result: w,
    obsQueryFields: _,
    observable: m,
    resultData: T,
    client: n,
    onQueryExecuted: E
  };
}
function Nl(t, e, n, r, s, i, a, u, c) {
  var l = Z.useRef(c);
  Z.useEffect(function() {
    l.current = c;
  });
  var d = (u || i) && r.ssr === !1 && !r.skip ? (
    // If SSR has been explicitly disabled, and this function has been called
    // on the server side, return the default loading state.
    La
  ) : r.skip || s.fetchPolicy === "standby" ? (
    // When skipping a query (ie. we're not querying for data but still want to
    // render children), make sure the `data` is cleared out and `loading` is
    // set to `false` (since we aren't loading anything).
    //
    // NOTE: We no longer think this is the correct behavior. Skipping should
    // not automatically set `data` to `undefined`, but instead leave the
    // previous data in place. In other words, skipping should not mandate that
    // previously received data is all of a sudden removed. Unfortunately,
    // changing this is breaking, so we'll have to wait until Apollo Client 4.0
    // to address this.
    Pa
  ) : void 0, m = t.previousData, T = Z.useMemo(function() {
    return d && An(d, m, e, n);
  }, [n, e, d, m]);
  return bl(Z.useCallback(function(E) {
    if (u)
      return function() {
      };
    var S = function() {
      var v = t.current, O = e.getCurrentResult();
      v && v.loading === O.loading && v.networkStatus === O.networkStatus && zt(v.data, O.data) || Pr(O, t, e, n, a, E, l.current);
    }, _ = function(v) {
      if (w.current.unsubscribe(), w.current = e.resubscribeAfterError(S, _), !Sl.call(v, "graphQLErrors"))
        throw v;
      var O = t.current;
      (!O || O && O.loading || !zt(v, O.error)) && Pr({
        data: O && O.data,
        error: v,
        loading: !1,
        networkStatus: ct.error
      }, t, e, n, a, E, l.current);
    }, w = { current: e.subscribe(S, _) };
    return function() {
      setTimeout(function() {
        return w.current.unsubscribe();
      });
    };
  }, [
    i,
    u,
    e,
    t,
    a,
    n
  ]), function() {
    return T || hi(t, e, l.current, a, n);
  }, function() {
    return T || hi(t, e, l.current, a, n);
  });
}
function Il(t, e, n) {
  e && n && (e.registerSSRObservable(t), t.getCurrentResult().loading && e.addObservableQueryPromise(t));
}
function Dl(t, e, n, r, s) {
  var i;
  e[Sn] && !zt(e[Sn], s) && (e.reobserve(Kr(e, n, r, s)), t.previousData = ((i = t.current) === null || i === void 0 ? void 0 : i.data) || t.previousData, t.current = void 0), e[Sn] = s;
}
function Fa(t, e, n, r) {
  n === void 0 && (n = {});
  var s = n.skip;
  n.ssr, n.onCompleted, n.onError;
  var i = n.defaultOptions, a = ta(n, ["skip", "ssr", "onCompleted", "onError", "defaultOptions"]);
  return function(u) {
    var c = Object.assign(a, { query: e });
    return r && (c.fetchPolicy === "network-only" || c.fetchPolicy === "cache-and-network") && (c.fetchPolicy = "cache-first"), c.variables || (c.variables = {}), s ? (c.initialFetchPolicy = c.initialFetchPolicy || c.fetchPolicy || Vr(i, t.defaultOptions), c.fetchPolicy = "standby") : c.fetchPolicy || (c.fetchPolicy = u?.options.initialFetchPolicy || Vr(i, t.defaultOptions)), c;
  };
}
function Kr(t, e, n, r) {
  var s = [], i = e.defaultOptions.watchQuery;
  return i && s.push(i), n.defaultOptions && s.push(n.defaultOptions), s.push(Rr(t && t.options, r)), s.reduce(Dn);
}
function Pr(t, e, n, r, s, i, a) {
  var u = e.current;
  u && u.data && (e.previousData = u.data), !t.error && Sa(t.errors) && (t.error = new Jr({ graphQLErrors: t.errors })), e.current = An(xl(t, n, s), e.previousData, n, r), i(), Cl(t, u?.networkStatus, a);
}
function Cl(t, e, n) {
  if (!t.loading) {
    var r = Al(t);
    Promise.resolve().then(function() {
      r ? n.onError(r) : t.data && e !== t.networkStatus && t.networkStatus === ct.ready && n.onCompleted(t.data);
    }).catch(function(s) {
      globalThis.__DEV__ !== !1 && Ue.warn(s);
    });
  }
}
function hi(t, e, n, r, s) {
  return t.current || Pr(e.getCurrentResult(), t, e, s, r, function() {
  }, n), t.current;
}
function Vr(t, e) {
  var n;
  return t?.fetchPolicy || ((n = e?.watchQuery) === null || n === void 0 ? void 0 : n.fetchPolicy) || "cache-first";
}
function Al(t) {
  return Sa(t.errors) ? new Jr({ graphQLErrors: t.errors }) : t.error;
}
function An(t, e, n, r) {
  var s = t.data;
  t.partial;
  var i = ta(t, ["data", "partial"]), a = X(X({ data: s }, i), { client: r, observable: n, variables: n.variables, called: t !== La && t !== Pa, previousData: e });
  return a;
}
function xl(t, e, n) {
  return t.partial && n && !t.loading && (!t.data || Object.keys(t.data).length === 0) && e.options.fetchPolicy !== "cache-only" ? (e.refetch(), X(X({}, t), { loading: !0, networkStatus: ct.refetch })) : t;
}
var La = _a({
  loading: !0,
  data: void 0,
  error: void 0,
  networkStatus: ct.loading
}), Pa = _a({
  loading: !1,
  data: void 0,
  error: void 0,
  networkStatus: ct.ready
});
function Rl(t) {
  return {
    refetch: t.refetch.bind(t),
    reobserve: t.reobserve.bind(t),
    fetchMore: t.fetchMore.bind(t),
    updateQuery: t.updateQuery.bind(t),
    startPolling: t.startPolling.bind(t),
    stopPolling: t.stopPolling.bind(t),
    subscribeToMore: t.subscribeToMore.bind(t)
  };
}
var Ml = [
  "refetch",
  "reobserve",
  "fetchMore",
  "updateQuery",
  "startPolling",
  "stopPolling",
  "subscribeToMore"
];
function Va(t, e) {
  var n, r = Z.useRef(), s = Z.useRef(), i = Z.useRef(), a = Dn(e, r.current || {}), u = (n = a?.query) !== null && n !== void 0 ? n : t;
  s.current = e, i.current = u;
  var c = X(X({}, a), { skip: !r.current }), l = Ma(u, c), d = l.obsQueryFields, m = l.result, T = l.client, E = l.resultData, S = l.observable, _ = l.onQueryExecuted, w = S.options.initialFetchPolicy || Vr(c.defaultOptions, T.defaultOptions), v = Z.useReducer(function(V) {
    return V + 1;
  }, 0)[1], O = Z.useMemo(function() {
    for (var V = {}, A = function(ze) {
      var Be = d[ze];
      V[ze] = function() {
        return r.current || (r.current = /* @__PURE__ */ Object.create(null), v()), Be.apply(this, arguments);
      };
    }, q = 0, ne = Ml; q < ne.length; q++) {
      var je = ne[q];
      A(je);
    }
    return V;
  }, [v, d]), R = !!r.current, M = Z.useMemo(function() {
    return X(X(X({}, m), O), { called: R });
  }, [m, O, R]), U = Z.useCallback(function(V) {
    r.current = V ? X(X({}, V), { fetchPolicy: V.fetchPolicy || w }) : {
      fetchPolicy: w
    };
    var A = Dn(s.current, X({ query: i.current }, r.current)), q = Fl(E, S, T, u, X(X({}, A), { skip: !1 }), _).then(function(ne) {
      return Object.assign(ne, O);
    });
    return q.catch(function() {
    }), q;
  }, [
    T,
    u,
    O,
    w,
    S,
    E,
    _
  ]), D = Z.useRef(U);
  Ra(function() {
    D.current = U;
  });
  var j = Z.useCallback(function() {
    for (var V = [], A = 0; A < arguments.length; A++)
      V[A] = arguments[A];
    return D.current.apply(D, V);
  }, []);
  return [j, M];
}
function Fl(t, e, n, r, s, i) {
  var a = s.query || r, u = Fa(n, a, s, !1)(e), c = e.reobserveAsConcast(Kr(e, n, s, u));
  return i(u), new Promise(function(l) {
    var d;
    c.subscribe({
      next: function(m) {
        d = m;
      },
      error: function() {
        l(An(e.getCurrentResult(), t.previousData, e, n));
      },
      complete: function() {
        l(An(d, t.previousData, e, n));
      }
    });
  });
}
function lt(t, e) {
  var n = Xr(e?.client);
  xa(t, Pe.Mutation);
  var r = Z.useState({
    called: !1,
    loading: !1,
    client: n
  }), s = r[0], i = r[1], a = Z.useRef({
    result: s,
    mutationId: 0,
    isMounted: !0,
    client: n,
    mutation: t,
    options: e
  });
  Ra(function() {
    Object.assign(a.current, { client: n, options: e, mutation: t });
  });
  var u = Z.useCallback(function(l) {
    l === void 0 && (l = {});
    var d = a.current, m = d.options, T = d.mutation, E = X(X({}, m), { mutation: T }), S = l.client || a.current.client;
    !a.current.result.loading && !E.ignoreResults && a.current.isMounted && i(a.current.result = {
      loading: !0,
      error: void 0,
      data: void 0,
      called: !0,
      client: S
    });
    var _ = ++a.current.mutationId, w = Dn(E, l);
    return S.mutate(w).then(function(v) {
      var O, R, M = v.data, U = v.errors, D = U && U.length > 0 ? new Jr({ graphQLErrors: U }) : void 0, j = l.onError || ((O = a.current.options) === null || O === void 0 ? void 0 : O.onError);
      if (D && j && j(D, w), _ === a.current.mutationId && !w.ignoreResults) {
        var V = {
          called: !0,
          loading: !1,
          data: M,
          error: D,
          client: S
        };
        a.current.isMounted && !zt(a.current.result, V) && i(a.current.result = V);
      }
      var A = l.onCompleted || ((R = a.current.options) === null || R === void 0 ? void 0 : R.onCompleted);
      return D || A?.(v.data, w), v;
    }).catch(function(v) {
      var O;
      if (_ === a.current.mutationId && a.current.isMounted) {
        var R = {
          loading: !1,
          error: v,
          data: void 0,
          called: !0,
          client: S
        };
        zt(a.current.result, R) || i(a.current.result = R);
      }
      var M = l.onError || ((O = a.current.options) === null || O === void 0 ? void 0 : O.onError);
      if (M)
        return M(v, w), { data: void 0, errors: v };
      throw v;
    });
  }, []), c = Z.useCallback(function() {
    if (a.current.isMounted) {
      var l = {
        called: !1,
        loading: !1,
        client: a.current.client
      };
      Object.assign(a.current, { mutationId: 0, result: l }), i(l);
    }
  }, []);
  return Z.useEffect(function() {
    var l = a.current;
    return l.isMounted = !0, function() {
      l.isMounted = !1;
    };
  }, []), [u, X({ reset: c }, s)];
}
const _e = {};
var Qe = /* @__PURE__ */ ((t) => (t.OneShot = "ONE_SHOT", t.DailyOrMore_1d = "DAILY_OR_MORE_1d", t.DailyOrMore_2d = "DAILY_OR_MORE_2d", t.DailyOrMore_3d = "DAILY_OR_MORE_3d", t.LessThanDaily_1w = "LESS_THAN_DAILY_1w", t.LessThanDaily_1m = "LESS_THAN_DAILY_1m", t.LessThanDaily_1q = "LESS_THAN_DAILY_1q", t))(Qe || {}), Ll = /* @__PURE__ */ ((t) => (t.Astro = "Astro", t.Sub = "Sub", t.Atom = "Atom", t))(Ll || {});
const Pl = ye`
    query getOrbit($id: ID!) {
  orbit(id: $id) {
    id
    eH
    name
    sphereHash
    frequency
    scale
    parentHash
    metadata {
      description
      timeframe {
        startTime
        endTime
      }
    }
  }
}
    `;
function _p(t) {
  const e = { ..._e, ...t };
  return Gt(Pl, e);
}
const Vl = ye`
    query getOrbits($sphereEntryHashB64: String) {
  orbits(sphereEntryHashB64: $sphereEntryHashB64) {
    edges {
      node {
        id
        eH
        name
        sphereHash
        parentHash
        frequency
        scale
        metadata {
          description
          timeframe {
            startTime
            endTime
          }
        }
      }
    }
  }
}
    `;
function kp(t) {
  const e = { ..._e, ...t };
  return Gt(Vl, e);
}
const Wl = ye`
    query getLowestSphereHierarchyLevel($sphereEntryHashB64: String!) {
  getLowestSphereHierarchyLevel(sphereEntryHashB64: $sphereEntryHashB64)
}
    `;
function Np(t) {
  const e = { ..._e, ...t };
  return Gt(Wl, e);
}
const Ul = ye`
    query getSphere($id: ID!) {
  sphere(id: $id) {
    id
    eH
    name
    metadata {
      description
      image
    }
  }
}
    `;
function Ip(t) {
  const e = { ..._e, ...t };
  return Gt(Ul, e);
}
const $l = ye`
    query getSpheres {
  spheres {
    edges {
      node {
        id
        eH
        name
        metadata {
          description
          image
        }
      }
    }
  }
}
    `;
function Dp(t) {
  const e = { ..._e, ...t };
  return Gt($l, e);
}
const Hl = ye`
    query getWinRecordForOrbitForMonth($params: OrbitWinRecordQueryParams!) {
  getWinRecordForOrbitForMonth(params: $params) {
    id
    eH
    winData {
      date
      value {
        ... on SingleWin {
          single
        }
        ... on MultipleWins {
          multiple
        }
      }
    }
  }
}
    `;
function Cp(t) {
  const e = { ..._e, ...t };
  return Va(Hl, e);
}
const jl = ye`
    mutation createOrbit($variables: OrbitCreateParams!) {
  createOrbit(orbit: $variables) {
    id
    eH
    name
    parentHash
    sphereHash
    scale
    frequency
    metadata {
      description
      timeframe {
        startTime
        endTime
      }
    }
  }
}
    `;
function Ap(t) {
  const e = { ..._e, ...t };
  return lt(jl, e);
}
const zl = ye`
    mutation deleteOrbit($id: ID!) {
  deleteOrbit(orbitHash: $id)
}
    `;
function xp(t) {
  const e = { ..._e, ...t };
  return lt(zl, e);
}
const Bl = ye`
    query getOrbitHierarchy($params: OrbitHierarchyQueryParams!) {
  getOrbitHierarchy(params: $params)
}
    `;
function Rp(t) {
  const e = { ..._e, ...t };
  return Va(Bl, e);
}
const Yl = ye`
    mutation updateOrbit($orbitFields: OrbitUpdateParams!) {
  updateOrbit(orbit: $orbitFields) {
    id
    eH
    name
    parentHash
    sphereHash
    scale
    frequency
    metadata {
      description
      timeframe {
        startTime
        endTime
      }
    }
  }
}
    `;
function Mp(t) {
  const e = { ..._e, ...t };
  return lt(Yl, e);
}
const ql = ye`
    mutation createSphere($variables: SphereCreateParams!) {
  createSphere(sphere: $variables) {
    actionHash
    entryHash
    name
    spin
  }
}
    `;
function Fp(t) {
  const e = { ..._e, ...t };
  return lt(ql, e);
}
const Gl = ye`
    mutation deleteSphere($id: ID!) {
  deleteSphere(sphereHash: $id)
}
    `;
function Lp(t) {
  const e = { ..._e, ...t };
  return lt(Gl, e);
}
const Zl = ye`
    mutation updateSphere($sphere: SphereUpdateParams!) {
  updateSphere(sphere: $sphere) {
    actionHash
    entryHash
  }
}
    `;
function Pp(t) {
  const e = { ..._e, ...t };
  return lt(Zl, e);
}
const Ql = ye`
    mutation createWinRecord($winRecord: WinRecordCreateParams!) {
  createWinRecord(winRecord: $winRecord) {
    id
    eH
    winData {
      date
      value {
        ... on SingleWin {
          single
        }
        ... on MultipleWins {
          multiple
        }
      }
    }
  }
}
    `;
function Vp(t) {
  const e = { ..._e, ...t };
  return lt(Ql, e);
}
ye`
    mutation updateWinRecord($winRecord: WinRecordUpdateParams!) {
  updateWinRecord(winRecord: $winRecord) {
    id
    eH
    orbitId
    winData {
      date
      value {
        ... on SingleWin {
          single
        }
        ... on MultipleWins {
          multiple
        }
      }
    }
  }
}
    `;
const Re = { BASE_URL: "/", DEV: !1, MODE: "production", PROD: !0, SSR: !1, VITE_ADMIN_PORT: "9001", VITE_APP_PORT: "9000", VITE_UI_PORT: "8888" };
let Jl = 0;
function C(t, e) {
  const n = `atom${++Jl}`, r = {
    toString() {
      return (Re ? "production" : void 0) !== "production" && this.debugLabel ? n + ":" + this.debugLabel : n;
    }
  };
  return typeof t == "function" ? r.read = t : (r.init = t, r.read = Xl, r.write = Kl), e && (r.write = e), r;
}
function Xl(t) {
  return t(this);
}
function Kl(t, e, n) {
  return e(
    this,
    typeof n == "function" ? n(t(this)) : n
  );
}
const pi = (t, e) => t.unstable_is ? t.unstable_is(e) : e === t, lr = (t) => "init" in t, fr = (t) => !!t.write, xn = /* @__PURE__ */ new WeakMap(), Wr = (t) => {
  var e;
  return Ur(t) && !((e = xn.get(t)) != null && e[1]);
}, ef = (t, e) => {
  const n = xn.get(t);
  if (n)
    n[1] = !0, n[0].forEach((r) => r(e));
  else if ((Re ? "production" : void 0) !== "production")
    throw new Error("[Bug] cancelable promise not found");
}, tf = (t) => {
  if (xn.has(t))
    return;
  const e = [/* @__PURE__ */ new Set(), !1];
  xn.set(t, e);
  const n = () => {
    e[1] = !0;
  };
  t.then(n, n), t.onCancel = (r) => {
    e[0].add(r);
  };
}, Ur = (t) => typeof t?.then == "function", mi = (t) => "v" in t || "e" in t, yn = (t) => {
  if ("e" in t)
    throw t.e;
  if ((Re ? "production" : void 0) !== "production" && !("v" in t))
    throw new Error("[Bug] atom state is not initialized");
  return t.v;
}, Wa = (t, e, n) => {
  n.p.has(t) || (n.p.add(t), e.then(
    () => {
      n.p.delete(t);
    },
    () => {
      n.p.delete(t);
    }
  ));
}, yi = (t, e, n, r, s) => {
  var i;
  if ((Re ? "production" : void 0) !== "production" && r === e)
    throw new Error("[Bug] atom cannot depend on itself");
  n.d.set(r, s.n), Wr(n.v) && Wa(e, n.v, s), (i = s.m) == null || i.t.add(e), t && nf(t, r, e);
}, yt = () => [/* @__PURE__ */ new Map(), /* @__PURE__ */ new Map(), /* @__PURE__ */ new Set()], dr = (t, e, n) => {
  t[0].has(e) || t[0].set(e, /* @__PURE__ */ new Set()), t[1].set(e, n);
}, nf = (t, e, n) => {
  const r = t[0].get(e);
  r && r.add(n);
}, rf = (t, e) => t[0].get(e), vi = (t, e) => {
  t[2].add(e);
}, tt = (t) => {
  for (; t[1].size || t[2].size; ) {
    t[0].clear();
    const e = new Set(t[1].values());
    t[1].clear();
    const n = new Set(t[2]);
    t[2].clear(), e.forEach((r) => {
      var s;
      return (s = r.m) == null ? void 0 : s.l.forEach((i) => i());
    }), n.forEach((r) => r());
  }
}, Ua = (t) => {
  let e;
  (Re ? "production" : void 0) !== "production" && (e = /* @__PURE__ */ new Set());
  const n = (_, w, v) => {
    const O = "v" in w, R = w.v, M = Wr(w.v) ? w.v : null;
    if (Ur(v)) {
      tf(v);
      for (const U of w.d.keys())
        Wa(
          _,
          v,
          t(U, w)
        );
      w.v = v, delete w.e;
    } else
      w.v = v, delete w.e;
    (!O || !Object.is(R, w.v)) && (++w.n, M && ef(M, v));
  }, r = (_, w, v, O) => {
    var R;
    if (mi(v) && (v.m && !O?.has(w) || Array.from(v.d).every(
      ([A, q]) => (
        // Recursively, read the atom state of the dependency, and
        // check if the atom epoch number is unchanged
        r(_, A, t(A, v), O).n === q
      )
    )))
      return v;
    v.d.clear();
    let M = !0;
    const U = (A) => {
      if (pi(w, A)) {
        const ne = t(A, v);
        if (!mi(ne))
          if (lr(A))
            n(A, ne, A.init);
          else
            throw new Error("no atom init");
        return yn(ne);
      }
      const q = r(
        _,
        A,
        t(A, v),
        O
      );
      if (M)
        yi(_, w, v, A, q);
      else {
        const ne = yt();
        yi(ne, w, v, A, q), l(ne, w, v), tt(ne);
      }
      return yn(q);
    };
    let D, j;
    const V = {
      get signal() {
        return D || (D = new AbortController()), D.signal;
      },
      get setSelf() {
        return (Re ? "production" : void 0) !== "production" && !fr(w) && console.warn("setSelf function cannot be used with read-only atom"), !j && fr(w) && (j = (...A) => {
          if ((Re ? "production" : void 0) !== "production" && M && console.warn("setSelf function cannot be called in sync"), !M)
            return c(w, ...A);
        }), j;
      }
    };
    try {
      const A = w.read(U, V);
      if (n(w, v, A), Ur(A)) {
        (R = A.onCancel) == null || R.call(A, () => D?.abort());
        const q = () => {
          if (v.m) {
            const ne = yt();
            l(ne, w, v), tt(ne);
          }
        };
        A.then(q, q);
      }
      return v;
    } catch (A) {
      return delete v.v, v.e = A, ++v.n, v;
    } finally {
      M = !1;
    }
  }, s = (_) => yn(r(void 0, _, t(_))), i = (_, w, v) => {
    var O, R;
    const M = /* @__PURE__ */ new Map();
    for (const U of ((O = v.m) == null ? void 0 : O.t) || [])
      M.set(U, t(U, v));
    for (const U of v.p)
      M.set(
        U,
        t(U, v)
      );
    return (R = rf(_, w)) == null || R.forEach((U) => {
      M.set(U, t(U, v));
    }), M;
  }, a = (_, w, v) => {
    const O = [], R = /* @__PURE__ */ new Set(), M = (D, j) => {
      if (!R.has(D)) {
        R.add(D);
        for (const [V, A] of i(_, D, j))
          D !== V && M(V, A);
        O.push([D, j, j.n]);
      }
    };
    M(w, v);
    const U = /* @__PURE__ */ new Set([w]);
    for (let D = O.length - 1; D >= 0; --D) {
      const [j, V, A] = O[D];
      let q = !1;
      for (const ne of V.d.keys())
        if (ne !== j && U.has(ne)) {
          q = !0;
          break;
        }
      q && (r(_, j, V, R), l(_, j, V), A !== V.n && (dr(_, j, V), U.add(j))), R.delete(j);
    }
  }, u = (_, w, v, ...O) => {
    const R = (D) => yn(r(_, D, t(D, v))), M = (D, ...j) => {
      const V = t(D, v);
      let A;
      if (pi(w, D)) {
        if (!lr(D))
          throw new Error("atom not writable");
        const q = "v" in V, ne = V.v, je = j[0];
        n(D, V, je), l(_, D, V), (!q || !Object.is(ne, V.v)) && (dr(_, D, V), a(_, D, V));
      } else
        A = u(_, D, V, ...j);
      return tt(_), A;
    };
    return w.write(R, M, ...O);
  }, c = (_, ...w) => {
    const v = yt(), O = u(v, _, t(_), ...w);
    return tt(v), O;
  }, l = (_, w, v) => {
    if (v.m && !Wr(v.v)) {
      for (const O of v.d.keys())
        v.m.d.has(O) || (d(_, O, t(O, v)).t.add(w), v.m.d.add(O));
      for (const O of v.m.d || [])
        if (!v.d.has(O)) {
          v.m.d.delete(O);
          const R = m(_, O, t(O, v));
          R?.t.delete(w);
        }
    }
  }, d = (_, w, v) => {
    if (!v.m) {
      r(_, w, v);
      for (const O of v.d.keys())
        d(_, O, t(O, v)).t.add(w);
      if (v.m = {
        l: /* @__PURE__ */ new Set(),
        d: new Set(v.d.keys()),
        t: /* @__PURE__ */ new Set()
      }, (Re ? "production" : void 0) !== "production" && e.add(w), fr(w) && w.onMount) {
        const O = v.m, { onMount: R } = w;
        vi(_, () => {
          const M = R(
            (...U) => u(_, w, v, ...U)
          );
          M && (O.u = M);
        });
      }
    }
    return v.m;
  }, m = (_, w, v) => {
    if (v.m && !v.m.l.size && !Array.from(v.m.t).some(
      (O) => {
        var R;
        return (R = t(O, v).m) == null ? void 0 : R.d.has(w);
      }
    )) {
      const O = v.m.u;
      O && vi(_, O), delete v.m, (Re ? "production" : void 0) !== "production" && e.delete(w);
      for (const R of v.d.keys()) {
        const M = m(_, R, t(R, v));
        M?.t.delete(w);
      }
      return;
    }
    return v.m;
  }, S = {
    get: s,
    set: c,
    sub: (_, w) => {
      const v = yt(), O = t(_), R = d(v, _, O);
      tt(v);
      const M = R.l;
      return M.add(w), () => {
        M.delete(w);
        const U = yt();
        m(U, _, O), tt(U);
      };
    },
    unstable_derive: (_) => Ua(..._(t))
  };
  return (Re ? "production" : void 0) !== "production" && Object.assign(S, {
    // store dev methods (these are tentative and subject to change without notice)
    dev4_get_internal_weak_map: () => ({
      get: (w) => {
        const v = t(w);
        if (v.n !== 0)
          return v;
      }
    }),
    dev4_get_mounted_atoms: () => e,
    dev4_restore_atoms: (w) => {
      const v = yt();
      for (const [O, R] of w)
        if (lr(O)) {
          const M = t(O), U = "v" in M, D = M.v;
          n(O, M, R), l(v, O, M), (!U || !Object.is(D, M.v)) && (dr(v, O, M), a(v, O, M));
        }
      tt(v);
    }
  }), S;
}, $a = () => {
  const t = /* @__PURE__ */ new WeakMap();
  return Ua((n) => {
    let r = t.get(n);
    return r || (r = { d: /* @__PURE__ */ new Map(), p: /* @__PURE__ */ new Set(), n: 0 }, t.set(n, r)), r;
  });
};
let Lt;
const Wp = () => (Lt || (Lt = $a(), (Re ? "production" : void 0) !== "production" && (globalThis.__JOTAI_DEFAULT_STORE__ || (globalThis.__JOTAI_DEFAULT_STORE__ = Lt), globalThis.__JOTAI_DEFAULT_STORE__ !== Lt && console.warn(
  "Detected multiple Jotai instances. It may cause unexpected behavior with the default store. https://github.com/pmndrs/jotai/discussions/2044"
))), Lt);
class ft extends Error {
}
class sf extends ft {
  constructor(e) {
    super(`Invalid DateTime: ${e.toMessage()}`);
  }
}
class af extends ft {
  constructor(e) {
    super(`Invalid Interval: ${e.toMessage()}`);
  }
}
class of extends ft {
  constructor(e) {
    super(`Invalid Duration: ${e.toMessage()}`);
  }
}
class Ot extends ft {
}
class Ha extends ft {
  constructor(e) {
    super(`Invalid unit ${e}`);
  }
}
class we extends ft {
}
class Ge extends ft {
  constructor() {
    super("Zone is an abstract class");
  }
}
const N = "numeric", Fe = "short", ke = "long", Rn = {
  year: N,
  month: N,
  day: N
}, ja = {
  year: N,
  month: Fe,
  day: N
}, uf = {
  year: N,
  month: Fe,
  day: N,
  weekday: Fe
}, za = {
  year: N,
  month: ke,
  day: N
}, Ba = {
  year: N,
  month: ke,
  day: N,
  weekday: ke
}, Ya = {
  hour: N,
  minute: N
}, qa = {
  hour: N,
  minute: N,
  second: N
}, Ga = {
  hour: N,
  minute: N,
  second: N,
  timeZoneName: Fe
}, Za = {
  hour: N,
  minute: N,
  second: N,
  timeZoneName: ke
}, Qa = {
  hour: N,
  minute: N,
  hourCycle: "h23"
}, Ja = {
  hour: N,
  minute: N,
  second: N,
  hourCycle: "h23"
}, Xa = {
  hour: N,
  minute: N,
  second: N,
  hourCycle: "h23",
  timeZoneName: Fe
}, Ka = {
  hour: N,
  minute: N,
  second: N,
  hourCycle: "h23",
  timeZoneName: ke
}, eo = {
  year: N,
  month: N,
  day: N,
  hour: N,
  minute: N
}, to = {
  year: N,
  month: N,
  day: N,
  hour: N,
  minute: N,
  second: N
}, no = {
  year: N,
  month: Fe,
  day: N,
  hour: N,
  minute: N
}, ro = {
  year: N,
  month: Fe,
  day: N,
  hour: N,
  minute: N,
  second: N
}, cf = {
  year: N,
  month: Fe,
  day: N,
  weekday: Fe,
  hour: N,
  minute: N
}, so = {
  year: N,
  month: ke,
  day: N,
  hour: N,
  minute: N,
  timeZoneName: Fe
}, io = {
  year: N,
  month: ke,
  day: N,
  hour: N,
  minute: N,
  second: N,
  timeZoneName: Fe
}, ao = {
  year: N,
  month: ke,
  day: N,
  weekday: ke,
  hour: N,
  minute: N,
  timeZoneName: ke
}, oo = {
  year: N,
  month: ke,
  day: N,
  weekday: ke,
  hour: N,
  minute: N,
  second: N,
  timeZoneName: ke
};
class Zt {
  /**
   * The type of zone
   * @abstract
   * @type {string}
   */
  get type() {
    throw new Ge();
  }
  /**
   * The name of this zone.
   * @abstract
   * @type {string}
   */
  get name() {
    throw new Ge();
  }
  /**
   * The IANA name of this zone.
   * Defaults to `name` if not overwritten by a subclass.
   * @abstract
   * @type {string}
   */
  get ianaName() {
    return this.name;
  }
  /**
   * Returns whether the offset is known to be fixed for the whole year.
   * @abstract
   * @type {boolean}
   */
  get isUniversal() {
    throw new Ge();
  }
  /**
   * Returns the offset's common name (such as EST) at the specified timestamp
   * @abstract
   * @param {number} ts - Epoch milliseconds for which to get the name
   * @param {Object} opts - Options to affect the format
   * @param {string} opts.format - What style of offset to return. Accepts 'long' or 'short'.
   * @param {string} opts.locale - What locale to return the offset name in.
   * @return {string}
   */
  offsetName(e, n) {
    throw new Ge();
  }
  /**
   * Returns the offset's value as a string
   * @abstract
   * @param {number} ts - Epoch milliseconds for which to get the offset
   * @param {string} format - What style of offset to return.
   *                          Accepts 'narrow', 'short', or 'techie'. Returning '+6', '+06:00', or '+0600' respectively
   * @return {string}
   */
  formatOffset(e, n) {
    throw new Ge();
  }
  /**
   * Return the offset in minutes for this zone at the specified timestamp.
   * @abstract
   * @param {number} ts - Epoch milliseconds for which to compute the offset
   * @return {number}
   */
  offset(e) {
    throw new Ge();
  }
  /**
   * Return whether this Zone is equal to another zone
   * @abstract
   * @param {Zone} otherZone - the zone to compare
   * @return {boolean}
   */
  equals(e) {
    throw new Ge();
  }
  /**
   * Return whether this Zone is valid.
   * @abstract
   * @type {boolean}
   */
  get isValid() {
    throw new Ge();
  }
}
let hr = null;
class Un extends Zt {
  /**
   * Get a singleton instance of the local zone
   * @return {SystemZone}
   */
  static get instance() {
    return hr === null && (hr = new Un()), hr;
  }
  /** @override **/
  get type() {
    return "system";
  }
  /** @override **/
  get name() {
    return new Intl.DateTimeFormat().resolvedOptions().timeZone;
  }
  /** @override **/
  get isUniversal() {
    return !1;
  }
  /** @override **/
  offsetName(e, { format: n, locale: r }) {
    return vo(e, n, r);
  }
  /** @override **/
  formatOffset(e, n) {
    return Ht(this.offset(e), n);
  }
  /** @override **/
  offset(e) {
    return -new Date(e).getTimezoneOffset();
  }
  /** @override **/
  equals(e) {
    return e.type === "system";
  }
  /** @override **/
  get isValid() {
    return !0;
  }
}
let _n = {};
function lf(t) {
  return _n[t] || (_n[t] = new Intl.DateTimeFormat("en-US", {
    hour12: !1,
    timeZone: t,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    era: "short"
  })), _n[t];
}
const ff = {
  year: 0,
  month: 1,
  day: 2,
  era: 3,
  hour: 4,
  minute: 5,
  second: 6
};
function df(t, e) {
  const n = t.format(e).replace(/\u200E/g, ""), r = /(\d+)\/(\d+)\/(\d+) (AD|BC),? (\d+):(\d+):(\d+)/.exec(n), [, s, i, a, u, c, l, d] = r;
  return [a, s, i, u, c, l, d];
}
function hf(t, e) {
  const n = t.formatToParts(e), r = [];
  for (let s = 0; s < n.length; s++) {
    const { type: i, value: a } = n[s], u = ff[i];
    i === "era" ? r[u] = a : P(u) || (r[u] = parseInt(a, 10));
  }
  return r;
}
let vn = {};
class $e extends Zt {
  /**
   * @param {string} name - Zone name
   * @return {IANAZone}
   */
  static create(e) {
    return vn[e] || (vn[e] = new $e(e)), vn[e];
  }
  /**
   * Reset local caches. Should only be necessary in testing scenarios.
   * @return {void}
   */
  static resetCache() {
    vn = {}, _n = {};
  }
  /**
   * Returns whether the provided string is a valid specifier. This only checks the string's format, not that the specifier identifies a known zone; see isValidZone for that.
   * @param {string} s - The string to check validity on
   * @example IANAZone.isValidSpecifier("America/New_York") //=> true
   * @example IANAZone.isValidSpecifier("Sport~~blorp") //=> false
   * @deprecated For backward compatibility, this forwards to isValidZone, better use `isValidZone()` directly instead.
   * @return {boolean}
   */
  static isValidSpecifier(e) {
    return this.isValidZone(e);
  }
  /**
   * Returns whether the provided string identifies a real zone
   * @param {string} zone - The string to check
   * @example IANAZone.isValidZone("America/New_York") //=> true
   * @example IANAZone.isValidZone("Fantasia/Castle") //=> false
   * @example IANAZone.isValidZone("Sport~~blorp") //=> false
   * @return {boolean}
   */
  static isValidZone(e) {
    if (!e)
      return !1;
    try {
      return new Intl.DateTimeFormat("en-US", { timeZone: e }).format(), !0;
    } catch {
      return !1;
    }
  }
  constructor(e) {
    super(), this.zoneName = e, this.valid = $e.isValidZone(e);
  }
  /**
   * The type of zone. `iana` for all instances of `IANAZone`.
   * @override
   * @type {string}
   */
  get type() {
    return "iana";
  }
  /**
   * The name of this zone (i.e. the IANA zone name).
   * @override
   * @type {string}
   */
  get name() {
    return this.zoneName;
  }
  /**
   * Returns whether the offset is known to be fixed for the whole year:
   * Always returns false for all IANA zones.
   * @override
   * @type {boolean}
   */
  get isUniversal() {
    return !1;
  }
  /**
   * Returns the offset's common name (such as EST) at the specified timestamp
   * @override
   * @param {number} ts - Epoch milliseconds for which to get the name
   * @param {Object} opts - Options to affect the format
   * @param {string} opts.format - What style of offset to return. Accepts 'long' or 'short'.
   * @param {string} opts.locale - What locale to return the offset name in.
   * @return {string}
   */
  offsetName(e, { format: n, locale: r }) {
    return vo(e, n, r, this.name);
  }
  /**
   * Returns the offset's value as a string
   * @override
   * @param {number} ts - Epoch milliseconds for which to get the offset
   * @param {string} format - What style of offset to return.
   *                          Accepts 'narrow', 'short', or 'techie'. Returning '+6', '+06:00', or '+0600' respectively
   * @return {string}
   */
  formatOffset(e, n) {
    return Ht(this.offset(e), n);
  }
  /**
   * Return the offset in minutes for this zone at the specified timestamp.
   * @override
   * @param {number} ts - Epoch milliseconds for which to compute the offset
   * @return {number}
   */
  offset(e) {
    const n = new Date(e);
    if (isNaN(n)) return NaN;
    const r = lf(this.name);
    let [s, i, a, u, c, l, d] = r.formatToParts ? hf(r, n) : df(r, n);
    u === "BC" && (s = -Math.abs(s) + 1);
    const T = Hn({
      year: s,
      month: i,
      day: a,
      hour: c === 24 ? 0 : c,
      minute: l,
      second: d,
      millisecond: 0
    });
    let E = +n;
    const S = E % 1e3;
    return E -= S >= 0 ? S : 1e3 + S, (T - E) / (60 * 1e3);
  }
  /**
   * Return whether this Zone is equal to another zone
   * @override
   * @param {Zone} otherZone - the zone to compare
   * @return {boolean}
   */
  equals(e) {
    return e.type === "iana" && e.name === this.name;
  }
  /**
   * Return whether this Zone is valid.
   * @override
   * @type {boolean}
   */
  get isValid() {
    return this.valid;
  }
}
let gi = {};
function pf(t, e = {}) {
  const n = JSON.stringify([t, e]);
  let r = gi[n];
  return r || (r = new Intl.ListFormat(t, e), gi[n] = r), r;
}
let $r = {};
function Hr(t, e = {}) {
  const n = JSON.stringify([t, e]);
  let r = $r[n];
  return r || (r = new Intl.DateTimeFormat(t, e), $r[n] = r), r;
}
let jr = {};
function mf(t, e = {}) {
  const n = JSON.stringify([t, e]);
  let r = jr[n];
  return r || (r = new Intl.NumberFormat(t, e), jr[n] = r), r;
}
let zr = {};
function yf(t, e = {}) {
  const { base: n, ...r } = e, s = JSON.stringify([t, r]);
  let i = zr[s];
  return i || (i = new Intl.RelativeTimeFormat(t, e), zr[s] = i), i;
}
let Ut = null;
function vf() {
  return Ut || (Ut = new Intl.DateTimeFormat().resolvedOptions().locale, Ut);
}
let Ei = {};
function gf(t) {
  let e = Ei[t];
  if (!e) {
    const n = new Intl.Locale(t);
    e = "getWeekInfo" in n ? n.getWeekInfo() : n.weekInfo, Ei[t] = e;
  }
  return e;
}
function Ef(t) {
  const e = t.indexOf("-x-");
  e !== -1 && (t = t.substring(0, e));
  const n = t.indexOf("-u-");
  if (n === -1)
    return [t];
  {
    let r, s;
    try {
      r = Hr(t).resolvedOptions(), s = t;
    } catch {
      const c = t.substring(0, n);
      r = Hr(c).resolvedOptions(), s = c;
    }
    const { numberingSystem: i, calendar: a } = r;
    return [s, i, a];
  }
}
function wf(t, e, n) {
  return (n || e) && (t.includes("-u-") || (t += "-u"), n && (t += `-ca-${n}`), e && (t += `-nu-${e}`)), t;
}
function bf(t) {
  const e = [];
  for (let n = 1; n <= 12; n++) {
    const r = x.utc(2009, n, 1);
    e.push(t(r));
  }
  return e;
}
function Of(t) {
  const e = [];
  for (let n = 1; n <= 7; n++) {
    const r = x.utc(2016, 11, 13 + n);
    e.push(t(r));
  }
  return e;
}
function gn(t, e, n, r) {
  const s = t.listingMode();
  return s === "error" ? null : s === "en" ? n(e) : r(e);
}
function Tf(t) {
  return t.numberingSystem && t.numberingSystem !== "latn" ? !1 : t.numberingSystem === "latn" || !t.locale || t.locale.startsWith("en") || new Intl.DateTimeFormat(t.intl).resolvedOptions().numberingSystem === "latn";
}
class Sf {
  constructor(e, n, r) {
    this.padTo = r.padTo || 0, this.floor = r.floor || !1;
    const { padTo: s, floor: i, ...a } = r;
    if (!n || Object.keys(a).length > 0) {
      const u = { useGrouping: !1, ...r };
      r.padTo > 0 && (u.minimumIntegerDigits = r.padTo), this.inf = mf(e, u);
    }
  }
  format(e) {
    if (this.inf) {
      const n = this.floor ? Math.floor(e) : e;
      return this.inf.format(n);
    } else {
      const n = this.floor ? Math.floor(e) : ss(e, 3);
      return me(n, this.padTo);
    }
  }
}
class _f {
  constructor(e, n, r) {
    this.opts = r, this.originalZone = void 0;
    let s;
    if (this.opts.timeZone)
      this.dt = e;
    else if (e.zone.type === "fixed") {
      const a = -1 * (e.offset / 60), u = a >= 0 ? `Etc/GMT+${a}` : `Etc/GMT${a}`;
      e.offset !== 0 && $e.create(u).valid ? (s = u, this.dt = e) : (s = "UTC", this.dt = e.offset === 0 ? e : e.setZone("UTC").plus({ minutes: e.offset }), this.originalZone = e.zone);
    } else e.zone.type === "system" ? this.dt = e : e.zone.type === "iana" ? (this.dt = e, s = e.zone.name) : (s = "UTC", this.dt = e.setZone("UTC").plus({ minutes: e.offset }), this.originalZone = e.zone);
    const i = { ...this.opts };
    i.timeZone = i.timeZone || s, this.dtf = Hr(n, i);
  }
  format() {
    return this.originalZone ? this.formatToParts().map(({ value: e }) => e).join("") : this.dtf.format(this.dt.toJSDate());
  }
  formatToParts() {
    const e = this.dtf.formatToParts(this.dt.toJSDate());
    return this.originalZone ? e.map((n) => {
      if (n.type === "timeZoneName") {
        const r = this.originalZone.offsetName(this.dt.ts, {
          locale: this.dt.locale,
          format: this.opts.timeZoneName
        });
        return {
          ...n,
          value: r
        };
      } else
        return n;
    }) : e;
  }
  resolvedOptions() {
    return this.dtf.resolvedOptions();
  }
}
class kf {
  constructor(e, n, r) {
    this.opts = { style: "long", ...r }, !n && mo() && (this.rtf = yf(e, r));
  }
  format(e, n) {
    return this.rtf ? this.rtf.format(e, n) : Zf(n, e, this.opts.numeric, this.opts.style !== "long");
  }
  formatToParts(e, n) {
    return this.rtf ? this.rtf.formatToParts(e, n) : [];
  }
}
const Nf = {
  firstDay: 1,
  minimalDays: 4,
  weekend: [6, 7]
};
class K {
  static fromOpts(e) {
    return K.create(
      e.locale,
      e.numberingSystem,
      e.outputCalendar,
      e.weekSettings,
      e.defaultToEN
    );
  }
  static create(e, n, r, s, i = !1) {
    const a = e || fe.defaultLocale, u = a || (i ? "en-US" : vf()), c = n || fe.defaultNumberingSystem, l = r || fe.defaultOutputCalendar, d = Br(s) || fe.defaultWeekSettings;
    return new K(u, c, l, d, a);
  }
  static resetCache() {
    Ut = null, $r = {}, jr = {}, zr = {};
  }
  static fromObject({ locale: e, numberingSystem: n, outputCalendar: r, weekSettings: s } = {}) {
    return K.create(e, n, r, s);
  }
  constructor(e, n, r, s, i) {
    const [a, u, c] = Ef(e);
    this.locale = a, this.numberingSystem = n || u || null, this.outputCalendar = r || c || null, this.weekSettings = s, this.intl = wf(this.locale, this.numberingSystem, this.outputCalendar), this.weekdaysCache = { format: {}, standalone: {} }, this.monthsCache = { format: {}, standalone: {} }, this.meridiemCache = null, this.eraCache = {}, this.specifiedLocale = i, this.fastNumbersCached = null;
  }
  get fastNumbers() {
    return this.fastNumbersCached == null && (this.fastNumbersCached = Tf(this)), this.fastNumbersCached;
  }
  listingMode() {
    const e = this.isEnglish(), n = (this.numberingSystem === null || this.numberingSystem === "latn") && (this.outputCalendar === null || this.outputCalendar === "gregory");
    return e && n ? "en" : "intl";
  }
  clone(e) {
    return !e || Object.getOwnPropertyNames(e).length === 0 ? this : K.create(
      e.locale || this.specifiedLocale,
      e.numberingSystem || this.numberingSystem,
      e.outputCalendar || this.outputCalendar,
      Br(e.weekSettings) || this.weekSettings,
      e.defaultToEN || !1
    );
  }
  redefaultToEN(e = {}) {
    return this.clone({ ...e, defaultToEN: !0 });
  }
  redefaultToSystem(e = {}) {
    return this.clone({ ...e, defaultToEN: !1 });
  }
  months(e, n = !1) {
    return gn(this, e, wo, () => {
      const r = n ? { month: e, day: "numeric" } : { month: e }, s = n ? "format" : "standalone";
      return this.monthsCache[s][e] || (this.monthsCache[s][e] = bf((i) => this.extract(i, r, "month"))), this.monthsCache[s][e];
    });
  }
  weekdays(e, n = !1) {
    return gn(this, e, To, () => {
      const r = n ? { weekday: e, year: "numeric", month: "long", day: "numeric" } : { weekday: e }, s = n ? "format" : "standalone";
      return this.weekdaysCache[s][e] || (this.weekdaysCache[s][e] = Of(
        (i) => this.extract(i, r, "weekday")
      )), this.weekdaysCache[s][e];
    });
  }
  meridiems() {
    return gn(
      this,
      void 0,
      () => So,
      () => {
        if (!this.meridiemCache) {
          const e = { hour: "numeric", hourCycle: "h12" };
          this.meridiemCache = [x.utc(2016, 11, 13, 9), x.utc(2016, 11, 13, 19)].map(
            (n) => this.extract(n, e, "dayperiod")
          );
        }
        return this.meridiemCache;
      }
    );
  }
  eras(e) {
    return gn(this, e, _o, () => {
      const n = { era: e };
      return this.eraCache[e] || (this.eraCache[e] = [x.utc(-40, 1, 1), x.utc(2017, 1, 1)].map(
        (r) => this.extract(r, n, "era")
      )), this.eraCache[e];
    });
  }
  extract(e, n, r) {
    const s = this.dtFormatter(e, n), i = s.formatToParts(), a = i.find((u) => u.type.toLowerCase() === r);
    return a ? a.value : null;
  }
  numberFormatter(e = {}) {
    return new Sf(this.intl, e.forceSimple || this.fastNumbers, e);
  }
  dtFormatter(e, n = {}) {
    return new _f(e, this.intl, n);
  }
  relFormatter(e = {}) {
    return new kf(this.intl, this.isEnglish(), e);
  }
  listFormatter(e = {}) {
    return pf(this.intl, e);
  }
  isEnglish() {
    return this.locale === "en" || this.locale.toLowerCase() === "en-us" || new Intl.DateTimeFormat(this.intl).resolvedOptions().locale.startsWith("en-us");
  }
  getWeekSettings() {
    return this.weekSettings ? this.weekSettings : yo() ? gf(this.locale) : Nf;
  }
  getStartOfWeek() {
    return this.getWeekSettings().firstDay;
  }
  getMinDaysInFirstWeek() {
    return this.getWeekSettings().minimalDays;
  }
  getWeekendDays() {
    return this.getWeekSettings().weekend;
  }
  equals(e) {
    return this.locale === e.locale && this.numberingSystem === e.numberingSystem && this.outputCalendar === e.outputCalendar;
  }
  toString() {
    return `Locale(${this.locale}, ${this.numberingSystem}, ${this.outputCalendar})`;
  }
}
let pr = null;
class Se extends Zt {
  /**
   * Get a singleton instance of UTC
   * @return {FixedOffsetZone}
   */
  static get utcInstance() {
    return pr === null && (pr = new Se(0)), pr;
  }
  /**
   * Get an instance with a specified offset
   * @param {number} offset - The offset in minutes
   * @return {FixedOffsetZone}
   */
  static instance(e) {
    return e === 0 ? Se.utcInstance : new Se(e);
  }
  /**
   * Get an instance of FixedOffsetZone from a UTC offset string, like "UTC+6"
   * @param {string} s - The offset string to parse
   * @example FixedOffsetZone.parseSpecifier("UTC+6")
   * @example FixedOffsetZone.parseSpecifier("UTC+06")
   * @example FixedOffsetZone.parseSpecifier("UTC-6:00")
   * @return {FixedOffsetZone}
   */
  static parseSpecifier(e) {
    if (e) {
      const n = e.match(/^utc(?:([+-]\d{1,2})(?::(\d{2}))?)?$/i);
      if (n)
        return new Se(jn(n[1], n[2]));
    }
    return null;
  }
  constructor(e) {
    super(), this.fixed = e;
  }
  /**
   * The type of zone. `fixed` for all instances of `FixedOffsetZone`.
   * @override
   * @type {string}
   */
  get type() {
    return "fixed";
  }
  /**
   * The name of this zone.
   * All fixed zones' names always start with "UTC" (plus optional offset)
   * @override
   * @type {string}
   */
  get name() {
    return this.fixed === 0 ? "UTC" : `UTC${Ht(this.fixed, "narrow")}`;
  }
  /**
   * The IANA name of this zone, i.e. `Etc/UTC` or `Etc/GMT+/-nn`
   *
   * @override
   * @type {string}
   */
  get ianaName() {
    return this.fixed === 0 ? "Etc/UTC" : `Etc/GMT${Ht(-this.fixed, "narrow")}`;
  }
  /**
   * Returns the offset's common name at the specified timestamp.
   *
   * For fixed offset zones this equals to the zone name.
   * @override
   */
  offsetName() {
    return this.name;
  }
  /**
   * Returns the offset's value as a string
   * @override
   * @param {number} ts - Epoch milliseconds for which to get the offset
   * @param {string} format - What style of offset to return.
   *                          Accepts 'narrow', 'short', or 'techie'. Returning '+6', '+06:00', or '+0600' respectively
   * @return {string}
   */
  formatOffset(e, n) {
    return Ht(this.fixed, n);
  }
  /**
   * Returns whether the offset is known to be fixed for the whole year:
   * Always returns true for all fixed offset zones.
   * @override
   * @type {boolean}
   */
  get isUniversal() {
    return !0;
  }
  /**
   * Return the offset in minutes for this zone at the specified timestamp.
   *
   * For fixed offset zones, this is constant and does not depend on a timestamp.
   * @override
   * @return {number}
   */
  offset() {
    return this.fixed;
  }
  /**
   * Return whether this Zone is equal to another zone (i.e. also fixed and same offset)
   * @override
   * @param {Zone} otherZone - the zone to compare
   * @return {boolean}
   */
  equals(e) {
    return e.type === "fixed" && e.fixed === this.fixed;
  }
  /**
   * Return whether this Zone is valid:
   * All fixed offset zones are valid.
   * @override
   * @type {boolean}
   */
  get isValid() {
    return !0;
  }
}
class If extends Zt {
  constructor(e) {
    super(), this.zoneName = e;
  }
  /** @override **/
  get type() {
    return "invalid";
  }
  /** @override **/
  get name() {
    return this.zoneName;
  }
  /** @override **/
  get isUniversal() {
    return !1;
  }
  /** @override **/
  offsetName() {
    return null;
  }
  /** @override **/
  formatOffset() {
    return "";
  }
  /** @override **/
  offset() {
    return NaN;
  }
  /** @override **/
  equals() {
    return !1;
  }
  /** @override **/
  get isValid() {
    return !1;
  }
}
function Ke(t, e) {
  if (P(t) || t === null)
    return e;
  if (t instanceof Zt)
    return t;
  if (Mf(t)) {
    const n = t.toLowerCase();
    return n === "default" ? e : n === "local" || n === "system" ? Un.instance : n === "utc" || n === "gmt" ? Se.utcInstance : Se.parseSpecifier(n) || $e.create(t);
  } else return et(t) ? Se.instance(t) : typeof t == "object" && "offset" in t && typeof t.offset == "function" ? t : new If(t);
}
const es = {
  arab: "[٠-٩]",
  arabext: "[۰-۹]",
  bali: "[᭐-᭙]",
  beng: "[০-৯]",
  deva: "[०-९]",
  fullwide: "[０-９]",
  gujr: "[૦-૯]",
  hanidec: "[〇|一|二|三|四|五|六|七|八|九]",
  khmr: "[០-៩]",
  knda: "[೦-೯]",
  laoo: "[໐-໙]",
  limb: "[᥆-᥏]",
  mlym: "[൦-൯]",
  mong: "[᠐-᠙]",
  mymr: "[၀-၉]",
  orya: "[୦-୯]",
  tamldec: "[௦-௯]",
  telu: "[౦-౯]",
  thai: "[๐-๙]",
  tibt: "[༠-༩]",
  latn: "\\d"
}, wi = {
  arab: [1632, 1641],
  arabext: [1776, 1785],
  bali: [6992, 7001],
  beng: [2534, 2543],
  deva: [2406, 2415],
  fullwide: [65296, 65303],
  gujr: [2790, 2799],
  khmr: [6112, 6121],
  knda: [3302, 3311],
  laoo: [3792, 3801],
  limb: [6470, 6479],
  mlym: [3430, 3439],
  mong: [6160, 6169],
  mymr: [4160, 4169],
  orya: [2918, 2927],
  tamldec: [3046, 3055],
  telu: [3174, 3183],
  thai: [3664, 3673],
  tibt: [3872, 3881]
}, Df = es.hanidec.replace(/[\[|\]]/g, "").split("");
function Cf(t) {
  let e = parseInt(t, 10);
  if (isNaN(e)) {
    e = "";
    for (let n = 0; n < t.length; n++) {
      const r = t.charCodeAt(n);
      if (t[n].search(es.hanidec) !== -1)
        e += Df.indexOf(t[n]);
      else
        for (const s in wi) {
          const [i, a] = wi[s];
          r >= i && r <= a && (e += r - i);
        }
    }
    return parseInt(e, 10);
  } else
    return e;
}
let wt = {};
function Af() {
  wt = {};
}
function Ae({ numberingSystem: t }, e = "") {
  const n = t || "latn";
  return wt[n] || (wt[n] = {}), wt[n][e] || (wt[n][e] = new RegExp(`${es[n]}${e}`)), wt[n][e];
}
let bi = () => Date.now(), Oi = "system", Ti = null, Si = null, _i = null, ki = 60, Ni, Ii = null;
class fe {
  /**
   * Get the callback for returning the current timestamp.
   * @type {function}
   */
  static get now() {
    return bi;
  }
  /**
   * Set the callback for returning the current timestamp.
   * The function should return a number, which will be interpreted as an Epoch millisecond count
   * @type {function}
   * @example Settings.now = () => Date.now() + 3000 // pretend it is 3 seconds in the future
   * @example Settings.now = () => 0 // always pretend it's Jan 1, 1970 at midnight in UTC time
   */
  static set now(e) {
    bi = e;
  }
  /**
   * Set the default time zone to create DateTimes in. Does not affect existing instances.
   * Use the value "system" to reset this value to the system's time zone.
   * @type {string}
   */
  static set defaultZone(e) {
    Oi = e;
  }
  /**
   * Get the default time zone object currently used to create DateTimes. Does not affect existing instances.
   * The default value is the system's time zone (the one set on the machine that runs this code).
   * @type {Zone}
   */
  static get defaultZone() {
    return Ke(Oi, Un.instance);
  }
  /**
   * Get the default locale to create DateTimes with. Does not affect existing instances.
   * @type {string}
   */
  static get defaultLocale() {
    return Ti;
  }
  /**
   * Set the default locale to create DateTimes with. Does not affect existing instances.
   * @type {string}
   */
  static set defaultLocale(e) {
    Ti = e;
  }
  /**
   * Get the default numbering system to create DateTimes with. Does not affect existing instances.
   * @type {string}
   */
  static get defaultNumberingSystem() {
    return Si;
  }
  /**
   * Set the default numbering system to create DateTimes with. Does not affect existing instances.
   * @type {string}
   */
  static set defaultNumberingSystem(e) {
    Si = e;
  }
  /**
   * Get the default output calendar to create DateTimes with. Does not affect existing instances.
   * @type {string}
   */
  static get defaultOutputCalendar() {
    return _i;
  }
  /**
   * Set the default output calendar to create DateTimes with. Does not affect existing instances.
   * @type {string}
   */
  static set defaultOutputCalendar(e) {
    _i = e;
  }
  /**
   * @typedef {Object} WeekSettings
   * @property {number} firstDay
   * @property {number} minimalDays
   * @property {number[]} weekend
   */
  /**
   * @return {WeekSettings|null}
   */
  static get defaultWeekSettings() {
    return Ii;
  }
  /**
   * Allows overriding the default locale week settings, i.e. the start of the week, the weekend and
   * how many days are required in the first week of a year.
   * Does not affect existing instances.
   *
   * @param {WeekSettings|null} weekSettings
   */
  static set defaultWeekSettings(e) {
    Ii = Br(e);
  }
  /**
   * Get the cutoff year for whether a 2-digit year string is interpreted in the current or previous century. Numbers higher than the cutoff will be considered to mean 19xx and numbers lower or equal to the cutoff will be considered 20xx.
   * @type {number}
   */
  static get twoDigitCutoffYear() {
    return ki;
  }
  /**
   * Set the cutoff year for whether a 2-digit year string is interpreted in the current or previous century. Numbers higher than the cutoff will be considered to mean 19xx and numbers lower or equal to the cutoff will be considered 20xx.
   * @type {number}
   * @example Settings.twoDigitCutoffYear = 0 // all 'yy' are interpreted as 20th century
   * @example Settings.twoDigitCutoffYear = 99 // all 'yy' are interpreted as 21st century
   * @example Settings.twoDigitCutoffYear = 50 // '49' -> 2049; '50' -> 1950
   * @example Settings.twoDigitCutoffYear = 1950 // interpreted as 50
   * @example Settings.twoDigitCutoffYear = 2050 // ALSO interpreted as 50
   */
  static set twoDigitCutoffYear(e) {
    ki = e % 100;
  }
  /**
   * Get whether Luxon will throw when it encounters invalid DateTimes, Durations, or Intervals
   * @type {boolean}
   */
  static get throwOnInvalid() {
    return Ni;
  }
  /**
   * Set whether Luxon will throw when it encounters invalid DateTimes, Durations, or Intervals
   * @type {boolean}
   */
  static set throwOnInvalid(e) {
    Ni = e;
  }
  /**
   * Reset Luxon's global caches. Should only be necessary in testing scenarios.
   * @return {void}
   */
  static resetCaches() {
    K.resetCache(), $e.resetCache(), x.resetCache(), Af();
  }
}
class Me {
  constructor(e, n) {
    this.reason = e, this.explanation = n;
  }
  toMessage() {
    return this.explanation ? `${this.reason}: ${this.explanation}` : this.reason;
  }
}
const uo = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334], co = [0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335];
function Ie(t, e) {
  return new Me(
    "unit out of range",
    `you specified ${e} (of type ${typeof e}) as a ${t}, which is invalid`
  );
}
function ts(t, e, n) {
  const r = new Date(Date.UTC(t, e - 1, n));
  t < 100 && t >= 0 && r.setUTCFullYear(r.getUTCFullYear() - 1900);
  const s = r.getUTCDay();
  return s === 0 ? 7 : s;
}
function lo(t, e, n) {
  return n + (Qt(t) ? co : uo)[e - 1];
}
function fo(t, e) {
  const n = Qt(t) ? co : uo, r = n.findIndex((i) => i < e), s = e - n[r];
  return { month: r + 1, day: s };
}
function ns(t, e) {
  return (t - e + 7) % 7 + 1;
}
function Mn(t, e = 4, n = 1) {
  const { year: r, month: s, day: i } = t, a = lo(r, s, i), u = ns(ts(r, s, i), n);
  let c = Math.floor((a - u + 14 - e) / 7), l;
  return c < 1 ? (l = r - 1, c = Bt(l, e, n)) : c > Bt(r, e, n) ? (l = r + 1, c = 1) : l = r, { weekYear: l, weekNumber: c, weekday: u, ...zn(t) };
}
function Di(t, e = 4, n = 1) {
  const { weekYear: r, weekNumber: s, weekday: i } = t, a = ns(ts(r, 1, e), n), u = Tt(r);
  let c = s * 7 + i - a - 7 + e, l;
  c < 1 ? (l = r - 1, c += Tt(l)) : c > u ? (l = r + 1, c -= Tt(r)) : l = r;
  const { month: d, day: m } = fo(l, c);
  return { year: l, month: d, day: m, ...zn(t) };
}
function mr(t) {
  const { year: e, month: n, day: r } = t, s = lo(e, n, r);
  return { year: e, ordinal: s, ...zn(t) };
}
function Ci(t) {
  const { year: e, ordinal: n } = t, { month: r, day: s } = fo(e, n);
  return { year: e, month: r, day: s, ...zn(t) };
}
function Ai(t, e) {
  if (!P(t.localWeekday) || !P(t.localWeekNumber) || !P(t.localWeekYear)) {
    if (!P(t.weekday) || !P(t.weekNumber) || !P(t.weekYear))
      throw new Ot(
        "Cannot mix locale-based week fields with ISO-based week fields"
      );
    return P(t.localWeekday) || (t.weekday = t.localWeekday), P(t.localWeekNumber) || (t.weekNumber = t.localWeekNumber), P(t.localWeekYear) || (t.weekYear = t.localWeekYear), delete t.localWeekday, delete t.localWeekNumber, delete t.localWeekYear, {
      minDaysInFirstWeek: e.getMinDaysInFirstWeek(),
      startOfWeek: e.getStartOfWeek()
    };
  } else
    return { minDaysInFirstWeek: 4, startOfWeek: 1 };
}
function xf(t, e = 4, n = 1) {
  const r = $n(t.weekYear), s = De(
    t.weekNumber,
    1,
    Bt(t.weekYear, e, n)
  ), i = De(t.weekday, 1, 7);
  return r ? s ? i ? !1 : Ie("weekday", t.weekday) : Ie("week", t.weekNumber) : Ie("weekYear", t.weekYear);
}
function Rf(t) {
  const e = $n(t.year), n = De(t.ordinal, 1, Tt(t.year));
  return e ? n ? !1 : Ie("ordinal", t.ordinal) : Ie("year", t.year);
}
function ho(t) {
  const e = $n(t.year), n = De(t.month, 1, 12), r = De(t.day, 1, Fn(t.year, t.month));
  return e ? n ? r ? !1 : Ie("day", t.day) : Ie("month", t.month) : Ie("year", t.year);
}
function po(t) {
  const { hour: e, minute: n, second: r, millisecond: s } = t, i = De(e, 0, 23) || e === 24 && n === 0 && r === 0 && s === 0, a = De(n, 0, 59), u = De(r, 0, 59), c = De(s, 0, 999);
  return i ? a ? u ? c ? !1 : Ie("millisecond", s) : Ie("second", r) : Ie("minute", n) : Ie("hour", e);
}
function P(t) {
  return typeof t > "u";
}
function et(t) {
  return typeof t == "number";
}
function $n(t) {
  return typeof t == "number" && t % 1 === 0;
}
function Mf(t) {
  return typeof t == "string";
}
function Ff(t) {
  return Object.prototype.toString.call(t) === "[object Date]";
}
function mo() {
  try {
    return typeof Intl < "u" && !!Intl.RelativeTimeFormat;
  } catch {
    return !1;
  }
}
function yo() {
  try {
    return typeof Intl < "u" && !!Intl.Locale && ("weekInfo" in Intl.Locale.prototype || "getWeekInfo" in Intl.Locale.prototype);
  } catch {
    return !1;
  }
}
function Lf(t) {
  return Array.isArray(t) ? t : [t];
}
function xi(t, e, n) {
  if (t.length !== 0)
    return t.reduce((r, s) => {
      const i = [e(s), s];
      return r && n(r[0], i[0]) === r[0] ? r : i;
    }, null)[1];
}
function Pf(t, e) {
  return e.reduce((n, r) => (n[r] = t[r], n), {});
}
function _t(t, e) {
  return Object.prototype.hasOwnProperty.call(t, e);
}
function Br(t) {
  if (t == null)
    return null;
  if (typeof t != "object")
    throw new we("Week settings must be an object");
  if (!De(t.firstDay, 1, 7) || !De(t.minimalDays, 1, 7) || !Array.isArray(t.weekend) || t.weekend.some((e) => !De(e, 1, 7)))
    throw new we("Invalid week settings");
  return {
    firstDay: t.firstDay,
    minimalDays: t.minimalDays,
    weekend: Array.from(t.weekend)
  };
}
function De(t, e, n) {
  return $n(t) && t >= e && t <= n;
}
function Vf(t, e) {
  return t - e * Math.floor(t / e);
}
function me(t, e = 2) {
  const n = t < 0;
  let r;
  return n ? r = "-" + ("" + -t).padStart(e, "0") : r = ("" + t).padStart(e, "0"), r;
}
function Xe(t) {
  if (!(P(t) || t === null || t === ""))
    return parseInt(t, 10);
}
function nt(t) {
  if (!(P(t) || t === null || t === ""))
    return parseFloat(t);
}
function rs(t) {
  if (!(P(t) || t === null || t === "")) {
    const e = parseFloat("0." + t) * 1e3;
    return Math.floor(e);
  }
}
function ss(t, e, n = !1) {
  const r = 10 ** e;
  return (n ? Math.trunc : Math.round)(t * r) / r;
}
function Qt(t) {
  return t % 4 === 0 && (t % 100 !== 0 || t % 400 === 0);
}
function Tt(t) {
  return Qt(t) ? 366 : 365;
}
function Fn(t, e) {
  const n = Vf(e - 1, 12) + 1, r = t + (e - n) / 12;
  return n === 2 ? Qt(r) ? 29 : 28 : [31, null, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][n - 1];
}
function Hn(t) {
  let e = Date.UTC(
    t.year,
    t.month - 1,
    t.day,
    t.hour,
    t.minute,
    t.second,
    t.millisecond
  );
  return t.year < 100 && t.year >= 0 && (e = new Date(e), e.setUTCFullYear(t.year, t.month - 1, t.day)), +e;
}
function Ri(t, e, n) {
  return -ns(ts(t, 1, e), n) + e - 1;
}
function Bt(t, e = 4, n = 1) {
  const r = Ri(t, e, n), s = Ri(t + 1, e, n);
  return (Tt(t) - r + s) / 7;
}
function Yr(t) {
  return t > 99 ? t : t > fe.twoDigitCutoffYear ? 1900 + t : 2e3 + t;
}
function vo(t, e, n, r = null) {
  const s = new Date(t), i = {
    hourCycle: "h23",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit"
  };
  r && (i.timeZone = r);
  const a = { timeZoneName: e, ...i }, u = new Intl.DateTimeFormat(n, a).formatToParts(s).find((c) => c.type.toLowerCase() === "timezonename");
  return u ? u.value : null;
}
function jn(t, e) {
  let n = parseInt(t, 10);
  Number.isNaN(n) && (n = 0);
  const r = parseInt(e, 10) || 0, s = n < 0 || Object.is(n, -0) ? -r : r;
  return n * 60 + s;
}
function go(t) {
  const e = Number(t);
  if (typeof t == "boolean" || t === "" || Number.isNaN(e))
    throw new we(`Invalid unit value ${t}`);
  return e;
}
function Ln(t, e) {
  const n = {};
  for (const r in t)
    if (_t(t, r)) {
      const s = t[r];
      if (s == null) continue;
      n[e(r)] = go(s);
    }
  return n;
}
function Ht(t, e) {
  const n = Math.trunc(Math.abs(t / 60)), r = Math.trunc(Math.abs(t % 60)), s = t >= 0 ? "+" : "-";
  switch (e) {
    case "short":
      return `${s}${me(n, 2)}:${me(r, 2)}`;
    case "narrow":
      return `${s}${n}${r > 0 ? `:${r}` : ""}`;
    case "techie":
      return `${s}${me(n, 2)}${me(r, 2)}`;
    default:
      throw new RangeError(`Value format ${e} is out of range for property format`);
  }
}
function zn(t) {
  return Pf(t, ["hour", "minute", "second", "millisecond"]);
}
const Wf = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December"
], Eo = [
  "Jan",
  "Feb",
  "Mar",
  "Apr",
  "May",
  "Jun",
  "Jul",
  "Aug",
  "Sep",
  "Oct",
  "Nov",
  "Dec"
], Uf = ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"];
function wo(t) {
  switch (t) {
    case "narrow":
      return [...Uf];
    case "short":
      return [...Eo];
    case "long":
      return [...Wf];
    case "numeric":
      return ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"];
    case "2-digit":
      return ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"];
    default:
      return null;
  }
}
const bo = [
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
  "Sunday"
], Oo = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"], $f = ["M", "T", "W", "T", "F", "S", "S"];
function To(t) {
  switch (t) {
    case "narrow":
      return [...$f];
    case "short":
      return [...Oo];
    case "long":
      return [...bo];
    case "numeric":
      return ["1", "2", "3", "4", "5", "6", "7"];
    default:
      return null;
  }
}
const So = ["AM", "PM"], Hf = ["Before Christ", "Anno Domini"], jf = ["BC", "AD"], zf = ["B", "A"];
function _o(t) {
  switch (t) {
    case "narrow":
      return [...zf];
    case "short":
      return [...jf];
    case "long":
      return [...Hf];
    default:
      return null;
  }
}
function Bf(t) {
  return So[t.hour < 12 ? 0 : 1];
}
function Yf(t, e) {
  return To(e)[t.weekday - 1];
}
function qf(t, e) {
  return wo(e)[t.month - 1];
}
function Gf(t, e) {
  return _o(e)[t.year < 0 ? 0 : 1];
}
function Zf(t, e, n = "always", r = !1) {
  const s = {
    years: ["year", "yr."],
    quarters: ["quarter", "qtr."],
    months: ["month", "mo."],
    weeks: ["week", "wk."],
    days: ["day", "day", "days"],
    hours: ["hour", "hr."],
    minutes: ["minute", "min."],
    seconds: ["second", "sec."]
  }, i = ["hours", "minutes", "seconds"].indexOf(t) === -1;
  if (n === "auto" && i) {
    const m = t === "days";
    switch (e) {
      case 1:
        return m ? "tomorrow" : `next ${s[t][0]}`;
      case -1:
        return m ? "yesterday" : `last ${s[t][0]}`;
      case 0:
        return m ? "today" : `this ${s[t][0]}`;
    }
  }
  const a = Object.is(e, -0) || e < 0, u = Math.abs(e), c = u === 1, l = s[t], d = r ? c ? l[1] : l[2] || l[1] : c ? s[t][0] : t;
  return a ? `${u} ${d} ago` : `in ${u} ${d}`;
}
function Mi(t, e) {
  let n = "";
  for (const r of t)
    r.literal ? n += r.val : n += e(r.val);
  return n;
}
const Qf = {
  D: Rn,
  DD: ja,
  DDD: za,
  DDDD: Ba,
  t: Ya,
  tt: qa,
  ttt: Ga,
  tttt: Za,
  T: Qa,
  TT: Ja,
  TTT: Xa,
  TTTT: Ka,
  f: eo,
  ff: no,
  fff: so,
  ffff: ao,
  F: to,
  FF: ro,
  FFF: io,
  FFFF: oo
};
class be {
  static create(e, n = {}) {
    return new be(e, n);
  }
  static parseFormat(e) {
    let n = null, r = "", s = !1;
    const i = [];
    for (let a = 0; a < e.length; a++) {
      const u = e.charAt(a);
      u === "'" ? (r.length > 0 && i.push({ literal: s || /^\s+$/.test(r), val: r }), n = null, r = "", s = !s) : s || u === n ? r += u : (r.length > 0 && i.push({ literal: /^\s+$/.test(r), val: r }), r = u, n = u);
    }
    return r.length > 0 && i.push({ literal: s || /^\s+$/.test(r), val: r }), i;
  }
  static macroTokenToFormatOpts(e) {
    return Qf[e];
  }
  constructor(e, n) {
    this.opts = n, this.loc = e, this.systemLoc = null;
  }
  formatWithSystemDefault(e, n) {
    return this.systemLoc === null && (this.systemLoc = this.loc.redefaultToSystem()), this.systemLoc.dtFormatter(e, { ...this.opts, ...n }).format();
  }
  dtFormatter(e, n = {}) {
    return this.loc.dtFormatter(e, { ...this.opts, ...n });
  }
  formatDateTime(e, n) {
    return this.dtFormatter(e, n).format();
  }
  formatDateTimeParts(e, n) {
    return this.dtFormatter(e, n).formatToParts();
  }
  formatInterval(e, n) {
    return this.dtFormatter(e.start, n).dtf.formatRange(e.start.toJSDate(), e.end.toJSDate());
  }
  resolvedOptions(e, n) {
    return this.dtFormatter(e, n).resolvedOptions();
  }
  num(e, n = 0) {
    if (this.opts.forceSimple)
      return me(e, n);
    const r = { ...this.opts };
    return n > 0 && (r.padTo = n), this.loc.numberFormatter(r).format(e);
  }
  formatDateTimeFromString(e, n) {
    const r = this.loc.listingMode() === "en", s = this.loc.outputCalendar && this.loc.outputCalendar !== "gregory", i = (E, S) => this.loc.extract(e, E, S), a = (E) => e.isOffsetFixed && e.offset === 0 && E.allowZ ? "Z" : e.isValid ? e.zone.formatOffset(e.ts, E.format) : "", u = () => r ? Bf(e) : i({ hour: "numeric", hourCycle: "h12" }, "dayperiod"), c = (E, S) => r ? qf(e, E) : i(S ? { month: E } : { month: E, day: "numeric" }, "month"), l = (E, S) => r ? Yf(e, E) : i(
      S ? { weekday: E } : { weekday: E, month: "long", day: "numeric" },
      "weekday"
    ), d = (E) => {
      const S = be.macroTokenToFormatOpts(E);
      return S ? this.formatWithSystemDefault(e, S) : E;
    }, m = (E) => r ? Gf(e, E) : i({ era: E }, "era"), T = (E) => {
      switch (E) {
        case "S":
          return this.num(e.millisecond);
        case "u":
        case "SSS":
          return this.num(e.millisecond, 3);
        case "s":
          return this.num(e.second);
        case "ss":
          return this.num(e.second, 2);
        case "uu":
          return this.num(Math.floor(e.millisecond / 10), 2);
        case "uuu":
          return this.num(Math.floor(e.millisecond / 100));
        case "m":
          return this.num(e.minute);
        case "mm":
          return this.num(e.minute, 2);
        case "h":
          return this.num(e.hour % 12 === 0 ? 12 : e.hour % 12);
        case "hh":
          return this.num(e.hour % 12 === 0 ? 12 : e.hour % 12, 2);
        case "H":
          return this.num(e.hour);
        case "HH":
          return this.num(e.hour, 2);
        case "Z":
          return a({ format: "narrow", allowZ: this.opts.allowZ });
        case "ZZ":
          return a({ format: "short", allowZ: this.opts.allowZ });
        case "ZZZ":
          return a({ format: "techie", allowZ: this.opts.allowZ });
        case "ZZZZ":
          return e.zone.offsetName(e.ts, { format: "short", locale: this.loc.locale });
        case "ZZZZZ":
          return e.zone.offsetName(e.ts, { format: "long", locale: this.loc.locale });
        case "z":
          return e.zoneName;
        case "a":
          return u();
        case "d":
          return s ? i({ day: "numeric" }, "day") : this.num(e.day);
        case "dd":
          return s ? i({ day: "2-digit" }, "day") : this.num(e.day, 2);
        case "c":
          return this.num(e.weekday);
        case "ccc":
          return l("short", !0);
        case "cccc":
          return l("long", !0);
        case "ccccc":
          return l("narrow", !0);
        case "E":
          return this.num(e.weekday);
        case "EEE":
          return l("short", !1);
        case "EEEE":
          return l("long", !1);
        case "EEEEE":
          return l("narrow", !1);
        case "L":
          return s ? i({ month: "numeric", day: "numeric" }, "month") : this.num(e.month);
        case "LL":
          return s ? i({ month: "2-digit", day: "numeric" }, "month") : this.num(e.month, 2);
        case "LLL":
          return c("short", !0);
        case "LLLL":
          return c("long", !0);
        case "LLLLL":
          return c("narrow", !0);
        case "M":
          return s ? i({ month: "numeric" }, "month") : this.num(e.month);
        case "MM":
          return s ? i({ month: "2-digit" }, "month") : this.num(e.month, 2);
        case "MMM":
          return c("short", !1);
        case "MMMM":
          return c("long", !1);
        case "MMMMM":
          return c("narrow", !1);
        case "y":
          return s ? i({ year: "numeric" }, "year") : this.num(e.year);
        case "yy":
          return s ? i({ year: "2-digit" }, "year") : this.num(e.year.toString().slice(-2), 2);
        case "yyyy":
          return s ? i({ year: "numeric" }, "year") : this.num(e.year, 4);
        case "yyyyyy":
          return s ? i({ year: "numeric" }, "year") : this.num(e.year, 6);
        case "G":
          return m("short");
        case "GG":
          return m("long");
        case "GGGGG":
          return m("narrow");
        case "kk":
          return this.num(e.weekYear.toString().slice(-2), 2);
        case "kkkk":
          return this.num(e.weekYear, 4);
        case "W":
          return this.num(e.weekNumber);
        case "WW":
          return this.num(e.weekNumber, 2);
        case "n":
          return this.num(e.localWeekNumber);
        case "nn":
          return this.num(e.localWeekNumber, 2);
        case "ii":
          return this.num(e.localWeekYear.toString().slice(-2), 2);
        case "iiii":
          return this.num(e.localWeekYear, 4);
        case "o":
          return this.num(e.ordinal);
        case "ooo":
          return this.num(e.ordinal, 3);
        case "q":
          return this.num(e.quarter);
        case "qq":
          return this.num(e.quarter, 2);
        case "X":
          return this.num(Math.floor(e.ts / 1e3));
        case "x":
          return this.num(e.ts);
        default:
          return d(E);
      }
    };
    return Mi(be.parseFormat(n), T);
  }
  formatDurationFromString(e, n) {
    const r = (c) => {
      switch (c[0]) {
        case "S":
          return "millisecond";
        case "s":
          return "second";
        case "m":
          return "minute";
        case "h":
          return "hour";
        case "d":
          return "day";
        case "w":
          return "week";
        case "M":
          return "month";
        case "y":
          return "year";
        default:
          return null;
      }
    }, s = (c) => (l) => {
      const d = r(l);
      return d ? this.num(c.get(d), l.length) : l;
    }, i = be.parseFormat(n), a = i.reduce(
      (c, { literal: l, val: d }) => l ? c : c.concat(d),
      []
    ), u = e.shiftTo(...a.map(r).filter((c) => c));
    return Mi(i, s(u));
  }
}
const ko = /[A-Za-z_+-]{1,256}(?::?\/[A-Za-z0-9_+-]{1,256}(?:\/[A-Za-z0-9_+-]{1,256})?)?/;
function Nt(...t) {
  const e = t.reduce((n, r) => n + r.source, "");
  return RegExp(`^${e}$`);
}
function It(...t) {
  return (e) => t.reduce(
    ([n, r, s], i) => {
      const [a, u, c] = i(e, s);
      return [{ ...n, ...a }, u || r, c];
    },
    [{}, null, 1]
  ).slice(0, 2);
}
function Dt(t, ...e) {
  if (t == null)
    return [null, null];
  for (const [n, r] of e) {
    const s = n.exec(t);
    if (s)
      return r(s);
  }
  return [null, null];
}
function No(...t) {
  return (e, n) => {
    const r = {};
    let s;
    for (s = 0; s < t.length; s++)
      r[t[s]] = Xe(e[n + s]);
    return [r, null, n + s];
  };
}
const Io = /(?:(Z)|([+-]\d\d)(?::?(\d\d))?)/, Jf = `(?:${Io.source}?(?:\\[(${ko.source})\\])?)?`, is = /(\d\d)(?::?(\d\d)(?::?(\d\d)(?:[.,](\d{1,30}))?)?)?/, Do = RegExp(`${is.source}${Jf}`), as = RegExp(`(?:T${Do.source})?`), Xf = /([+-]\d{6}|\d{4})(?:-?(\d\d)(?:-?(\d\d))?)?/, Kf = /(\d{4})-?W(\d\d)(?:-?(\d))?/, ed = /(\d{4})-?(\d{3})/, td = No("weekYear", "weekNumber", "weekDay"), nd = No("year", "ordinal"), rd = /(\d{4})-(\d\d)-(\d\d)/, Co = RegExp(
  `${is.source} ?(?:${Io.source}|(${ko.source}))?`
), sd = RegExp(`(?: ${Co.source})?`);
function St(t, e, n) {
  const r = t[e];
  return P(r) ? n : Xe(r);
}
function id(t, e) {
  return [{
    year: St(t, e),
    month: St(t, e + 1, 1),
    day: St(t, e + 2, 1)
  }, null, e + 3];
}
function Ct(t, e) {
  return [{
    hours: St(t, e, 0),
    minutes: St(t, e + 1, 0),
    seconds: St(t, e + 2, 0),
    milliseconds: rs(t[e + 3])
  }, null, e + 4];
}
function Jt(t, e) {
  const n = !t[e] && !t[e + 1], r = jn(t[e + 1], t[e + 2]), s = n ? null : Se.instance(r);
  return [{}, s, e + 3];
}
function Xt(t, e) {
  const n = t[e] ? $e.create(t[e]) : null;
  return [{}, n, e + 1];
}
const ad = RegExp(`^T?${is.source}$`), od = /^-?P(?:(?:(-?\d{1,20}(?:\.\d{1,20})?)Y)?(?:(-?\d{1,20}(?:\.\d{1,20})?)M)?(?:(-?\d{1,20}(?:\.\d{1,20})?)W)?(?:(-?\d{1,20}(?:\.\d{1,20})?)D)?(?:T(?:(-?\d{1,20}(?:\.\d{1,20})?)H)?(?:(-?\d{1,20}(?:\.\d{1,20})?)M)?(?:(-?\d{1,20})(?:[.,](-?\d{1,20}))?S)?)?)$/;
function ud(t) {
  const [e, n, r, s, i, a, u, c, l] = t, d = e[0] === "-", m = c && c[0] === "-", T = (E, S = !1) => E !== void 0 && (S || E && d) ? -E : E;
  return [
    {
      years: T(nt(n)),
      months: T(nt(r)),
      weeks: T(nt(s)),
      days: T(nt(i)),
      hours: T(nt(a)),
      minutes: T(nt(u)),
      seconds: T(nt(c), c === "-0"),
      milliseconds: T(rs(l), m)
    }
  ];
}
const cd = {
  GMT: 0,
  EDT: -4 * 60,
  EST: -5 * 60,
  CDT: -5 * 60,
  CST: -6 * 60,
  MDT: -6 * 60,
  MST: -7 * 60,
  PDT: -7 * 60,
  PST: -8 * 60
};
function os(t, e, n, r, s, i, a) {
  const u = {
    year: e.length === 2 ? Yr(Xe(e)) : Xe(e),
    month: Eo.indexOf(n) + 1,
    day: Xe(r),
    hour: Xe(s),
    minute: Xe(i)
  };
  return a && (u.second = Xe(a)), t && (u.weekday = t.length > 3 ? bo.indexOf(t) + 1 : Oo.indexOf(t) + 1), u;
}
const ld = /^(?:(Mon|Tue|Wed|Thu|Fri|Sat|Sun),\s)?(\d{1,2})\s(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s(\d{2,4})\s(\d\d):(\d\d)(?::(\d\d))?\s(?:(UT|GMT|[ECMP][SD]T)|([Zz])|(?:([+-]\d\d)(\d\d)))$/;
function fd(t) {
  const [
    ,
    e,
    n,
    r,
    s,
    i,
    a,
    u,
    c,
    l,
    d,
    m
  ] = t, T = os(e, s, r, n, i, a, u);
  let E;
  return c ? E = cd[c] : l ? E = 0 : E = jn(d, m), [T, new Se(E)];
}
function dd(t) {
  return t.replace(/\([^()]*\)|[\n\t]/g, " ").replace(/(\s\s+)/g, " ").trim();
}
const hd = /^(Mon|Tue|Wed|Thu|Fri|Sat|Sun), (\d\d) (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) (\d{4}) (\d\d):(\d\d):(\d\d) GMT$/, pd = /^(Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday), (\d\d)-(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)-(\d\d) (\d\d):(\d\d):(\d\d) GMT$/, md = /^(Mon|Tue|Wed|Thu|Fri|Sat|Sun) (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) ( \d|\d\d) (\d\d):(\d\d):(\d\d) (\d{4})$/;
function Fi(t) {
  const [, e, n, r, s, i, a, u] = t;
  return [os(e, s, r, n, i, a, u), Se.utcInstance];
}
function yd(t) {
  const [, e, n, r, s, i, a, u] = t;
  return [os(e, u, n, r, s, i, a), Se.utcInstance];
}
const vd = Nt(Xf, as), gd = Nt(Kf, as), Ed = Nt(ed, as), wd = Nt(Do), Ao = It(
  id,
  Ct,
  Jt,
  Xt
), bd = It(
  td,
  Ct,
  Jt,
  Xt
), Od = It(
  nd,
  Ct,
  Jt,
  Xt
), Td = It(
  Ct,
  Jt,
  Xt
);
function Sd(t) {
  return Dt(
    t,
    [vd, Ao],
    [gd, bd],
    [Ed, Od],
    [wd, Td]
  );
}
function _d(t) {
  return Dt(dd(t), [ld, fd]);
}
function kd(t) {
  return Dt(
    t,
    [hd, Fi],
    [pd, Fi],
    [md, yd]
  );
}
function Nd(t) {
  return Dt(t, [od, ud]);
}
const Id = It(Ct);
function Dd(t) {
  return Dt(t, [ad, Id]);
}
const Cd = Nt(rd, sd), Ad = Nt(Co), xd = It(
  Ct,
  Jt,
  Xt
);
function Rd(t) {
  return Dt(
    t,
    [Cd, Ao],
    [Ad, xd]
  );
}
const Li = "Invalid Duration", xo = {
  weeks: {
    days: 7,
    hours: 7 * 24,
    minutes: 7 * 24 * 60,
    seconds: 7 * 24 * 60 * 60,
    milliseconds: 7 * 24 * 60 * 60 * 1e3
  },
  days: {
    hours: 24,
    minutes: 24 * 60,
    seconds: 24 * 60 * 60,
    milliseconds: 24 * 60 * 60 * 1e3
  },
  hours: { minutes: 60, seconds: 60 * 60, milliseconds: 60 * 60 * 1e3 },
  minutes: { seconds: 60, milliseconds: 60 * 1e3 },
  seconds: { milliseconds: 1e3 }
}, Md = {
  years: {
    quarters: 4,
    months: 12,
    weeks: 52,
    days: 365,
    hours: 365 * 24,
    minutes: 365 * 24 * 60,
    seconds: 365 * 24 * 60 * 60,
    milliseconds: 365 * 24 * 60 * 60 * 1e3
  },
  quarters: {
    months: 3,
    weeks: 13,
    days: 91,
    hours: 91 * 24,
    minutes: 91 * 24 * 60,
    seconds: 91 * 24 * 60 * 60,
    milliseconds: 91 * 24 * 60 * 60 * 1e3
  },
  months: {
    weeks: 4,
    days: 30,
    hours: 30 * 24,
    minutes: 30 * 24 * 60,
    seconds: 30 * 24 * 60 * 60,
    milliseconds: 30 * 24 * 60 * 60 * 1e3
  },
  ...xo
}, Ne = 146097 / 400, vt = 146097 / 4800, Fd = {
  years: {
    quarters: 4,
    months: 12,
    weeks: Ne / 7,
    days: Ne,
    hours: Ne * 24,
    minutes: Ne * 24 * 60,
    seconds: Ne * 24 * 60 * 60,
    milliseconds: Ne * 24 * 60 * 60 * 1e3
  },
  quarters: {
    months: 3,
    weeks: Ne / 28,
    days: Ne / 4,
    hours: Ne * 24 / 4,
    minutes: Ne * 24 * 60 / 4,
    seconds: Ne * 24 * 60 * 60 / 4,
    milliseconds: Ne * 24 * 60 * 60 * 1e3 / 4
  },
  months: {
    weeks: vt / 7,
    days: vt,
    hours: vt * 24,
    minutes: vt * 24 * 60,
    seconds: vt * 24 * 60 * 60,
    milliseconds: vt * 24 * 60 * 60 * 1e3
  },
  ...xo
}, ot = [
  "years",
  "quarters",
  "months",
  "weeks",
  "days",
  "hours",
  "minutes",
  "seconds",
  "milliseconds"
], Ld = ot.slice(0).reverse();
function Ze(t, e, n = !1) {
  const r = {
    values: n ? e.values : { ...t.values, ...e.values || {} },
    loc: t.loc.clone(e.loc),
    conversionAccuracy: e.conversionAccuracy || t.conversionAccuracy,
    matrix: e.matrix || t.matrix
  };
  return new G(r);
}
function Ro(t, e) {
  let n = e.milliseconds ?? 0;
  for (const r of Ld.slice(1))
    e[r] && (n += e[r] * t[r].milliseconds);
  return n;
}
function Pi(t, e) {
  const n = Ro(t, e) < 0 ? -1 : 1;
  ot.reduceRight((r, s) => {
    if (P(e[s]))
      return r;
    if (r) {
      const i = e[r] * n, a = t[s][r], u = Math.floor(i / a);
      e[s] += u * n, e[r] -= u * a * n;
    }
    return s;
  }, null), ot.reduce((r, s) => {
    if (P(e[s]))
      return r;
    if (r) {
      const i = e[r] % 1;
      e[r] -= i, e[s] += i * t[r][s];
    }
    return s;
  }, null);
}
function Pd(t) {
  const e = {};
  for (const [n, r] of Object.entries(t))
    r !== 0 && (e[n] = r);
  return e;
}
class G {
  /**
   * @private
   */
  constructor(e) {
    const n = e.conversionAccuracy === "longterm" || !1;
    let r = n ? Fd : Md;
    e.matrix && (r = e.matrix), this.values = e.values, this.loc = e.loc || K.create(), this.conversionAccuracy = n ? "longterm" : "casual", this.invalid = e.invalid || null, this.matrix = r, this.isLuxonDuration = !0;
  }
  /**
   * Create Duration from a number of milliseconds.
   * @param {number} count of milliseconds
   * @param {Object} opts - options for parsing
   * @param {string} [opts.locale='en-US'] - the locale to use
   * @param {string} opts.numberingSystem - the numbering system to use
   * @param {string} [opts.conversionAccuracy='casual'] - the conversion system to use
   * @return {Duration}
   */
  static fromMillis(e, n) {
    return G.fromObject({ milliseconds: e }, n);
  }
  /**
   * Create a Duration from a JavaScript object with keys like 'years' and 'hours'.
   * If this object is empty then a zero milliseconds duration is returned.
   * @param {Object} obj - the object to create the DateTime from
   * @param {number} obj.years
   * @param {number} obj.quarters
   * @param {number} obj.months
   * @param {number} obj.weeks
   * @param {number} obj.days
   * @param {number} obj.hours
   * @param {number} obj.minutes
   * @param {number} obj.seconds
   * @param {number} obj.milliseconds
   * @param {Object} [opts=[]] - options for creating this Duration
   * @param {string} [opts.locale='en-US'] - the locale to use
   * @param {string} opts.numberingSystem - the numbering system to use
   * @param {string} [opts.conversionAccuracy='casual'] - the preset conversion system to use
   * @param {string} [opts.matrix=Object] - the custom conversion system to use
   * @return {Duration}
   */
  static fromObject(e, n = {}) {
    if (e == null || typeof e != "object")
      throw new we(
        `Duration.fromObject: argument expected to be an object, got ${e === null ? "null" : typeof e}`
      );
    return new G({
      values: Ln(e, G.normalizeUnit),
      loc: K.fromObject(n),
      conversionAccuracy: n.conversionAccuracy,
      matrix: n.matrix
    });
  }
  /**
   * Create a Duration from DurationLike.
   *
   * @param {Object | number | Duration} durationLike
   * One of:
   * - object with keys like 'years' and 'hours'.
   * - number representing milliseconds
   * - Duration instance
   * @return {Duration}
   */
  static fromDurationLike(e) {
    if (et(e))
      return G.fromMillis(e);
    if (G.isDuration(e))
      return e;
    if (typeof e == "object")
      return G.fromObject(e);
    throw new we(
      `Unknown duration argument ${e} of type ${typeof e}`
    );
  }
  /**
   * Create a Duration from an ISO 8601 duration string.
   * @param {string} text - text to parse
   * @param {Object} opts - options for parsing
   * @param {string} [opts.locale='en-US'] - the locale to use
   * @param {string} opts.numberingSystem - the numbering system to use
   * @param {string} [opts.conversionAccuracy='casual'] - the preset conversion system to use
   * @param {string} [opts.matrix=Object] - the preset conversion system to use
   * @see https://en.wikipedia.org/wiki/ISO_8601#Durations
   * @example Duration.fromISO('P3Y6M1W4DT12H30M5S').toObject() //=> { years: 3, months: 6, weeks: 1, days: 4, hours: 12, minutes: 30, seconds: 5 }
   * @example Duration.fromISO('PT23H').toObject() //=> { hours: 23 }
   * @example Duration.fromISO('P5Y3M').toObject() //=> { years: 5, months: 3 }
   * @return {Duration}
   */
  static fromISO(e, n) {
    const [r] = Nd(e);
    return r ? G.fromObject(r, n) : G.invalid("unparsable", `the input "${e}" can't be parsed as ISO 8601`);
  }
  /**
   * Create a Duration from an ISO 8601 time string.
   * @param {string} text - text to parse
   * @param {Object} opts - options for parsing
   * @param {string} [opts.locale='en-US'] - the locale to use
   * @param {string} opts.numberingSystem - the numbering system to use
   * @param {string} [opts.conversionAccuracy='casual'] - the preset conversion system to use
   * @param {string} [opts.matrix=Object] - the conversion system to use
   * @see https://en.wikipedia.org/wiki/ISO_8601#Times
   * @example Duration.fromISOTime('11:22:33.444').toObject() //=> { hours: 11, minutes: 22, seconds: 33, milliseconds: 444 }
   * @example Duration.fromISOTime('11:00').toObject() //=> { hours: 11, minutes: 0, seconds: 0 }
   * @example Duration.fromISOTime('T11:00').toObject() //=> { hours: 11, minutes: 0, seconds: 0 }
   * @example Duration.fromISOTime('1100').toObject() //=> { hours: 11, minutes: 0, seconds: 0 }
   * @example Duration.fromISOTime('T1100').toObject() //=> { hours: 11, minutes: 0, seconds: 0 }
   * @return {Duration}
   */
  static fromISOTime(e, n) {
    const [r] = Dd(e);
    return r ? G.fromObject(r, n) : G.invalid("unparsable", `the input "${e}" can't be parsed as ISO 8601`);
  }
  /**
   * Create an invalid Duration.
   * @param {string} reason - simple string of why this datetime is invalid. Should not contain parameters or anything else data-dependent
   * @param {string} [explanation=null] - longer explanation, may include parameters and other useful debugging information
   * @return {Duration}
   */
  static invalid(e, n = null) {
    if (!e)
      throw new we("need to specify a reason the Duration is invalid");
    const r = e instanceof Me ? e : new Me(e, n);
    if (fe.throwOnInvalid)
      throw new of(r);
    return new G({ invalid: r });
  }
  /**
   * @private
   */
  static normalizeUnit(e) {
    const n = {
      year: "years",
      years: "years",
      quarter: "quarters",
      quarters: "quarters",
      month: "months",
      months: "months",
      week: "weeks",
      weeks: "weeks",
      day: "days",
      days: "days",
      hour: "hours",
      hours: "hours",
      minute: "minutes",
      minutes: "minutes",
      second: "seconds",
      seconds: "seconds",
      millisecond: "milliseconds",
      milliseconds: "milliseconds"
    }[e && e.toLowerCase()];
    if (!n) throw new Ha(e);
    return n;
  }
  /**
   * Check if an object is a Duration. Works across context boundaries
   * @param {object} o
   * @return {boolean}
   */
  static isDuration(e) {
    return e && e.isLuxonDuration || !1;
  }
  /**
   * Get  the locale of a Duration, such 'en-GB'
   * @type {string}
   */
  get locale() {
    return this.isValid ? this.loc.locale : null;
  }
  /**
   * Get the numbering system of a Duration, such 'beng'. The numbering system is used when formatting the Duration
   *
   * @type {string}
   */
  get numberingSystem() {
    return this.isValid ? this.loc.numberingSystem : null;
  }
  /**
   * Returns a string representation of this Duration formatted according to the specified format string. You may use these tokens:
   * * `S` for milliseconds
   * * `s` for seconds
   * * `m` for minutes
   * * `h` for hours
   * * `d` for days
   * * `w` for weeks
   * * `M` for months
   * * `y` for years
   * Notes:
   * * Add padding by repeating the token, e.g. "yy" pads the years to two digits, "hhhh" pads the hours out to four digits
   * * Tokens can be escaped by wrapping with single quotes.
   * * The duration will be converted to the set of units in the format string using {@link Duration#shiftTo} and the Durations's conversion accuracy setting.
   * @param {string} fmt - the format string
   * @param {Object} opts - options
   * @param {boolean} [opts.floor=true] - floor numerical values
   * @example Duration.fromObject({ years: 1, days: 6, seconds: 2 }).toFormat("y d s") //=> "1 6 2"
   * @example Duration.fromObject({ years: 1, days: 6, seconds: 2 }).toFormat("yy dd sss") //=> "01 06 002"
   * @example Duration.fromObject({ years: 1, days: 6, seconds: 2 }).toFormat("M S") //=> "12 518402000"
   * @return {string}
   */
  toFormat(e, n = {}) {
    const r = {
      ...n,
      floor: n.round !== !1 && n.floor !== !1
    };
    return this.isValid ? be.create(this.loc, r).formatDurationFromString(this, e) : Li;
  }
  /**
   * Returns a string representation of a Duration with all units included.
   * To modify its behavior, use `listStyle` and any Intl.NumberFormat option, though `unitDisplay` is especially relevant.
   * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Intl/NumberFormat/NumberFormat#options
   * @param {Object} opts - Formatting options. Accepts the same keys as the options parameter of the native `Intl.NumberFormat` constructor, as well as `listStyle`.
   * @param {string} [opts.listStyle='narrow'] - How to format the merged list. Corresponds to the `style` property of the options parameter of the native `Intl.ListFormat` constructor.
   * @example
   * ```js
   * var dur = Duration.fromObject({ days: 1, hours: 5, minutes: 6 })
   * dur.toHuman() //=> '1 day, 5 hours, 6 minutes'
   * dur.toHuman({ listStyle: "long" }) //=> '1 day, 5 hours, and 6 minutes'
   * dur.toHuman({ unitDisplay: "short" }) //=> '1 day, 5 hr, 6 min'
   * ```
   */
  toHuman(e = {}) {
    if (!this.isValid) return Li;
    const n = ot.map((r) => {
      const s = this.values[r];
      return P(s) ? null : this.loc.numberFormatter({ style: "unit", unitDisplay: "long", ...e, unit: r.slice(0, -1) }).format(s);
    }).filter((r) => r);
    return this.loc.listFormatter({ type: "conjunction", style: e.listStyle || "narrow", ...e }).format(n);
  }
  /**
   * Returns a JavaScript object with this Duration's values.
   * @example Duration.fromObject({ years: 1, days: 6, seconds: 2 }).toObject() //=> { years: 1, days: 6, seconds: 2 }
   * @return {Object}
   */
  toObject() {
    return this.isValid ? { ...this.values } : {};
  }
  /**
   * Returns an ISO 8601-compliant string representation of this Duration.
   * @see https://en.wikipedia.org/wiki/ISO_8601#Durations
   * @example Duration.fromObject({ years: 3, seconds: 45 }).toISO() //=> 'P3YT45S'
   * @example Duration.fromObject({ months: 4, seconds: 45 }).toISO() //=> 'P4MT45S'
   * @example Duration.fromObject({ months: 5 }).toISO() //=> 'P5M'
   * @example Duration.fromObject({ minutes: 5 }).toISO() //=> 'PT5M'
   * @example Duration.fromObject({ milliseconds: 6 }).toISO() //=> 'PT0.006S'
   * @return {string}
   */
  toISO() {
    if (!this.isValid) return null;
    let e = "P";
    return this.years !== 0 && (e += this.years + "Y"), (this.months !== 0 || this.quarters !== 0) && (e += this.months + this.quarters * 3 + "M"), this.weeks !== 0 && (e += this.weeks + "W"), this.days !== 0 && (e += this.days + "D"), (this.hours !== 0 || this.minutes !== 0 || this.seconds !== 0 || this.milliseconds !== 0) && (e += "T"), this.hours !== 0 && (e += this.hours + "H"), this.minutes !== 0 && (e += this.minutes + "M"), (this.seconds !== 0 || this.milliseconds !== 0) && (e += ss(this.seconds + this.milliseconds / 1e3, 3) + "S"), e === "P" && (e += "T0S"), e;
  }
  /**
   * Returns an ISO 8601-compliant string representation of this Duration, formatted as a time of day.
   * Note that this will return null if the duration is invalid, negative, or equal to or greater than 24 hours.
   * @see https://en.wikipedia.org/wiki/ISO_8601#Times
   * @param {Object} opts - options
   * @param {boolean} [opts.suppressMilliseconds=false] - exclude milliseconds from the format if they're 0
   * @param {boolean} [opts.suppressSeconds=false] - exclude seconds from the format if they're 0
   * @param {boolean} [opts.includePrefix=false] - include the `T` prefix
   * @param {string} [opts.format='extended'] - choose between the basic and extended format
   * @example Duration.fromObject({ hours: 11 }).toISOTime() //=> '11:00:00.000'
   * @example Duration.fromObject({ hours: 11 }).toISOTime({ suppressMilliseconds: true }) //=> '11:00:00'
   * @example Duration.fromObject({ hours: 11 }).toISOTime({ suppressSeconds: true }) //=> '11:00'
   * @example Duration.fromObject({ hours: 11 }).toISOTime({ includePrefix: true }) //=> 'T11:00:00.000'
   * @example Duration.fromObject({ hours: 11 }).toISOTime({ format: 'basic' }) //=> '110000.000'
   * @return {string}
   */
  toISOTime(e = {}) {
    if (!this.isValid) return null;
    const n = this.toMillis();
    return n < 0 || n >= 864e5 ? null : (e = {
      suppressMilliseconds: !1,
      suppressSeconds: !1,
      includePrefix: !1,
      format: "extended",
      ...e,
      includeOffset: !1
    }, x.fromMillis(n, { zone: "UTC" }).toISOTime(e));
  }
  /**
   * Returns an ISO 8601 representation of this Duration appropriate for use in JSON.
   * @return {string}
   */
  toJSON() {
    return this.toISO();
  }
  /**
   * Returns an ISO 8601 representation of this Duration appropriate for use in debugging.
   * @return {string}
   */
  toString() {
    return this.toISO();
  }
  /**
   * Returns a string representation of this Duration appropriate for the REPL.
   * @return {string}
   */
  [Symbol.for("nodejs.util.inspect.custom")]() {
    return this.isValid ? `Duration { values: ${JSON.stringify(this.values)} }` : `Duration { Invalid, reason: ${this.invalidReason} }`;
  }
  /**
   * Returns an milliseconds value of this Duration.
   * @return {number}
   */
  toMillis() {
    return this.isValid ? Ro(this.matrix, this.values) : NaN;
  }
  /**
   * Returns an milliseconds value of this Duration. Alias of {@link toMillis}
   * @return {number}
   */
  valueOf() {
    return this.toMillis();
  }
  /**
   * Make this Duration longer by the specified amount. Return a newly-constructed Duration.
   * @param {Duration|Object|number} duration - The amount to add. Either a Luxon Duration, a number of milliseconds, the object argument to Duration.fromObject()
   * @return {Duration}
   */
  plus(e) {
    if (!this.isValid) return this;
    const n = G.fromDurationLike(e), r = {};
    for (const s of ot)
      (_t(n.values, s) || _t(this.values, s)) && (r[s] = n.get(s) + this.get(s));
    return Ze(this, { values: r }, !0);
  }
  /**
   * Make this Duration shorter by the specified amount. Return a newly-constructed Duration.
   * @param {Duration|Object|number} duration - The amount to subtract. Either a Luxon Duration, a number of milliseconds, the object argument to Duration.fromObject()
   * @return {Duration}
   */
  minus(e) {
    if (!this.isValid) return this;
    const n = G.fromDurationLike(e);
    return this.plus(n.negate());
  }
  /**
   * Scale this Duration by the specified amount. Return a newly-constructed Duration.
   * @param {function} fn - The function to apply to each unit. Arity is 1 or 2: the value of the unit and, optionally, the unit name. Must return a number.
   * @example Duration.fromObject({ hours: 1, minutes: 30 }).mapUnits(x => x * 2) //=> { hours: 2, minutes: 60 }
   * @example Duration.fromObject({ hours: 1, minutes: 30 }).mapUnits((x, u) => u === "hours" ? x * 2 : x) //=> { hours: 2, minutes: 30 }
   * @return {Duration}
   */
  mapUnits(e) {
    if (!this.isValid) return this;
    const n = {};
    for (const r of Object.keys(this.values))
      n[r] = go(e(this.values[r], r));
    return Ze(this, { values: n }, !0);
  }
  /**
   * Get the value of unit.
   * @param {string} unit - a unit such as 'minute' or 'day'
   * @example Duration.fromObject({years: 2, days: 3}).get('years') //=> 2
   * @example Duration.fromObject({years: 2, days: 3}).get('months') //=> 0
   * @example Duration.fromObject({years: 2, days: 3}).get('days') //=> 3
   * @return {number}
   */
  get(e) {
    return this[G.normalizeUnit(e)];
  }
  /**
   * "Set" the values of specified units. Return a newly-constructed Duration.
   * @param {Object} values - a mapping of units to numbers
   * @example dur.set({ years: 2017 })
   * @example dur.set({ hours: 8, minutes: 30 })
   * @return {Duration}
   */
  set(e) {
    if (!this.isValid) return this;
    const n = { ...this.values, ...Ln(e, G.normalizeUnit) };
    return Ze(this, { values: n });
  }
  /**
   * "Set" the locale and/or numberingSystem.  Returns a newly-constructed Duration.
   * @example dur.reconfigure({ locale: 'en-GB' })
   * @return {Duration}
   */
  reconfigure({ locale: e, numberingSystem: n, conversionAccuracy: r, matrix: s } = {}) {
    const a = { loc: this.loc.clone({ locale: e, numberingSystem: n }), matrix: s, conversionAccuracy: r };
    return Ze(this, a);
  }
  /**
   * Return the length of the duration in the specified unit.
   * @param {string} unit - a unit such as 'minutes' or 'days'
   * @example Duration.fromObject({years: 1}).as('days') //=> 365
   * @example Duration.fromObject({years: 1}).as('months') //=> 12
   * @example Duration.fromObject({hours: 60}).as('days') //=> 2.5
   * @return {number}
   */
  as(e) {
    return this.isValid ? this.shiftTo(e).get(e) : NaN;
  }
  /**
   * Reduce this Duration to its canonical representation in its current units.
   * Assuming the overall value of the Duration is positive, this means:
   * - excessive values for lower-order units are converted to higher-order units (if possible, see first and second example)
   * - negative lower-order units are converted to higher order units (there must be such a higher order unit, otherwise
   *   the overall value would be negative, see third example)
   * - fractional values for higher-order units are converted to lower-order units (if possible, see fourth example)
   *
   * If the overall value is negative, the result of this method is equivalent to `this.negate().normalize().negate()`.
   * @example Duration.fromObject({ years: 2, days: 5000 }).normalize().toObject() //=> { years: 15, days: 255 }
   * @example Duration.fromObject({ days: 5000 }).normalize().toObject() //=> { days: 5000 }
   * @example Duration.fromObject({ hours: 12, minutes: -45 }).normalize().toObject() //=> { hours: 11, minutes: 15 }
   * @example Duration.fromObject({ years: 2.5, days: 0, hours: 0 }).normalize().toObject() //=> { years: 2, days: 182, hours: 12 }
   * @return {Duration}
   */
  normalize() {
    if (!this.isValid) return this;
    const e = this.toObject();
    return Pi(this.matrix, e), Ze(this, { values: e }, !0);
  }
  /**
   * Rescale units to its largest representation
   * @example Duration.fromObject({ milliseconds: 90000 }).rescale().toObject() //=> { minutes: 1, seconds: 30 }
   * @return {Duration}
   */
  rescale() {
    if (!this.isValid) return this;
    const e = Pd(this.normalize().shiftToAll().toObject());
    return Ze(this, { values: e }, !0);
  }
  /**
   * Convert this Duration into its representation in a different set of units.
   * @example Duration.fromObject({ hours: 1, seconds: 30 }).shiftTo('minutes', 'milliseconds').toObject() //=> { minutes: 60, milliseconds: 30000 }
   * @return {Duration}
   */
  shiftTo(...e) {
    if (!this.isValid) return this;
    if (e.length === 0)
      return this;
    e = e.map((a) => G.normalizeUnit(a));
    const n = {}, r = {}, s = this.toObject();
    let i;
    for (const a of ot)
      if (e.indexOf(a) >= 0) {
        i = a;
        let u = 0;
        for (const l in r)
          u += this.matrix[l][a] * r[l], r[l] = 0;
        et(s[a]) && (u += s[a]);
        const c = Math.trunc(u);
        n[a] = c, r[a] = (u * 1e3 - c * 1e3) / 1e3;
      } else et(s[a]) && (r[a] = s[a]);
    for (const a in r)
      r[a] !== 0 && (n[i] += a === i ? r[a] : r[a] / this.matrix[i][a]);
    return Pi(this.matrix, n), Ze(this, { values: n }, !0);
  }
  /**
   * Shift this Duration to all available units.
   * Same as shiftTo("years", "months", "weeks", "days", "hours", "minutes", "seconds", "milliseconds")
   * @return {Duration}
   */
  shiftToAll() {
    return this.isValid ? this.shiftTo(
      "years",
      "months",
      "weeks",
      "days",
      "hours",
      "minutes",
      "seconds",
      "milliseconds"
    ) : this;
  }
  /**
   * Return the negative of this Duration.
   * @example Duration.fromObject({ hours: 1, seconds: 30 }).negate().toObject() //=> { hours: -1, seconds: -30 }
   * @return {Duration}
   */
  negate() {
    if (!this.isValid) return this;
    const e = {};
    for (const n of Object.keys(this.values))
      e[n] = this.values[n] === 0 ? 0 : -this.values[n];
    return Ze(this, { values: e }, !0);
  }
  /**
   * Get the years.
   * @type {number}
   */
  get years() {
    return this.isValid ? this.values.years || 0 : NaN;
  }
  /**
   * Get the quarters.
   * @type {number}
   */
  get quarters() {
    return this.isValid ? this.values.quarters || 0 : NaN;
  }
  /**
   * Get the months.
   * @type {number}
   */
  get months() {
    return this.isValid ? this.values.months || 0 : NaN;
  }
  /**
   * Get the weeks
   * @type {number}
   */
  get weeks() {
    return this.isValid ? this.values.weeks || 0 : NaN;
  }
  /**
   * Get the days.
   * @type {number}
   */
  get days() {
    return this.isValid ? this.values.days || 0 : NaN;
  }
  /**
   * Get the hours.
   * @type {number}
   */
  get hours() {
    return this.isValid ? this.values.hours || 0 : NaN;
  }
  /**
   * Get the minutes.
   * @type {number}
   */
  get minutes() {
    return this.isValid ? this.values.minutes || 0 : NaN;
  }
  /**
   * Get the seconds.
   * @return {number}
   */
  get seconds() {
    return this.isValid ? this.values.seconds || 0 : NaN;
  }
  /**
   * Get the milliseconds.
   * @return {number}
   */
  get milliseconds() {
    return this.isValid ? this.values.milliseconds || 0 : NaN;
  }
  /**
   * Returns whether the Duration is invalid. Invalid durations are returned by diff operations
   * on invalid DateTimes or Intervals.
   * @return {boolean}
   */
  get isValid() {
    return this.invalid === null;
  }
  /**
   * Returns an error code if this Duration became invalid, or null if the Duration is valid
   * @return {string}
   */
  get invalidReason() {
    return this.invalid ? this.invalid.reason : null;
  }
  /**
   * Returns an explanation of why this Duration became invalid, or null if the Duration is valid
   * @type {string}
   */
  get invalidExplanation() {
    return this.invalid ? this.invalid.explanation : null;
  }
  /**
   * Equality check
   * Two Durations are equal iff they have the same units and the same values for each unit.
   * @param {Duration} other
   * @return {boolean}
   */
  equals(e) {
    if (!this.isValid || !e.isValid || !this.loc.equals(e.loc))
      return !1;
    function n(r, s) {
      return r === void 0 || r === 0 ? s === void 0 || s === 0 : r === s;
    }
    for (const r of ot)
      if (!n(this.values[r], e.values[r]))
        return !1;
    return !0;
  }
}
const gt = "Invalid Interval";
function Vd(t, e) {
  return !t || !t.isValid ? le.invalid("missing or invalid start") : !e || !e.isValid ? le.invalid("missing or invalid end") : e < t ? le.invalid(
    "end before start",
    `The end of an interval must be after its start, but you had start=${t.toISO()} and end=${e.toISO()}`
  ) : null;
}
class le {
  /**
   * @private
   */
  constructor(e) {
    this.s = e.start, this.e = e.end, this.invalid = e.invalid || null, this.isLuxonInterval = !0;
  }
  /**
   * Create an invalid Interval.
   * @param {string} reason - simple string of why this Interval is invalid. Should not contain parameters or anything else data-dependent
   * @param {string} [explanation=null] - longer explanation, may include parameters and other useful debugging information
   * @return {Interval}
   */
  static invalid(e, n = null) {
    if (!e)
      throw new we("need to specify a reason the Interval is invalid");
    const r = e instanceof Me ? e : new Me(e, n);
    if (fe.throwOnInvalid)
      throw new af(r);
    return new le({ invalid: r });
  }
  /**
   * Create an Interval from a start DateTime and an end DateTime. Inclusive of the start but not the end.
   * @param {DateTime|Date|Object} start
   * @param {DateTime|Date|Object} end
   * @return {Interval}
   */
  static fromDateTimes(e, n) {
    const r = Pt(e), s = Pt(n), i = Vd(r, s);
    return i ?? new le({
      start: r,
      end: s
    });
  }
  /**
   * Create an Interval from a start DateTime and a Duration to extend to.
   * @param {DateTime|Date|Object} start
   * @param {Duration|Object|number} duration - the length of the Interval.
   * @return {Interval}
   */
  static after(e, n) {
    const r = G.fromDurationLike(n), s = Pt(e);
    return le.fromDateTimes(s, s.plus(r));
  }
  /**
   * Create an Interval from an end DateTime and a Duration to extend backwards to.
   * @param {DateTime|Date|Object} end
   * @param {Duration|Object|number} duration - the length of the Interval.
   * @return {Interval}
   */
  static before(e, n) {
    const r = G.fromDurationLike(n), s = Pt(e);
    return le.fromDateTimes(s.minus(r), s);
  }
  /**
   * Create an Interval from an ISO 8601 string.
   * Accepts `<start>/<end>`, `<start>/<duration>`, and `<duration>/<end>` formats.
   * @param {string} text - the ISO string to parse
   * @param {Object} [opts] - options to pass {@link DateTime#fromISO} and optionally {@link Duration#fromISO}
   * @see https://en.wikipedia.org/wiki/ISO_8601#Time_intervals
   * @return {Interval}
   */
  static fromISO(e, n) {
    const [r, s] = (e || "").split("/", 2);
    if (r && s) {
      let i, a;
      try {
        i = x.fromISO(r, n), a = i.isValid;
      } catch {
        a = !1;
      }
      let u, c;
      try {
        u = x.fromISO(s, n), c = u.isValid;
      } catch {
        c = !1;
      }
      if (a && c)
        return le.fromDateTimes(i, u);
      if (a) {
        const l = G.fromISO(s, n);
        if (l.isValid)
          return le.after(i, l);
      } else if (c) {
        const l = G.fromISO(r, n);
        if (l.isValid)
          return le.before(u, l);
      }
    }
    return le.invalid("unparsable", `the input "${e}" can't be parsed as ISO 8601`);
  }
  /**
   * Check if an object is an Interval. Works across context boundaries
   * @param {object} o
   * @return {boolean}
   */
  static isInterval(e) {
    return e && e.isLuxonInterval || !1;
  }
  /**
   * Returns the start of the Interval
   * @type {DateTime}
   */
  get start() {
    return this.isValid ? this.s : null;
  }
  /**
   * Returns the end of the Interval
   * @type {DateTime}
   */
  get end() {
    return this.isValid ? this.e : null;
  }
  /**
   * Returns whether this Interval's end is at least its start, meaning that the Interval isn't 'backwards'.
   * @type {boolean}
   */
  get isValid() {
    return this.invalidReason === null;
  }
  /**
   * Returns an error code if this Interval is invalid, or null if the Interval is valid
   * @type {string}
   */
  get invalidReason() {
    return this.invalid ? this.invalid.reason : null;
  }
  /**
   * Returns an explanation of why this Interval became invalid, or null if the Interval is valid
   * @type {string}
   */
  get invalidExplanation() {
    return this.invalid ? this.invalid.explanation : null;
  }
  /**
   * Returns the length of the Interval in the specified unit.
   * @param {string} unit - the unit (such as 'hours' or 'days') to return the length in.
   * @return {number}
   */
  length(e = "milliseconds") {
    return this.isValid ? this.toDuration(e).get(e) : NaN;
  }
  /**
   * Returns the count of minutes, hours, days, months, or years included in the Interval, even in part.
   * Unlike {@link Interval#length} this counts sections of the calendar, not periods of time, e.g. specifying 'day'
   * asks 'what dates are included in this interval?', not 'how many days long is this interval?'
   * @param {string} [unit='milliseconds'] - the unit of time to count.
   * @param {Object} opts - options
   * @param {boolean} [opts.useLocaleWeeks=false] - If true, use weeks based on the locale, i.e. use the locale-dependent start of the week; this operation will always use the locale of the start DateTime
   * @return {number}
   */
  count(e = "milliseconds", n) {
    if (!this.isValid) return NaN;
    const r = this.start.startOf(e, n);
    let s;
    return n?.useLocaleWeeks ? s = this.end.reconfigure({ locale: r.locale }) : s = this.end, s = s.startOf(e, n), Math.floor(s.diff(r, e).get(e)) + (s.valueOf() !== this.end.valueOf());
  }
  /**
   * Returns whether this Interval's start and end are both in the same unit of time
   * @param {string} unit - the unit of time to check sameness on
   * @return {boolean}
   */
  hasSame(e) {
    return this.isValid ? this.isEmpty() || this.e.minus(1).hasSame(this.s, e) : !1;
  }
  /**
   * Return whether this Interval has the same start and end DateTimes.
   * @return {boolean}
   */
  isEmpty() {
    return this.s.valueOf() === this.e.valueOf();
  }
  /**
   * Return whether this Interval's start is after the specified DateTime.
   * @param {DateTime} dateTime
   * @return {boolean}
   */
  isAfter(e) {
    return this.isValid ? this.s > e : !1;
  }
  /**
   * Return whether this Interval's end is before the specified DateTime.
   * @param {DateTime} dateTime
   * @return {boolean}
   */
  isBefore(e) {
    return this.isValid ? this.e <= e : !1;
  }
  /**
   * Return whether this Interval contains the specified DateTime.
   * @param {DateTime} dateTime
   * @return {boolean}
   */
  contains(e) {
    return this.isValid ? this.s <= e && this.e > e : !1;
  }
  /**
   * "Sets" the start and/or end dates. Returns a newly-constructed Interval.
   * @param {Object} values - the values to set
   * @param {DateTime} values.start - the starting DateTime
   * @param {DateTime} values.end - the ending DateTime
   * @return {Interval}
   */
  set({ start: e, end: n } = {}) {
    return this.isValid ? le.fromDateTimes(e || this.s, n || this.e) : this;
  }
  /**
   * Split this Interval at each of the specified DateTimes
   * @param {...DateTime} dateTimes - the unit of time to count.
   * @return {Array}
   */
  splitAt(...e) {
    if (!this.isValid) return [];
    const n = e.map(Pt).filter((a) => this.contains(a)).sort((a, u) => a.toMillis() - u.toMillis()), r = [];
    let { s } = this, i = 0;
    for (; s < this.e; ) {
      const a = n[i] || this.e, u = +a > +this.e ? this.e : a;
      r.push(le.fromDateTimes(s, u)), s = u, i += 1;
    }
    return r;
  }
  /**
   * Split this Interval into smaller Intervals, each of the specified length.
   * Left over time is grouped into a smaller interval
   * @param {Duration|Object|number} duration - The length of each resulting interval.
   * @return {Array}
   */
  splitBy(e) {
    const n = G.fromDurationLike(e);
    if (!this.isValid || !n.isValid || n.as("milliseconds") === 0)
      return [];
    let { s: r } = this, s = 1, i;
    const a = [];
    for (; r < this.e; ) {
      const u = this.start.plus(n.mapUnits((c) => c * s));
      i = +u > +this.e ? this.e : u, a.push(le.fromDateTimes(r, i)), r = i, s += 1;
    }
    return a;
  }
  /**
   * Split this Interval into the specified number of smaller intervals.
   * @param {number} numberOfParts - The number of Intervals to divide the Interval into.
   * @return {Array}
   */
  divideEqually(e) {
    return this.isValid ? this.splitBy(this.length() / e).slice(0, e) : [];
  }
  /**
   * Return whether this Interval overlaps with the specified Interval
   * @param {Interval} other
   * @return {boolean}
   */
  overlaps(e) {
    return this.e > e.s && this.s < e.e;
  }
  /**
   * Return whether this Interval's end is adjacent to the specified Interval's start.
   * @param {Interval} other
   * @return {boolean}
   */
  abutsStart(e) {
    return this.isValid ? +this.e == +e.s : !1;
  }
  /**
   * Return whether this Interval's start is adjacent to the specified Interval's end.
   * @param {Interval} other
   * @return {boolean}
   */
  abutsEnd(e) {
    return this.isValid ? +e.e == +this.s : !1;
  }
  /**
   * Returns true if this Interval fully contains the specified Interval, specifically if the intersect (of this Interval and the other Interval) is equal to the other Interval; false otherwise.
   * @param {Interval} other
   * @return {boolean}
   */
  engulfs(e) {
    return this.isValid ? this.s <= e.s && this.e >= e.e : !1;
  }
  /**
   * Return whether this Interval has the same start and end as the specified Interval.
   * @param {Interval} other
   * @return {boolean}
   */
  equals(e) {
    return !this.isValid || !e.isValid ? !1 : this.s.equals(e.s) && this.e.equals(e.e);
  }
  /**
   * Return an Interval representing the intersection of this Interval and the specified Interval.
   * Specifically, the resulting Interval has the maximum start time and the minimum end time of the two Intervals.
   * Returns null if the intersection is empty, meaning, the intervals don't intersect.
   * @param {Interval} other
   * @return {Interval}
   */
  intersection(e) {
    if (!this.isValid) return this;
    const n = this.s > e.s ? this.s : e.s, r = this.e < e.e ? this.e : e.e;
    return n >= r ? null : le.fromDateTimes(n, r);
  }
  /**
   * Return an Interval representing the union of this Interval and the specified Interval.
   * Specifically, the resulting Interval has the minimum start time and the maximum end time of the two Intervals.
   * @param {Interval} other
   * @return {Interval}
   */
  union(e) {
    if (!this.isValid) return this;
    const n = this.s < e.s ? this.s : e.s, r = this.e > e.e ? this.e : e.e;
    return le.fromDateTimes(n, r);
  }
  /**
   * Merge an array of Intervals into a equivalent minimal set of Intervals.
   * Combines overlapping and adjacent Intervals.
   * @param {Array} intervals
   * @return {Array}
   */
  static merge(e) {
    const [n, r] = e.sort((s, i) => s.s - i.s).reduce(
      ([s, i], a) => i ? i.overlaps(a) || i.abutsStart(a) ? [s, i.union(a)] : [s.concat([i]), a] : [s, a],
      [[], null]
    );
    return r && n.push(r), n;
  }
  /**
   * Return an array of Intervals representing the spans of time that only appear in one of the specified Intervals.
   * @param {Array} intervals
   * @return {Array}
   */
  static xor(e) {
    let n = null, r = 0;
    const s = [], i = e.map((c) => [
      { time: c.s, type: "s" },
      { time: c.e, type: "e" }
    ]), a = Array.prototype.concat(...i), u = a.sort((c, l) => c.time - l.time);
    for (const c of u)
      r += c.type === "s" ? 1 : -1, r === 1 ? n = c.time : (n && +n != +c.time && s.push(le.fromDateTimes(n, c.time)), n = null);
    return le.merge(s);
  }
  /**
   * Return an Interval representing the span of time in this Interval that doesn't overlap with any of the specified Intervals.
   * @param {...Interval} intervals
   * @return {Array}
   */
  difference(...e) {
    return le.xor([this].concat(e)).map((n) => this.intersection(n)).filter((n) => n && !n.isEmpty());
  }
  /**
   * Returns a string representation of this Interval appropriate for debugging.
   * @return {string}
   */
  toString() {
    return this.isValid ? `[${this.s.toISO()} – ${this.e.toISO()})` : gt;
  }
  /**
   * Returns a string representation of this Interval appropriate for the REPL.
   * @return {string}
   */
  [Symbol.for("nodejs.util.inspect.custom")]() {
    return this.isValid ? `Interval { start: ${this.s.toISO()}, end: ${this.e.toISO()} }` : `Interval { Invalid, reason: ${this.invalidReason} }`;
  }
  /**
   * Returns a localized string representing this Interval. Accepts the same options as the
   * Intl.DateTimeFormat constructor and any presets defined by Luxon, such as
   * {@link DateTime.DATE_FULL} or {@link DateTime.TIME_SIMPLE}. The exact behavior of this method
   * is browser-specific, but in general it will return an appropriate representation of the
   * Interval in the assigned locale. Defaults to the system's locale if no locale has been
   * specified.
   * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DateTimeFormat
   * @param {Object} [formatOpts=DateTime.DATE_SHORT] - Either a DateTime preset or
   * Intl.DateTimeFormat constructor options.
   * @param {Object} opts - Options to override the configuration of the start DateTime.
   * @example Interval.fromISO('2022-11-07T09:00Z/2022-11-08T09:00Z').toLocaleString(); //=> 11/7/2022 – 11/8/2022
   * @example Interval.fromISO('2022-11-07T09:00Z/2022-11-08T09:00Z').toLocaleString(DateTime.DATE_FULL); //=> November 7 – 8, 2022
   * @example Interval.fromISO('2022-11-07T09:00Z/2022-11-08T09:00Z').toLocaleString(DateTime.DATE_FULL, { locale: 'fr-FR' }); //=> 7–8 novembre 2022
   * @example Interval.fromISO('2022-11-07T17:00Z/2022-11-07T19:00Z').toLocaleString(DateTime.TIME_SIMPLE); //=> 6:00 – 8:00 PM
   * @example Interval.fromISO('2022-11-07T17:00Z/2022-11-07T19:00Z').toLocaleString({ weekday: 'short', month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit' }); //=> Mon, Nov 07, 6:00 – 8:00 p
   * @return {string}
   */
  toLocaleString(e = Rn, n = {}) {
    return this.isValid ? be.create(this.s.loc.clone(n), e).formatInterval(this) : gt;
  }
  /**
   * Returns an ISO 8601-compliant string representation of this Interval.
   * @see https://en.wikipedia.org/wiki/ISO_8601#Time_intervals
   * @param {Object} opts - The same options as {@link DateTime#toISO}
   * @return {string}
   */
  toISO(e) {
    return this.isValid ? `${this.s.toISO(e)}/${this.e.toISO(e)}` : gt;
  }
  /**
   * Returns an ISO 8601-compliant string representation of date of this Interval.
   * The time components are ignored.
   * @see https://en.wikipedia.org/wiki/ISO_8601#Time_intervals
   * @return {string}
   */
  toISODate() {
    return this.isValid ? `${this.s.toISODate()}/${this.e.toISODate()}` : gt;
  }
  /**
   * Returns an ISO 8601-compliant string representation of time of this Interval.
   * The date components are ignored.
   * @see https://en.wikipedia.org/wiki/ISO_8601#Time_intervals
   * @param {Object} opts - The same options as {@link DateTime#toISO}
   * @return {string}
   */
  toISOTime(e) {
    return this.isValid ? `${this.s.toISOTime(e)}/${this.e.toISOTime(e)}` : gt;
  }
  /**
   * Returns a string representation of this Interval formatted according to the specified format
   * string. **You may not want this.** See {@link Interval#toLocaleString} for a more flexible
   * formatting tool.
   * @param {string} dateFormat - The format string. This string formats the start and end time.
   * See {@link DateTime#toFormat} for details.
   * @param {Object} opts - Options.
   * @param {string} [opts.separator =  ' – '] - A separator to place between the start and end
   * representations.
   * @return {string}
   */
  toFormat(e, { separator: n = " – " } = {}) {
    return this.isValid ? `${this.s.toFormat(e)}${n}${this.e.toFormat(e)}` : gt;
  }
  /**
   * Return a Duration representing the time spanned by this interval.
   * @param {string|string[]} [unit=['milliseconds']] - the unit or units (such as 'hours' or 'days') to include in the duration.
   * @param {Object} opts - options that affect the creation of the Duration
   * @param {string} [opts.conversionAccuracy='casual'] - the conversion system to use
   * @example Interval.fromDateTimes(dt1, dt2).toDuration().toObject() //=> { milliseconds: 88489257 }
   * @example Interval.fromDateTimes(dt1, dt2).toDuration('days').toObject() //=> { days: 1.0241812152777778 }
   * @example Interval.fromDateTimes(dt1, dt2).toDuration(['hours', 'minutes']).toObject() //=> { hours: 24, minutes: 34.82095 }
   * @example Interval.fromDateTimes(dt1, dt2).toDuration(['hours', 'minutes', 'seconds']).toObject() //=> { hours: 24, minutes: 34, seconds: 49.257 }
   * @example Interval.fromDateTimes(dt1, dt2).toDuration('seconds').toObject() //=> { seconds: 88489.257 }
   * @return {Duration}
   */
  toDuration(e, n) {
    return this.isValid ? this.e.diff(this.s, e, n) : G.invalid(this.invalidReason);
  }
  /**
   * Run mapFn on the interval start and end, returning a new Interval from the resulting DateTimes
   * @param {function} mapFn
   * @return {Interval}
   * @example Interval.fromDateTimes(dt1, dt2).mapEndpoints(endpoint => endpoint.toUTC())
   * @example Interval.fromDateTimes(dt1, dt2).mapEndpoints(endpoint => endpoint.plus({ hours: 2 }))
   */
  mapEndpoints(e) {
    return le.fromDateTimes(e(this.s), e(this.e));
  }
}
class En {
  /**
   * Return whether the specified zone contains a DST.
   * @param {string|Zone} [zone='local'] - Zone to check. Defaults to the environment's local zone.
   * @return {boolean}
   */
  static hasDST(e = fe.defaultZone) {
    const n = x.now().setZone(e).set({ month: 12 });
    return !e.isUniversal && n.offset !== n.set({ month: 6 }).offset;
  }
  /**
   * Return whether the specified zone is a valid IANA specifier.
   * @param {string} zone - Zone to check
   * @return {boolean}
   */
  static isValidIANAZone(e) {
    return $e.isValidZone(e);
  }
  /**
   * Converts the input into a {@link Zone} instance.
   *
   * * If `input` is already a Zone instance, it is returned unchanged.
   * * If `input` is a string containing a valid time zone name, a Zone instance
   *   with that name is returned.
   * * If `input` is a string that doesn't refer to a known time zone, a Zone
   *   instance with {@link Zone#isValid} == false is returned.
   * * If `input is a number, a Zone instance with the specified fixed offset
   *   in minutes is returned.
   * * If `input` is `null` or `undefined`, the default zone is returned.
   * @param {string|Zone|number} [input] - the value to be converted
   * @return {Zone}
   */
  static normalizeZone(e) {
    return Ke(e, fe.defaultZone);
  }
  /**
   * Get the weekday on which the week starts according to the given locale.
   * @param {Object} opts - options
   * @param {string} [opts.locale] - the locale code
   * @param {string} [opts.locObj=null] - an existing locale object to use
   * @returns {number} the start of the week, 1 for Monday through 7 for Sunday
   */
  static getStartOfWeek({ locale: e = null, locObj: n = null } = {}) {
    return (n || K.create(e)).getStartOfWeek();
  }
  /**
   * Get the minimum number of days necessary in a week before it is considered part of the next year according
   * to the given locale.
   * @param {Object} opts - options
   * @param {string} [opts.locale] - the locale code
   * @param {string} [opts.locObj=null] - an existing locale object to use
   * @returns {number}
   */
  static getMinimumDaysInFirstWeek({ locale: e = null, locObj: n = null } = {}) {
    return (n || K.create(e)).getMinDaysInFirstWeek();
  }
  /**
   * Get the weekdays, which are considered the weekend according to the given locale
   * @param {Object} opts - options
   * @param {string} [opts.locale] - the locale code
   * @param {string} [opts.locObj=null] - an existing locale object to use
   * @returns {number[]} an array of weekdays, 1 for Monday through 7 for Sunday
   */
  static getWeekendWeekdays({ locale: e = null, locObj: n = null } = {}) {
    return (n || K.create(e)).getWeekendDays().slice();
  }
  /**
   * Return an array of standalone month names.
   * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DateTimeFormat
   * @param {string} [length='long'] - the length of the month representation, such as "numeric", "2-digit", "narrow", "short", "long"
   * @param {Object} opts - options
   * @param {string} [opts.locale] - the locale code
   * @param {string} [opts.numberingSystem=null] - the numbering system
   * @param {string} [opts.locObj=null] - an existing locale object to use
   * @param {string} [opts.outputCalendar='gregory'] - the calendar
   * @example Info.months()[0] //=> 'January'
   * @example Info.months('short')[0] //=> 'Jan'
   * @example Info.months('numeric')[0] //=> '1'
   * @example Info.months('short', { locale: 'fr-CA' } )[0] //=> 'janv.'
   * @example Info.months('numeric', { locale: 'ar' })[0] //=> '١'
   * @example Info.months('long', { outputCalendar: 'islamic' })[0] //=> 'Rabiʻ I'
   * @return {Array}
   */
  static months(e = "long", { locale: n = null, numberingSystem: r = null, locObj: s = null, outputCalendar: i = "gregory" } = {}) {
    return (s || K.create(n, r, i)).months(e);
  }
  /**
   * Return an array of format month names.
   * Format months differ from standalone months in that they're meant to appear next to the day of the month. In some languages, that
   * changes the string.
   * See {@link Info#months}
   * @param {string} [length='long'] - the length of the month representation, such as "numeric", "2-digit", "narrow", "short", "long"
   * @param {Object} opts - options
   * @param {string} [opts.locale] - the locale code
   * @param {string} [opts.numberingSystem=null] - the numbering system
   * @param {string} [opts.locObj=null] - an existing locale object to use
   * @param {string} [opts.outputCalendar='gregory'] - the calendar
   * @return {Array}
   */
  static monthsFormat(e = "long", { locale: n = null, numberingSystem: r = null, locObj: s = null, outputCalendar: i = "gregory" } = {}) {
    return (s || K.create(n, r, i)).months(e, !0);
  }
  /**
   * Return an array of standalone week names.
   * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DateTimeFormat
   * @param {string} [length='long'] - the length of the weekday representation, such as "narrow", "short", "long".
   * @param {Object} opts - options
   * @param {string} [opts.locale] - the locale code
   * @param {string} [opts.numberingSystem=null] - the numbering system
   * @param {string} [opts.locObj=null] - an existing locale object to use
   * @example Info.weekdays()[0] //=> 'Monday'
   * @example Info.weekdays('short')[0] //=> 'Mon'
   * @example Info.weekdays('short', { locale: 'fr-CA' })[0] //=> 'lun.'
   * @example Info.weekdays('short', { locale: 'ar' })[0] //=> 'الاثنين'
   * @return {Array}
   */
  static weekdays(e = "long", { locale: n = null, numberingSystem: r = null, locObj: s = null } = {}) {
    return (s || K.create(n, r, null)).weekdays(e);
  }
  /**
   * Return an array of format week names.
   * Format weekdays differ from standalone weekdays in that they're meant to appear next to more date information. In some languages, that
   * changes the string.
   * See {@link Info#weekdays}
   * @param {string} [length='long'] - the length of the month representation, such as "narrow", "short", "long".
   * @param {Object} opts - options
   * @param {string} [opts.locale=null] - the locale code
   * @param {string} [opts.numberingSystem=null] - the numbering system
   * @param {string} [opts.locObj=null] - an existing locale object to use
   * @return {Array}
   */
  static weekdaysFormat(e = "long", { locale: n = null, numberingSystem: r = null, locObj: s = null } = {}) {
    return (s || K.create(n, r, null)).weekdays(e, !0);
  }
  /**
   * Return an array of meridiems.
   * @param {Object} opts - options
   * @param {string} [opts.locale] - the locale code
   * @example Info.meridiems() //=> [ 'AM', 'PM' ]
   * @example Info.meridiems({ locale: 'my' }) //=> [ 'နံနက်', 'ညနေ' ]
   * @return {Array}
   */
  static meridiems({ locale: e = null } = {}) {
    return K.create(e).meridiems();
  }
  /**
   * Return an array of eras, such as ['BC', 'AD']. The locale can be specified, but the calendar system is always Gregorian.
   * @param {string} [length='short'] - the length of the era representation, such as "short" or "long".
   * @param {Object} opts - options
   * @param {string} [opts.locale] - the locale code
   * @example Info.eras() //=> [ 'BC', 'AD' ]
   * @example Info.eras('long') //=> [ 'Before Christ', 'Anno Domini' ]
   * @example Info.eras('long', { locale: 'fr' }) //=> [ 'avant Jésus-Christ', 'après Jésus-Christ' ]
   * @return {Array}
   */
  static eras(e = "short", { locale: n = null } = {}) {
    return K.create(n, null, "gregory").eras(e);
  }
  /**
   * Return the set of available features in this environment.
   * Some features of Luxon are not available in all environments. For example, on older browsers, relative time formatting support is not available. Use this function to figure out if that's the case.
   * Keys:
   * * `relative`: whether this environment supports relative time formatting
   * * `localeWeek`: whether this environment supports different weekdays for the start of the week based on the locale
   * @example Info.features() //=> { relative: false, localeWeek: true }
   * @return {Object}
   */
  static features() {
    return { relative: mo(), localeWeek: yo() };
  }
}
function Vi(t, e) {
  const n = (s) => s.toUTC(0, { keepLocalTime: !0 }).startOf("day").valueOf(), r = n(e) - n(t);
  return Math.floor(G.fromMillis(r).as("days"));
}
function Wd(t, e, n) {
  const r = [
    ["years", (c, l) => l.year - c.year],
    ["quarters", (c, l) => l.quarter - c.quarter + (l.year - c.year) * 4],
    ["months", (c, l) => l.month - c.month + (l.year - c.year) * 12],
    [
      "weeks",
      (c, l) => {
        const d = Vi(c, l);
        return (d - d % 7) / 7;
      }
    ],
    ["days", Vi]
  ], s = {}, i = t;
  let a, u;
  for (const [c, l] of r)
    n.indexOf(c) >= 0 && (a = c, s[c] = l(t, e), u = i.plus(s), u > e ? (s[c]--, t = i.plus(s), t > e && (u = t, s[c]--, t = i.plus(s))) : t = u);
  return [t, s, u, a];
}
function Ud(t, e, n, r) {
  let [s, i, a, u] = Wd(t, e, n);
  const c = e - s, l = n.filter(
    (m) => ["hours", "minutes", "seconds", "milliseconds"].indexOf(m) >= 0
  );
  l.length === 0 && (a < e && (a = s.plus({ [u]: 1 })), a !== s && (i[u] = (i[u] || 0) + c / (a - s)));
  const d = G.fromObject(i, r);
  return l.length > 0 ? G.fromMillis(c, r).shiftTo(...l).plus(d) : d;
}
const $d = "missing Intl.DateTimeFormat.formatToParts support";
function J(t, e = (n) => n) {
  return { regex: t, deser: ([n]) => e(Cf(n)) };
}
const Hd = " ", Mo = `[ ${Hd}]`, Fo = new RegExp(Mo, "g");
function jd(t) {
  return t.replace(/\./g, "\\.?").replace(Fo, Mo);
}
function Wi(t) {
  return t.replace(/\./g, "").replace(Fo, " ").toLowerCase();
}
function xe(t, e) {
  return t === null ? null : {
    regex: RegExp(t.map(jd).join("|")),
    deser: ([n]) => t.findIndex((r) => Wi(n) === Wi(r)) + e
  };
}
function Ui(t, e) {
  return { regex: t, deser: ([, n, r]) => jn(n, r), groups: e };
}
function wn(t) {
  return { regex: t, deser: ([e]) => e };
}
function zd(t) {
  return t.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g, "\\$&");
}
function Bd(t, e) {
  const n = Ae(e), r = Ae(e, "{2}"), s = Ae(e, "{3}"), i = Ae(e, "{4}"), a = Ae(e, "{6}"), u = Ae(e, "{1,2}"), c = Ae(e, "{1,3}"), l = Ae(e, "{1,6}"), d = Ae(e, "{1,9}"), m = Ae(e, "{2,4}"), T = Ae(e, "{4,6}"), E = (w) => ({ regex: RegExp(zd(w.val)), deser: ([v]) => v, literal: !0 }), _ = ((w) => {
    if (t.literal)
      return E(w);
    switch (w.val) {
      case "G":
        return xe(e.eras("short"), 0);
      case "GG":
        return xe(e.eras("long"), 0);
      case "y":
        return J(l);
      case "yy":
        return J(m, Yr);
      case "yyyy":
        return J(i);
      case "yyyyy":
        return J(T);
      case "yyyyyy":
        return J(a);
      case "M":
        return J(u);
      case "MM":
        return J(r);
      case "MMM":
        return xe(e.months("short", !0), 1);
      case "MMMM":
        return xe(e.months("long", !0), 1);
      case "L":
        return J(u);
      case "LL":
        return J(r);
      case "LLL":
        return xe(e.months("short", !1), 1);
      case "LLLL":
        return xe(e.months("long", !1), 1);
      case "d":
        return J(u);
      case "dd":
        return J(r);
      case "o":
        return J(c);
      case "ooo":
        return J(s);
      case "HH":
        return J(r);
      case "H":
        return J(u);
      case "hh":
        return J(r);
      case "h":
        return J(u);
      case "mm":
        return J(r);
      case "m":
        return J(u);
      case "q":
        return J(u);
      case "qq":
        return J(r);
      case "s":
        return J(u);
      case "ss":
        return J(r);
      case "S":
        return J(c);
      case "SSS":
        return J(s);
      case "u":
        return wn(d);
      case "uu":
        return wn(u);
      case "uuu":
        return J(n);
      case "a":
        return xe(e.meridiems(), 0);
      case "kkkk":
        return J(i);
      case "kk":
        return J(m, Yr);
      case "W":
        return J(u);
      case "WW":
        return J(r);
      case "E":
      case "c":
        return J(n);
      case "EEE":
        return xe(e.weekdays("short", !1), 1);
      case "EEEE":
        return xe(e.weekdays("long", !1), 1);
      case "ccc":
        return xe(e.weekdays("short", !0), 1);
      case "cccc":
        return xe(e.weekdays("long", !0), 1);
      case "Z":
      case "ZZ":
        return Ui(new RegExp(`([+-]${u.source})(?::(${r.source}))?`), 2);
      case "ZZZ":
        return Ui(new RegExp(`([+-]${u.source})(${r.source})?`), 2);
      case "z":
        return wn(/[a-z_+-/]{1,256}?/i);
      case " ":
        return wn(/[^\S\n\r]/);
      default:
        return E(w);
    }
  })(t) || {
    invalidReason: $d
  };
  return _.token = t, _;
}
const Yd = {
  year: {
    "2-digit": "yy",
    numeric: "yyyyy"
  },
  month: {
    numeric: "M",
    "2-digit": "MM",
    short: "MMM",
    long: "MMMM"
  },
  day: {
    numeric: "d",
    "2-digit": "dd"
  },
  weekday: {
    short: "EEE",
    long: "EEEE"
  },
  dayperiod: "a",
  dayPeriod: "a",
  hour12: {
    numeric: "h",
    "2-digit": "hh"
  },
  hour24: {
    numeric: "H",
    "2-digit": "HH"
  },
  minute: {
    numeric: "m",
    "2-digit": "mm"
  },
  second: {
    numeric: "s",
    "2-digit": "ss"
  },
  timeZoneName: {
    long: "ZZZZZ",
    short: "ZZZ"
  }
};
function qd(t, e, n) {
  const { type: r, value: s } = t;
  if (r === "literal") {
    const c = /^\s+$/.test(s);
    return {
      literal: !c,
      val: c ? " " : s
    };
  }
  const i = e[r];
  let a = r;
  r === "hour" && (e.hour12 != null ? a = e.hour12 ? "hour12" : "hour24" : e.hourCycle != null ? e.hourCycle === "h11" || e.hourCycle === "h12" ? a = "hour12" : a = "hour24" : a = n.hour12 ? "hour12" : "hour24");
  let u = Yd[a];
  if (typeof u == "object" && (u = u[i]), u)
    return {
      literal: !1,
      val: u
    };
}
function Gd(t) {
  return [`^${t.map((n) => n.regex).reduce((n, r) => `${n}(${r.source})`, "")}$`, t];
}
function Zd(t, e, n) {
  const r = t.match(e);
  if (r) {
    const s = {};
    let i = 1;
    for (const a in n)
      if (_t(n, a)) {
        const u = n[a], c = u.groups ? u.groups + 1 : 1;
        !u.literal && u.token && (s[u.token.val[0]] = u.deser(r.slice(i, i + c))), i += c;
      }
    return [r, s];
  } else
    return [r, {}];
}
function Qd(t) {
  const e = (i) => {
    switch (i) {
      case "S":
        return "millisecond";
      case "s":
        return "second";
      case "m":
        return "minute";
      case "h":
      case "H":
        return "hour";
      case "d":
        return "day";
      case "o":
        return "ordinal";
      case "L":
      case "M":
        return "month";
      case "y":
        return "year";
      case "E":
      case "c":
        return "weekday";
      case "W":
        return "weekNumber";
      case "k":
        return "weekYear";
      case "q":
        return "quarter";
      default:
        return null;
    }
  };
  let n = null, r;
  return P(t.z) || (n = $e.create(t.z)), P(t.Z) || (n || (n = new Se(t.Z)), r = t.Z), P(t.q) || (t.M = (t.q - 1) * 3 + 1), P(t.h) || (t.h < 12 && t.a === 1 ? t.h += 12 : t.h === 12 && t.a === 0 && (t.h = 0)), t.G === 0 && t.y && (t.y = -t.y), P(t.u) || (t.S = rs(t.u)), [Object.keys(t).reduce((i, a) => {
    const u = e(a);
    return u && (i[u] = t[a]), i;
  }, {}), n, r];
}
let yr = null;
function Jd() {
  return yr || (yr = x.fromMillis(1555555555555)), yr;
}
function Xd(t, e) {
  if (t.literal)
    return t;
  const n = be.macroTokenToFormatOpts(t.val), r = Wo(n, e);
  return r == null || r.includes(void 0) ? t : r;
}
function Lo(t, e) {
  return Array.prototype.concat(...t.map((n) => Xd(n, e)));
}
class Po {
  constructor(e, n) {
    if (this.locale = e, this.format = n, this.tokens = Lo(be.parseFormat(n), e), this.units = this.tokens.map((r) => Bd(r, e)), this.disqualifyingUnit = this.units.find((r) => r.invalidReason), !this.disqualifyingUnit) {
      const [r, s] = Gd(this.units);
      this.regex = RegExp(r, "i"), this.handlers = s;
    }
  }
  explainFromTokens(e) {
    if (this.isValid) {
      const [n, r] = Zd(e, this.regex, this.handlers), [s, i, a] = r ? Qd(r) : [null, null, void 0];
      if (_t(r, "a") && _t(r, "H"))
        throw new Ot(
          "Can't include meridiem when specifying 24-hour format"
        );
      return {
        input: e,
        tokens: this.tokens,
        regex: this.regex,
        rawMatches: n,
        matches: r,
        result: s,
        zone: i,
        specificOffset: a
      };
    } else
      return { input: e, tokens: this.tokens, invalidReason: this.invalidReason };
  }
  get isValid() {
    return !this.disqualifyingUnit;
  }
  get invalidReason() {
    return this.disqualifyingUnit ? this.disqualifyingUnit.invalidReason : null;
  }
}
function Vo(t, e, n) {
  return new Po(t, n).explainFromTokens(e);
}
function Kd(t, e, n) {
  const { result: r, zone: s, specificOffset: i, invalidReason: a } = Vo(t, e, n);
  return [r, s, i, a];
}
function Wo(t, e) {
  if (!t)
    return null;
  const r = be.create(e, t).dtFormatter(Jd()), s = r.formatToParts(), i = r.resolvedOptions();
  return s.map((a) => qd(a, t, i));
}
const vr = "Invalid DateTime", $i = 864e13;
function $t(t) {
  return new Me("unsupported zone", `the zone "${t.name}" is not supported`);
}
function gr(t) {
  return t.weekData === null && (t.weekData = Mn(t.c)), t.weekData;
}
function Er(t) {
  return t.localWeekData === null && (t.localWeekData = Mn(
    t.c,
    t.loc.getMinDaysInFirstWeek(),
    t.loc.getStartOfWeek()
  )), t.localWeekData;
}
function rt(t, e) {
  const n = {
    ts: t.ts,
    zone: t.zone,
    c: t.c,
    o: t.o,
    loc: t.loc,
    invalid: t.invalid
  };
  return new x({ ...n, ...e, old: n });
}
function Uo(t, e, n) {
  let r = t - e * 60 * 1e3;
  const s = n.offset(r);
  if (e === s)
    return [r, e];
  r -= (s - e) * 60 * 1e3;
  const i = n.offset(r);
  return s === i ? [r, s] : [t - Math.min(s, i) * 60 * 1e3, Math.max(s, i)];
}
function bn(t, e) {
  t += e * 60 * 1e3;
  const n = new Date(t);
  return {
    year: n.getUTCFullYear(),
    month: n.getUTCMonth() + 1,
    day: n.getUTCDate(),
    hour: n.getUTCHours(),
    minute: n.getUTCMinutes(),
    second: n.getUTCSeconds(),
    millisecond: n.getUTCMilliseconds()
  };
}
function kn(t, e, n) {
  return Uo(Hn(t), e, n);
}
function Hi(t, e) {
  const n = t.o, r = t.c.year + Math.trunc(e.years), s = t.c.month + Math.trunc(e.months) + Math.trunc(e.quarters) * 3, i = {
    ...t.c,
    year: r,
    month: s,
    day: Math.min(t.c.day, Fn(r, s)) + Math.trunc(e.days) + Math.trunc(e.weeks) * 7
  }, a = G.fromObject({
    years: e.years - Math.trunc(e.years),
    quarters: e.quarters - Math.trunc(e.quarters),
    months: e.months - Math.trunc(e.months),
    weeks: e.weeks - Math.trunc(e.weeks),
    days: e.days - Math.trunc(e.days),
    hours: e.hours,
    minutes: e.minutes,
    seconds: e.seconds,
    milliseconds: e.milliseconds
  }).as("milliseconds"), u = Hn(i);
  let [c, l] = Uo(u, n, t.zone);
  return a !== 0 && (c += a, l = t.zone.offset(c)), { ts: c, o: l };
}
function Et(t, e, n, r, s, i) {
  const { setZone: a, zone: u } = n;
  if (t && Object.keys(t).length !== 0 || e) {
    const c = e || u, l = x.fromObject(t, {
      ...n,
      zone: c,
      specificOffset: i
    });
    return a ? l : l.setZone(u);
  } else
    return x.invalid(
      new Me("unparsable", `the input "${s}" can't be parsed as ${r}`)
    );
}
function On(t, e, n = !0) {
  return t.isValid ? be.create(K.create("en-US"), {
    allowZ: n,
    forceSimple: !0
  }).formatDateTimeFromString(t, e) : null;
}
function wr(t, e) {
  const n = t.c.year > 9999 || t.c.year < 0;
  let r = "";
  return n && t.c.year >= 0 && (r += "+"), r += me(t.c.year, n ? 6 : 4), e ? (r += "-", r += me(t.c.month), r += "-", r += me(t.c.day)) : (r += me(t.c.month), r += me(t.c.day)), r;
}
function ji(t, e, n, r, s, i) {
  let a = me(t.c.hour);
  return e ? (a += ":", a += me(t.c.minute), (t.c.millisecond !== 0 || t.c.second !== 0 || !n) && (a += ":")) : a += me(t.c.minute), (t.c.millisecond !== 0 || t.c.second !== 0 || !n) && (a += me(t.c.second), (t.c.millisecond !== 0 || !r) && (a += ".", a += me(t.c.millisecond, 3))), s && (t.isOffsetFixed && t.offset === 0 && !i ? a += "Z" : t.o < 0 ? (a += "-", a += me(Math.trunc(-t.o / 60)), a += ":", a += me(Math.trunc(-t.o % 60))) : (a += "+", a += me(Math.trunc(t.o / 60)), a += ":", a += me(Math.trunc(t.o % 60)))), i && (a += "[" + t.zone.ianaName + "]"), a;
}
const $o = {
  month: 1,
  day: 1,
  hour: 0,
  minute: 0,
  second: 0,
  millisecond: 0
}, eh = {
  weekNumber: 1,
  weekday: 1,
  hour: 0,
  minute: 0,
  second: 0,
  millisecond: 0
}, th = {
  ordinal: 1,
  hour: 0,
  minute: 0,
  second: 0,
  millisecond: 0
}, Ho = ["year", "month", "day", "hour", "minute", "second", "millisecond"], nh = [
  "weekYear",
  "weekNumber",
  "weekday",
  "hour",
  "minute",
  "second",
  "millisecond"
], rh = ["year", "ordinal", "hour", "minute", "second", "millisecond"];
function sh(t) {
  const e = {
    year: "year",
    years: "year",
    month: "month",
    months: "month",
    day: "day",
    days: "day",
    hour: "hour",
    hours: "hour",
    minute: "minute",
    minutes: "minute",
    quarter: "quarter",
    quarters: "quarter",
    second: "second",
    seconds: "second",
    millisecond: "millisecond",
    milliseconds: "millisecond",
    weekday: "weekday",
    weekdays: "weekday",
    weeknumber: "weekNumber",
    weeksnumber: "weekNumber",
    weeknumbers: "weekNumber",
    weekyear: "weekYear",
    weekyears: "weekYear",
    ordinal: "ordinal"
  }[t.toLowerCase()];
  if (!e) throw new Ha(t);
  return e;
}
function zi(t) {
  switch (t.toLowerCase()) {
    case "localweekday":
    case "localweekdays":
      return "localWeekday";
    case "localweeknumber":
    case "localweeknumbers":
      return "localWeekNumber";
    case "localweekyear":
    case "localweekyears":
      return "localWeekYear";
    default:
      return sh(t);
  }
}
function ih(t) {
  return In[t] || (Nn === void 0 && (Nn = fe.now()), In[t] = t.offset(Nn)), In[t];
}
function Bi(t, e) {
  const n = Ke(e.zone, fe.defaultZone);
  if (!n.isValid)
    return x.invalid($t(n));
  const r = K.fromObject(e);
  let s, i;
  if (P(t.year))
    s = fe.now();
  else {
    for (const c of Ho)
      P(t[c]) && (t[c] = $o[c]);
    const a = ho(t) || po(t);
    if (a)
      return x.invalid(a);
    const u = ih(n);
    [s, i] = kn(t, u, n);
  }
  return new x({ ts: s, zone: n, loc: r, o: i });
}
function Yi(t, e, n) {
  const r = P(n.round) ? !0 : n.round, s = (a, u) => (a = ss(a, r || n.calendary ? 0 : 2, !0), e.loc.clone(n).relFormatter(n).format(a, u)), i = (a) => n.calendary ? e.hasSame(t, a) ? 0 : e.startOf(a).diff(t.startOf(a), a).get(a) : e.diff(t, a).get(a);
  if (n.unit)
    return s(i(n.unit), n.unit);
  for (const a of n.units) {
    const u = i(a);
    if (Math.abs(u) >= 1)
      return s(u, a);
  }
  return s(t > e ? -0 : 0, n.units[n.units.length - 1]);
}
function qi(t) {
  let e = {}, n;
  return t.length > 0 && typeof t[t.length - 1] == "object" ? (e = t[t.length - 1], n = Array.from(t).slice(0, t.length - 1)) : n = Array.from(t), [e, n];
}
let Nn, In = {};
class x {
  /**
   * @access private
   */
  constructor(e) {
    const n = e.zone || fe.defaultZone;
    let r = e.invalid || (Number.isNaN(e.ts) ? new Me("invalid input") : null) || (n.isValid ? null : $t(n));
    this.ts = P(e.ts) ? fe.now() : e.ts;
    let s = null, i = null;
    if (!r)
      if (e.old && e.old.ts === this.ts && e.old.zone.equals(n))
        [s, i] = [e.old.c, e.old.o];
      else {
        const u = et(e.o) && !e.old ? e.o : n.offset(this.ts);
        s = bn(this.ts, u), r = Number.isNaN(s.year) ? new Me("invalid input") : null, s = r ? null : s, i = r ? null : u;
      }
    this._zone = n, this.loc = e.loc || K.create(), this.invalid = r, this.weekData = null, this.localWeekData = null, this.c = s, this.o = i, this.isLuxonDateTime = !0;
  }
  // CONSTRUCT
  /**
   * Create a DateTime for the current instant, in the system's time zone.
   *
   * Use Settings to override these default values if needed.
   * @example DateTime.now().toISO() //~> now in the ISO format
   * @return {DateTime}
   */
  static now() {
    return new x({});
  }
  /**
   * Create a local DateTime
   * @param {number} [year] - The calendar year. If omitted (as in, call `local()` with no arguments), the current time will be used
   * @param {number} [month=1] - The month, 1-indexed
   * @param {number} [day=1] - The day of the month, 1-indexed
   * @param {number} [hour=0] - The hour of the day, in 24-hour time
   * @param {number} [minute=0] - The minute of the hour, meaning a number between 0 and 59
   * @param {number} [second=0] - The second of the minute, meaning a number between 0 and 59
   * @param {number} [millisecond=0] - The millisecond of the second, meaning a number between 0 and 999
   * @example DateTime.local()                                  //~> now
   * @example DateTime.local({ zone: "America/New_York" })      //~> now, in US east coast time
   * @example DateTime.local(2017)                              //~> 2017-01-01T00:00:00
   * @example DateTime.local(2017, 3)                           //~> 2017-03-01T00:00:00
   * @example DateTime.local(2017, 3, 12, { locale: "fr" })     //~> 2017-03-12T00:00:00, with a French locale
   * @example DateTime.local(2017, 3, 12, 5)                    //~> 2017-03-12T05:00:00
   * @example DateTime.local(2017, 3, 12, 5, { zone: "utc" })   //~> 2017-03-12T05:00:00, in UTC
   * @example DateTime.local(2017, 3, 12, 5, 45)                //~> 2017-03-12T05:45:00
   * @example DateTime.local(2017, 3, 12, 5, 45, 10)            //~> 2017-03-12T05:45:10
   * @example DateTime.local(2017, 3, 12, 5, 45, 10, 765)       //~> 2017-03-12T05:45:10.765
   * @return {DateTime}
   */
  static local() {
    const [e, n] = qi(arguments), [r, s, i, a, u, c, l] = n;
    return Bi({ year: r, month: s, day: i, hour: a, minute: u, second: c, millisecond: l }, e);
  }
  /**
   * Create a DateTime in UTC
   * @param {number} [year] - The calendar year. If omitted (as in, call `utc()` with no arguments), the current time will be used
   * @param {number} [month=1] - The month, 1-indexed
   * @param {number} [day=1] - The day of the month
   * @param {number} [hour=0] - The hour of the day, in 24-hour time
   * @param {number} [minute=0] - The minute of the hour, meaning a number between 0 and 59
   * @param {number} [second=0] - The second of the minute, meaning a number between 0 and 59
   * @param {number} [millisecond=0] - The millisecond of the second, meaning a number between 0 and 999
   * @param {Object} options - configuration options for the DateTime
   * @param {string} [options.locale] - a locale to set on the resulting DateTime instance
   * @param {string} [options.outputCalendar] - the output calendar to set on the resulting DateTime instance
   * @param {string} [options.numberingSystem] - the numbering system to set on the resulting DateTime instance
   * @param {string} [options.weekSettings] - the week settings to set on the resulting DateTime instance
   * @example DateTime.utc()                                              //~> now
   * @example DateTime.utc(2017)                                          //~> 2017-01-01T00:00:00Z
   * @example DateTime.utc(2017, 3)                                       //~> 2017-03-01T00:00:00Z
   * @example DateTime.utc(2017, 3, 12)                                   //~> 2017-03-12T00:00:00Z
   * @example DateTime.utc(2017, 3, 12, 5)                                //~> 2017-03-12T05:00:00Z
   * @example DateTime.utc(2017, 3, 12, 5, 45)                            //~> 2017-03-12T05:45:00Z
   * @example DateTime.utc(2017, 3, 12, 5, 45, { locale: "fr" })          //~> 2017-03-12T05:45:00Z with a French locale
   * @example DateTime.utc(2017, 3, 12, 5, 45, 10)                        //~> 2017-03-12T05:45:10Z
   * @example DateTime.utc(2017, 3, 12, 5, 45, 10, 765, { locale: "fr" }) //~> 2017-03-12T05:45:10.765Z with a French locale
   * @return {DateTime}
   */
  static utc() {
    const [e, n] = qi(arguments), [r, s, i, a, u, c, l] = n;
    return e.zone = Se.utcInstance, Bi({ year: r, month: s, day: i, hour: a, minute: u, second: c, millisecond: l }, e);
  }
  /**
   * Create a DateTime from a JavaScript Date object. Uses the default zone.
   * @param {Date} date - a JavaScript Date object
   * @param {Object} options - configuration options for the DateTime
   * @param {string|Zone} [options.zone='local'] - the zone to place the DateTime into
   * @return {DateTime}
   */
  static fromJSDate(e, n = {}) {
    const r = Ff(e) ? e.valueOf() : NaN;
    if (Number.isNaN(r))
      return x.invalid("invalid input");
    const s = Ke(n.zone, fe.defaultZone);
    return s.isValid ? new x({
      ts: r,
      zone: s,
      loc: K.fromObject(n)
    }) : x.invalid($t(s));
  }
  /**
   * Create a DateTime from a number of milliseconds since the epoch (meaning since 1 January 1970 00:00:00 UTC). Uses the default zone.
   * @param {number} milliseconds - a number of milliseconds since 1970 UTC
   * @param {Object} options - configuration options for the DateTime
   * @param {string|Zone} [options.zone='local'] - the zone to place the DateTime into
   * @param {string} [options.locale] - a locale to set on the resulting DateTime instance
   * @param {string} options.outputCalendar - the output calendar to set on the resulting DateTime instance
   * @param {string} options.numberingSystem - the numbering system to set on the resulting DateTime instance
   * @param {string} options.weekSettings - the week settings to set on the resulting DateTime instance
   * @return {DateTime}
   */
  static fromMillis(e, n = {}) {
    if (et(e))
      return e < -$i || e > $i ? x.invalid("Timestamp out of range") : new x({
        ts: e,
        zone: Ke(n.zone, fe.defaultZone),
        loc: K.fromObject(n)
      });
    throw new we(
      `fromMillis requires a numerical input, but received a ${typeof e} with value ${e}`
    );
  }
  /**
   * Create a DateTime from a number of seconds since the epoch (meaning since 1 January 1970 00:00:00 UTC). Uses the default zone.
   * @param {number} seconds - a number of seconds since 1970 UTC
   * @param {Object} options - configuration options for the DateTime
   * @param {string|Zone} [options.zone='local'] - the zone to place the DateTime into
   * @param {string} [options.locale] - a locale to set on the resulting DateTime instance
   * @param {string} options.outputCalendar - the output calendar to set on the resulting DateTime instance
   * @param {string} options.numberingSystem - the numbering system to set on the resulting DateTime instance
   * @param {string} options.weekSettings - the week settings to set on the resulting DateTime instance
   * @return {DateTime}
   */
  static fromSeconds(e, n = {}) {
    if (et(e))
      return new x({
        ts: e * 1e3,
        zone: Ke(n.zone, fe.defaultZone),
        loc: K.fromObject(n)
      });
    throw new we("fromSeconds requires a numerical input");
  }
  /**
   * Create a DateTime from a JavaScript object with keys like 'year' and 'hour' with reasonable defaults.
   * @param {Object} obj - the object to create the DateTime from
   * @param {number} obj.year - a year, such as 1987
   * @param {number} obj.month - a month, 1-12
   * @param {number} obj.day - a day of the month, 1-31, depending on the month
   * @param {number} obj.ordinal - day of the year, 1-365 or 366
   * @param {number} obj.weekYear - an ISO week year
   * @param {number} obj.weekNumber - an ISO week number, between 1 and 52 or 53, depending on the year
   * @param {number} obj.weekday - an ISO weekday, 1-7, where 1 is Monday and 7 is Sunday
   * @param {number} obj.localWeekYear - a week year, according to the locale
   * @param {number} obj.localWeekNumber - a week number, between 1 and 52 or 53, depending on the year, according to the locale
   * @param {number} obj.localWeekday - a weekday, 1-7, where 1 is the first and 7 is the last day of the week, according to the locale
   * @param {number} obj.hour - hour of the day, 0-23
   * @param {number} obj.minute - minute of the hour, 0-59
   * @param {number} obj.second - second of the minute, 0-59
   * @param {number} obj.millisecond - millisecond of the second, 0-999
   * @param {Object} opts - options for creating this DateTime
   * @param {string|Zone} [opts.zone='local'] - interpret the numbers in the context of a particular zone. Can take any value taken as the first argument to setZone()
   * @param {string} [opts.locale='system\'s locale'] - a locale to set on the resulting DateTime instance
   * @param {string} opts.outputCalendar - the output calendar to set on the resulting DateTime instance
   * @param {string} opts.numberingSystem - the numbering system to set on the resulting DateTime instance
   * @param {string} opts.weekSettings - the week settings to set on the resulting DateTime instance
   * @example DateTime.fromObject({ year: 1982, month: 5, day: 25}).toISODate() //=> '1982-05-25'
   * @example DateTime.fromObject({ year: 1982 }).toISODate() //=> '1982-01-01'
   * @example DateTime.fromObject({ hour: 10, minute: 26, second: 6 }) //~> today at 10:26:06
   * @example DateTime.fromObject({ hour: 10, minute: 26, second: 6 }, { zone: 'utc' }),
   * @example DateTime.fromObject({ hour: 10, minute: 26, second: 6 }, { zone: 'local' })
   * @example DateTime.fromObject({ hour: 10, minute: 26, second: 6 }, { zone: 'America/New_York' })
   * @example DateTime.fromObject({ weekYear: 2016, weekNumber: 2, weekday: 3 }).toISODate() //=> '2016-01-13'
   * @example DateTime.fromObject({ localWeekYear: 2022, localWeekNumber: 1, localWeekday: 1 }, { locale: "en-US" }).toISODate() //=> '2021-12-26'
   * @return {DateTime}
   */
  static fromObject(e, n = {}) {
    e = e || {};
    const r = Ke(n.zone, fe.defaultZone);
    if (!r.isValid)
      return x.invalid($t(r));
    const s = K.fromObject(n), i = Ln(e, zi), { minDaysInFirstWeek: a, startOfWeek: u } = Ai(i, s), c = fe.now(), l = P(n.specificOffset) ? r.offset(c) : n.specificOffset, d = !P(i.ordinal), m = !P(i.year), T = !P(i.month) || !P(i.day), E = m || T, S = i.weekYear || i.weekNumber;
    if ((E || d) && S)
      throw new Ot(
        "Can't mix weekYear/weekNumber units with year/month/day or ordinals"
      );
    if (T && d)
      throw new Ot("Can't mix ordinal dates with month/day");
    const _ = S || i.weekday && !E;
    let w, v, O = bn(c, l);
    _ ? (w = nh, v = eh, O = Mn(O, a, u)) : d ? (w = rh, v = th, O = mr(O)) : (w = Ho, v = $o);
    let R = !1;
    for (const q of w) {
      const ne = i[q];
      P(ne) ? R ? i[q] = v[q] : i[q] = O[q] : R = !0;
    }
    const M = _ ? xf(i, a, u) : d ? Rf(i) : ho(i), U = M || po(i);
    if (U)
      return x.invalid(U);
    const D = _ ? Di(i, a, u) : d ? Ci(i) : i, [j, V] = kn(D, l, r), A = new x({
      ts: j,
      zone: r,
      o: V,
      loc: s
    });
    return i.weekday && E && e.weekday !== A.weekday ? x.invalid(
      "mismatched weekday",
      `you can't specify both a weekday of ${i.weekday} and a date of ${A.toISO()}`
    ) : A.isValid ? A : x.invalid(A.invalid);
  }
  /**
   * Create a DateTime from an ISO 8601 string
   * @param {string} text - the ISO string
   * @param {Object} opts - options to affect the creation
   * @param {string|Zone} [opts.zone='local'] - use this zone if no offset is specified in the input string itself. Will also convert the time to this zone
   * @param {boolean} [opts.setZone=false] - override the zone with a fixed-offset zone specified in the string itself, if it specifies one
   * @param {string} [opts.locale='system's locale'] - a locale to set on the resulting DateTime instance
   * @param {string} [opts.outputCalendar] - the output calendar to set on the resulting DateTime instance
   * @param {string} [opts.numberingSystem] - the numbering system to set on the resulting DateTime instance
   * @param {string} [opts.weekSettings] - the week settings to set on the resulting DateTime instance
   * @example DateTime.fromISO('2016-05-25T09:08:34.123')
   * @example DateTime.fromISO('2016-05-25T09:08:34.123+06:00')
   * @example DateTime.fromISO('2016-05-25T09:08:34.123+06:00', {setZone: true})
   * @example DateTime.fromISO('2016-05-25T09:08:34.123', {zone: 'utc'})
   * @example DateTime.fromISO('2016-W05-4')
   * @return {DateTime}
   */
  static fromISO(e, n = {}) {
    const [r, s] = Sd(e);
    return Et(r, s, n, "ISO 8601", e);
  }
  /**
   * Create a DateTime from an RFC 2822 string
   * @param {string} text - the RFC 2822 string
   * @param {Object} opts - options to affect the creation
   * @param {string|Zone} [opts.zone='local'] - convert the time to this zone. Since the offset is always specified in the string itself, this has no effect on the interpretation of string, merely the zone the resulting DateTime is expressed in.
   * @param {boolean} [opts.setZone=false] - override the zone with a fixed-offset zone specified in the string itself, if it specifies one
   * @param {string} [opts.locale='system's locale'] - a locale to set on the resulting DateTime instance
   * @param {string} opts.outputCalendar - the output calendar to set on the resulting DateTime instance
   * @param {string} opts.numberingSystem - the numbering system to set on the resulting DateTime instance
   * @param {string} opts.weekSettings - the week settings to set on the resulting DateTime instance
   * @example DateTime.fromRFC2822('25 Nov 2016 13:23:12 GMT')
   * @example DateTime.fromRFC2822('Fri, 25 Nov 2016 13:23:12 +0600')
   * @example DateTime.fromRFC2822('25 Nov 2016 13:23 Z')
   * @return {DateTime}
   */
  static fromRFC2822(e, n = {}) {
    const [r, s] = _d(e);
    return Et(r, s, n, "RFC 2822", e);
  }
  /**
   * Create a DateTime from an HTTP header date
   * @see https://www.w3.org/Protocols/rfc2616/rfc2616-sec3.html#sec3.3.1
   * @param {string} text - the HTTP header date
   * @param {Object} opts - options to affect the creation
   * @param {string|Zone} [opts.zone='local'] - convert the time to this zone. Since HTTP dates are always in UTC, this has no effect on the interpretation of string, merely the zone the resulting DateTime is expressed in.
   * @param {boolean} [opts.setZone=false] - override the zone with the fixed-offset zone specified in the string. For HTTP dates, this is always UTC, so this option is equivalent to setting the `zone` option to 'utc', but this option is included for consistency with similar methods.
   * @param {string} [opts.locale='system's locale'] - a locale to set on the resulting DateTime instance
   * @param {string} opts.outputCalendar - the output calendar to set on the resulting DateTime instance
   * @param {string} opts.numberingSystem - the numbering system to set on the resulting DateTime instance
   * @param {string} opts.weekSettings - the week settings to set on the resulting DateTime instance
   * @example DateTime.fromHTTP('Sun, 06 Nov 1994 08:49:37 GMT')
   * @example DateTime.fromHTTP('Sunday, 06-Nov-94 08:49:37 GMT')
   * @example DateTime.fromHTTP('Sun Nov  6 08:49:37 1994')
   * @return {DateTime}
   */
  static fromHTTP(e, n = {}) {
    const [r, s] = kd(e);
    return Et(r, s, n, "HTTP", n);
  }
  /**
   * Create a DateTime from an input string and format string.
   * Defaults to en-US if no locale has been specified, regardless of the system's locale. For a table of tokens and their interpretations, see [here](https://moment.github.io/luxon/#/parsing?id=table-of-tokens).
   * @param {string} text - the string to parse
   * @param {string} fmt - the format the string is expected to be in (see the link below for the formats)
   * @param {Object} opts - options to affect the creation
   * @param {string|Zone} [opts.zone='local'] - use this zone if no offset is specified in the input string itself. Will also convert the DateTime to this zone
   * @param {boolean} [opts.setZone=false] - override the zone with a zone specified in the string itself, if it specifies one
   * @param {string} [opts.locale='en-US'] - a locale string to use when parsing. Will also set the DateTime to this locale
   * @param {string} opts.numberingSystem - the numbering system to use when parsing. Will also set the resulting DateTime to this numbering system
   * @param {string} opts.weekSettings - the week settings to set on the resulting DateTime instance
   * @param {string} opts.outputCalendar - the output calendar to set on the resulting DateTime instance
   * @return {DateTime}
   */
  static fromFormat(e, n, r = {}) {
    if (P(e) || P(n))
      throw new we("fromFormat requires an input string and a format");
    const { locale: s = null, numberingSystem: i = null } = r, a = K.fromOpts({
      locale: s,
      numberingSystem: i,
      defaultToEN: !0
    }), [u, c, l, d] = Kd(a, e, n);
    return d ? x.invalid(d) : Et(u, c, r, `format ${n}`, e, l);
  }
  /**
   * @deprecated use fromFormat instead
   */
  static fromString(e, n, r = {}) {
    return x.fromFormat(e, n, r);
  }
  /**
   * Create a DateTime from a SQL date, time, or datetime
   * Defaults to en-US if no locale has been specified, regardless of the system's locale
   * @param {string} text - the string to parse
   * @param {Object} opts - options to affect the creation
   * @param {string|Zone} [opts.zone='local'] - use this zone if no offset is specified in the input string itself. Will also convert the DateTime to this zone
   * @param {boolean} [opts.setZone=false] - override the zone with a zone specified in the string itself, if it specifies one
   * @param {string} [opts.locale='en-US'] - a locale string to use when parsing. Will also set the DateTime to this locale
   * @param {string} opts.numberingSystem - the numbering system to use when parsing. Will also set the resulting DateTime to this numbering system
   * @param {string} opts.weekSettings - the week settings to set on the resulting DateTime instance
   * @param {string} opts.outputCalendar - the output calendar to set on the resulting DateTime instance
   * @example DateTime.fromSQL('2017-05-15')
   * @example DateTime.fromSQL('2017-05-15 09:12:34')
   * @example DateTime.fromSQL('2017-05-15 09:12:34.342')
   * @example DateTime.fromSQL('2017-05-15 09:12:34.342+06:00')
   * @example DateTime.fromSQL('2017-05-15 09:12:34.342 America/Los_Angeles')
   * @example DateTime.fromSQL('2017-05-15 09:12:34.342 America/Los_Angeles', { setZone: true })
   * @example DateTime.fromSQL('2017-05-15 09:12:34.342', { zone: 'America/Los_Angeles' })
   * @example DateTime.fromSQL('09:12:34.342')
   * @return {DateTime}
   */
  static fromSQL(e, n = {}) {
    const [r, s] = Rd(e);
    return Et(r, s, n, "SQL", e);
  }
  /**
   * Create an invalid DateTime.
   * @param {string} reason - simple string of why this DateTime is invalid. Should not contain parameters or anything else data-dependent.
   * @param {string} [explanation=null] - longer explanation, may include parameters and other useful debugging information
   * @return {DateTime}
   */
  static invalid(e, n = null) {
    if (!e)
      throw new we("need to specify a reason the DateTime is invalid");
    const r = e instanceof Me ? e : new Me(e, n);
    if (fe.throwOnInvalid)
      throw new sf(r);
    return new x({ invalid: r });
  }
  /**
   * Check if an object is an instance of DateTime. Works across context boundaries
   * @param {object} o
   * @return {boolean}
   */
  static isDateTime(e) {
    return e && e.isLuxonDateTime || !1;
  }
  /**
   * Produce the format string for a set of options
   * @param formatOpts
   * @param localeOpts
   * @returns {string}
   */
  static parseFormatForOpts(e, n = {}) {
    const r = Wo(e, K.fromObject(n));
    return r ? r.map((s) => s ? s.val : null).join("") : null;
  }
  /**
   * Produce the the fully expanded format token for the locale
   * Does NOT quote characters, so quoted tokens will not round trip correctly
   * @param fmt
   * @param localeOpts
   * @returns {string}
   */
  static expandFormat(e, n = {}) {
    return Lo(be.parseFormat(e), K.fromObject(n)).map((s) => s.val).join("");
  }
  static resetCache() {
    Nn = void 0, In = {};
  }
  // INFO
  /**
   * Get the value of unit.
   * @param {string} unit - a unit such as 'minute' or 'day'
   * @example DateTime.local(2017, 7, 4).get('month'); //=> 7
   * @example DateTime.local(2017, 7, 4).get('day'); //=> 4
   * @return {number}
   */
  get(e) {
    return this[e];
  }
  /**
   * Returns whether the DateTime is valid. Invalid DateTimes occur when:
   * * The DateTime was created from invalid calendar information, such as the 13th month or February 30
   * * The DateTime was created by an operation on another invalid date
   * @type {boolean}
   */
  get isValid() {
    return this.invalid === null;
  }
  /**
   * Returns an error code if this DateTime is invalid, or null if the DateTime is valid
   * @type {string}
   */
  get invalidReason() {
    return this.invalid ? this.invalid.reason : null;
  }
  /**
   * Returns an explanation of why this DateTime became invalid, or null if the DateTime is valid
   * @type {string}
   */
  get invalidExplanation() {
    return this.invalid ? this.invalid.explanation : null;
  }
  /**
   * Get the locale of a DateTime, such 'en-GB'. The locale is used when formatting the DateTime
   *
   * @type {string}
   */
  get locale() {
    return this.isValid ? this.loc.locale : null;
  }
  /**
   * Get the numbering system of a DateTime, such 'beng'. The numbering system is used when formatting the DateTime
   *
   * @type {string}
   */
  get numberingSystem() {
    return this.isValid ? this.loc.numberingSystem : null;
  }
  /**
   * Get the output calendar of a DateTime, such 'islamic'. The output calendar is used when formatting the DateTime
   *
   * @type {string}
   */
  get outputCalendar() {
    return this.isValid ? this.loc.outputCalendar : null;
  }
  /**
   * Get the time zone associated with this DateTime.
   * @type {Zone}
   */
  get zone() {
    return this._zone;
  }
  /**
   * Get the name of the time zone.
   * @type {string}
   */
  get zoneName() {
    return this.isValid ? this.zone.name : null;
  }
  /**
   * Get the year
   * @example DateTime.local(2017, 5, 25).year //=> 2017
   * @type {number}
   */
  get year() {
    return this.isValid ? this.c.year : NaN;
  }
  /**
   * Get the quarter
   * @example DateTime.local(2017, 5, 25).quarter //=> 2
   * @type {number}
   */
  get quarter() {
    return this.isValid ? Math.ceil(this.c.month / 3) : NaN;
  }
  /**
   * Get the month (1-12).
   * @example DateTime.local(2017, 5, 25).month //=> 5
   * @type {number}
   */
  get month() {
    return this.isValid ? this.c.month : NaN;
  }
  /**
   * Get the day of the month (1-30ish).
   * @example DateTime.local(2017, 5, 25).day //=> 25
   * @type {number}
   */
  get day() {
    return this.isValid ? this.c.day : NaN;
  }
  /**
   * Get the hour of the day (0-23).
   * @example DateTime.local(2017, 5, 25, 9).hour //=> 9
   * @type {number}
   */
  get hour() {
    return this.isValid ? this.c.hour : NaN;
  }
  /**
   * Get the minute of the hour (0-59).
   * @example DateTime.local(2017, 5, 25, 9, 30).minute //=> 30
   * @type {number}
   */
  get minute() {
    return this.isValid ? this.c.minute : NaN;
  }
  /**
   * Get the second of the minute (0-59).
   * @example DateTime.local(2017, 5, 25, 9, 30, 52).second //=> 52
   * @type {number}
   */
  get second() {
    return this.isValid ? this.c.second : NaN;
  }
  /**
   * Get the millisecond of the second (0-999).
   * @example DateTime.local(2017, 5, 25, 9, 30, 52, 654).millisecond //=> 654
   * @type {number}
   */
  get millisecond() {
    return this.isValid ? this.c.millisecond : NaN;
  }
  /**
   * Get the week year
   * @see https://en.wikipedia.org/wiki/ISO_week_date
   * @example DateTime.local(2014, 12, 31).weekYear //=> 2015
   * @type {number}
   */
  get weekYear() {
    return this.isValid ? gr(this).weekYear : NaN;
  }
  /**
   * Get the week number of the week year (1-52ish).
   * @see https://en.wikipedia.org/wiki/ISO_week_date
   * @example DateTime.local(2017, 5, 25).weekNumber //=> 21
   * @type {number}
   */
  get weekNumber() {
    return this.isValid ? gr(this).weekNumber : NaN;
  }
  /**
   * Get the day of the week.
   * 1 is Monday and 7 is Sunday
   * @see https://en.wikipedia.org/wiki/ISO_week_date
   * @example DateTime.local(2014, 11, 31).weekday //=> 4
   * @type {number}
   */
  get weekday() {
    return this.isValid ? gr(this).weekday : NaN;
  }
  /**
   * Returns true if this date is on a weekend according to the locale, false otherwise
   * @returns {boolean}
   */
  get isWeekend() {
    return this.isValid && this.loc.getWeekendDays().includes(this.weekday);
  }
  /**
   * Get the day of the week according to the locale.
   * 1 is the first day of the week and 7 is the last day of the week.
   * If the locale assigns Sunday as the first day of the week, then a date which is a Sunday will return 1,
   * @returns {number}
   */
  get localWeekday() {
    return this.isValid ? Er(this).weekday : NaN;
  }
  /**
   * Get the week number of the week year according to the locale. Different locales assign week numbers differently,
   * because the week can start on different days of the week (see localWeekday) and because a different number of days
   * is required for a week to count as the first week of a year.
   * @returns {number}
   */
  get localWeekNumber() {
    return this.isValid ? Er(this).weekNumber : NaN;
  }
  /**
   * Get the week year according to the locale. Different locales assign week numbers (and therefor week years)
   * differently, see localWeekNumber.
   * @returns {number}
   */
  get localWeekYear() {
    return this.isValid ? Er(this).weekYear : NaN;
  }
  /**
   * Get the ordinal (meaning the day of the year)
   * @example DateTime.local(2017, 5, 25).ordinal //=> 145
   * @type {number|DateTime}
   */
  get ordinal() {
    return this.isValid ? mr(this.c).ordinal : NaN;
  }
  /**
   * Get the human readable short month name, such as 'Oct'.
   * Defaults to the system's locale if no locale has been specified
   * @example DateTime.local(2017, 10, 30).monthShort //=> Oct
   * @type {string}
   */
  get monthShort() {
    return this.isValid ? En.months("short", { locObj: this.loc })[this.month - 1] : null;
  }
  /**
   * Get the human readable long month name, such as 'October'.
   * Defaults to the system's locale if no locale has been specified
   * @example DateTime.local(2017, 10, 30).monthLong //=> October
   * @type {string}
   */
  get monthLong() {
    return this.isValid ? En.months("long", { locObj: this.loc })[this.month - 1] : null;
  }
  /**
   * Get the human readable short weekday, such as 'Mon'.
   * Defaults to the system's locale if no locale has been specified
   * @example DateTime.local(2017, 10, 30).weekdayShort //=> Mon
   * @type {string}
   */
  get weekdayShort() {
    return this.isValid ? En.weekdays("short", { locObj: this.loc })[this.weekday - 1] : null;
  }
  /**
   * Get the human readable long weekday, such as 'Monday'.
   * Defaults to the system's locale if no locale has been specified
   * @example DateTime.local(2017, 10, 30).weekdayLong //=> Monday
   * @type {string}
   */
  get weekdayLong() {
    return this.isValid ? En.weekdays("long", { locObj: this.loc })[this.weekday - 1] : null;
  }
  /**
   * Get the UTC offset of this DateTime in minutes
   * @example DateTime.now().offset //=> -240
   * @example DateTime.utc().offset //=> 0
   * @type {number}
   */
  get offset() {
    return this.isValid ? +this.o : NaN;
  }
  /**
   * Get the short human name for the zone's current offset, for example "EST" or "EDT".
   * Defaults to the system's locale if no locale has been specified
   * @type {string}
   */
  get offsetNameShort() {
    return this.isValid ? this.zone.offsetName(this.ts, {
      format: "short",
      locale: this.locale
    }) : null;
  }
  /**
   * Get the long human name for the zone's current offset, for example "Eastern Standard Time" or "Eastern Daylight Time".
   * Defaults to the system's locale if no locale has been specified
   * @type {string}
   */
  get offsetNameLong() {
    return this.isValid ? this.zone.offsetName(this.ts, {
      format: "long",
      locale: this.locale
    }) : null;
  }
  /**
   * Get whether this zone's offset ever changes, as in a DST.
   * @type {boolean}
   */
  get isOffsetFixed() {
    return this.isValid ? this.zone.isUniversal : null;
  }
  /**
   * Get whether the DateTime is in a DST.
   * @type {boolean}
   */
  get isInDST() {
    return this.isOffsetFixed ? !1 : this.offset > this.set({ month: 1, day: 1 }).offset || this.offset > this.set({ month: 5 }).offset;
  }
  /**
   * Get those DateTimes which have the same local time as this DateTime, but a different offset from UTC
   * in this DateTime's zone. During DST changes local time can be ambiguous, for example
   * `2023-10-29T02:30:00` in `Europe/Berlin` can have offset `+01:00` or `+02:00`.
   * This method will return both possible DateTimes if this DateTime's local time is ambiguous.
   * @returns {DateTime[]}
   */
  getPossibleOffsets() {
    if (!this.isValid || this.isOffsetFixed)
      return [this];
    const e = 864e5, n = 6e4, r = Hn(this.c), s = this.zone.offset(r - e), i = this.zone.offset(r + e), a = this.zone.offset(r - s * n), u = this.zone.offset(r - i * n);
    if (a === u)
      return [this];
    const c = r - a * n, l = r - u * n, d = bn(c, a), m = bn(l, u);
    return d.hour === m.hour && d.minute === m.minute && d.second === m.second && d.millisecond === m.millisecond ? [rt(this, { ts: c }), rt(this, { ts: l })] : [this];
  }
  /**
   * Returns true if this DateTime is in a leap year, false otherwise
   * @example DateTime.local(2016).isInLeapYear //=> true
   * @example DateTime.local(2013).isInLeapYear //=> false
   * @type {boolean}
   */
  get isInLeapYear() {
    return Qt(this.year);
  }
  /**
   * Returns the number of days in this DateTime's month
   * @example DateTime.local(2016, 2).daysInMonth //=> 29
   * @example DateTime.local(2016, 3).daysInMonth //=> 31
   * @type {number}
   */
  get daysInMonth() {
    return Fn(this.year, this.month);
  }
  /**
   * Returns the number of days in this DateTime's year
   * @example DateTime.local(2016).daysInYear //=> 366
   * @example DateTime.local(2013).daysInYear //=> 365
   * @type {number}
   */
  get daysInYear() {
    return this.isValid ? Tt(this.year) : NaN;
  }
  /**
   * Returns the number of weeks in this DateTime's year
   * @see https://en.wikipedia.org/wiki/ISO_week_date
   * @example DateTime.local(2004).weeksInWeekYear //=> 53
   * @example DateTime.local(2013).weeksInWeekYear //=> 52
   * @type {number}
   */
  get weeksInWeekYear() {
    return this.isValid ? Bt(this.weekYear) : NaN;
  }
  /**
   * Returns the number of weeks in this DateTime's local week year
   * @example DateTime.local(2020, 6, {locale: 'en-US'}).weeksInLocalWeekYear //=> 52
   * @example DateTime.local(2020, 6, {locale: 'de-DE'}).weeksInLocalWeekYear //=> 53
   * @type {number}
   */
  get weeksInLocalWeekYear() {
    return this.isValid ? Bt(
      this.localWeekYear,
      this.loc.getMinDaysInFirstWeek(),
      this.loc.getStartOfWeek()
    ) : NaN;
  }
  /**
   * Returns the resolved Intl options for this DateTime.
   * This is useful in understanding the behavior of formatting methods
   * @param {Object} opts - the same options as toLocaleString
   * @return {Object}
   */
  resolvedLocaleOptions(e = {}) {
    const { locale: n, numberingSystem: r, calendar: s } = be.create(
      this.loc.clone(e),
      e
    ).resolvedOptions(this);
    return { locale: n, numberingSystem: r, outputCalendar: s };
  }
  // TRANSFORM
  /**
   * "Set" the DateTime's zone to UTC. Returns a newly-constructed DateTime.
   *
   * Equivalent to {@link DateTime#setZone}('utc')
   * @param {number} [offset=0] - optionally, an offset from UTC in minutes
   * @param {Object} [opts={}] - options to pass to `setZone()`
   * @return {DateTime}
   */
  toUTC(e = 0, n = {}) {
    return this.setZone(Se.instance(e), n);
  }
  /**
   * "Set" the DateTime's zone to the host's local zone. Returns a newly-constructed DateTime.
   *
   * Equivalent to `setZone('local')`
   * @return {DateTime}
   */
  toLocal() {
    return this.setZone(fe.defaultZone);
  }
  /**
   * "Set" the DateTime's zone to specified zone. Returns a newly-constructed DateTime.
   *
   * By default, the setter keeps the underlying time the same (as in, the same timestamp), but the new instance will report different local times and consider DSTs when making computations, as with {@link DateTime#plus}. You may wish to use {@link DateTime#toLocal} and {@link DateTime#toUTC} which provide simple convenience wrappers for commonly used zones.
   * @param {string|Zone} [zone='local'] - a zone identifier. As a string, that can be any IANA zone supported by the host environment, or a fixed-offset name of the form 'UTC+3', or the strings 'local' or 'utc'. You may also supply an instance of a {@link DateTime#Zone} class.
   * @param {Object} opts - options
   * @param {boolean} [opts.keepLocalTime=false] - If true, adjust the underlying time so that the local time stays the same, but in the target zone. You should rarely need this.
   * @return {DateTime}
   */
  setZone(e, { keepLocalTime: n = !1, keepCalendarTime: r = !1 } = {}) {
    if (e = Ke(e, fe.defaultZone), e.equals(this.zone))
      return this;
    if (e.isValid) {
      let s = this.ts;
      if (n || r) {
        const i = e.offset(this.ts), a = this.toObject();
        [s] = kn(a, i, e);
      }
      return rt(this, { ts: s, zone: e });
    } else
      return x.invalid($t(e));
  }
  /**
   * "Set" the locale, numberingSystem, or outputCalendar. Returns a newly-constructed DateTime.
   * @param {Object} properties - the properties to set
   * @example DateTime.local(2017, 5, 25).reconfigure({ locale: 'en-GB' })
   * @return {DateTime}
   */
  reconfigure({ locale: e, numberingSystem: n, outputCalendar: r } = {}) {
    const s = this.loc.clone({ locale: e, numberingSystem: n, outputCalendar: r });
    return rt(this, { loc: s });
  }
  /**
   * "Set" the locale. Returns a newly-constructed DateTime.
   * Just a convenient alias for reconfigure({ locale })
   * @example DateTime.local(2017, 5, 25).setLocale('en-GB')
   * @return {DateTime}
   */
  setLocale(e) {
    return this.reconfigure({ locale: e });
  }
  /**
   * "Set" the values of specified units. Returns a newly-constructed DateTime.
   * You can only set units with this method; for "setting" metadata, see {@link DateTime#reconfigure} and {@link DateTime#setZone}.
   *
   * This method also supports setting locale-based week units, i.e. `localWeekday`, `localWeekNumber` and `localWeekYear`.
   * They cannot be mixed with ISO-week units like `weekday`.
   * @param {Object} values - a mapping of units to numbers
   * @example dt.set({ year: 2017 })
   * @example dt.set({ hour: 8, minute: 30 })
   * @example dt.set({ weekday: 5 })
   * @example dt.set({ year: 2005, ordinal: 234 })
   * @return {DateTime}
   */
  set(e) {
    if (!this.isValid) return this;
    const n = Ln(e, zi), { minDaysInFirstWeek: r, startOfWeek: s } = Ai(n, this.loc), i = !P(n.weekYear) || !P(n.weekNumber) || !P(n.weekday), a = !P(n.ordinal), u = !P(n.year), c = !P(n.month) || !P(n.day), l = u || c, d = n.weekYear || n.weekNumber;
    if ((l || a) && d)
      throw new Ot(
        "Can't mix weekYear/weekNumber units with year/month/day or ordinals"
      );
    if (c && a)
      throw new Ot("Can't mix ordinal dates with month/day");
    let m;
    i ? m = Di(
      { ...Mn(this.c, r, s), ...n },
      r,
      s
    ) : P(n.ordinal) ? (m = { ...this.toObject(), ...n }, P(n.day) && (m.day = Math.min(Fn(m.year, m.month), m.day))) : m = Ci({ ...mr(this.c), ...n });
    const [T, E] = kn(m, this.o, this.zone);
    return rt(this, { ts: T, o: E });
  }
  /**
   * Add a period of time to this DateTime and return the resulting DateTime
   *
   * Adding hours, minutes, seconds, or milliseconds increases the timestamp by the right number of milliseconds. Adding days, months, or years shifts the calendar, accounting for DSTs and leap years along the way. Thus, `dt.plus({ hours: 24 })` may result in a different time than `dt.plus({ days: 1 })` if there's a DST shift in between.
   * @param {Duration|Object|number} duration - The amount to add. Either a Luxon Duration, a number of milliseconds, the object argument to Duration.fromObject()
   * @example DateTime.now().plus(123) //~> in 123 milliseconds
   * @example DateTime.now().plus({ minutes: 15 }) //~> in 15 minutes
   * @example DateTime.now().plus({ days: 1 }) //~> this time tomorrow
   * @example DateTime.now().plus({ days: -1 }) //~> this time yesterday
   * @example DateTime.now().plus({ hours: 3, minutes: 13 }) //~> in 3 hr, 13 min
   * @example DateTime.now().plus(Duration.fromObject({ hours: 3, minutes: 13 })) //~> in 3 hr, 13 min
   * @return {DateTime}
   */
  plus(e) {
    if (!this.isValid) return this;
    const n = G.fromDurationLike(e);
    return rt(this, Hi(this, n));
  }
  /**
   * Subtract a period of time to this DateTime and return the resulting DateTime
   * See {@link DateTime#plus}
   * @param {Duration|Object|number} duration - The amount to subtract. Either a Luxon Duration, a number of milliseconds, the object argument to Duration.fromObject()
   @return {DateTime}
   */
  minus(e) {
    if (!this.isValid) return this;
    const n = G.fromDurationLike(e).negate();
    return rt(this, Hi(this, n));
  }
  /**
   * "Set" this DateTime to the beginning of a unit of time.
   * @param {string} unit - The unit to go to the beginning of. Can be 'year', 'quarter', 'month', 'week', 'day', 'hour', 'minute', 'second', or 'millisecond'.
   * @param {Object} opts - options
   * @param {boolean} [opts.useLocaleWeeks=false] - If true, use weeks based on the locale, i.e. use the locale-dependent start of the week
   * @example DateTime.local(2014, 3, 3).startOf('month').toISODate(); //=> '2014-03-01'
   * @example DateTime.local(2014, 3, 3).startOf('year').toISODate(); //=> '2014-01-01'
   * @example DateTime.local(2014, 3, 3).startOf('week').toISODate(); //=> '2014-03-03', weeks always start on Mondays
   * @example DateTime.local(2014, 3, 3, 5, 30).startOf('day').toISOTime(); //=> '00:00.000-05:00'
   * @example DateTime.local(2014, 3, 3, 5, 30).startOf('hour').toISOTime(); //=> '05:00:00.000-05:00'
   * @return {DateTime}
   */
  startOf(e, { useLocaleWeeks: n = !1 } = {}) {
    if (!this.isValid) return this;
    const r = {}, s = G.normalizeUnit(e);
    switch (s) {
      case "years":
        r.month = 1;
      case "quarters":
      case "months":
        r.day = 1;
      case "weeks":
      case "days":
        r.hour = 0;
      case "hours":
        r.minute = 0;
      case "minutes":
        r.second = 0;
      case "seconds":
        r.millisecond = 0;
        break;
    }
    if (s === "weeks")
      if (n) {
        const i = this.loc.getStartOfWeek(), { weekday: a } = this;
        a < i && (r.weekNumber = this.weekNumber - 1), r.weekday = i;
      } else
        r.weekday = 1;
    if (s === "quarters") {
      const i = Math.ceil(this.month / 3);
      r.month = (i - 1) * 3 + 1;
    }
    return this.set(r);
  }
  /**
   * "Set" this DateTime to the end (meaning the last millisecond) of a unit of time
   * @param {string} unit - The unit to go to the end of. Can be 'year', 'quarter', 'month', 'week', 'day', 'hour', 'minute', 'second', or 'millisecond'.
   * @param {Object} opts - options
   * @param {boolean} [opts.useLocaleWeeks=false] - If true, use weeks based on the locale, i.e. use the locale-dependent start of the week
   * @example DateTime.local(2014, 3, 3).endOf('month').toISO(); //=> '2014-03-31T23:59:59.999-05:00'
   * @example DateTime.local(2014, 3, 3).endOf('year').toISO(); //=> '2014-12-31T23:59:59.999-05:00'
   * @example DateTime.local(2014, 3, 3).endOf('week').toISO(); // => '2014-03-09T23:59:59.999-05:00', weeks start on Mondays
   * @example DateTime.local(2014, 3, 3, 5, 30).endOf('day').toISO(); //=> '2014-03-03T23:59:59.999-05:00'
   * @example DateTime.local(2014, 3, 3, 5, 30).endOf('hour').toISO(); //=> '2014-03-03T05:59:59.999-05:00'
   * @return {DateTime}
   */
  endOf(e, n) {
    return this.isValid ? this.plus({ [e]: 1 }).startOf(e, n).minus(1) : this;
  }
  // OUTPUT
  /**
   * Returns a string representation of this DateTime formatted according to the specified format string.
   * **You may not want this.** See {@link DateTime#toLocaleString} for a more flexible formatting tool. For a table of tokens and their interpretations, see [here](https://moment.github.io/luxon/#/formatting?id=table-of-tokens).
   * Defaults to en-US if no locale has been specified, regardless of the system's locale.
   * @param {string} fmt - the format string
   * @param {Object} opts - opts to override the configuration options on this DateTime
   * @example DateTime.now().toFormat('yyyy LLL dd') //=> '2017 Apr 22'
   * @example DateTime.now().setLocale('fr').toFormat('yyyy LLL dd') //=> '2017 avr. 22'
   * @example DateTime.now().toFormat('yyyy LLL dd', { locale: "fr" }) //=> '2017 avr. 22'
   * @example DateTime.now().toFormat("HH 'hours and' mm 'minutes'") //=> '20 hours and 55 minutes'
   * @return {string}
   */
  toFormat(e, n = {}) {
    return this.isValid ? be.create(this.loc.redefaultToEN(n)).formatDateTimeFromString(this, e) : vr;
  }
  /**
   * Returns a localized string representing this date. Accepts the same options as the Intl.DateTimeFormat constructor and any presets defined by Luxon, such as `DateTime.DATE_FULL` or `DateTime.TIME_SIMPLE`.
   * The exact behavior of this method is browser-specific, but in general it will return an appropriate representation
   * of the DateTime in the assigned locale.
   * Defaults to the system's locale if no locale has been specified
   * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DateTimeFormat
   * @param formatOpts {Object} - Intl.DateTimeFormat constructor options and configuration options
   * @param {Object} opts - opts to override the configuration options on this DateTime
   * @example DateTime.now().toLocaleString(); //=> 4/20/2017
   * @example DateTime.now().setLocale('en-gb').toLocaleString(); //=> '20/04/2017'
   * @example DateTime.now().toLocaleString(DateTime.DATE_FULL); //=> 'April 20, 2017'
   * @example DateTime.now().toLocaleString(DateTime.DATE_FULL, { locale: 'fr' }); //=> '28 août 2022'
   * @example DateTime.now().toLocaleString(DateTime.TIME_SIMPLE); //=> '11:32 AM'
   * @example DateTime.now().toLocaleString(DateTime.DATETIME_SHORT); //=> '4/20/2017, 11:32 AM'
   * @example DateTime.now().toLocaleString({ weekday: 'long', month: 'long', day: '2-digit' }); //=> 'Thursday, April 20'
   * @example DateTime.now().toLocaleString({ weekday: 'short', month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit' }); //=> 'Thu, Apr 20, 11:27 AM'
   * @example DateTime.now().toLocaleString({ hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }); //=> '11:32'
   * @return {string}
   */
  toLocaleString(e = Rn, n = {}) {
    return this.isValid ? be.create(this.loc.clone(n), e).formatDateTime(this) : vr;
  }
  /**
   * Returns an array of format "parts", meaning individual tokens along with metadata. This is allows callers to post-process individual sections of the formatted output.
   * Defaults to the system's locale if no locale has been specified
   * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DateTimeFormat/formatToParts
   * @param opts {Object} - Intl.DateTimeFormat constructor options, same as `toLocaleString`.
   * @example DateTime.now().toLocaleParts(); //=> [
   *                                   //=>   { type: 'day', value: '25' },
   *                                   //=>   { type: 'literal', value: '/' },
   *                                   //=>   { type: 'month', value: '05' },
   *                                   //=>   { type: 'literal', value: '/' },
   *                                   //=>   { type: 'year', value: '1982' }
   *                                   //=> ]
   */
  toLocaleParts(e = {}) {
    return this.isValid ? be.create(this.loc.clone(e), e).formatDateTimeParts(this) : [];
  }
  /**
   * Returns an ISO 8601-compliant string representation of this DateTime
   * @param {Object} opts - options
   * @param {boolean} [opts.suppressMilliseconds=false] - exclude milliseconds from the format if they're 0
   * @param {boolean} [opts.suppressSeconds=false] - exclude seconds from the format if they're 0
   * @param {boolean} [opts.includeOffset=true] - include the offset, such as 'Z' or '-04:00'
   * @param {boolean} [opts.extendedZone=false] - add the time zone format extension
   * @param {string} [opts.format='extended'] - choose between the basic and extended format
   * @example DateTime.utc(1983, 5, 25).toISO() //=> '1982-05-25T00:00:00.000Z'
   * @example DateTime.now().toISO() //=> '2017-04-22T20:47:05.335-04:00'
   * @example DateTime.now().toISO({ includeOffset: false }) //=> '2017-04-22T20:47:05.335'
   * @example DateTime.now().toISO({ format: 'basic' }) //=> '20170422T204705.335-0400'
   * @return {string}
   */
  toISO({
    format: e = "extended",
    suppressSeconds: n = !1,
    suppressMilliseconds: r = !1,
    includeOffset: s = !0,
    extendedZone: i = !1
  } = {}) {
    if (!this.isValid)
      return null;
    const a = e === "extended";
    let u = wr(this, a);
    return u += "T", u += ji(this, a, n, r, s, i), u;
  }
  /**
   * Returns an ISO 8601-compliant string representation of this DateTime's date component
   * @param {Object} opts - options
   * @param {string} [opts.format='extended'] - choose between the basic and extended format
   * @example DateTime.utc(1982, 5, 25).toISODate() //=> '1982-05-25'
   * @example DateTime.utc(1982, 5, 25).toISODate({ format: 'basic' }) //=> '19820525'
   * @return {string}
   */
  toISODate({ format: e = "extended" } = {}) {
    return this.isValid ? wr(this, e === "extended") : null;
  }
  /**
   * Returns an ISO 8601-compliant string representation of this DateTime's week date
   * @example DateTime.utc(1982, 5, 25).toISOWeekDate() //=> '1982-W21-2'
   * @return {string}
   */
  toISOWeekDate() {
    return On(this, "kkkk-'W'WW-c");
  }
  /**
   * Returns an ISO 8601-compliant string representation of this DateTime's time component
   * @param {Object} opts - options
   * @param {boolean} [opts.suppressMilliseconds=false] - exclude milliseconds from the format if they're 0
   * @param {boolean} [opts.suppressSeconds=false] - exclude seconds from the format if they're 0
   * @param {boolean} [opts.includeOffset=true] - include the offset, such as 'Z' or '-04:00'
   * @param {boolean} [opts.extendedZone=true] - add the time zone format extension
   * @param {boolean} [opts.includePrefix=false] - include the `T` prefix
   * @param {string} [opts.format='extended'] - choose between the basic and extended format
   * @example DateTime.utc().set({ hour: 7, minute: 34 }).toISOTime() //=> '07:34:19.361Z'
   * @example DateTime.utc().set({ hour: 7, minute: 34, seconds: 0, milliseconds: 0 }).toISOTime({ suppressSeconds: true }) //=> '07:34Z'
   * @example DateTime.utc().set({ hour: 7, minute: 34 }).toISOTime({ format: 'basic' }) //=> '073419.361Z'
   * @example DateTime.utc().set({ hour: 7, minute: 34 }).toISOTime({ includePrefix: true }) //=> 'T07:34:19.361Z'
   * @return {string}
   */
  toISOTime({
    suppressMilliseconds: e = !1,
    suppressSeconds: n = !1,
    includeOffset: r = !0,
    includePrefix: s = !1,
    extendedZone: i = !1,
    format: a = "extended"
  } = {}) {
    return this.isValid ? (s ? "T" : "") + ji(
      this,
      a === "extended",
      n,
      e,
      r,
      i
    ) : null;
  }
  /**
   * Returns an RFC 2822-compatible string representation of this DateTime
   * @example DateTime.utc(2014, 7, 13).toRFC2822() //=> 'Sun, 13 Jul 2014 00:00:00 +0000'
   * @example DateTime.local(2014, 7, 13).toRFC2822() //=> 'Sun, 13 Jul 2014 00:00:00 -0400'
   * @return {string}
   */
  toRFC2822() {
    return On(this, "EEE, dd LLL yyyy HH:mm:ss ZZZ", !1);
  }
  /**
   * Returns a string representation of this DateTime appropriate for use in HTTP headers. The output is always expressed in GMT.
   * Specifically, the string conforms to RFC 1123.
   * @see https://www.w3.org/Protocols/rfc2616/rfc2616-sec3.html#sec3.3.1
   * @example DateTime.utc(2014, 7, 13).toHTTP() //=> 'Sun, 13 Jul 2014 00:00:00 GMT'
   * @example DateTime.utc(2014, 7, 13, 19).toHTTP() //=> 'Sun, 13 Jul 2014 19:00:00 GMT'
   * @return {string}
   */
  toHTTP() {
    return On(this.toUTC(), "EEE, dd LLL yyyy HH:mm:ss 'GMT'");
  }
  /**
   * Returns a string representation of this DateTime appropriate for use in SQL Date
   * @example DateTime.utc(2014, 7, 13).toSQLDate() //=> '2014-07-13'
   * @return {string}
   */
  toSQLDate() {
    return this.isValid ? wr(this, !0) : null;
  }
  /**
   * Returns a string representation of this DateTime appropriate for use in SQL Time
   * @param {Object} opts - options
   * @param {boolean} [opts.includeZone=false] - include the zone, such as 'America/New_York'. Overrides includeOffset.
   * @param {boolean} [opts.includeOffset=true] - include the offset, such as 'Z' or '-04:00'
   * @param {boolean} [opts.includeOffsetSpace=true] - include the space between the time and the offset, such as '05:15:16.345 -04:00'
   * @example DateTime.utc().toSQL() //=> '05:15:16.345'
   * @example DateTime.now().toSQL() //=> '05:15:16.345 -04:00'
   * @example DateTime.now().toSQL({ includeOffset: false }) //=> '05:15:16.345'
   * @example DateTime.now().toSQL({ includeZone: false }) //=> '05:15:16.345 America/New_York'
   * @return {string}
   */
  toSQLTime({ includeOffset: e = !0, includeZone: n = !1, includeOffsetSpace: r = !0 } = {}) {
    let s = "HH:mm:ss.SSS";
    return (n || e) && (r && (s += " "), n ? s += "z" : e && (s += "ZZ")), On(this, s, !0);
  }
  /**
   * Returns a string representation of this DateTime appropriate for use in SQL DateTime
   * @param {Object} opts - options
   * @param {boolean} [opts.includeZone=false] - include the zone, such as 'America/New_York'. Overrides includeOffset.
   * @param {boolean} [opts.includeOffset=true] - include the offset, such as 'Z' or '-04:00'
   * @param {boolean} [opts.includeOffsetSpace=true] - include the space between the time and the offset, such as '05:15:16.345 -04:00'
   * @example DateTime.utc(2014, 7, 13).toSQL() //=> '2014-07-13 00:00:00.000 Z'
   * @example DateTime.local(2014, 7, 13).toSQL() //=> '2014-07-13 00:00:00.000 -04:00'
   * @example DateTime.local(2014, 7, 13).toSQL({ includeOffset: false }) //=> '2014-07-13 00:00:00.000'
   * @example DateTime.local(2014, 7, 13).toSQL({ includeZone: true }) //=> '2014-07-13 00:00:00.000 America/New_York'
   * @return {string}
   */
  toSQL(e = {}) {
    return this.isValid ? `${this.toSQLDate()} ${this.toSQLTime(e)}` : null;
  }
  /**
   * Returns a string representation of this DateTime appropriate for debugging
   * @return {string}
   */
  toString() {
    return this.isValid ? this.toISO() : vr;
  }
  /**
   * Returns a string representation of this DateTime appropriate for the REPL.
   * @return {string}
   */
  [Symbol.for("nodejs.util.inspect.custom")]() {
    return this.isValid ? `DateTime { ts: ${this.toISO()}, zone: ${this.zone.name}, locale: ${this.locale} }` : `DateTime { Invalid, reason: ${this.invalidReason} }`;
  }
  /**
   * Returns the epoch milliseconds of this DateTime. Alias of {@link DateTime#toMillis}
   * @return {number}
   */
  valueOf() {
    return this.toMillis();
  }
  /**
   * Returns the epoch milliseconds of this DateTime.
   * @return {number}
   */
  toMillis() {
    return this.isValid ? this.ts : NaN;
  }
  /**
   * Returns the epoch seconds of this DateTime.
   * @return {number}
   */
  toSeconds() {
    return this.isValid ? this.ts / 1e3 : NaN;
  }
  /**
   * Returns the epoch seconds (as a whole number) of this DateTime.
   * @return {number}
   */
  toUnixInteger() {
    return this.isValid ? Math.floor(this.ts / 1e3) : NaN;
  }
  /**
   * Returns an ISO 8601 representation of this DateTime appropriate for use in JSON.
   * @return {string}
   */
  toJSON() {
    return this.toISO();
  }
  /**
   * Returns a BSON serializable equivalent to this DateTime.
   * @return {Date}
   */
  toBSON() {
    return this.toJSDate();
  }
  /**
   * Returns a JavaScript object with this DateTime's year, month, day, and so on.
   * @param opts - options for generating the object
   * @param {boolean} [opts.includeConfig=false] - include configuration attributes in the output
   * @example DateTime.now().toObject() //=> { year: 2017, month: 4, day: 22, hour: 20, minute: 49, second: 42, millisecond: 268 }
   * @return {Object}
   */
  toObject(e = {}) {
    if (!this.isValid) return {};
    const n = { ...this.c };
    return e.includeConfig && (n.outputCalendar = this.outputCalendar, n.numberingSystem = this.loc.numberingSystem, n.locale = this.loc.locale), n;
  }
  /**
   * Returns a JavaScript Date equivalent to this DateTime.
   * @return {Date}
   */
  toJSDate() {
    return new Date(this.isValid ? this.ts : NaN);
  }
  // COMPARE
  /**
   * Return the difference between two DateTimes as a Duration.
   * @param {DateTime} otherDateTime - the DateTime to compare this one to
   * @param {string|string[]} [unit=['milliseconds']] - the unit or array of units (such as 'hours' or 'days') to include in the duration.
   * @param {Object} opts - options that affect the creation of the Duration
   * @param {string} [opts.conversionAccuracy='casual'] - the conversion system to use
   * @example
   * var i1 = DateTime.fromISO('1982-05-25T09:45'),
   *     i2 = DateTime.fromISO('1983-10-14T10:30');
   * i2.diff(i1).toObject() //=> { milliseconds: 43807500000 }
   * i2.diff(i1, 'hours').toObject() //=> { hours: 12168.75 }
   * i2.diff(i1, ['months', 'days']).toObject() //=> { months: 16, days: 19.03125 }
   * i2.diff(i1, ['months', 'days', 'hours']).toObject() //=> { months: 16, days: 19, hours: 0.75 }
   * @return {Duration}
   */
  diff(e, n = "milliseconds", r = {}) {
    if (!this.isValid || !e.isValid)
      return G.invalid("created by diffing an invalid DateTime");
    const s = { locale: this.locale, numberingSystem: this.numberingSystem, ...r }, i = Lf(n).map(G.normalizeUnit), a = e.valueOf() > this.valueOf(), u = a ? this : e, c = a ? e : this, l = Ud(u, c, i, s);
    return a ? l.negate() : l;
  }
  /**
   * Return the difference between this DateTime and right now.
   * See {@link DateTime#diff}
   * @param {string|string[]} [unit=['milliseconds']] - the unit or units units (such as 'hours' or 'days') to include in the duration
   * @param {Object} opts - options that affect the creation of the Duration
   * @param {string} [opts.conversionAccuracy='casual'] - the conversion system to use
   * @return {Duration}
   */
  diffNow(e = "milliseconds", n = {}) {
    return this.diff(x.now(), e, n);
  }
  /**
   * Return an Interval spanning between this DateTime and another DateTime
   * @param {DateTime} otherDateTime - the other end point of the Interval
   * @return {Interval}
   */
  until(e) {
    return this.isValid ? le.fromDateTimes(this, e) : this;
  }
  /**
   * Return whether this DateTime is in the same unit of time as another DateTime.
   * Higher-order units must also be identical for this function to return `true`.
   * Note that time zones are **ignored** in this comparison, which compares the **local** calendar time. Use {@link DateTime#setZone} to convert one of the dates if needed.
   * @param {DateTime} otherDateTime - the other DateTime
   * @param {string} unit - the unit of time to check sameness on
   * @param {Object} opts - options
   * @param {boolean} [opts.useLocaleWeeks=false] - If true, use weeks based on the locale, i.e. use the locale-dependent start of the week; only the locale of this DateTime is used
   * @example DateTime.now().hasSame(otherDT, 'day'); //~> true if otherDT is in the same current calendar day
   * @return {boolean}
   */
  hasSame(e, n, r) {
    if (!this.isValid) return !1;
    const s = e.valueOf(), i = this.setZone(e.zone, { keepLocalTime: !0 });
    return i.startOf(n, r) <= s && s <= i.endOf(n, r);
  }
  /**
   * Equality check
   * Two DateTimes are equal if and only if they represent the same millisecond, have the same zone and location, and are both valid.
   * To compare just the millisecond values, use `+dt1 === +dt2`.
   * @param {DateTime} other - the other DateTime
   * @return {boolean}
   */
  equals(e) {
    return this.isValid && e.isValid && this.valueOf() === e.valueOf() && this.zone.equals(e.zone) && this.loc.equals(e.loc);
  }
  /**
   * Returns a string representation of a this time relative to now, such as "in two days". Can only internationalize if your
   * platform supports Intl.RelativeTimeFormat. Rounds down by default.
   * @param {Object} options - options that affect the output
   * @param {DateTime} [options.base=DateTime.now()] - the DateTime to use as the basis to which this time is compared. Defaults to now.
   * @param {string} [options.style="long"] - the style of units, must be "long", "short", or "narrow"
   * @param {string|string[]} options.unit - use a specific unit or array of units; if omitted, or an array, the method will pick the best unit. Use an array or one of "years", "quarters", "months", "weeks", "days", "hours", "minutes", or "seconds"
   * @param {boolean} [options.round=true] - whether to round the numbers in the output.
   * @param {number} [options.padding=0] - padding in milliseconds. This allows you to round up the result if it fits inside the threshold. Don't use in combination with {round: false} because the decimal output will include the padding.
   * @param {string} options.locale - override the locale of this DateTime
   * @param {string} options.numberingSystem - override the numberingSystem of this DateTime. The Intl system may choose not to honor this
   * @example DateTime.now().plus({ days: 1 }).toRelative() //=> "in 1 day"
   * @example DateTime.now().setLocale("es").toRelative({ days: 1 }) //=> "dentro de 1 día"
   * @example DateTime.now().plus({ days: 1 }).toRelative({ locale: "fr" }) //=> "dans 23 heures"
   * @example DateTime.now().minus({ days: 2 }).toRelative() //=> "2 days ago"
   * @example DateTime.now().minus({ days: 2 }).toRelative({ unit: "hours" }) //=> "48 hours ago"
   * @example DateTime.now().minus({ hours: 36 }).toRelative({ round: false }) //=> "1.5 days ago"
   */
  toRelative(e = {}) {
    if (!this.isValid) return null;
    const n = e.base || x.fromObject({}, { zone: this.zone }), r = e.padding ? this < n ? -e.padding : e.padding : 0;
    let s = ["years", "months", "days", "hours", "minutes", "seconds"], i = e.unit;
    return Array.isArray(e.unit) && (s = e.unit, i = void 0), Yi(n, this.plus(r), {
      ...e,
      numeric: "always",
      units: s,
      unit: i
    });
  }
  /**
   * Returns a string representation of this date relative to today, such as "yesterday" or "next month".
   * Only internationalizes on platforms that supports Intl.RelativeTimeFormat.
   * @param {Object} options - options that affect the output
   * @param {DateTime} [options.base=DateTime.now()] - the DateTime to use as the basis to which this time is compared. Defaults to now.
   * @param {string} options.locale - override the locale of this DateTime
   * @param {string} options.unit - use a specific unit; if omitted, the method will pick the unit. Use one of "years", "quarters", "months", "weeks", or "days"
   * @param {string} options.numberingSystem - override the numberingSystem of this DateTime. The Intl system may choose not to honor this
   * @example DateTime.now().plus({ days: 1 }).toRelativeCalendar() //=> "tomorrow"
   * @example DateTime.now().setLocale("es").plus({ days: 1 }).toRelative() //=> ""mañana"
   * @example DateTime.now().plus({ days: 1 }).toRelativeCalendar({ locale: "fr" }) //=> "demain"
   * @example DateTime.now().minus({ days: 2 }).toRelativeCalendar() //=> "2 days ago"
   */
  toRelativeCalendar(e = {}) {
    return this.isValid ? Yi(e.base || x.fromObject({}, { zone: this.zone }), this, {
      ...e,
      numeric: "auto",
      units: ["years", "months", "days"],
      calendary: !0
    }) : null;
  }
  /**
   * Return the min of several date times
   * @param {...DateTime} dateTimes - the DateTimes from which to choose the minimum
   * @return {DateTime} the min DateTime, or undefined if called with no argument
   */
  static min(...e) {
    if (!e.every(x.isDateTime))
      throw new we("min requires all arguments be DateTimes");
    return xi(e, (n) => n.valueOf(), Math.min);
  }
  /**
   * Return the max of several date times
   * @param {...DateTime} dateTimes - the DateTimes from which to choose the maximum
   * @return {DateTime} the max DateTime, or undefined if called with no argument
   */
  static max(...e) {
    if (!e.every(x.isDateTime))
      throw new we("max requires all arguments be DateTimes");
    return xi(e, (n) => n.valueOf(), Math.max);
  }
  // MISC
  /**
   * Explain how a string would be parsed by fromFormat()
   * @param {string} text - the string to parse
   * @param {string} fmt - the format the string is expected to be in (see description)
   * @param {Object} options - options taken by fromFormat()
   * @return {Object}
   */
  static fromFormatExplain(e, n, r = {}) {
    const { locale: s = null, numberingSystem: i = null } = r, a = K.fromOpts({
      locale: s,
      numberingSystem: i,
      defaultToEN: !0
    });
    return Vo(a, e, n);
  }
  /**
   * @deprecated use fromFormatExplain instead
   */
  static fromStringExplain(e, n, r = {}) {
    return x.fromFormatExplain(e, n, r);
  }
  /**
   * Build a parser for `fmt` using the given locale. This parser can be passed
   * to {@link DateTime.fromFormatParser} to a parse a date in this format. This
   * can be used to optimize cases where many dates need to be parsed in a
   * specific format.
   *
   * @param {String} fmt - the format the string is expected to be in (see
   * description)
   * @param {Object} options - options used to set locale and numberingSystem
   * for parser
   * @returns {TokenParser} - opaque object to be used
   */
  static buildFormatParser(e, n = {}) {
    const { locale: r = null, numberingSystem: s = null } = n, i = K.fromOpts({
      locale: r,
      numberingSystem: s,
      defaultToEN: !0
    });
    return new Po(i, e);
  }
  /**
   * Create a DateTime from an input string and format parser.
   *
   * The format parser must have been created with the same locale as this call.
   *
   * @param {String} text - the string to parse
   * @param {TokenParser} formatParser - parser from {@link DateTime.buildFormatParser}
   * @param {Object} opts - options taken by fromFormat()
   * @returns {DateTime}
   */
  static fromFormatParser(e, n, r = {}) {
    if (P(e) || P(n))
      throw new we(
        "fromFormatParser requires an input string and a format parser"
      );
    const { locale: s = null, numberingSystem: i = null } = r, a = K.fromOpts({
      locale: s,
      numberingSystem: i,
      defaultToEN: !0
    });
    if (!a.equals(n.locale))
      throw new we(
        `fromFormatParser called with a locale of ${a}, but the format parser was created for ${n.locale}`
      );
    const { result: u, zone: c, specificOffset: l, invalidReason: d } = n.explainFromTokens(e);
    return d ? x.invalid(d) : Et(
      u,
      c,
      r,
      `format ${n.format}`,
      e,
      l
    );
  }
  // FORMAT PRESETS
  /**
   * {@link DateTime#toLocaleString} format like 10/14/1983
   * @type {Object}
   */
  static get DATE_SHORT() {
    return Rn;
  }
  /**
   * {@link DateTime#toLocaleString} format like 'Oct 14, 1983'
   * @type {Object}
   */
  static get DATE_MED() {
    return ja;
  }
  /**
   * {@link DateTime#toLocaleString} format like 'Fri, Oct 14, 1983'
   * @type {Object}
   */
  static get DATE_MED_WITH_WEEKDAY() {
    return uf;
  }
  /**
   * {@link DateTime#toLocaleString} format like 'October 14, 1983'
   * @type {Object}
   */
  static get DATE_FULL() {
    return za;
  }
  /**
   * {@link DateTime#toLocaleString} format like 'Tuesday, October 14, 1983'
   * @type {Object}
   */
  static get DATE_HUGE() {
    return Ba;
  }
  /**
   * {@link DateTime#toLocaleString} format like '09:30 AM'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get TIME_SIMPLE() {
    return Ya;
  }
  /**
   * {@link DateTime#toLocaleString} format like '09:30:23 AM'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get TIME_WITH_SECONDS() {
    return qa;
  }
  /**
   * {@link DateTime#toLocaleString} format like '09:30:23 AM EDT'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get TIME_WITH_SHORT_OFFSET() {
    return Ga;
  }
  /**
   * {@link DateTime#toLocaleString} format like '09:30:23 AM Eastern Daylight Time'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get TIME_WITH_LONG_OFFSET() {
    return Za;
  }
  /**
   * {@link DateTime#toLocaleString} format like '09:30', always 24-hour.
   * @type {Object}
   */
  static get TIME_24_SIMPLE() {
    return Qa;
  }
  /**
   * {@link DateTime#toLocaleString} format like '09:30:23', always 24-hour.
   * @type {Object}
   */
  static get TIME_24_WITH_SECONDS() {
    return Ja;
  }
  /**
   * {@link DateTime#toLocaleString} format like '09:30:23 EDT', always 24-hour.
   * @type {Object}
   */
  static get TIME_24_WITH_SHORT_OFFSET() {
    return Xa;
  }
  /**
   * {@link DateTime#toLocaleString} format like '09:30:23 Eastern Daylight Time', always 24-hour.
   * @type {Object}
   */
  static get TIME_24_WITH_LONG_OFFSET() {
    return Ka;
  }
  /**
   * {@link DateTime#toLocaleString} format like '10/14/1983, 9:30 AM'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get DATETIME_SHORT() {
    return eo;
  }
  /**
   * {@link DateTime#toLocaleString} format like '10/14/1983, 9:30:33 AM'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get DATETIME_SHORT_WITH_SECONDS() {
    return to;
  }
  /**
   * {@link DateTime#toLocaleString} format like 'Oct 14, 1983, 9:30 AM'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get DATETIME_MED() {
    return no;
  }
  /**
   * {@link DateTime#toLocaleString} format like 'Oct 14, 1983, 9:30:33 AM'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get DATETIME_MED_WITH_SECONDS() {
    return ro;
  }
  /**
   * {@link DateTime#toLocaleString} format like 'Fri, 14 Oct 1983, 9:30 AM'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get DATETIME_MED_WITH_WEEKDAY() {
    return cf;
  }
  /**
   * {@link DateTime#toLocaleString} format like 'October 14, 1983, 9:30 AM EDT'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get DATETIME_FULL() {
    return so;
  }
  /**
   * {@link DateTime#toLocaleString} format like 'October 14, 1983, 9:30:33 AM EDT'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get DATETIME_FULL_WITH_SECONDS() {
    return io;
  }
  /**
   * {@link DateTime#toLocaleString} format like 'Friday, October 14, 1983, 9:30 AM Eastern Daylight Time'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get DATETIME_HUGE() {
    return ao;
  }
  /**
   * {@link DateTime#toLocaleString} format like 'Friday, October 14, 1983, 9:30:33 AM Eastern Daylight Time'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get DATETIME_HUGE_WITH_SECONDS() {
    return oo;
  }
}
function Pt(t) {
  if (x.isDateTime(t))
    return t;
  if (t && t.valueOf && et(t.valueOf()))
    return x.fromJSDate(t);
  if (t && typeof t == "object")
    return x.fromObject(t);
  throw new we(
    `Unknown datetime argument: ${t}, of type ${typeof t}`
  );
}
const Up = C(x.local()), us = { BASE_URL: "/", DEV: !1, MODE: "production", PROD: !0, SSR: !1, VITE_ADMIN_PORT: "9001", VITE_APP_PORT: "9000", VITE_UI_PORT: "8888" }, ah = Symbol(
  (us ? "production" : void 0) !== "production" ? "RESET" : ""
);
function oh(t, e) {
  let n = null;
  const r = /* @__PURE__ */ new Map(), s = /* @__PURE__ */ new Set(), i = (u) => {
    let c;
    if (c = r.get(u), c !== void 0)
      if (n?.(c[1], u))
        i.remove(u);
      else
        return c[0];
    const l = t(u);
    return r.set(u, [l, Date.now()]), a("CREATE", u, l), l;
  };
  function a(u, c, l) {
    for (const d of s)
      d({ type: u, param: c, atom: l });
  }
  return i.unstable_listen = (u) => (s.add(u), () => {
    s.delete(u);
  }), i.getParams = () => r.keys(), i.remove = (u) => {
    {
      if (!r.has(u)) return;
      const [c] = r.get(u);
      r.delete(u), a("REMOVE", u, c);
    }
  }, i.setShouldRemove = (u) => {
    if (n = u, !!n)
      for (const [c, [l, d]] of r)
        n(d, c) && (r.delete(c), a("REMOVE", c, l));
  }, i;
}
const uh = (t) => typeof t?.then == "function";
function ch(t = () => {
  try {
    return window.localStorage;
  } catch (n) {
    (us ? "production" : void 0) !== "production" && typeof window < "u" && console.warn(n);
    return;
  }
}, e) {
  var n;
  let r, s;
  const i = {
    getItem: (c, l) => {
      var d, m;
      const T = (S) => {
        if (S = S || "", r !== S) {
          try {
            s = JSON.parse(S, e?.reviver);
          } catch {
            return l;
          }
          r = S;
        }
        return s;
      }, E = (m = (d = t()) == null ? void 0 : d.getItem(c)) != null ? m : null;
      return uh(E) ? E.then(T) : T(E);
    },
    setItem: (c, l) => {
      var d;
      return (d = t()) == null ? void 0 : d.setItem(
        c,
        JSON.stringify(l, void 0)
      );
    },
    removeItem: (c) => {
      var l;
      return (l = t()) == null ? void 0 : l.removeItem(c);
    }
  }, a = (c) => (l, d, m) => c(l, (T) => {
    let E;
    try {
      E = JSON.parse(T || "");
    } catch {
      E = m;
    }
    d(E);
  });
  let u;
  try {
    u = (n = t()) == null ? void 0 : n.subscribe;
  } catch {
  }
  return !u && typeof window < "u" && typeof window.addEventListener == "function" && window.Storage && (u = (c, l) => {
    if (!(t() instanceof window.Storage))
      return () => {
      };
    const d = (m) => {
      m.storageArea === t() && m.key === c && l(m.newValue);
    };
    return window.addEventListener("storage", d), () => {
      window.removeEventListener("storage", d);
    };
  }), u && (i.subscribe = a(u)), i;
}
const lh = ch();
function fh(t, e, n = lh, r) {
  const s = C(
    e
  );
  return (us ? "production" : void 0) !== "production" && (s.debugPrivate = !0), s.onMount = (a) => {
    a(n.getItem(t, e));
    let u;
    return n.subscribe && (u = n.subscribe(t, a, e)), u;
  }, C(
    (a) => a(s),
    (a, u, c) => {
      const l = typeof c == "function" ? c(a(s)) : c;
      return l === ah ? (u(s, e), n.removeItem(t)) : l instanceof Promise ? l.then((d) => (u(s, d), n.setItem(t, d))) : (u(s, l), n.setItem(t, l));
    }
  );
}
var dh = Object.defineProperty, hh = (t, e, n) => e in t ? dh(t, e, { enumerable: !0, configurable: !0, writable: !0, value: n }) : t[e] = n, ve = (t, e, n) => (hh(t, typeof e != "symbol" ? e + "" : e, n), n);
function Ce(t) {
  return new Promise((e, n) => {
    t.oncomplete = t.onsuccess = () => e(t.result), t.onabort = t.onerror = () => n(t.error);
  });
}
function ph(t, e) {
  const n = indexedDB.open(t);
  n.onupgradeneeded = () => n.result.createObjectStore(e);
  const r = Ce(n);
  return (s, i) => r.then((a) => i(a.transaction(e, s).objectStore(e)));
}
let br;
function Kt() {
  return br || (br = ph("keyval-store", "keyval")), br;
}
function mh(t, e, n = Kt()) {
  return n("readwrite", (r) => (r.put(e, t), Ce(r.transaction)));
}
function Gi(t, e = Kt()) {
  return e("readwrite", (n) => (t.forEach((r) => n.put(r[1], r[0])), Ce(n.transaction)));
}
function yh(t, e = Kt()) {
  return e("readwrite", (n) => (n.delete(t), Ce(n.transaction)));
}
function vh(t = Kt()) {
  return t("readwrite", (e) => (e.clear(), Ce(e.transaction)));
}
function gh(t, e) {
  return t.openCursor().onsuccess = function() {
    this.result && (e(this.result), this.result.continue());
  }, Ce(t.transaction);
}
function Or(t = Kt()) {
  return t("readonly", (e) => {
    if (e.getAll && e.getAllKeys)
      return Promise.all([
        Ce(e.getAllKeys()),
        Ce(e.getAll())
      ]).then(([r, s]) => r.map((i, a) => [i, s[a]]));
    const n = [];
    return t("readonly", (r) => gh(r, (s) => n.push([s.key, s.value])).then(() => n));
  });
}
const Eh = "jotai-minidb", wh = {
  name: Eh,
  version: 0,
  migrations: {},
  onMigrationCompleted: () => {
    alert("Data has been migrated. Page will be reloaded"), window.location.reload();
  },
  onVersionMissmatch: () => {
  }
};
class bh {
  constructor(e = {}) {
    ve(this, "channel"), ve(this, "cache", C(void 0)), ve(this, "idbStorage"), ve(this, "metaStorage"), ve(this, "config"), ve(this, "initStarted", C(!1)), ve(this, "initialDataThenable", Oh()), ve(this, "suspendBeforeInit", C(async (s) => {
      s(this.items), await s(this.initialDataThenable).promise;
    })), ve(this, "isInitialized", C(!1)), ve(this, "items", C(
      (s, { setSelf: i }) => (s(this.initStarted) || Promise.resolve().then(i), s(this.cache)),
      async (s, i) => {
        s(this.initStarted) || (i(this.initStarted, !0), this.preloadData().then((a) => {
          i(this.cache, a), s(this.initialDataThenable).resolve();
        }), this.channel.onmessage = async (a) => {
          const u = a.data;
          u.type === "UPDATE" ? i(this.cache, (c) => ({
            ...c,
            [u.id]: u.item
          })) : u.type === "DELETE" ? i(this.cache, (c) => {
            const l = { ...c };
            return delete l[u.id], l;
          }) : u.type === "UPDATE_MANY" ? i(
            this.cache,
            Object.fromEntries(await Or(this.idbStorage))
          ) : u.type === "MIGRATION_COMPLETED" && this.config.onMigrationCompleted();
        });
      }
    )), ve(this, "entries", C((s) => Object.entries(s(this.items) || {}))), ve(this, "keys", C((s) => Object.keys(s(this.items) || {}))), ve(this, "values", C((s) => Object.values(s(this.items) || {}))), ve(this, "item", oh(
      (s) => C(
        (i) => {
          var a;
          return (a = i(this.items)) == null ? void 0 : a[s];
        },
        async (i, a, u) => {
          await a(this.set, s, u);
        }
      )
    )), ve(this, "set", C(
      null,
      async (s, i, a, u) => {
        s(this.cache) || await s(this.suspendBeforeInit);
        const c = s(this.cache);
        if (!c)
          throw new Error("Cache was not initialized");
        const l = Sh(u) ? u(c[a]) : u;
        i(this.cache, (d) => ({ ...d, [a]: l })), await mh(a, l, this.idbStorage), this.channel.postMessage({ type: "UPDATE", id: a, item: l });
      }
    )), ve(this, "setMany", C(null, async (s, i, a) => {
      s(this.cache) || await s(this.suspendBeforeInit);
      const u = { ...s(this.cache) };
      for (const [c, l] of a)
        u[c] = l;
      i(this.cache, u), await Gi(a, this.idbStorage), this.channel.postMessage({ type: "UPDATE_MANY" });
    })), ve(this, "delete", C(null, async (s, i, a) => {
      s(this.cache) || await s(this.suspendBeforeInit), i(this.cache, (u) => {
        const c = { ...u };
        return delete c[a], c;
      }), await yh(a, this.idbStorage), this.channel.postMessage({ type: "DELETE", id: a });
    })), ve(this, "clear", C(null, async (s, i) => {
      s(this.cache) || await s(this.suspendBeforeInit), i(this.cache, {}), await vh(this.idbStorage), this.channel.postMessage({ type: "UPDATE_MANY" });
    })), this.config = { ...wh, initialData: {}, ...e };
    const { keyvalStorage: n, metaStorage: r } = Th(
      this.config.name,
      "key-value",
      this.config.initialData
    );
    this.idbStorage = n, this.metaStorage = r, this.channel = new BroadcastChannel(
      `jotai-minidb-broadcast:${this.config.name}`
    );
  }
  async preloadData() {
    return await this.migrate(), Object.fromEntries(await Or(this.idbStorage));
  }
  async migrate() {
    const e = await this.metaStorage(
      "readonly",
      (n) => Ce(n.get("version"))
    ) || 0;
    if (this.config.version > e) {
      let n = await Or(this.idbStorage);
      for (let r = e + 1; r <= this.config.version; r++) {
        const s = this.config.migrations[r];
        if (!s)
          throw new Error(
            `Migrate function for version ${r} is not provided`
          );
        n = await Promise.all(
          n.map(
            async ([i, a]) => [i, await s(a)]
          )
        );
      }
      await Gi(n, this.idbStorage), await this.metaStorage(
        "readwrite",
        (r) => Ce(r.put(this.config.version, "version"))
      ), this.channel.postMessage({ type: "MIGRATION_COMPLETED" });
    } else if (this.config.version < e)
      throw this.config.onVersionMissmatch(), new Error(
        `[jotai-minidb] Minimal client version is ${this.config.version} but indexeddb database version is ${e}`
      );
  }
}
function Oh() {
  return C(() => {
    let t, e;
    return {
      promise: new Promise((n, r) => {
        t = n, e = r;
      }),
      resolve: t,
      reject: e
    };
  });
}
function Th(t, e, n) {
  const r = indexedDB.open(t), s = [];
  r.onupgradeneeded = (a) => {
    const u = r.result.createObjectStore(e);
    r.result.createObjectStore("_meta");
    for (const [c, l] of Object.entries(n))
      s.push(
        Ce(u.add(l, c))
      );
  };
  const i = Ce(r);
  return {
    keyvalStorage: async (a, u) => {
      const c = await i;
      return await Promise.all(s), u(c.transaction(e, a).objectStore(e));
    },
    metaStorage: (a, u) => i.then(
      (c) => u(c.transaction("_meta", a).objectStore("_meta"))
    )
  };
}
function Sh(t) {
  return typeof t == "function";
}
const Bn = new bh(), $p = $a(), Zi = fh("appState", {
  spheres: {
    currentSphereHash: "",
    byHash: { default: {} }
  },
  hierarchies: {
    byRootOrbitEntryHash: {}
  },
  orbitNodes: {
    currentOrbitHash: null,
    byHash: { default: {} }
  },
  wins: {},
  ui: {
    listSortFilter: {
      sortCriteria: "name",
      sortOrder: "lowestToGreatest"
    },
    currentDay: (/* @__PURE__ */ new Date()).toISOString()
  }
}), Q = C(
  (t) => t(Zi),
  (t, e, n) => {
    e(Zi, n);
  }
);
var Ve;
((t) => {
  t.LESS_THAN_DAILY = {
    WEEKLY: 0.143,
    // 1/7 rounded to 3 decimal places
    MONTHLY: 0.032,
    // 1/31 rounded to 3 decimal places
    QUARTERLY: 0.011
    // 1/91 rounded to 3 decimal places
  }, t.ONE_SHOT = 0, t.DAILY_OR_MORE = {
    DAILY: 1,
    TWO: 2,
    THREE: 3,
    FOUR: 4,
    FIVE: 5,
    SIX: 6,
    SEVEN: 7,
    EIGHT: 8,
    NINE: 9,
    TEN: 10,
    ELEVEN: 11,
    TWELVE: 12,
    THIRTEEN: 13,
    FOURTEEN: 14,
    FIFTEEN: 15,
    SIXTEEN: 16,
    SEVENTEEN: 17,
    EIGHTEEN: 18,
    NINETEEN: 19,
    TWENTY: 20,
    TWENTY_ONE: 21,
    TWENTY_TWO: 22,
    TWENTY_THREE: 23,
    HOURLY: 24
  };
})(Ve || (Ve = {}));
const _h = (t) => {
  switch (t) {
    case Qe.OneShot:
      return Ve.ONE_SHOT;
    case Qe.DailyOrMore_1d:
      return Ve.DAILY_OR_MORE.DAILY;
    case Qe.DailyOrMore_2d:
      return Ve.DAILY_OR_MORE.TWO;
    case Qe.DailyOrMore_3d:
      return Ve.DAILY_OR_MORE.THREE;
    case Qe.LessThanDaily_1w:
      return Ve.LESS_THAN_DAILY.WEEKLY;
    case Qe.LessThanDaily_1m:
      return Ve.LESS_THAN_DAILY.MONTHLY;
    case Qe.LessThanDaily_1q:
      return Ve.LESS_THAN_DAILY.QUARTERLY;
    default:
      throw new Error(`Unsupported GraphQL frequency: ${t}`);
  }
}, Hp = (t) => {
  const e = _h(t.frequency);
  return {
    id: t.id,
    eH: t.eH,
    parentEh: t.parentHash || void 0,
    name: t.name,
    scale: t.scale,
    sphereHash: t.sphereHash,
    frequency: e,
    description: t.metadata?.description || "",
    startTime: t.metadata?.timeframe.startTime,
    endTime: t.metadata?.timeframe.endTime || void 0
  };
}, kh = C((t) => {
  const n = t(Q).spheres.currentSphereHash;
  return n && t(Bn.item(n)) || null;
});
kh.testId = "currentSphereOrbitNodeDetailsAtom";
const He = (t) => C((e) => {
  const n = e(Bn.entries)?.map(
    //@ts-ignore
    ([i, a]) => a
  ), r = n?.find(
    (i) => i[t]
  );
  return !n || !r ? null : r[t] || null;
});
He.testId = "getOrbitNodeDetailsFromEhAtom";
const jo = C((t) => {
  const e = t(zo)?.id;
  if (!e) return null;
  let n = e;
  if (!n.startsWith("uhCE")) {
    const r = t(ls(e));
    if (!r) return null;
    n = r;
  }
  return t(He(n));
});
jo.testId = "currentOrbitDetailsAtom";
const cs = (t) => C((e) => {
  const n = e(ls(t));
  return !n || typeof n != "string" ? null : e(He(n));
});
cs.testId = "getOrbitNodeDetailsFromIdAtom";
const Nh = (t) => C((e) => {
  const n = e(Q), r = n.spheres.currentSphereHash;
  if (!n.spheres.byHash[r]) return null;
  const i = e(
    Bn.item(r)
  );
  return i && i[t] || null;
}), jp = C(
  (t) => (e) => t(Nh(e))?.startTime || null
), zp = C(
  null,
  (t, e, {
    orbitEh: n,
    update: r
  }) => {
    const s = t(Q), i = Object.keys(s.orbitNodes.byHash).find(
      (u) => s.orbitNodes.byHash[u].eH === n
    );
    if (!i) return;
    const a = {
      ...s,
      orbitNodes: {
        ...s.orbitNodes,
        byHash: {
          ...s.orbitNodes.byHash,
          [i]: {
            ...s.orbitNodes.byHash[i],
            ...r
          }
        }
      }
    };
    e(Q, a);
  }
), Ih = C((t) => {
  const e = t(jo)?.id;
  return e ? t(Bo(e)) : null;
});
Ih.testId = "currentOrbitIsLeafAtom";
const Bp = (t) => C((n) => n(cs(t))?.frequency || null), Yp = C(
  (t) => {
    const e = t(Q), n = e.spheres.currentSphereHash, r = e.spheres.byHash[n];
    if (!r) return null;
    const s = {};
    return Object.entries(e.orbitNodes.byHash).forEach(([i, a]) => {
      a.sphereHash === r.details.entryHash && (s[i] = a);
    }), Object.keys(s).length > 0 ? s : null;
  }
), zo = C(
  (t) => {
    const e = t(Q);
    return e.orbitNodes.currentOrbitHash ? { id: e.orbitNodes.currentOrbitHash } : null;
  },
  (t, e, n) => {
    const r = t(Q), s = {
      ...r,
      orbitNodes: {
        ...r.orbitNodes,
        currentOrbitHash: n
      }
    };
    e(Q, s);
  }
);
zo.testId = "currentOrbitIdAtom";
const Dh = (t) => C((e) => {
  const n = e(Q);
  return Object.keys(n.orbitNodes.byHash).find(
    (s) => n.orbitNodes.byHash[s].eH === t
  ) || null;
});
Dh.testId = "getOrbitIdFromEh";
const ls = (t) => C((e) => e(Q).orbitNodes.byHash[t]?.eH || null), qp = (t) => C((n) => n(Q).wins[t] || {});
function Ch(t) {
  var e = 0, n = t.children, r = n && n.length;
  if (!r) e = 1;
  else for (; --r >= 0; ) e += n[r].value;
  t.value = e;
}
function Ah() {
  return this.eachAfter(Ch);
}
function xh(t, e) {
  let n = -1;
  for (const r of this)
    t.call(e, r, ++n, this);
  return this;
}
function Rh(t, e) {
  for (var n = this, r = [n], s, i, a = -1; n = r.pop(); )
    if (t.call(e, n, ++a, this), s = n.children)
      for (i = s.length - 1; i >= 0; --i)
        r.push(s[i]);
  return this;
}
function Mh(t, e) {
  for (var n = this, r = [n], s = [], i, a, u, c = -1; n = r.pop(); )
    if (s.push(n), i = n.children)
      for (a = 0, u = i.length; a < u; ++a)
        r.push(i[a]);
  for (; n = s.pop(); )
    t.call(e, n, ++c, this);
  return this;
}
function Fh(t, e) {
  let n = -1;
  for (const r of this)
    if (t.call(e, r, ++n, this))
      return r;
}
function Lh(t) {
  return this.eachAfter(function(e) {
    for (var n = +t(e.data) || 0, r = e.children, s = r && r.length; --s >= 0; ) n += r[s].value;
    e.value = n;
  });
}
function Ph(t) {
  return this.eachBefore(function(e) {
    e.children && e.children.sort(t);
  });
}
function Vh(t) {
  for (var e = this, n = Wh(e, t), r = [e]; e !== n; )
    e = e.parent, r.push(e);
  for (var s = r.length; t !== n; )
    r.splice(s, 0, t), t = t.parent;
  return r;
}
function Wh(t, e) {
  if (t === e) return t;
  var n = t.ancestors(), r = e.ancestors(), s = null;
  for (t = n.pop(), e = r.pop(); t === e; )
    s = t, t = n.pop(), e = r.pop();
  return s;
}
function Uh() {
  for (var t = this, e = [t]; t = t.parent; )
    e.push(t);
  return e;
}
function $h() {
  return Array.from(this);
}
function Hh() {
  var t = [];
  return this.eachBefore(function(e) {
    e.children || t.push(e);
  }), t;
}
function jh() {
  var t = this, e = [];
  return t.each(function(n) {
    n !== t && e.push({ source: n.parent, target: n });
  }), e;
}
function* zh() {
  var t = this, e, n = [t], r, s, i;
  do
    for (e = n.reverse(), n = []; t = e.pop(); )
      if (yield t, r = t.children)
        for (s = 0, i = r.length; s < i; ++s)
          n.push(r[s]);
  while (n.length);
}
function fs(t, e) {
  t instanceof Map ? (t = [void 0, t], e === void 0 && (e = qh)) : e === void 0 && (e = Yh);
  for (var n = new Pn(t), r, s = [n], i, a, u, c; r = s.pop(); )
    if ((a = e(r.data)) && (c = (a = Array.from(a)).length))
      for (r.children = a, u = c - 1; u >= 0; --u)
        s.push(i = a[u] = new Pn(a[u])), i.parent = r, i.depth = r.depth + 1;
  return n.eachBefore(Zh);
}
function Bh() {
  return fs(this).eachBefore(Gh);
}
function Yh(t) {
  return t.children;
}
function qh(t) {
  return Array.isArray(t) ? t[1] : null;
}
function Gh(t) {
  t.data.value !== void 0 && (t.value = t.data.value), t.data = t.data.data;
}
function Zh(t) {
  var e = 0;
  do
    t.height = e;
  while ((t = t.parent) && t.height < ++e);
}
function Pn(t) {
  this.data = t, this.depth = this.height = 0, this.parent = null;
}
Pn.prototype = fs.prototype = {
  constructor: Pn,
  count: Ah,
  each: xh,
  eachAfter: Mh,
  eachBefore: Rh,
  find: Fh,
  sum: Lh,
  sort: Ph,
  path: Vh,
  ancestors: Uh,
  descendants: $h,
  leaves: Hh,
  links: jh,
  copy: Bh,
  [Symbol.iterator]: zh
};
const Qh = C(
  (t) => {
    const e = t(Q), n = e.spheres.currentSphereHash, r = e.spheres.byHash[n];
    return r ? {
      entryHash: r.details.entryHash,
      actionHash: n
    } : null;
  },
  (t, e, n) => {
    const r = t(Q);
    if (!n) return;
    const s = {
      ...r,
      spheres: {
        ...r.spheres,
        currentSphereHash: n
      }
    };
    e(Q, s);
  }
);
Qh.testId = "currentSphereHashes";
const Jh = C((t) => {
  const e = t(Q), n = e.spheres.currentSphereHash;
  return e.spheres.byHash[n]?.details || null;
});
Jh.testId = "currentSphereDetailsAtom";
const Xh = (t) => C((e) => {
  const n = e(Q), r = Object.entries(n.spheres.byHash).find(
    ([s, i]) => i.details.entryHash == t
  );
  return r && r[0] || null;
}), Gp = C((t) => {
  const n = t(Q).spheres.currentSphereHash;
  return n ? t(Kh(n)) : !1;
}), Kh = (t) => C((e) => {
  const r = e(Q).spheres.byHash[t];
  if (!r) return null;
  const s = r.hierarchyRootOrbitEntryHashes;
  return !s || s.length == 0 || !e(Bn.item(t)) ? null : s.every((a) => !!e(He(a)));
});
C(
  null,
  (t, e, {
    orbitHash: n,
    date: r,
    winData: s
  }) => {
    const i = t(Q), a = i.wins[n] || {};
    e(Q, {
      ...i,
      wins: {
        ...i.wins,
        [n]: {
          ...a,
          [r]: s
        }
      }
    });
  }
);
const Zp = (t) => C(
  (e) => e(Q).wins[t] || null,
  (e, n, r) => {
    const s = e(Q);
    n(Q, {
      ...s,
      wins: {
        ...s.wins,
        [t]: r
      }
    });
  }
), Qi = (t, e) => C((n) => {
  const r = n(Q);
  let s = t;
  if (!s.startsWith("uhCE")) {
    const d = n(ls(t));
    if (!d) return null;
    s = d;
  }
  const i = n(
    He(s)
  ), a = r.wins[s] || {};
  if (!i) return !1;
  const u = a[e];
  return i.frequency > 1 ? u?.every((d) => d) : typeof u > "u" ? !1 : u;
}), ep = (t, e) => C((n) => {
  const r = n(
    He(t)
  );
  if (!r) return null;
  if (n(Bo(r.id)))
    return n(Qi(t, e));
  {
    const i = n(Yo(t));
    return i ? i.flat().every((a) => n(Qi(a.content, e))) : null;
  }
}), tp = (t) => C((e) => {
  console.log("Starting calculation for:", t);
  const n = e(He(t));
  if (console.log("Got orbit details:", {
    orbitEh: t,
    orbit: n,
    exists: !!n
  }), !n)
    return console.warn("No orbit found for:", t), null;
  const r = e(Yo(t));
  if (console.log("Got leaf descendants:", {
    orbitEh: t,
    leafDescendants: r,
    count: r?.length,
    exists: !!r
  }), !r)
    return console.warn("No leaf descendants found for:", t), null;
  const s = x.now(), i = s.startOf("month"), a = s.endOf("month"), u = {};
  let c = i;
  for (console.log("Calculating for date range:", {
    start: i.toLocaleString(),
    end: a.toLocaleString()
  }); c <= a; ) {
    const l = c.toLocaleString(), d = r.every((m) => e(ep(m.content, l)));
    n.frequency > 1 ? u[l] = Array(n.frequency).fill(d) : u[l] = d, c = c.plus({ days: 1 });
  }
  return console.log("Final calculated win data:", {
    orbitEh: t,
    winData: u
  }), u;
}), np = (t) => {
  const e = cs(t);
  return C((r) => {
    const s = r(e);
    if (!s) return null;
    const i = r(Q), a = x.now().toLocaleString(), u = i.wins[s.eH] || {};
    let c = 0, l = x.fromFormat(a, "dd/MM/yyyy");
    for (; ; ) {
      const d = l.toFormat("dd/MM/yyyy"), m = u[d];
      if (m === void 0) break;
      if (Array.isArray(m))
        if (m.every(Boolean))
          c++;
        else
          break;
      else if (m === !0)
        c++;
      else
        break;
      l = l.minus({ days: 1 });
    }
    return c;
  });
};
np.testId = "calculateCurrentStreakAtom";
const rp = (t) => C((n) => {
  const r = n(Q), s = r.orbitNodes.byHash[t];
  if (!s) return null;
  const i = r.wins[s.eH] || {};
  let a = 0, u = 0, c = null;
  const l = Object.keys(i).sort((d, m) => {
    const T = x.fromFormat(d, "dd/MM/yyyy"), E = x.fromFormat(m, "dd/MM/yyyy");
    return T.toMillis() - E.toMillis();
  });
  for (const d of l) {
    const m = i[d], T = x.fromFormat(d, "dd/MM/yyyy");
    c && T.diff(c, "days").days !== 1 && (u = 0), Array.isArray(m) ? m.every(Boolean) ? u++ : u = 0 : m === !0 ? u++ : u = 0, u > a && (a = u), c = T;
  }
  return a;
});
rp.testId = "calculateLongestStreakAtom";
const Yt = C({});
Yt.testId = "currentSphereHierarchyBounds";
const qt = C({
  x: 0,
  y: 0
});
qt.testId = "currentSphereHierarchyIndices";
const Qp = C(null, (t, e, n) => {
  const r = t(qt);
  e(qt, { ...r, x: n });
}), Jp = C(null, (t, e, n) => {
  const r = t(qt);
  e(qt, { ...r, x: n });
}), Xp = C(
  null,
  (t, e, n, [r, s]) => {
    const i = t(Yt);
    e(Yt, {
      ...i,
      [n]: { ...i[n], minDepth: r, maxDepth: s }
    });
  }
), Kp = C(
  null,
  (t, e, n, [r, s]) => {
    const i = t(Yt);
    e(Yt, {
      ...i,
      [n]: { ...i[n], minBreadth: r, maxBreadth: s }
    });
  }
), sp = C({
  id: null
});
sp.testId = "newTraversalLevelIndexId";
const em = (t) => C((n) => n(Q).hierarchies.byRootOrbitEntryHash[t] || null), tm = C(
  null,
  (t, e, n) => {
    if (!n?.rootData) return null;
    const r = t(Q), s = n.rootData.data.content, i = [], a = [];
    let u;
    const c = Object.keys(r.orbitNodes.byHash);
    n.rootData.each((T) => {
      const E = T.data.content, S = c.find(
        (_) => r.orbitNodes.byHash[_].eH === E
      );
      S && (r.orbitNodes.currentOrbitHash == S && (u = S), i.push(S), T.data?.children && T.data.children.length == 0 && a.push(S));
    });
    const l = {
      rootNode: s,
      json: n?._json,
      bounds: void 0,
      // TODO: decide whether to keep this as a primitive atom and remove from appstate
      indices: void 0,
      // TODO: decide whether to keep this as a primitive atom and remove from appstate
      currentNode: u,
      nodeHashes: i,
      leafNodeHashes: a
    }, d = r.spheres.byHash[n.sphereAh]?.hierarchyRootOrbitEntryHashes || [], m = {
      ...r,
      spheres: {
        ...r.spheres,
        byHash: {
          ...r.spheres.byHash,
          [n.sphereAh]: {
            ...r.spheres.byHash[n.sphereAh],
            hierarchyRootOrbitEntryHashes: d.includes(s) ? d : [
              ...d,
              s
            ]
          }
        }
      },
      hierarchies: {
        ...r.hierarchies,
        byRootOrbitEntryHash: {
          ...r.hierarchies.byRootOrbitEntryHash,
          [s]: l
        }
      }
    };
    e(Q, m);
  }
), ip = (t) => C((e) => {
  const n = e(Q), r = Object.values(n.spheres.byHash).find(
    (s) => s?.details?.entryHash === t
  );
  return !r || !r.hierarchyRootOrbitEntryHashes.length ? null : r.hierarchyRootOrbitEntryHashes[0];
}), nm = (t) => C((e) => {
  const n = e(ip(t));
  return !n || !e(He(n)) ? null : e(tp(n));
}), Bo = (t) => C((e) => {
  const r = e(Q).hierarchies.byRootOrbitEntryHash;
  for (const s in r)
    if (r[s]?.leafNodeHashes?.includes(t))
      return !0;
  return !1;
}), Yo = (t) => C((e) => {
  const n = e(Q), r = e(
    He(t)
  );
  if (!r) return null;
  const s = r.id;
  let i = null, a = null;
  for (const [d, m] of Object.entries(
    n.hierarchies.byRootOrbitEntryHash
  ))
    if (m.nodeHashes.includes(t) || m.nodeHashes.includes(s)) {
      i = m.json, a = d;
      break;
    }
  if (!i || !a) return null;
  const u = JSON.parse(i);
  return (fs(u[0]).find((d) => d.data.content === r.eH)?.leaves() || []).map((d) => d.data);
}), rm = (t) => C((n) => {
  const r = n(Q), s = r.hierarchies.byRootOrbitEntryHash[t], i = r.orbitNodes.byHash[t].sphereHash, a = n(Xh(i));
  return null;
});
export {
  Sp as $,
  vp as A,
  Sa as B,
  va as C,
  Nr as D,
  ea as E,
  yp as F,
  Qr as G,
  cp as H,
  lp as I,
  We as J,
  L as K,
  ta as L,
  zt as M,
  Pn as N,
  bt as O,
  sl as P,
  hc as Q,
  nc as R,
  ri as S,
  wp as T,
  Rr as U,
  _a as V,
  si as W,
  ac as X,
  Ep as Y,
  ct as Z,
  X as _,
  Ki as a,
  Kh as a$,
  Tp as a0,
  Jr as a1,
  ic as a2,
  Op as a3,
  Dn as a4,
  gp as a5,
  sa as a6,
  Ca as a7,
  Z as a8,
  $a as a9,
  zo as aA,
  Bl as aB,
  Fp as aC,
  Pp as aD,
  kh as aE,
  jo as aF,
  Up as aG,
  Dh as aH,
  ep as aI,
  Bo as aJ,
  Zp as aK,
  tp as aL,
  Cp as aM,
  Vp as aN,
  Yt as aO,
  Ih as aP,
  jp as aQ,
  ye as aR,
  g as aS,
  pa as aT,
  Dp as aU,
  Vl as aV,
  Hp as aW,
  Rp as aX,
  Zi as aY,
  Lp as aZ,
  Yp as a_,
  Wp as aa,
  $p as ab,
  Jh as ac,
  kp as ad,
  xp as ae,
  np as af,
  rp as ag,
  op as ah,
  ap as ai,
  qt as aj,
  Jp as ak,
  Qp as al,
  Qh as am,
  Bn as an,
  Q as ao,
  Ap as ap,
  _h as aq,
  _p as ar,
  Ip as as,
  Mp as at,
  ls as au,
  Qe as av,
  Ll as aw,
  x as ax,
  He as ay,
  sp as az,
  up as b,
  Gp as b0,
  Kp as b1,
  Xp as b2,
  Np as b3,
  tm as b4,
  em as b5,
  ip as b6,
  nm as b7,
  Yo as b8,
  rm as b9,
  cs as ba,
  Nh as bb,
  zp as bc,
  Bp as bd,
  qp as be,
  Xh as bf,
  Ve as bg,
  Zh as c,
  ar as d,
  ha as e,
  mc as f,
  Xi as g,
  fs as h,
  dp as i,
  ca as j,
  Pc as k,
  oc as l,
  uc as m,
  Wc as n,
  Ue as o,
  hp as p,
  fp as q,
  qr as r,
  Le as s,
  wa as t,
  Jc as u,
  Dr as v,
  mp as w,
  pp as x,
  Zc as y,
  bp as z
};
