export const RAISIN_BLACK = "rgba(36, 36, 36, 1)";
export const KEPPEL = "rgba(54, 175, 152, 1)";
export const DEEP_SPACE = "rgba(69, 97, 95, 1)";
export const MAJORELLE_BLUE = "#6069df";
export const PURPLE = "#8b67e5";
export const BLUE_CYAN = "#5380e5";
export const SEA_GREEN = "rgba(11,254,184, 1)";
export const RIPE_MANGO = "rgba(251,200,43, 1)";
export const DEEP_CARMINE = "rgba(231,50,50, 1)";
export const OPAL = "rgba(169,189,182, 1)";
export const CHINESE_WHITE = "rgba(219,228,226, 1)";
export const WHITE = "rgb(255, 255, 255)";
export const BLUE_GRAY = "#688acc";
export const MOSS_GREEN = "#c0dea9";
export const AMETHYST = "#9e5fcb";
export const CEIL = "#92a8d4";
export const BURNT_SIENNA = "#f16d53";
export const SUNRAY = "#e2b657";
export const LAVENDER_GRAY = "#c0c7ce";
export const SPANISH_GRAY = "#909896";
export const DAVYS_GRAY = "#505554";
export const ONYX = "#37383a";
export const RICH_BLACK = "#00120f";
export function changeOpacity(color, newOpacity) {
    if (newOpacity < 0 || newOpacity > 1) {
        throw new Error('Opacity must be between 0 and 1.');
    }
    const rgbaRegex = /rgba\((\d{1,3}), (\d{1,3}), (\d{1,3}), (\d(\.\d+)?)\)/;
    const match = color.match(rgbaRegex);
    if (!match) {
        throw new Error('Invalid RGBA color format.');
    }
    const updatedColor = `rgba(${match[1]}, ${match[2]}, ${match[3]}, ${newOpacity})`;
    return updatedColor;
}
//# sourceMappingURL=colour-palette.js.map