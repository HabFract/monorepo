export declare function checkForAppUpdates(onUserClick?: boolean): Promise<void>;
//# sourceMappingURL=update.d.ts.map