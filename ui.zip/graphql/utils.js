export const extractEdges = (withEdges) => {
    if (!withEdges?.edges || !withEdges.edges.length) {
        return [];
    }
    return withEdges.edges.map(({ node }) => node);
};
export const createEdges = (nodes) => {
    const edges = nodes.map((node) => ({ node, cursor: null }));
    return { edges };
};
export function serializeAsyncActions(actions) {
    let actionFiber = Promise.resolve({});
    actionFiber = actions.reduce((chain, curr) => chain.then(curr), actionFiber);
}
//# sourceMappingURL=utils.js.map