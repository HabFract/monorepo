import { ADMIN_WS_PORT, APP_WS_PORT, HAPP_DNA_NAME, HAPP_ID, NODE_ENV } from '../constants';
import { AdminWebsocket, AppWebsocket } from '@holochain/client';
import deepForEach from 'deep-for-each';
import { format, parse } from 'fecha';
import isObject from 'is-object';
import { Base64 } from 'js-base64';
export function getCellId(cellInfo) {
    if ("provisioned" in cellInfo) {
        return cellInfo.provisioned.cell_id;
    }
    if ("cloned" in cellInfo) {
        return cellInfo.cloned.cell_id;
    }
    throw new Error("CellInfo does not contain a CellId.");
}
const DEFAULT_CONNECTION_URI = `ws://localhost:${APP_WS_PORT}` || '';
const HOLOCHAIN_APP_ID = HAPP_ID || '';
const CONNECTION_CACHE = {};
export async function autoConnect(conductorUri) {
    console.log(`Environment: `, NODE_ENV);
    const dev = NODE_ENV == 'dev';
    let dnaConfig, appWs;
    if (!conductorUri) {
        conductorUri = (dev ? DEFAULT_CONNECTION_URI : `ws://localhost:NONE`);
    }
    if (!dev) {
        appWs = await openConnection();
        dnaConfig = await sniffHolochainAppCells(appWs);
    }
    else {
        const adminWs = await AdminWebsocket.connect({ url: new URL(`ws://localhost:${ADMIN_WS_PORT}`) });
        const token = await adminWs.issueAppAuthenticationToken({ installed_app_id: HAPP_ID });
        appWs = await openConnection(token.token);
        dnaConfig = await sniffHolochainAppCells(appWs);
        await adminWs.authorizeSigningCredentials(dnaConfig[HAPP_DNA_NAME].cell_id);
    }
    CONNECTION_CACHE[HAPP_ID] = { client: appWs, dnaConfig, conductorUri };
    return CONNECTION_CACHE[HAPP_ID];
}
export const openConnection = (token) => {
    return AppWebsocket.connect(NODE_ENV == 'dev' ? { token, url: DEFAULT_CONNECTION_URI } : undefined).then((client) => {
        console.log(`Holochain connection to ${HAPP_ID} OK:`, client);
        return client;
    });
};
export const getConnection = async () => {
    if (!CONNECTION_CACHE[HAPP_ID]) {
        return autoConnect();
    }
    return CONNECTION_CACHE[HAPP_ID];
};
export async function sniffHolochainAppCells(conn, appID) {
    const appInfo = await conn.appInfo();
    if (!appInfo) {
        throw new Error(`appInfo call failed for Holochain app '${appID || HOLOCHAIN_APP_ID}' - ensure the name is correct and that the app installation has succeeded`);
    }
    const dnas = (appInfo['cell_info']);
    const dnaMappings = { [HAPP_DNA_NAME]: dnas[HAPP_DNA_NAME][0]['provisioned'] };
    return dnaMappings;
}
const HOLOCHAIN_IDENTIFIER_LEN = 39;
const HOLOHASH_PREFIX_DNA = [0x84, 0x2d, 0x24];
const HOLOHASH_PREFIX_ENTRY = [0x84, 0x21, 0x24];
const HOLOHASH_PREFIX_HEADER = [0x84, 0x29, 0x24];
const HOLOHASH_PREFIX_AGENT = [0x84, 0x20, 0x24];
const serializedHashMatchRegex = /^[A-Za-z0-9_+\-/]{53}={0,2}$/;
const idMatchRegex = /^[A-Za-z0-9_+\-/]{53}={0,2}:[A-Za-z0-9_+\-/]{53}={0,2}$/;
const stringIdRegex = /^\w+?:[A-Za-z0-9_+\-/]{53}={0,2}$/;
export function deserializeHash(hash) {
    return Base64.toUint8Array(hash.slice(1));
}
function deserializeId(field) {
    const matches = field.split(':');
    return [
        Buffer.from(deserializeHash(matches[1])),
        Buffer.from(deserializeHash(matches[0])),
    ];
}
function deserializeStringId(field) {
    const matches = field.split(':');
    return [Buffer.from(deserializeHash(matches[1])), matches[0]];
}
export function serializeHash(hash) {
    return `u${Base64.fromUint8Array(hash, true)}`;
}
function seralizeId(id) {
    return `${serializeHash(id[1])}:${serializeHash(id[0])}`;
}
function seralizeStringId(id) {
    return `${id[1]}:${serializeHash(id[0])}`;
}
export function remapCellId(originalId, newCellId) {
    const [origId, _origCell] = originalId.split(':');
    return `${origId}:${newCellId.split(':')[1]}`;
}
const LONG_DATETIME_FORMAT = 'YYYY-MM-DDTHH:mm:ss.SSSZ';
const SHORT_DATETIME_FORMAT = 'YYYY-MM-DDTHH:mm:ssZ';
const isoDateRegex = /^\d{4}-\d\d-\d\d(T\d\d:\d\d:\d\d(\.\d\d\d)?)?([+-]\d\d:\d\d)?$/;
const decodeFields = (result) => {
    deepForEach(result, (value, prop, subject) => {
        if ((value instanceof Buffer || value instanceof Uint8Array) &&
            value.length === HOLOCHAIN_IDENTIFIER_LEN &&
            checkLeadingBytes(value, HOLOHASH_PREFIX_HEADER)) {
            subject[prop] = serializeHash(value);
        }
        if (Array.isArray(value) &&
            value.length == 2 &&
            (value[0] instanceof Buffer || value[0] instanceof Uint8Array) &&
            value[0].length === HOLOCHAIN_IDENTIFIER_LEN &&
            checkLeadingBytes(value[0], HOLOHASH_PREFIX_DNA)) {
            if ((value[1] instanceof Buffer || value[1] instanceof Uint8Array) &&
                value[1].length === HOLOCHAIN_IDENTIFIER_LEN &&
                (checkLeadingBytes(value[1], HOLOHASH_PREFIX_ENTRY) ||
                    checkLeadingBytes(value[1], HOLOHASH_PREFIX_HEADER) ||
                    checkLeadingBytes(value[1], HOLOHASH_PREFIX_AGENT))) {
                subject[prop] = seralizeId(value);
            }
            else {
                subject[prop] = seralizeStringId(value);
            }
        }
        if (value && value.match && value.match(isoDateRegex)) {
            subject[prop] = parse(value, LONG_DATETIME_FORMAT);
            if (subject[prop] === null) {
                subject[prop] = parse(value, SHORT_DATETIME_FORMAT);
            }
        }
    });
};
function checkLeadingBytes(ofVar, against) {
    return (ofVar[0] === against[0] &&
        ofVar[1] === against[1] &&
        ofVar[2] === against[2]);
}
const encodeFields = (args) => {
    if (!args)
        return args;
    let res = args;
    if (args instanceof Date) {
        return format(args, LONG_DATETIME_FORMAT);
    }
    else if (args.match && args.match(serializedHashMatchRegex)) {
        return deserializeHash(args);
    }
    else if (args.match && args.match(idMatchRegex)) {
        return deserializeId(args);
    }
    else if (args.match && args.match(stringIdRegex)) {
        return deserializeStringId(args);
    }
    else if (Array.isArray(args)) {
        res = [];
        args.forEach((value, key) => {
            res[key] = encodeFields(value);
        });
    }
    else if (isObject(args)) {
        res = {};
        for (const key in args) {
            res[key] = encodeFields(args[key]);
        }
    }
    return res;
};
const zomeFunction = (socketURI, cell_id, zome_name, fn_name, skipEncodeDecode) => async (args) => {
    const conn = await getConnection();
    const res = await conn.client.callZome({
        cap_secret: null,
        cell_id,
        zome_name,
        fn_name,
        provenance: cell_id[1],
        payload: skipEncodeDecode ? args : encodeFields(args),
    }, 60000);
    if (!skipEncodeDecode)
        decodeFields(res);
    return res;
};
export const mapZomeFn = (mappings, socketURI, instance, zome, fn, skipEncodeDecode) => {
    return zomeFunction(socketURI, mappings && mappings[instance]['cell_id'], zome, fn, skipEncodeDecode);
};
//# sourceMappingURL=connection.js.map