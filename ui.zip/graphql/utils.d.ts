import { ApolloClient } from "@apollo/client";
import { EntryHashB64 } from "@state/types";
import { DateTime } from "luxon";
export declare function decodeEntry(record: any): unknown;
export declare function timestampToMillis(timestamp: any): number;
export declare function encodeHashToBase64(hash: any): string;
export type HolochainRecord = {
    signed_action: any;
    entry: any;
};
export declare class EntryRecord<T> {
    record: {
        signed_action: any;
        entry: any;
    };
    constructor(record: any);
    get actionHash(): any;
    get action(): any;
    get entry(): unknown;
    get entryHash(): any;
}
export declare const extractEdges: <T>(withEdges: {
    edges: {
        node: T;
    }[];
}) => T[];
export declare const createEdges: <T>(nodes: T[]) => {
    edges: {
        node: T;
    }[];
};
export declare function serializeAsyncActions<T>(actions: Array<() => Promise<T>>): void;
export declare function fetchWinDataForOrbit(client: ApolloClient<any>, orbitEh: EntryHashB64, date: DateTime): Promise<any>;
//# sourceMappingURL=utils.d.ts.map