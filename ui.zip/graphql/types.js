import { HAPP_DNA_NAME } from "../constants";
export function addTypename(name) {
    return (obj) => {
        obj["__typename"] = name;
        return obj;
    };
}
export function injectTypename(name, fn) {
    return async (root, args) => {
        const data = await fn(root, args);
        data["__typename"] = name;
        return data;
    };
}
//# sourceMappingURL=types.js.map