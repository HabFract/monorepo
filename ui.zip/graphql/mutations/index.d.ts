import { DNAIdMappings } from "../types";
declare const _default: (dnaConfig: DNAIdMappings, conductorUri: string) => {
    createWinRecord: (_: any, args: any) => Promise<{
        winData: {
            date: string;
            value: unknown;
        }[];
        id: any;
        eH: string;
    }>;
    createSphere: import("./sphere").createHandler;
    updateSphere: import("./sphere").updateHandler;
    deleteSphere: import("./sphere").deleteHandler;
    createOrbit: import("./orbit").createHandler;
    updateOrbit: import("./orbit").updateHandler;
    deleteOrbit: import("./orbit").deleteHandler;
};
export default _default;
//# sourceMappingURL=index.d.ts.map