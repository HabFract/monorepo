import Orbit from './orbit';
import Sphere from './sphere';
export default (dnaConfig, conductorUri) => {
    return {
        ...Orbit(dnaConfig, conductorUri),
        ...Sphere(dnaConfig, conductorUri),
    };
};
//# sourceMappingURL=index.js.map