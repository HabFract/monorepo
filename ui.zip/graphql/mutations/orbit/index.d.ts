import { DNAIdMappings } from "../../types";
import { CreateOrbitResponsePayload, OrbitCreateParams, OrbitUpdateParams, UpdateOrbitResponsePayload } from "../../generated";
import { ActionHashB64 } from "@state/types";
export type createArgs = {
    orbit: OrbitCreateParams;
};
export type updateArgs = {
    orbit: OrbitUpdateParams;
};
export type createHandler = (root: any, args: createArgs) => Promise<CreateOrbitResponsePayload>;
export type updateHandler = (root: any, args: updateArgs) => Promise<UpdateOrbitResponsePayload>;
export type deleteHandler = (root: any, args: {
    orbitHash: ActionHashB64;
}) => Promise<ActionHashB64>;
declare const _default: (dnaConfig: DNAIdMappings, conductorUri: string) => {
    createOrbit: createHandler;
    updateOrbit: updateHandler;
    deleteOrbit: deleteHandler;
};
export default _default;
//# sourceMappingURL=index.d.ts.map