import { DNAIdMappings } from "../../types";
import { WinRecord, WinRecordCreateParams, WinRecordUpdateParams } from "../../generated";
export type createHandler = (root: any, args: WinRecordCreateParams) => Promise<WinRecord>;
export type updateHandler = (root: any, args: WinRecordUpdateParams) => Promise<WinRecord>;
declare const _default: (dnaConfig: DNAIdMappings, conductorUri: string) => {
    createWinRecord: (_: any, args: any) => Promise<{
        winData: {
            date: string;
            value: unknown;
        }[];
        id: any;
        eH: string;
    }>;
};
export default _default;
//# sourceMappingURL=index.d.ts.map