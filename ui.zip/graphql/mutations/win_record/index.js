import { mapZomeFn } from "../../connection";
import { HAPP_DNA_NAME, HAPP_ZOME_NAME_PERSONAL_HABITS, } from "../../../constants";
import { EntryRecord, encodeHashToBase64 } from "../../utils";
export default (dnaConfig, conductorUri) => {
    const runCreate = mapZomeFn(dnaConfig, conductorUri, HAPP_DNA_NAME, HAPP_ZOME_NAME_PERSONAL_HABITS, "create_or_update_win_record");
    const createWinRecord = async (_, args) => {
        const { winRecord } = args;
        const rawRecord = await runCreate({
            orbitEh: winRecord.orbitEh,
            winData: winRecord.winData.reduce((acc, val) => {
                acc[val.date] =
                    "single" in val ? { single: val.single } : { multiple: val.multiple };
                return acc;
            }, {}),
        });
        const entryRecord = new EntryRecord(rawRecord);
        return {
            winData: Object.entries(entryRecord.entry.winData).map(([date, value]) => ({ date, value })),
            id: entryRecord.actionHash,
            eH: encodeHashToBase64(entryRecord.entryHash),
        };
    };
    return {
        createWinRecord,
    };
};
//# sourceMappingURL=index.js.map