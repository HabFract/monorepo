import { DNAIdMappings } from "../../types";
import { SphereCreateParams, SphereUpdateParams } from "../../generated";
import { ActionHashB64 } from "@state/types";
export type createArgs = {
    sphere: SphereCreateParams;
};
export type updateArgs = {
    sphere: SphereUpdateParams;
};
export type createHandler = (root: any, args: createArgs) => Promise<object>;
export type updateHandler = (root: any, args: updateArgs) => Promise<object>;
export type deleteHandler = (root: any, args: {
    sphereHash: ActionHashB64;
}) => Promise<ActionHashB64>;
declare const _default: (dnaConfig: DNAIdMappings, conductorUri: string) => {
    createSphere: createHandler;
    updateSphere: updateHandler;
    deleteSphere: deleteHandler;
};
export default _default;
//# sourceMappingURL=index.d.ts.map