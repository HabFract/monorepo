import { mapZomeFn } from "../../connection";
import { HAPP_DNA_NAME, HAPP_ZOME_NAME_PERSONAL_HABITS, } from "../../../constants";
import { EntryRecord } from "@holochain-open-dev/utils";
import { encodeHashToBase64, } from "@holochain/client";
export default (dnaConfig, conductorUri) => {
    const runCreate = mapZomeFn(dnaConfig, conductorUri, HAPP_DNA_NAME, HAPP_ZOME_NAME_PERSONAL_HABITS, "create_my_sphere");
    const runUpdate = mapZomeFn(dnaConfig, conductorUri, HAPP_DNA_NAME, HAPP_ZOME_NAME_PERSONAL_HABITS, "update_sphere");
    const runDelete = mapZomeFn(dnaConfig, conductorUri, HAPP_DNA_NAME, HAPP_ZOME_NAME_PERSONAL_HABITS, "delete_sphere");
    const createSphere = async (_, { sphere: { name, ...metadata } }) => {
        const rawRecord = await runCreate({
            name,
            metadata: {
                description: metadata?.description,
                hashtag: metadata?.hashtag,
                image: metadata?.image,
            },
        });
        const entryRecord = new EntryRecord(rawRecord);
        return {
            actionHash: entryRecord.actionHash,
            entryHash: encodeHashToBase64(entryRecord.entryHash),
            name
        };
    };
    const updateSphere = async (_, { sphere: { id, name, image, hashtag, description } }) => {
        const rawRecord = await runUpdate({
            originalSphereHash: id,
            updatedSphere: {
                name,
                metadata: {
                    description: description,
                    hashtag: hashtag,
                    image: image,
                },
            },
        });
        const entryRecord = new EntryRecord(rawRecord);
        return {
            actionHash: entryRecord.actionHash,
            entryHash: encodeHashToBase64(entryRecord.entryHash),
        };
    };
    const deleteSphere = async (_, args) => {
        const id = args.sphereHash;
        const rawRecord = await runDelete(id);
        return encodeHashToBase64(rawRecord);
    };
    return {
        createSphere,
        updateSphere,
        deleteSphere,
    };
};
//# sourceMappingURL=index.js.map