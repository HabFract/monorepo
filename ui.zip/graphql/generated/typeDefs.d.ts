export const typeDefs: import("graphql/language/ast").DocumentNode;
//# sourceMappingURL=typeDefs.d.ts.map