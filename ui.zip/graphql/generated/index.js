import { gql } from '@apollo/client';
import * as Apollo from '@apollo/client';
const defaultOptions = {};
export var Frequency;
(function (Frequency) {
    Frequency["Day"] = "Day";
    Frequency["Week"] = "Week";
    Frequency["Month"] = "Month";
    Frequency["Quarter"] = "Quarter";
})(Frequency || (Frequency = {}));
export var Scale;
(function (Scale) {
    Scale["Astro"] = "Astro";
    Scale["Sub"] = "Sub";
    Scale["Atom"] = "Atom";
})(Scale || (Scale = {}));
export const CreateOrbitDocument = gql `
    mutation createOrbit($variables: OrbitCreateParams!) {
  createOrbit(orbit: $variables) {
    id
    eH
    name
    parentHash
    sphereHash
    scale
    frequency
    metadata {
      description
      timeframe {
        startTime
        endTime
      }
    }
  }
}
    `;
export function useCreateOrbitMutation(baseOptions) {
    const options = { ...defaultOptions, ...baseOptions };
    return Apollo.useMutation(CreateOrbitDocument, options);
}
export const DeleteOrbitDocument = gql `
    mutation deleteOrbit($id: ID!) {
  deleteOrbit(orbitHash: $id)
}
    `;
export function useDeleteOrbitMutation(baseOptions) {
    const options = { ...defaultOptions, ...baseOptions };
    return Apollo.useMutation(DeleteOrbitDocument, options);
}
export const UpdateOrbitDocument = gql `
    mutation updateOrbit($orbitFields: OrbitUpdateParams!) {
  updateOrbit(orbit: $orbitFields) {
    actionHash
    entryHash
  }
}
    `;
export function useUpdateOrbitMutation(baseOptions) {
    const options = { ...defaultOptions, ...baseOptions };
    return Apollo.useMutation(UpdateOrbitDocument, options);
}
export const CreateSphereDocument = gql `
    mutation createSphere($variables: SphereCreateParams!) {
  createSphere(sphere: $variables) {
    actionHash
    entryHash
  }
}
    `;
export function useCreateSphereMutation(baseOptions) {
    const options = { ...defaultOptions, ...baseOptions };
    return Apollo.useMutation(CreateSphereDocument, options);
}
export const DeleteSphereDocument = gql `
    mutation deleteSphere($id: ID!) {
  deleteSphere(sphereHash: $id)
}
    `;
export function useDeleteSphereMutation(baseOptions) {
    const options = { ...defaultOptions, ...baseOptions };
    return Apollo.useMutation(DeleteSphereDocument, options);
}
export const UpdateSphereDocument = gql `
    mutation updateSphere($sphere: SphereUpdateParams!) {
  updateSphere(sphere: $sphere) {
    actionHash
    entryHash
  }
}
    `;
export function useUpdateSphereMutation(baseOptions) {
    const options = { ...defaultOptions, ...baseOptions };
    return Apollo.useMutation(UpdateSphereDocument, options);
}
export const GetOrbitDocument = gql `
    query getOrbit($id: ID!) {
  orbit(id: $id) {
    id
    eH
    name
    sphereHash
    frequency
    scale
    parentHash
    metadata {
      description
      timeframe {
        startTime
        endTime
      }
    }
  }
}
    `;
export function useGetOrbitQuery(baseOptions) {
    const options = { ...defaultOptions, ...baseOptions };
    return Apollo.useQuery(GetOrbitDocument, options);
}
export function useGetOrbitLazyQuery(baseOptions) {
    const options = { ...defaultOptions, ...baseOptions };
    return Apollo.useLazyQuery(GetOrbitDocument, options);
}
export function useGetOrbitSuspenseQuery(baseOptions) {
    const options = baseOptions === Apollo.skipToken ? baseOptions : { ...defaultOptions, ...baseOptions };
    return Apollo.useSuspenseQuery(GetOrbitDocument, options);
}
export const GetOrbitHierarchyDocument = gql `
    query getOrbitHierarchy($params: OrbitHierarchyQueryParams!) {
  getOrbitHierarchy(params: $params)
}
    `;
export function useGetOrbitHierarchyQuery(baseOptions) {
    const options = { ...defaultOptions, ...baseOptions };
    return Apollo.useQuery(GetOrbitHierarchyDocument, options);
}
export function useGetOrbitHierarchyLazyQuery(baseOptions) {
    const options = { ...defaultOptions, ...baseOptions };
    return Apollo.useLazyQuery(GetOrbitHierarchyDocument, options);
}
export function useGetOrbitHierarchySuspenseQuery(baseOptions) {
    const options = baseOptions === Apollo.skipToken ? baseOptions : { ...defaultOptions, ...baseOptions };
    return Apollo.useSuspenseQuery(GetOrbitHierarchyDocument, options);
}
export const GetOrbitsDocument = gql `
    query getOrbits($sphereEntryHashB64: String) {
  orbits(sphereEntryHashB64: $sphereEntryHashB64) {
    edges {
      node {
        id
        eH
        name
        sphereHash
        parentHash
        frequency
        scale
        metadata {
          description
          timeframe {
            startTime
            endTime
          }
        }
      }
    }
  }
}
    `;
export function useGetOrbitsQuery(baseOptions) {
    const options = { ...defaultOptions, ...baseOptions };
    return Apollo.useQuery(GetOrbitsDocument, options);
}
export function useGetOrbitsLazyQuery(baseOptions) {
    const options = { ...defaultOptions, ...baseOptions };
    return Apollo.useLazyQuery(GetOrbitsDocument, options);
}
export function useGetOrbitsSuspenseQuery(baseOptions) {
    const options = baseOptions === Apollo.skipToken ? baseOptions : { ...defaultOptions, ...baseOptions };
    return Apollo.useSuspenseQuery(GetOrbitsDocument, options);
}
export const GetLowestSphereHierarchyLevelDocument = gql `
    query getLowestSphereHierarchyLevel($sphereEntryHashB64: String!) {
  getLowestSphereHierarchyLevel(sphereEntryHashB64: $sphereEntryHashB64)
}
    `;
export function useGetLowestSphereHierarchyLevelQuery(baseOptions) {
    const options = { ...defaultOptions, ...baseOptions };
    return Apollo.useQuery(GetLowestSphereHierarchyLevelDocument, options);
}
export function useGetLowestSphereHierarchyLevelLazyQuery(baseOptions) {
    const options = { ...defaultOptions, ...baseOptions };
    return Apollo.useLazyQuery(GetLowestSphereHierarchyLevelDocument, options);
}
export function useGetLowestSphereHierarchyLevelSuspenseQuery(baseOptions) {
    const options = baseOptions === Apollo.skipToken ? baseOptions : { ...defaultOptions, ...baseOptions };
    return Apollo.useSuspenseQuery(GetLowestSphereHierarchyLevelDocument, options);
}
export const GetSphereDocument = gql `
    query getSphere($id: ID!) {
  sphere(id: $id) {
    id
    eH
    name
    metadata {
      description
      image
    }
  }
}
    `;
export function useGetSphereQuery(baseOptions) {
    const options = { ...defaultOptions, ...baseOptions };
    return Apollo.useQuery(GetSphereDocument, options);
}
export function useGetSphereLazyQuery(baseOptions) {
    const options = { ...defaultOptions, ...baseOptions };
    return Apollo.useLazyQuery(GetSphereDocument, options);
}
export function useGetSphereSuspenseQuery(baseOptions) {
    const options = baseOptions === Apollo.skipToken ? baseOptions : { ...defaultOptions, ...baseOptions };
    return Apollo.useSuspenseQuery(GetSphereDocument, options);
}
export const GetSpheresDocument = gql `
    query getSpheres {
  spheres {
    edges {
      node {
        id
        eH
        name
        metadata {
          description
          image
        }
      }
    }
  }
}
    `;
export function useGetSpheresQuery(baseOptions) {
    const options = { ...defaultOptions, ...baseOptions };
    return Apollo.useQuery(GetSpheresDocument, options);
}
export function useGetSpheresLazyQuery(baseOptions) {
    const options = { ...defaultOptions, ...baseOptions };
    return Apollo.useLazyQuery(GetSpheresDocument, options);
}
export function useGetSpheresSuspenseQuery(baseOptions) {
    const options = baseOptions === Apollo.skipToken ? baseOptions : { ...defaultOptions, ...baseOptions };
    return Apollo.useSuspenseQuery(GetSpheresDocument, options);
}
//# sourceMappingURL=index.js.map