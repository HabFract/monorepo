import { gql } from '@apollo/client';
import * as Apollo from '@apollo/client';
const defaultOptions = {};
export var Frequency;
(function (Frequency) {
    Frequency["OneShot"] = "ONE_SHOT";
    Frequency["DailyOrMore_1d"] = "DAILY_OR_MORE_1d";
    Frequency["DailyOrMore_2d"] = "DAILY_OR_MORE_2d";
    Frequency["DailyOrMore_3d"] = "DAILY_OR_MORE_3d";
    Frequency["DailyOrMore_4d"] = "DAILY_OR_MORE_4d";
    Frequency["DailyOrMore_5d"] = "DAILY_OR_MORE_5d";
    Frequency["DailyOrMore_6d"] = "DAILY_OR_MORE_6d";
    Frequency["DailyOrMore_7d"] = "DAILY_OR_MORE_7d";
    Frequency["DailyOrMore_8d"] = "DAILY_OR_MORE_8d";
    Frequency["DailyOrMore_9d"] = "DAILY_OR_MORE_9d";
    Frequency["DailyOrMore_10d"] = "DAILY_OR_MORE_10d";
    Frequency["LessThanDaily_1w"] = "LESS_THAN_DAILY_1w";
    Frequency["LessThanDaily_1m"] = "LESS_THAN_DAILY_1m";
    Frequency["LessThanDaily_1q"] = "LESS_THAN_DAILY_1q";
})(Frequency || (Frequency = {}));
export var Scale;
(function (Scale) {
    Scale["Astro"] = "Astro";
    Scale["Sub"] = "Sub";
    Scale["Atom"] = "Atom";
})(Scale || (Scale = {}));
export const CreateOrbitDocument = gql `
    mutation createOrbit($variables: OrbitCreateParams!) {
  createOrbit(orbit: $variables) {
    id
    eH
    name
    parentHash
    sphereHash
    scale
    frequency
    metadata {
      description
      timeframe {
        startTime
        endTime
      }
    }
  }
}
    `;
export function useCreateOrbitMutation(baseOptions) {
    const options = { ...defaultOptions, ...baseOptions };
    return Apollo.useMutation(CreateOrbitDocument, options);
}
export const DeleteOrbitDocument = gql `
    mutation deleteOrbit($id: ID!) {
  deleteOrbit(orbitHash: $id)
}
    `;
export function useDeleteOrbitMutation(baseOptions) {
    const options = { ...defaultOptions, ...baseOptions };
    return Apollo.useMutation(DeleteOrbitDocument, options);
}
export const CreateSphereDocument = gql `
    mutation createSphere($variables: SphereCreateParams!) {
  createSphere(sphere: $variables) {
    actionHash
    entryHash
    name
  }
}
    `;
export function useCreateSphereMutation(baseOptions) {
    const options = { ...defaultOptions, ...baseOptions };
    return Apollo.useMutation(CreateSphereDocument, options);
}
export const UpdateOrbitDocument = gql `
    mutation updateOrbit($orbitFields: OrbitUpdateParams!) {
  updateOrbit(orbit: $orbitFields) {
    id
    eH
    name
    parentHash
    sphereHash
    scale
    frequency
    metadata {
      description
      timeframe {
        startTime
        endTime
      }
    }
  }
}
    `;
export function useUpdateOrbitMutation(baseOptions) {
    const options = { ...defaultOptions, ...baseOptions };
    return Apollo.useMutation(UpdateOrbitDocument, options);
}
export const DeleteSphereDocument = gql `
    mutation deleteSphere($id: ID!) {
  deleteSphere(sphereHash: $id)
}
    `;
export function useDeleteSphereMutation(baseOptions) {
    const options = { ...defaultOptions, ...baseOptions };
    return Apollo.useMutation(DeleteSphereDocument, options);
}
export const CreateWinRecordDocument = gql `
    mutation createWinRecord($winRecord: WinRecordCreateParams!) {
  createWinRecord(winRecord: $winRecord) {
    id
    eH
    winData {
      date
      value {
        ... on SingleWin {
          single
        }
        ... on MultipleWins {
          multiple
        }
      }
    }
  }
}
    `;
export function useCreateWinRecordMutation(baseOptions) {
    const options = { ...defaultOptions, ...baseOptions };
    return Apollo.useMutation(CreateWinRecordDocument, options);
}
export const UpdateSphereDocument = gql `
    mutation updateSphere($sphere: SphereUpdateParams!) {
  updateSphere(sphere: $sphere) {
    actionHash
    entryHash
  }
}
    `;
export function useUpdateSphereMutation(baseOptions) {
    const options = { ...defaultOptions, ...baseOptions };
    return Apollo.useMutation(UpdateSphereDocument, options);
}
export const UpdateWinRecordDocument = gql `
    mutation updateWinRecord($winRecord: WinRecordUpdateParams!) {
  updateWinRecord(winRecord: $winRecord) {
    id
    eH
    orbitId
    winData {
      date
      value {
        ... on SingleWin {
          single
        }
        ... on MultipleWins {
          multiple
        }
      }
    }
  }
}
    `;
export function useUpdateWinRecordMutation(baseOptions) {
    const options = { ...defaultOptions, ...baseOptions };
    return Apollo.useMutation(UpdateWinRecordDocument, options);
}
export const GetLowestSphereHierarchyLevelDocument = gql `
    query getLowestSphereHierarchyLevel($sphereEntryHashB64: String!) {
  getLowestSphereHierarchyLevel(sphereEntryHashB64: $sphereEntryHashB64)
}
    `;
export function useGetLowestSphereHierarchyLevelQuery(baseOptions) {
    const options = { ...defaultOptions, ...baseOptions };
    return Apollo.useQuery(GetLowestSphereHierarchyLevelDocument, options);
}
export function useGetLowestSphereHierarchyLevelLazyQuery(baseOptions) {
    const options = { ...defaultOptions, ...baseOptions };
    return Apollo.useLazyQuery(GetLowestSphereHierarchyLevelDocument, options);
}
export function useGetLowestSphereHierarchyLevelSuspenseQuery(baseOptions) {
    const options = baseOptions === Apollo.skipToken ? baseOptions : { ...defaultOptions, ...baseOptions };
    return Apollo.useSuspenseQuery(GetLowestSphereHierarchyLevelDocument, options);
}
export const GetSphereDocument = gql `
    query getSphere($id: ID!) {
  sphere(id: $id) {
    id
    eH
    name
    metadata {
      description
      image
    }
  }
}
    `;
export function useGetSphereQuery(baseOptions) {
    const options = { ...defaultOptions, ...baseOptions };
    return Apollo.useQuery(GetSphereDocument, options);
}
export function useGetSphereLazyQuery(baseOptions) {
    const options = { ...defaultOptions, ...baseOptions };
    return Apollo.useLazyQuery(GetSphereDocument, options);
}
export function useGetSphereSuspenseQuery(baseOptions) {
    const options = baseOptions === Apollo.skipToken ? baseOptions : { ...defaultOptions, ...baseOptions };
    return Apollo.useSuspenseQuery(GetSphereDocument, options);
}
export const GetSpheresDocument = gql `
    query getSpheres {
  spheres {
    edges {
      node {
        id
        eH
        name
        metadata {
          description
          image
        }
      }
    }
  }
}
    `;
export function useGetSpheresQuery(baseOptions) {
    const options = { ...defaultOptions, ...baseOptions };
    return Apollo.useQuery(GetSpheresDocument, options);
}
export function useGetSpheresLazyQuery(baseOptions) {
    const options = { ...defaultOptions, ...baseOptions };
    return Apollo.useLazyQuery(GetSpheresDocument, options);
}
export function useGetSpheresSuspenseQuery(baseOptions) {
    const options = baseOptions === Apollo.skipToken ? baseOptions : { ...defaultOptions, ...baseOptions };
    return Apollo.useSuspenseQuery(GetSpheresDocument, options);
}
export const GetOrbitDocument = gql `
    query getOrbit($id: ID!) {
  orbit(id: $id) {
    id
    eH
    name
    sphereHash
    frequency
    scale
    parentHash
    metadata {
      description
      timeframe {
        startTime
        endTime
      }
    }
  }
}
    `;
export function useGetOrbitQuery(baseOptions) {
    const options = { ...defaultOptions, ...baseOptions };
    return Apollo.useQuery(GetOrbitDocument, options);
}
export function useGetOrbitLazyQuery(baseOptions) {
    const options = { ...defaultOptions, ...baseOptions };
    return Apollo.useLazyQuery(GetOrbitDocument, options);
}
export function useGetOrbitSuspenseQuery(baseOptions) {
    const options = baseOptions === Apollo.skipToken ? baseOptions : { ...defaultOptions, ...baseOptions };
    return Apollo.useSuspenseQuery(GetOrbitDocument, options);
}
export const GetOrbitHierarchyDocument = gql `
    query getOrbitHierarchy($params: OrbitHierarchyQueryParams!) {
  getOrbitHierarchy(params: $params)
}
    `;
export function useGetOrbitHierarchyQuery(baseOptions) {
    const options = { ...defaultOptions, ...baseOptions };
    return Apollo.useQuery(GetOrbitHierarchyDocument, options);
}
export function useGetOrbitHierarchyLazyQuery(baseOptions) {
    const options = { ...defaultOptions, ...baseOptions };
    return Apollo.useLazyQuery(GetOrbitHierarchyDocument, options);
}
export function useGetOrbitHierarchySuspenseQuery(baseOptions) {
    const options = baseOptions === Apollo.skipToken ? baseOptions : { ...defaultOptions, ...baseOptions };
    return Apollo.useSuspenseQuery(GetOrbitHierarchyDocument, options);
}
export const GetOrbitsDocument = gql `
    query getOrbits($sphereEntryHashB64: String) {
  orbits(sphereEntryHashB64: $sphereEntryHashB64) {
    edges {
      node {
        id
        eH
        name
        sphereHash
        parentHash
        frequency
        scale
        metadata {
          description
          timeframe {
            startTime
            endTime
          }
        }
      }
    }
  }
}
    `;
export function useGetOrbitsQuery(baseOptions) {
    const options = { ...defaultOptions, ...baseOptions };
    return Apollo.useQuery(GetOrbitsDocument, options);
}
export function useGetOrbitsLazyQuery(baseOptions) {
    const options = { ...defaultOptions, ...baseOptions };
    return Apollo.useLazyQuery(GetOrbitsDocument, options);
}
export function useGetOrbitsSuspenseQuery(baseOptions) {
    const options = baseOptions === Apollo.skipToken ? baseOptions : { ...defaultOptions, ...baseOptions };
    return Apollo.useSuspenseQuery(GetOrbitsDocument, options);
}
export const GetWinRecordForOrbitForMonthDocument = gql `
    query getWinRecordForOrbitForMonth($params: OrbitWinRecordQueryParams!) {
  getWinRecordForOrbitForMonth(params: $params) {
    id
    eH
    winData {
      date
      value {
        ... on SingleWin {
          single
        }
        ... on MultipleWins {
          multiple
        }
      }
    }
  }
}
    `;
export function useGetWinRecordForOrbitForMonthQuery(baseOptions) {
    const options = { ...defaultOptions, ...baseOptions };
    return Apollo.useQuery(GetWinRecordForOrbitForMonthDocument, options);
}
export function useGetWinRecordForOrbitForMonthLazyQuery(baseOptions) {
    const options = { ...defaultOptions, ...baseOptions };
    return Apollo.useLazyQuery(GetWinRecordForOrbitForMonthDocument, options);
}
export function useGetWinRecordForOrbitForMonthSuspenseQuery(baseOptions) {
    const options = baseOptions === Apollo.skipToken ? baseOptions : { ...defaultOptions, ...baseOptions };
    return Apollo.useSuspenseQuery(GetWinRecordForOrbitForMonthDocument, options);
}
//# sourceMappingURL=index.js.map