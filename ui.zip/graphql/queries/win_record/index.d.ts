import { DNAIdMappings } from "../../types";
import { Maybe, WinRecord } from "../../generated";
declare const _default: (dnaConfig: DNAIdMappings, conductorUri: string) => {
    getWinRecordForOrbitForMonth: (_: any, args: any) => Promise<Maybe<WinRecord>>;
};
export default _default;
//# sourceMappingURL=index.d.ts.map