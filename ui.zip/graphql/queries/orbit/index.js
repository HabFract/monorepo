import { mapZomeFn } from "../../connection";
import { HAPP_DNA_NAME, HAPP_ZOME_NAME_PERSONAL_HABITS, } from "../../../constants";
import { EntryRecord, createEdges, encodeHashToBase64 } from "../../utils";
export default (dnaConfig, conductorUri) => {
    const read = mapZomeFn(dnaConfig, conductorUri, HAPP_DNA_NAME, HAPP_ZOME_NAME_PERSONAL_HABITS, "get_my_orbit");
    const readAll = mapZomeFn(dnaConfig, conductorUri, HAPP_DNA_NAME, HAPP_ZOME_NAME_PERSONAL_HABITS, "get_all_my_sphere_orbits");
    const getHierarchyForOrbit = mapZomeFn(dnaConfig, conductorUri, HAPP_DNA_NAME, HAPP_ZOME_NAME_PERSONAL_HABITS, "get_orbit_hierarchy_json");
    return {
        orbit: async (_, args) => {
            const rawRecord = await read(args.id);
            const orbit = new EntryRecord(rawRecord);
            return {
                ...orbit.entry,
                id: args.id,
                eH: encodeHashToBase64(orbit.entryHash),
            };
        },
        orbits: async (_, args) => {
            const rawRecords = await readAll({
                sphereHash: args.sphereEntryHashB64,
            });
            if (typeof rawRecords !== "object" || !rawRecords?.length)
                return Promise.resolve({ edges: [], pageInfo: undefined });
            const entryRecords = rawRecords.map((record) => new EntryRecord(record));
            const orbitConnection = createEdges(entryRecords.map((entryRecord) => ({
                ...entryRecord.entry,
                id: entryRecord.actionHash,
                eH: encodeHashToBase64(entryRecord.entryHash),
            })));
            return Promise.resolve(orbitConnection);
        },
        getOrbitHierarchy: async (_, args) => {
            const maybeJson = await getHierarchyForOrbit(args.params);
            const json = JSON.stringify({ result: maybeJson });
            return Promise.resolve(JSON.stringify(json) || "");
        },
    };
};
//# sourceMappingURL=index.js.map