import { DNAIdMappings } from "../../types";
import { Orbit, OrbitConnection } from "../../generated";
declare const _default: (dnaConfig: DNAIdMappings, conductorUri: string) => {
    orbit: (_: any, args: any) => Promise<Orbit>;
    orbits: (_: any, args: any) => Promise<OrbitConnection>;
    getOrbitHierarchy: (_: any, args: any) => Promise<String>;
};
export default _default;
//# sourceMappingURL=index.d.ts.map