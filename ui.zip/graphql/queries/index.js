import Sphere from "./sphere";
import Orbit from "./orbit";
import WinRecord from "./win_record";
export default (dnaConfig, conductorUri) => {
    return {
        ...Sphere(dnaConfig, conductorUri),
        ...Orbit(dnaConfig, conductorUri),
        ...WinRecord(dnaConfig, conductorUri),
    };
};
//# sourceMappingURL=index.js.map