import Sphere from './sphere';
import Orbit from './orbit';
export default (dnaConfig, conductorUri) => {
    return {
        ...Sphere(dnaConfig, conductorUri),
        ...Orbit(dnaConfig, conductorUri),
    };
};
//# sourceMappingURL=index.js.map