import { mapZomeFn } from "../../connection";
import { HAPP_DNA_NAME, HAPP_ZOME_NAME_PERSONAL_HABITS, } from "../../../constants";
import { createEdges } from "../../utils";
import { EntryRecord } from "@holochain-open-dev/utils";
import { encodeHashToBase64, } from "@holochain/client";
export default (dnaConfig, conductorUri) => {
    const read = mapZomeFn(dnaConfig, conductorUri, HAPP_DNA_NAME, HAPP_ZOME_NAME_PERSONAL_HABITS, "get_sphere");
    const readAll = mapZomeFn(dnaConfig, conductorUri, HAPP_DNA_NAME, HAPP_ZOME_NAME_PERSONAL_HABITS, "get_all_my_spheres");
    const getLowestLevel = mapZomeFn(dnaConfig, conductorUri, HAPP_DNA_NAME, HAPP_ZOME_NAME_PERSONAL_HABITS, "get_lowest_sphere_hierarchy_level");
    return {
        sphere: async (_, args) => {
            const rawRecord = await read(args.id);
            const entryRecord = new EntryRecord(rawRecord);
            return {
                ...entryRecord.entry,
                id: encodeHashToBase64(entryRecord.actionHash),
                eH: encodeHashToBase64(entryRecord.entryHash),
            };
        },
        spheres: async () => {
            const rawRecords = await readAll(null);
            if (typeof rawRecords !== "object" || !rawRecords?.length)
                return Promise.resolve(createEdges([]));
            const entryRecords = rawRecords.map((record) => new EntryRecord(record));
            const sphereConnection = createEdges(entryRecords.map((entryRecord) => ({
                ...entryRecord.entry,
                id: entryRecord.actionHash,
                eH: encodeHashToBase64(entryRecord.entryHash),
            })));
            return Promise.resolve(sphereConnection);
        },
        getLowestSphereHierarchyLevel: async (_, args) => {
            const rawResponse = await getLowestLevel(args.sphereEntryHashB64);
            return Promise.resolve(rawResponse);
        },
    };
};
//# sourceMappingURL=index.js.map