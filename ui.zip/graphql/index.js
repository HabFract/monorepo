import { mapZomeFn, autoConnect, openConnection, sniffHolochainAppCells, } from "./connection.js";
import generateResolvers from "./resolvers";
import { typeDefs } from "./generated/typeDefs.js";
import { makeExecutableSchema } from "@graphql-tools/schema";
export { generateResolvers, autoConnect, openConnection, sniffHolochainAppCells, mapZomeFn, };
export default async (options) => {
    const coreResolvers = await generateResolvers(options);
    const resolvers = {
        ...coreResolvers,
        Query: {
            ...(coreResolvers.Query || {}),
        },
        Mutation: {
            ...(coreResolvers.Mutation || {}),
        },
    };
    return makeExecutableSchema({
        typeDefs,
        resolvers,
    });
};
//# sourceMappingURL=index.js.map