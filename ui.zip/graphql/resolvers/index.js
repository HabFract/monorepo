import Mutation from '../mutations';
import Query from '../queries';
export default async (options) => {
    const { conductorUri, dnaConfig } = options;
    return {
        Query: Query(dnaConfig, conductorUri),
        Mutation: Mutation(dnaConfig, conductorUri),
    };
};
//# sourceMappingURL=index.js.map