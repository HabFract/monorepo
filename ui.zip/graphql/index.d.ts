import { mapZomeFn, autoConnect, openConnection, sniffHolochainAppCells } from "./connection.js";
import generateResolvers from "./resolvers";
import { APIOptions, DNAIdMappings, CellId } from "./types.js";
export { generateResolvers, autoConnect, openConnection, sniffHolochainAppCells, mapZomeFn, };
export type { DNAIdMappings, CellId, APIOptions, };
declare const _default: (options: APIOptions) => Promise<import("graphql").GraphQLSchema>;
export default _default;
//# sourceMappingURL=index.d.ts.map