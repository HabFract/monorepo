export const APP_WS_PORT = import.meta.env.VITE_APP_PORT;
export const ADMIN_WS_PORT = import.meta.env.VITE_ADMIN_PORT;
export const NODE_ENV = import.meta.env.VITE_NODE_ENV;
export const HAPP_ID = "habit_fract";
export const HAPP_DNA_NAME = "habits";
export const HAPP_ZOME_NAME_PERSONAL_HABITS = "personal";
export const HAPP_ZOME_NAME_PROFILES = "profiles";
export const ALPHA_RELEASE_DISCLAIMER = `Thank you for being an early tester of this app.

This is an alpha release, meaning, the software is still in the early stages and will sometimes behave weirdly!

Some features are disabled/still being updated. 

If you experience any problems, the best course of action is to reload the app. You can submit feedback or bug reports from the settings menu. Have fun!`;
export const MODEL_DISPLAY_VALUES = {
    sphere: 'Space',
    hierarchy: 'System',
    orbit: 'Plannit',
    winRecord: 'Orbit',
    astro: 'Star',
    sub: 'Giant',
    atom: 'Dwarf',
};
export const ONBOARDING_FORM_TITLES = [`Create ${MODEL_DISPLAY_VALUES['sphere']}`, `Create ${MODEL_DISPLAY_VALUES['orbit']}`, `Break Up ${MODEL_DISPLAY_VALUES['orbit']}`];
export const ONBOARDING_FORM_DESCRIPTIONS = [
    `It all starts with a ${MODEL_DISPLAY_VALUES['sphere']}. Give your goals their own little universe, dedicated to a [em]special area of your life[em] It could be health, wealth, family, or career. Give the ${MODEL_DISPLAY_VALUES['sphere']} a short name, perhaps add a description of what you want to achieve, and upload a symbol or image to remember it by.`,
    `This is where your plans take shape: let's fill your ${MODEL_DISPLAY_VALUES['sphere']} by setting up a [em]${MODEL_DISPLAY_VALUES['hierarchy']}[em] Composed of ${MODEL_DISPLAY_VALUES['orbit']}s of different scales - representing [em]behaviour you want to track[em] Start a System with a Plannit of any scale. We'll begin with a Star (representing your most significant goal) shining brightly in your System.[em] Give it a short name, extra details if desired, and fill in [em]how frequently[em] you want to track this behaviour.`,
    `Break Up ${MODEL_DISPLAY_VALUES['orbit']}`
];
//# sourceMappingURL=constants.js.map