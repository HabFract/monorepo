import { jsx as _jsx, Fragment as _Fragment } from "react/jsx-runtime";
import { CreateSphere, CreateOrbit, RefineOrbit } from "./components/forms";
import { ListOrbits, ListSpheres } from "./components/lists";
import PreloadOrbitData from "./components/Preload";
import Home from "./components/layouts/Home";
import OrbitTree from "./components/vis/OrbitTree";
import { renderVis } from "./components/vis/helpers";
export const initialState = {
    currentState: "Home",
    params: {},
    client: null
};
export const routes = {
    Home: _jsx(Home, {}),
    PreloadAndCache: _jsx(PreloadOrbitData, {}),
    Vis: (() => renderVis(OrbitTree))(),
    Onboarding1: _jsx(CreateSphere, { editMode: false }),
    Onboarding2: _jsx(CreateOrbit, { editMode: false, inModal: false, sphereEh: "", parentOrbitEh: undefined }),
    Onboarding3: _jsx(RefineOrbit, { refiningOrbitAh: "" }),
    CreateSphere: _jsx(CreateSphere, { headerDiv: _jsx(_Fragment, {}), editMode: false }),
    ListSpheres: _jsx(ListSpheres, {}),
    CreateOrbit: _jsx(CreateOrbit, { editMode: false, inModal: false, sphereEh: "", parentOrbitEh: "" }),
    ListOrbits: _jsx(ListOrbits, {}),
};
const forms = ['CreateSphere', 'CreateOrbit'];
const lists = ['ListSpheres', 'ListOrbits'];
export const AppTransitions = {
    PreloadAndCache: ['Vis', 'CreateSphere', 'CreateOrbit'],
    Home: ['Home', ...lists, ...forms, 'Vis', "Onboarding1", "PreloadAndCache"],
    Onboarding1: ['Home', 'Onboarding2'],
    Onboarding2: ['Onboarding1', 'Onboarding2', 'Onboarding3'],
    Onboarding3: ['Onboarding2', 'Onboarding3', 'PreloadAndCache'],
    Vis: ['Home', ...forms, ...lists, 'Vis', 'PreloadAndCache'],
    CreateSphere: ['Home', ...lists, ...forms, 'Vis'],
    ListSpheres: ['Home', ...lists, ...forms, 'Vis', 'PreloadAndCache'],
    CreateOrbit: ['Home', ...lists, ...forms, 'Vis'],
    ListOrbits: ['Home', ...lists, ...forms, , 'Vis', 'PreloadAndCache'],
};
//# sourceMappingURL=routes.js.map