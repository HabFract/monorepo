import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import "./App.css";
import "habit-fract-design-system/dist/style.css";
import "./typo.css";
import { useStateTransition } from "./hooks/useStateTransition";
import withLayout from "./components/HOC/withLayout";
import Nav from "./components/navigation/Nav";
import { Flowbite } from "flowbite-react";
import { cloneElement, useMemo, useRef, useState } from "react";
import { darkTheme, Spinner } from "habit-fract-design-system";
import { useGetSpheresQuery, } from "./graphql/generated";
import { ALPHA_RELEASE_DISCLAIMER } from "./constants";
import { isSmallScreen } from "./components/vis/helpers";
import OnboardingHeader, { getNextOnboardingState, } from "./components/header/OnboardingHeader";
import VersionWithDisclaimerButton from "./components/home/VersionWithDisclaimerButton";
import { useOnboardingScroll } from "./hooks/useOnboardingScroll";
import { useMainContainerClass } from "./hooks/useMainContainerClass";
import { useCurrentVersion } from "./hooks/useCurrentVersion";
import OnboardingContinue from "./components/forms/buttons/OnboardingContinueButton";
import Toast from "./components/Toast";
import { useModal } from "./contexts/modal";
import { AppMachine } from "./main";
import { extractEdges } from "./graphql/utils";
function App({ children: pageComponent }) {
    const [_, transition, params] = useStateTransition();
    const state = AppMachine.state.currentState;
    const [sideNavExpanded, setSideNavExpanded] = useState(false);
    const { showModal } = useModal();
    const mainContainerClass = useMainContainerClass();
    const currentVersion = useCurrentVersion();
    const progressBarRef = useRef(null);
    const mainPageRef = useRef(null);
    useOnboardingScroll(state, progressBarRef, mainPageRef);
    const showDisclaimer = () => {
        showModal({
            title: "Disclaimer",
            message: ALPHA_RELEASE_DISCLAIMER,
            withConfirm: true,
            withCancel: false,
            size: "md"
        });
    };
    const { loading: loadingSpheres, error, data: spheres, } = useGetSpheresQuery();
    const spheresArray = spheres?.spheres?.edges && extractEdges(spheres.spheres);
    const userHasSpheres = spheresArray && spheresArray.length > 0;
    const showNav = useMemo(() => {
        return userHasSpheres && isSmallScreen() && state === "Vis";
    }, [userHasSpheres, state]);
    return (_jsxs(Flowbite, { theme: { theme: darkTheme, mode: "dark" }, children: [_jsx(Toast, {}), _jsxs("main", { ref: mainPageRef, className: mainContainerClass, children: [state == "Home" && !userHasSpheres && (_jsx(VersionWithDisclaimerButton, { currentVersion: currentVersion, open: showDisclaimer, isFrontPage: true })), showNav && (_jsx(Nav, { sideNavExpanded: sideNavExpanded, setSideNavExpanded: setSideNavExpanded })), loadingSpheres ? (_jsx(Spinner, {})) : (pageComponent &&
                        withLayout(cloneElement(pageComponent, {
                            headerDiv: state.match("Onboarding") && (_jsx(OnboardingHeader, { ref: progressBarRef })),
                            submitBtn: state.match("Onboarding") && (_jsx(OnboardingContinue, { onClick: () => {
                                    const nextStage = getNextOnboardingState(state);
                                    const lastStageCompleted = nextStage == "Vis";
                                    transition(nextStage, lastStageCompleted ? { currentSphereDetails: { ...spheresArray[spheresArray.length - 1] } } : {});
                                } })),
                        }))({ ...pageComponent.props, newUser: !userHasSpheres }))] })] }));
}
export default App;
//# sourceMappingURL=App.js.map