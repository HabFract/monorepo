import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
import { useStateTransition } from './hooks/useStateTransition';
import withLayout from './components/HOC/withLayout';
import Nav from './components/navigation/Nav';
import { Flowbite, Modal, Spinner } from 'flowbite-react';
import { cloneElement, useRef, useState } from 'react';
import Settings from './components/Settings';
import { darkTheme } from 'habit-fract-design-system';
import { store } from './state/jotaiKeyValueStore';
import { useGetSpheresQuery } from './graphql/generated';
import { ALPHA_RELEASE_DISCLAIMER } from './constants';
import { isSmallScreen } from './components/vis/helpers';
import { extractEdges } from './graphql/utils';
import OnboardingHeader, { getNextOnboardingState } from './components/header/OnboardingHeader';
import VersionWithDisclaimerButton from './components/home/VersionWithDisclaimerButton';
import { useOnboardingScroll } from './hooks/useOnboardingScroll';
import { useMainContainerClass } from './hooks/useMainContainerClass';
import { useCurrentVersion } from './hooks/useCurrentVersion';
import OnboardingContinue from './components/forms/buttons/OnboardingContinueButton';
import HomeContinue from './components/home/HomeContinueButton';
import Toast from './components/Toast';
import { useToast } from './contexts/toast';
import { currentSphereHashesAtom } from './state/sphere';
function App({ children: pageComponent }) {
    const [state, transition, params] = useStateTransition();
    const [sideNavExpanded, setSideNavExpanded] = useState(false);
    const { showToast, isToastVisible } = useToast();
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isSettingsOpen, setIsSettingsOpen] = useState(false);
    const mainContainerClass = useMainContainerClass();
    const currentVersion = useCurrentVersion();
    const progressBarRef = useRef(null);
    const mainPageRef = useRef(null);
    useOnboardingScroll(state, progressBarRef, mainPageRef);
    const { loading: loadingSpheres, error, data: spheres } = useGetSpheresQuery();
    const userHasSpheres = spheres?.spheres?.edges && spheres.spheres.edges.length > 0;
    const sphere = store.get(currentSphereHashesAtom);
    const currentSphere = userHasSpheres && extractEdges(spheres.spheres).find(possibleSphere => possibleSphere.id == sphere.actionHash);
    const currentSphereDetails = currentSphere ? {
        entryHash: currentSphere.eH,
        name: currentSphere.name,
        description: currentSphere.metadata?.description,
        hashtag: '',
        image: currentSphere?.metadata?.image || undefined,
    } : { entryHash: '' };
    return _jsxs(Flowbite, { theme: { theme: darkTheme }, children: [_jsx(Toast, {}), _jsxs("main", { ref: mainPageRef, className: mainContainerClass, children: [state == 'Home' && !userHasSpheres && _jsx(VersionWithDisclaimerButton, { currentVersion: currentVersion, open: () => setIsModalOpen(true), isFrontPage: true }), userHasSpheres && !((isSmallScreen() && ['CreateSphere', 'ListSpheres', 'CreateOrbit', 'ListOrbits'].includes(state)) || state.match('Onboarding'))
                        && _jsx(Nav, { transition: transition, sideNavExpanded: sideNavExpanded, setSettingsOpen: () => { setIsModalOpen(true); setIsSettingsOpen(true); }, setSideNavExpanded: setSideNavExpanded }), loadingSpheres
                        ? _jsx(Spinner, { "aria-label": "Loading!", size: "xl", className: 'full-spinner' })
                        : pageComponent && withLayout(cloneElement(pageComponent, {
                            startBtn: state.match('Home') ? _jsx(HomeContinue, { onClick: () => transition("Onboarding1") }) : _jsx(_Fragment, {}),
                            headerDiv: state.match('Onboarding') && _jsx(OnboardingHeader, { state: state, transition: transition, ref: progressBarRef }),
                            submitBtn: state.match('Onboarding') && _jsx(OnboardingContinue, { onClick: () => transition(getNextOnboardingState(state)) })
                        }), state, transition, params)({ currentSphereDetails, newUser: !!userHasSpheres })] }), _jsxs(Modal, { dismissible: true, show: isModalOpen, onClose: () => { setIsSettingsOpen(false); setIsModalOpen(false); }, children: [_jsx(Modal.Header, { children: isSettingsOpen ? "Settings" : "Disclaimer:" }), _jsx(Modal.Body, { children: isSettingsOpen ? _jsx(Settings, { version: currentVersion || "", spheres: spheres?.spheres, setIsModalOpen: setIsModalOpen, setIsSettingsOpen: setIsSettingsOpen }) : _jsx("p", { className: 'disclaimer', children: ALPHA_RELEASE_DISCLAIMER }) })] })] });
}
export default App;
//# sourceMappingURL=App.js.map