import { s as a, c, a as i, p as u, S as n, r as s, b as l } from "./index.es.js";
import { m as _, n as S, d as A, e as x, f as E, g as b, h as q, i as I } from "./index.es.js";
function h(t) {
  return a(c(t).call(document.documentElement));
}
var f = 0;
function m() {
  return new e();
}
function e() {
  this._ = "@" + (++f).toString(36);
}
e.prototype = m.prototype = {
  constructor: e,
  get: function(t) {
    for (var r = this._; !(r in t); ) if (!(t = t.parentNode)) return;
    return t[r];
  },
  set: function(t, r) {
    return t[this._] = r;
  },
  remove: function(t) {
    return this._ in t && delete t[this._];
  },
  toString: function() {
    return this._;
  }
};
function d(t, r) {
  return t.target && (t = i(t), r === void 0 && (r = t.currentTarget), t = t.touches || [t]), Array.from(t, (o) => u(o, r));
}
function g(t) {
  return typeof t == "string" ? new n([document.querySelectorAll(t)], [document.documentElement]) : new n([l(t)], s);
}
export {
  h as create,
  c as creator,
  m as local,
  _ as matcher,
  S as namespace,
  A as namespaces,
  u as pointer,
  d as pointers,
  a as select,
  g as selectAll,
  x as selection,
  E as selector,
  b as selectorAll,
  q as style,
  I as window
};
