import { jsx as _jsx } from "react/jsx-runtime";
import { useEffect, useState } from 'react';
import { AppMachine, WithCacheStore } from './main';
import { ApolloProvider } from '@apollo/client';
import { App } from 'antd';
import { StateMachineContext } from './contexts/state-machine';
import { ToastProvider } from './contexts/toast';
import { getConnection } from './graphql/connection';
import { initGraphQLClient } from './graphql/client';
import './App.css';
import 'habit-fract-design-system/dist/style.css';
import './typo.css';
import { Spinner } from 'flowbite-react';
function BootScreen({ children }) {
    const [connected, setConnected] = useState(false);
    const [apolloClient, setApolloClient] = useState();
    useEffect(() => {
        if (connected)
            return;
        getConnection().then(connection => {
            AppMachine.state.client = { ...connection, conductorUri: connection.client.client.url.href };
            initGraphQLClient(AppMachine.state.client).then(client => {
                setApolloClient(client);
            });
            setConnected(true);
        });
    }, [connected]);
    return !connected ? _jsx(Spinner, { "aria-label": "Loading!", size: "xl", className: 'full-spinner' }) : (_jsx(ApolloProvider, { client: apolloClient, children: _jsx(StateMachineContext.Provider, { value: AppMachine, children: _jsx(ToastProvider, { children: _jsx(App, { children: WithCacheStore(children) }) }) }) }));
}
export default BootScreen;
//# sourceMappingURL=BootScreen.js.map