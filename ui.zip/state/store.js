import { createStore } from "jotai";
import { MiniDb } from "jotai-minidb";
import { atomWithStorage } from "jotai/utils";
export const nodeCache = new MiniDb();
export const store = createStore();
export const appStateChangeAtom = atomWithStorage("appState", {
    spheres: {
        currentSphereHash: "",
        byHash: { default: {} },
    },
    hierarchies: {
        byRootOrbitEntryHash: {},
    },
    orbitNodes: {
        currentOrbitHash: null,
        byHash: { default: {} },
    },
    wins: {},
    ui: {
        listSortFilter: {
            sortCriteria: "name",
            sortOrder: "lowestToGreatest",
        },
        currentDay: new Date().toISOString(),
    },
});
//# sourceMappingURL=store.js.map