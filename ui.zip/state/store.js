import { atomWithStorage } from 'jotai/utils';
export const appStateAtom = atomWithStorage('appState', {
    spheres: {
        currentSphereHash: '',
        byHash: {},
    },
    hierarchies: {
        byRootOrbitEntryHash: {},
    },
    orbitNodes: {
        currentOrbitHash: null,
        byHash: {},
    },
    wins: {},
    ui: {
        listSortFilter: {
            sortCriteria: 'name',
            sortOrder: 'lowestToGreatest',
        },
        currentDay: new Date().toISOString()
    },
});
//# sourceMappingURL=store.js.map