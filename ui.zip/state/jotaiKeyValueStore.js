import { atom, createStore } from "jotai";
import { MiniDb } from "jotai-minidb";
export const nodeCache = new MiniDb();
export const store = createStore();
export const nodeCacheItemsAtom = atom((get) => get(nodeCache.items));
//# sourceMappingURL=jotaiKeyValueStore.js.map