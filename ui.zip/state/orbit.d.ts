import { ActionHashB64, EntryHashB64 } from "@state/types";
import { SphereOrbitNodeDetails, SphereOrbitNodes } from "./types/sphere";
import { Frequency, OrbitHashes, OrbitNodeDetails } from "./types/orbit";
import { Orbit, Frequency as GraphQLFrequency } from "../graphql/generated";
import { WinData } from "./types/win";
export declare const decodeFrequency: (frequency: GraphQLFrequency) => Frequency.Rationals;
export declare const mapToCacheObject: (orbit: Orbit) => OrbitNodeDetails;
export declare const currentSphereOrbitNodeDetailsAtom: import("jotai").Atom<SphereOrbitNodeDetails | null>;
export declare const getOrbitNodeDetailsFromEhAtom: (orbitEh: EntryHashB64) => import("jotai").Atom<OrbitNodeDetails | null>;
export declare const currentOrbitDetailsAtom: import("jotai").Atom<OrbitNodeDetails | null>;
export declare const getOrbitNodeDetailsFromIdAtom: (orbitId: ActionHashB64) => import("jotai").Atom<OrbitNodeDetails | null>;
export declare const getCurrentSphereOrbitNodeDetailsFromEhAtom: (orbitEh: EntryHashB64) => import("jotai").Atom<OrbitNodeDetails | null>;
export declare const getCurrentOrbitStartTimeFromEh: import("jotai").Atom<(orbitEh: EntryHashB64) => number | null>;
export declare const setOrbitWithEntryHashAtom: import("jotai").WritableAtom<null, [{
    orbitEh: EntryHashB64;
    update: Partial<OrbitNodeDetails>;
}], void> & {
    init: null;
};
export declare const currentOrbitIsLeafAtom: import("jotai").Atom<boolean | null>;
export declare const getOrbitFrequency: (orbitId: ActionHashB64) => import("jotai").Atom<Frequency.Rationals | null>;
export declare const currentSphereOrbitNodesAtom: import("jotai").Atom<SphereOrbitNodes | null>;
export declare const currentOrbitIdAtom: import("jotai").WritableAtom<Partial<OrbitHashes> | null, [newOrbitId: string], void>;
export declare const getOrbitIdFromEh: (orbitEh: EntryHashB64) => import("jotai").Atom<string | null>;
export declare const getOrbitEhFromId: (id: ActionHashB64) => import("jotai").Atom<string | null>;
export declare const orbitWinDataAtom: (orbitId: ActionHashB64) => import("jotai").Atom<WinData<Frequency.Rationals>>;
//# sourceMappingURL=orbit.d.ts.map