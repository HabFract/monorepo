import { getOrbitNodeDetailsFromEhAtom, } from "./orbit";
import { atom } from "jotai";
import { hierarchy } from "d3-hierarchy";
import { appStateAtom } from "./store";
import { getSphereIdFromEhAtom } from "./sphere";
export const currentSphereHierarchyBounds = atom({});
currentSphereHierarchyBounds.testId = "currentSphereHierarchyBounds";
export const currentSphereHierarchyIndices = atom({
    x: 0,
    y: 0,
});
currentSphereHierarchyIndices.testId = "currentSphereHierarchyIndices";
export const setCurrentBreadth = atom(null, (get, set, newBreadth) => {
    const prev = get(currentSphereHierarchyIndices);
    set(currentSphereHierarchyIndices, { ...prev, x: newBreadth });
});
export const setCurrentDepth = atom(null, (get, set, newDepth) => {
    const prev = get(currentSphereHierarchyIndices);
    set(currentSphereHierarchyIndices, { ...prev, x: newDepth });
});
export const setDepths = atom(null, (get, set, id, [min, max]) => {
    const prev = get(currentSphereHierarchyBounds);
    set(currentSphereHierarchyBounds, {
        ...prev,
        [id]: { ...prev[id], minDepth: min, maxDepth: max },
    });
});
export const setBreadths = atom(null, (get, set, id, [min, max]) => {
    const prev = get(currentSphereHierarchyBounds);
    set(currentSphereHierarchyBounds, {
        ...prev,
        [id]: { ...prev[id], minBreadth: min, maxBreadth: max },
    });
});
export const newTraversalLevelIndexId = atom({
    id: null,
});
newTraversalLevelIndexId.testId = "newTraversalLevelIndexId";
export const getHierarchyAtom = (rootOrbitEntryHash) => {
    const selectHierarchy = atom((get) => {
        const state = get(appStateAtom);
        return state.hierarchies.byRootOrbitEntryHash[rootOrbitEntryHash] || null;
    });
    return selectHierarchy;
};
export const updateHierarchyAtom = atom(null, (get, set, newHierarchy) => {
    if (!newHierarchy?.rootData)
        return null;
    const currentAppState = get(appStateAtom);
    const rootNode = newHierarchy.rootData.data.content;
    const nodeHashes = [];
    const leafNodeHashes = [];
    let currentHierarchyNode = undefined;
    const possibleNodes = Object.keys(currentAppState.orbitNodes.byHash);
    newHierarchy.rootData.each((node) => {
        const eH = node.data.content;
        const id = possibleNodes.find((key) => currentAppState.orbitNodes.byHash[key].eH === eH);
        if (!id)
            return;
        if (currentAppState.orbitNodes.currentOrbitHash == id)
            currentHierarchyNode = id;
        nodeHashes.push(id);
        if (node.data?.children && node.data.children.length == 0)
            leafNodeHashes.push(id);
    });
    const updatedHierarchy = {
        rootNode,
        json: newHierarchy?._json,
        bounds: undefined,
        indices: undefined,
        currentNode: currentHierarchyNode,
        nodeHashes,
        leafNodeHashes,
    };
    const currentSphereHierarchyRootNodes = currentAppState.spheres.byHash[newHierarchy.sphereAh]?.hierarchyRootOrbitEntryHashes || [];
    const newState = {
        ...currentAppState,
        spheres: {
            ...currentAppState.spheres,
            byHash: {
                ...currentAppState.spheres.byHash,
                [newHierarchy.sphereAh]: {
                    ...currentAppState.spheres.byHash[newHierarchy.sphereAh],
                    hierarchyRootOrbitEntryHashes: (currentSphereHierarchyRootNodes.includes(rootNode) ? currentSphereHierarchyRootNodes : [
                        ...currentSphereHierarchyRootNodes,
                        rootNode,
                    ]),
                },
            },
        },
        hierarchies: {
            ...currentAppState.hierarchies,
            byRootOrbitEntryHash: {
                ...currentAppState.hierarchies.byRootOrbitEntryHash,
                [rootNode]: updatedHierarchy,
            },
        },
    };
    set(appStateAtom, newState);
});
export const isLeafNodeHashAtom = (nodeId) => {
    return atom((get) => {
        const state = get(appStateAtom);
        const hierarchies = state.hierarchies.byRootOrbitEntryHash;
        for (const hierarchyKey in hierarchies) {
            const hierarchy = hierarchies[hierarchyKey];
            if (hierarchy?.leafNodeHashes?.includes(nodeId)) {
                return true;
            }
        }
        return false;
    });
};
export const getDescendantLeafNodesAtom = (orbitEh) => {
    return atom((get) => {
        const state = get(appStateAtom);
        const orbit = get(getOrbitNodeDetailsFromEhAtom(orbitEh));
        if (!orbit)
            return null;
        const orbitHash = orbit.id;
        let hierarchyJson = null;
        let hierarchyRoot = null;
        for (const [root, h] of Object.entries(state.hierarchies.byRootOrbitEntryHash)) {
            if (h.nodeHashes.includes(orbitHash)) {
                hierarchyJson = h.json;
                hierarchyRoot = root;
                break;
            }
        }
        if (!hierarchyJson || !hierarchyRoot)
            return null;
        const hierarchyData = JSON.parse(hierarchyJson);
        const hierarchyD3 = hierarchy(hierarchyData[0]);
        const leaves = hierarchyD3.find((node) => node.data.content === orbit.eH)?.leaves() ||
            [];
        return leaves.map((node) => node.data);
    });
};
export const getHierarchyOrbitDetailsAtom = (rootOrbitEntryHash) => {
    const selectOrbits = atom((get) => {
        const state = get(appStateAtom);
        const hierarchy = state.hierarchies.byRootOrbitEntryHash[rootOrbitEntryHash];
        const sphereEh = state.orbitNodes.byHash[rootOrbitEntryHash].sphereHash;
        const sphereId = get(getSphereIdFromEhAtom(sphereEh));
        if (!hierarchy || typeof sphereId !== "string")
            return null;
        return null;
    });
    return selectOrbits;
};
//# sourceMappingURL=hierarchy.js.map