import { atom } from "jotai";
import { appStateAtom } from "./store";
export const calculateCompletionStatusAtom = (orbitHash) => {
    const calculateCompletionStatus = atom((get) => {
        const state = get(appStateAtom);
        const orbit = state.orbitNodes.byHash[orbitHash];
        const winData = state.wins[orbitHash] || {};
        if (!orbit) {
            return null;
        }
        return 0;
    });
    return calculateCompletionStatus;
};
export const getHierarchyAtom = (rootOrbitEntryHash) => {
    const selectHierarchy = atom((get) => {
        const state = get(appStateAtom);
        return state.hierarchies.byRootOrbitEntryHash[rootOrbitEntryHash] || null;
    });
    return selectHierarchy;
};
export const getHierarchyOrbitsAtom = (rootOrbitEntryHash) => {
    const selectOrbits = atom((get) => {
        const state = get(appStateAtom);
        const hierarchy = state.hierarchies.byRootOrbitEntryHash[rootOrbitEntryHash];
        if (!hierarchy)
            return [];
        return hierarchy.nodeHashes.map(hash => state.orbitNodes.byHash[hash]);
    });
    return selectOrbits;
};
export const currentSphereHierarchyBounds = atom({});
export const currentSphereHierarchyIndices = atom({ x: 0, y: 0 });
export const setCurrentBreadth = atom(null, (get, set, newBreadth) => {
    const prev = get(currentSphereHierarchyIndices);
    set(currentSphereHierarchyIndices, { ...prev, x: newBreadth });
});
export const setCurrentDepth = atom(null, (get, set, newDepth) => {
    const prev = get(currentSphereHierarchyIndices);
    set(currentSphereHierarchyIndices, { ...prev, x: newDepth });
});
export const setDepths = atom(null, (get, set, id, [min, max]) => {
    const prev = get(currentSphereHierarchyBounds);
    set(currentSphereHierarchyBounds, { ...prev, [id]: { ...prev[id], minDepth: min, maxDepth: max } });
});
export const setBreadths = atom(null, (get, set, id, [min, max]) => {
    const prev = get(currentSphereHierarchyBounds);
    set(currentSphereHierarchyBounds, { ...prev, [id]: { ...prev[id], minBreadth: min, maxBreadth: max } });
});
export const newTraversalLevelIndexId = atom({ id: null });
//# sourceMappingURL=hierarchy.js.map