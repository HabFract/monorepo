import { NODE_ENV } from "./../constants";
import { atom } from "jotai";
import { appStateAtom } from "./store";
import { Frequency } from "./types/orbit";
import { Frequency as GraphQLFrequency } from "../graphql/generated";
import { nodeCache } from "./store";
import { isLeafNodeHashAtom } from "./hierarchy";
export const decodeFrequency = (frequency) => {
    switch (frequency) {
        case GraphQLFrequency.OneShot:
            return Frequency.ONE_SHOT;
        case GraphQLFrequency.DailyOrMore_1d:
            return Frequency.DAILY_OR_MORE.DAILY;
        case GraphQLFrequency.DailyOrMore_2d:
            return Frequency.DAILY_OR_MORE.TWO;
        case GraphQLFrequency.DailyOrMore_3d:
            return Frequency.DAILY_OR_MORE.THREE;
        case GraphQLFrequency.DailyOrMore_4d:
            return Frequency.DAILY_OR_MORE.FOUR;
        case GraphQLFrequency.DailyOrMore_5d:
            return Frequency.DAILY_OR_MORE.FIVE;
        case GraphQLFrequency.DailyOrMore_6d:
            return Frequency.DAILY_OR_MORE.SIX;
        case GraphQLFrequency.DailyOrMore_7d:
            return Frequency.DAILY_OR_MORE.SEVEN;
        case GraphQLFrequency.DailyOrMore_8d:
            return Frequency.DAILY_OR_MORE.EIGHT;
        case GraphQLFrequency.DailyOrMore_9d:
            return Frequency.DAILY_OR_MORE.NINE;
        case GraphQLFrequency.DailyOrMore_10d:
            return Frequency.DAILY_OR_MORE.TEN;
        case GraphQLFrequency.LessThanDaily_1w:
            return Frequency.LESS_THAN_DAILY.WEEKLY;
        case GraphQLFrequency.LessThanDaily_1m:
            return Frequency.LESS_THAN_DAILY.MONTHLY;
        case GraphQLFrequency.LessThanDaily_1q:
            return Frequency.LESS_THAN_DAILY.QUARTERLY;
        default:
            throw new Error(`Unsupported GraphQL frequency: ${frequency}`);
    }
};
export const mapToCacheObject = (orbit) => {
    const newFrequency = decodeFrequency(orbit.frequency);
    return {
        id: orbit.id,
        eH: orbit.eH,
        parentEh: orbit.parentHash || undefined,
        name: orbit.name,
        scale: orbit.scale,
        sphereHash: orbit.sphereHash,
        frequency: newFrequency,
        description: orbit.metadata?.description || "",
        startTime: orbit.metadata?.timeframe.startTime,
        endTime: orbit.metadata?.timeframe.endTime || undefined,
    };
};
export const currentSphereOrbitNodeDetailsAtom = atom((get) => {
    const state = get(appStateAtom);
    const currentSphereHash = state.spheres.currentSphereHash;
    if (!currentSphereHash)
        return null;
    const sphereOrbitNodeDetails = get(nodeCache.item(currentSphereHash)) ||
        null;
    return sphereOrbitNodeDetails;
});
currentSphereOrbitNodeDetailsAtom.testId =
    "currentSphereOrbitNodeDetailsAtom";
export const getOrbitNodeDetailsFromEhAtom = (orbitEh) => atom((get) => {
    const allSphereNodeDetails = get(nodeCache.entries)?.map(([_sphereId, sphereNodeDetails]) => sphereNodeDetails);
    const foundSphereEntry = allSphereNodeDetails?.find((entry) => entry[orbitEh]);
    if (!allSphereNodeDetails || !foundSphereEntry)
        return null;
    const foundOrbitDetails = foundSphereEntry[orbitEh];
    return foundOrbitDetails || null;
});
getOrbitNodeDetailsFromEhAtom.testId = "getOrbitNodeDetailsFromEhAtom";
export const currentOrbitDetailsAtom = atom((get) => {
    const currentOrbitHash = get(currentOrbitIdAtom)?.id;
    if (!currentOrbitHash)
        return null;
    let hash = currentOrbitHash;
    if (!hash.startsWith("uhCE")) {
        const eH = get(getOrbitEhFromId(currentOrbitHash));
        if (!eH)
            return null;
        hash = eH;
    }
    return get(getOrbitNodeDetailsFromEhAtom(hash));
});
currentOrbitDetailsAtom.testId = "currentOrbitDetailsAtom";
export const getOrbitNodeDetailsFromIdAtom = (orbitId) => atom((get) => {
    const eH = get(getOrbitEhFromId(orbitId));
    if (!eH || typeof eH !== "string")
        return null;
    return get(getOrbitNodeDetailsFromEhAtom(eH));
});
getOrbitNodeDetailsFromIdAtom.testId = "getOrbitNodeDetailsFromIdAtom";
export const getCurrentSphereOrbitNodeDetailsFromEhAtom = (orbitEh) => atom((get) => {
    const state = get(appStateAtom);
    const currentSphereHash = state.spheres.currentSphereHash;
    const currentSphere = state.spheres.byHash[currentSphereHash];
    if (!currentSphere)
        return null;
    const sphereOrbitNodeDetails = get(nodeCache.item(currentSphereHash));
    if (!sphereOrbitNodeDetails)
        return null;
    const orbitCacheItem = sphereOrbitNodeDetails[orbitEh];
    return orbitCacheItem || null;
});
export const getCurrentOrbitStartTimeFromEh = atom((get) => (orbitEh) => {
    const cacheItem = get(getCurrentSphereOrbitNodeDetailsFromEhAtom(orbitEh));
    return cacheItem?.startTime || null;
});
export const setOrbitWithEntryHashAtom = atom(null, (get, set, { orbitEh, update, }) => {
    const prevState = get(appStateAtom);
    const orbitActionHash = Object.keys(prevState.orbitNodes.byHash).find((key) => prevState.orbitNodes.byHash[key].eH === orbitEh);
    if (!orbitActionHash)
        return;
    const newState = {
        ...prevState,
        orbitNodes: {
            ...prevState.orbitNodes,
            byHash: {
                ...prevState.orbitNodes.byHash,
                [orbitActionHash]: {
                    ...prevState.orbitNodes.byHash[orbitActionHash],
                    ...update,
                },
            },
        },
    };
    set(appStateAtom, newState);
});
export const currentOrbitIsLeafAtom = atom((get) => {
    const currentOrbitId = get(currentOrbitDetailsAtom)?.id;
    if (!currentOrbitId)
        return null;
    return get(isLeafNodeHashAtom(currentOrbitId));
});
currentOrbitIsLeafAtom.testId = "currentOrbitIsLeafAtom";
export const getOrbitFrequency = (orbitId) => {
    const selectFrequency = atom((get) => {
        const orbit = get(getOrbitNodeDetailsFromIdAtom(orbitId));
        return orbit?.frequency || null;
    });
    return selectFrequency;
};
export const currentSphereOrbitNodesAtom = atom((get) => {
    const state = get(appStateAtom);
    const currentSphereHash = state.spheres.currentSphereHash;
    const currentSphere = state.spheres.byHash[currentSphereHash];
    if (!currentSphere)
        return null;
    const sphereNodes = {};
    Object.entries(state.orbitNodes.byHash).forEach(([nodeHash, orbitNode]) => {
        if (orbitNode.sphereHash === currentSphere.details.entryHash) {
            sphereNodes[nodeHash] = orbitNode;
        }
    });
    return Object.keys(sphereNodes).length > 0 ? sphereNodes : null;
});
export const currentOrbitIdAtom = atom((get) => {
    const state = get(appStateAtom);
    return state.orbitNodes.currentOrbitHash
        ? { id: state.orbitNodes.currentOrbitHash }
        : null;
}, (_get, set, newOrbitId) => {
    const prevState = _get(appStateAtom);
    const newState = {
        ...prevState,
        orbitNodes: {
            ...prevState.orbitNodes,
            currentOrbitHash: newOrbitId,
        },
    };
    NODE_ENV !== "test" && console.log("Setting orbit id :>> ", newState);
    set(appStateAtom, newState);
});
currentOrbitIdAtom.testId = "currentOrbitIdAtom";
export const getOrbitIdFromEh = (orbitEh) => atom((get) => {
    const state = get(appStateAtom);
    const orbitActionHash = Object.keys(state.orbitNodes.byHash).find((key) => state.orbitNodes.byHash[key].eH === orbitEh);
    return orbitActionHash || null;
});
getOrbitIdFromEh.testId = "getOrbitIdFromEh";
export const getOrbitEhFromId = (id) => atom((get) => {
    const state = get(appStateAtom);
    const orbitEh = state.orbitNodes.byHash[id]?.eH;
    return orbitEh || null;
});
export const orbitWinDataAtom = (orbitId) => {
    const selectWinData = atom((get) => {
        const state = get(appStateAtom);
        return state.wins[orbitId] || {};
    });
    return selectWinData;
};
//# sourceMappingURL=orbit.js.map