import { atom } from "jotai";
import { appStateAtom } from "./store";
import { Frequency } from "./types/orbit";
import { Frequency as Freq } from "../graphql/generated";
export const decodeFrequency = (frequency) => {
    switch (frequency) {
        case Freq.Day:
            return Frequency.DAILY_OR_MORE.DAILY;
        case Freq.Month:
            return Frequency.LESS_THAN_DAILY.MONTHLY;
        case Freq.Quarter:
            return Frequency.LESS_THAN_DAILY.QUARTERLY;
        default:
            return Frequency.DAILY_OR_MORE.DAILY;
    }
};
export const mapToCacheObject = (orbit) => {
    const newFrequency = decodeFrequency(orbit.frequency);
    return {
        id: orbit.id,
        eH: orbit.eH,
        parentEh: orbit.parentHash || undefined,
        name: orbit.name,
        scale: orbit.scale,
        sphereHash: orbit.sphereHash,
        frequency: newFrequency,
        description: orbit.metadata?.description || "",
        startTime: orbit.metadata?.timeframe.startTime,
        endTime: orbit.metadata?.timeframe.endTime || undefined,
    };
};
export const currentSphereOrbitNodesAtom = atom((get) => {
    const state = get(appStateAtom);
    const currentSphereHash = state.spheres.currentSphereHash;
    const currentSphere = state.spheres.byHash[currentSphereHash];
    if (!currentSphere)
        return null;
    const sphereNodes = {};
    Object.entries(state.orbitNodes.byHash).forEach(([nodeHash, orbitNode]) => {
        if (orbitNode.sphereHash === currentSphere.details.entryHash) {
            sphereNodes[nodeHash] = orbitNode;
        }
    });
    return Object.keys(sphereNodes).length > 0 ? sphereNodes : null;
});
export const currentOrbitDetailsAtom = atom((get) => {
    const state = get(appStateAtom);
    const currentOrbitHash = state.orbitNodes.currentOrbitHash;
    if (!currentOrbitHash)
        return null;
    return state.orbitNodes.byHash[currentOrbitHash] || null;
});
export const currentOrbitIdAtom = atom((get) => {
    const state = get(appStateAtom);
    return state.orbitNodes.currentOrbitHash
        ? { id: state.orbitNodes.currentOrbitHash }
        : null;
}, (get, set, newOrbitId) => {
    set(appStateAtom, (prevState) => ({
        ...prevState,
        orbitNodes: {
            ...prevState.orbitNodes,
            currentOrbitHash: newOrbitId,
        },
    }));
});
export const getOrbitAtom = (orbitId) => atom((get) => {
    const state = get(appStateAtom);
    return state.orbitNodes.byHash[orbitId] || null;
});
export const setOrbitWithEntryHashAtom = atom(null, (get, set, { orbitEh, update, }) => {
    set(appStateAtom, (prevState) => {
        const orbitActionHash = Object.keys(prevState.orbitNodes.byHash).find((key) => prevState.orbitNodes.byHash[key].eH === orbitEh);
        if (!orbitActionHash)
            return prevState;
        return {
            ...prevState,
            orbitNodes: {
                ...prevState.orbitNodes,
                byHash: {
                    ...prevState.orbitNodes.byHash,
                    [orbitActionHash]: {
                        ...prevState.orbitNodes.byHash[orbitActionHash],
                        ...update,
                    },
                },
            },
        };
    });
});
export const getOrbitFrequency = (orbitHash) => {
    const selectFrequency = atom((get) => {
        const state = get(appStateAtom);
        const orbit = state.orbitNodes.byHash[orbitHash];
        return orbit?.frequency || null;
    });
    return selectFrequency;
};
export const orbitWinDataAtom = (orbitHash) => {
    const selectWinData = atom((get) => {
        const state = get(appStateAtom);
        return state.wins[orbitHash] || {};
    });
    return selectWinData;
};
export const setWinForOrbit = atom(null, (get, set, { orbitHash, date, winIndex, hasWin, }) => {
    const state = get(appStateAtom);
    const orbit = state.orbitNodes.byHash[orbitHash];
    if (!orbit) {
        console.warn(`Attempted to set win for non-existent orbit: ${orbitHash}`);
        return;
    }
    const frequency = orbit.frequency;
    const currentWinData = state.wins[orbitHash] || {};
    let newWinData;
    if (frequency > 1) {
        const currentDayData = Array.isArray(currentWinData[date])
            ? currentWinData[date]
            : new Array(Math.round(frequency)).fill(false);
        const newDayData = [...currentDayData];
        if (winIndex !== undefined && winIndex < Math.round(frequency)) {
            newDayData[winIndex] = hasWin;
        }
        newWinData = { ...currentWinData, [date]: newDayData };
    }
    else {
        newWinData = { ...currentWinData, [date]: hasWin };
    }
    set(appStateAtom, {
        ...state,
        wins: {
            ...state.wins,
            [orbitHash]: newWinData,
        },
    });
});
export const calculateStreakAtom = (orbitHash) => {
    const calculateStreak = atom((get) => {
        const state = get(appStateAtom);
        const orbit = state.orbitNodes.byHash[orbitHash];
        const winData = state.wins[orbitHash] || {};
        if (!orbit) {
            return null;
        }
        return 0;
    });
    return calculateStreak;
};
//# sourceMappingURL=orbit.js.map