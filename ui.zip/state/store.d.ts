import { MiniDb } from "jotai-minidb";
import { AppState } from "./types/store";
export declare const nodeCache: MiniDb<unknown>;
export declare const store: any;
export declare const appStateChangeAtom: import("jotai").WritableAtom<AppState, [AppState | typeof import("jotai/utils").RESET | ((prev: AppState) => AppState | typeof import("jotai/utils").RESET)], void>;
export declare const appStateAtom: import("jotai").WritableAtom<AppState, [update: AppState], void>;
//# sourceMappingURL=store.d.ts.map