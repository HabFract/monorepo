import { atom } from "jotai";
import { DateTime } from "luxon";
export const currentDayAtom = atom(DateTime.local());
//# sourceMappingURL=date.js.map