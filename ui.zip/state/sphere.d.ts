import { SphereDetails } from "./types/sphere";
import { ActionHashB64, EntryHashB64 } from "@holochain/client";
export declare const currentSphereHashesAtom: import("jotai").WritableAtom<{
    entryHash: string;
    actionHash: string;
} | null, [newSphereActionHash: string], void>;
export declare const currentSphereDetailsAtom: import("jotai").Atom<SphereDetails | null>;
export declare const getSphereIdFromEhAtom: (sphereEh: EntryHashB64) => import("jotai").Atom<string | null>;
export declare const currentSphereHasCachedNodesAtom: import("jotai").Atom<boolean | null>;
export declare const sphereHasCachedNodesAtom: (sphereId: ActionHashB64) => import("jotai").Atom<boolean | null>;
//# sourceMappingURL=sphere.d.ts.map