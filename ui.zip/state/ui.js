import { atom } from 'jotai';
export var SortCriteria;
(function (SortCriteria) {
    SortCriteria["Name"] = "name";
    SortCriteria["Scale"] = "scale";
})(SortCriteria || (SortCriteria = {}));
export var SortOrder;
(function (SortOrder) {
    SortOrder["GreatestToLowest"] = "greatestToLowest";
    SortOrder["LowestToGreatest"] = "lowestToGreatest";
})(SortOrder || (SortOrder = {}));
export const listSortFilterAtom = atom({
    sortCriteria: SortCriteria.Name,
    sortOrder: SortOrder.LowestToGreatest,
});
//# sourceMappingURL=ui.js.map