import { atom } from "jotai";
import { appStateChangeAtom } from "./store";
export var SortCriteria;
(function (SortCriteria) {
    SortCriteria["Name"] = "name";
    SortCriteria["Scale"] = "scale";
})(SortCriteria || (SortCriteria = {}));
export var SortOrder;
(function (SortOrder) {
    SortOrder["GreatestToLowest"] = "greatestToLowest";
    SortOrder["LowestToGreatest"] = "lowestToGreatest";
})(SortOrder || (SortOrder = {}));
export const listSortFilterAtom = atom({
    sortCriteria: SortCriteria.Name,
    sortOrder: SortOrder.LowestToGreatest,
});
export const handednessAtom = atom((get) => get(appStateChangeAtom).ui.handedness, (get, set, newHandedness) => {
    const currentState = get(appStateChangeAtom);
    set(appStateChangeAtom, {
        ...currentState,
        ui: {
            ...currentState.ui,
            handedness: newHandedness,
        },
    });
});
export const performanceModeAtom = atom((get) => get(appStateChangeAtom).ui.performanceMode, (get, set, newPerformanceMode) => {
    const currentState = get(appStateChangeAtom);
    set(appStateChangeAtom, {
        ...currentState,
        ui: {
            ...currentState.ui,
            performanceMode: newPerformanceMode,
        },
    });
});
//# sourceMappingURL=ui.js.map