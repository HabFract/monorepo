export declare enum SortCriteria {
    Name = "name",
    Scale = "scale"
}
export declare enum SortOrder {
    GreatestToLowest = "greatestToLowest",
    LowestToGreatest = "lowestToGreatest"
}
export interface SortFilterState {
    sortCriteria: SortCriteria;
    sortOrder: SortOrder;
}
export declare const listSortFilterAtom: import("jotai").PrimitiveAtom<SortFilterState> & {
    init: SortFilterState;
};
export declare const handednessAtom: import("jotai").WritableAtom<"right" | "left", [newHandedness: "right" | "left"], void>;
export declare const performanceModeAtom: import("jotai").WritableAtom<"fancy" | "snappy" | "snancy", [newPerformanceMode: "fancy" | "snappy" | "snancy"], void>;
//# sourceMappingURL=ui.d.ts.map