export declare enum SortCriteria {
    Name = "name",
    Scale = "scale"
}
export declare enum SortOrder {
    GreatestToLowest = "greatestToLowest",
    LowestToGreatest = "lowestToGreatest"
}
export interface SortFilterState {
    sortCriteria: SortCriteria;
    sortOrder: SortOrder;
}
export declare const listSortFilterAtom: import("jotai").PrimitiveAtom<SortFilterState> & {
    init: SortFilterState;
};
//# sourceMappingURL=ui.d.ts.map