import { atom } from "jotai";
import { appStateAtom } from "./store";
import { getOrbitEhFromId, getOrbitNodeDetailsFromEhAtom, getOrbitNodeDetailsFromIdAtom, } from "./orbit";
import { getDescendantLeafNodesAtom, isLeafNodeHashAtom } from "./hierarchy";
import { DateTime } from "luxon";
export const setWinDataAtom = atom(null, (get, set, { orbitHash, date, winData, }) => {
    const state = get(appStateAtom);
    const currentWinData = state.wins[orbitHash] || {};
    set(appStateAtom, {
        ...state,
        wins: {
            ...state.wins,
            [orbitHash]: {
                ...currentWinData,
                [date]: winData,
            },
        },
    });
});
export const winDataPerOrbitNodeAtom = (orbitHash) => {
    return atom((get) => {
        const state = get(appStateAtom);
        return state.wins[orbitHash] || null;
    }, (get, set, winRecord) => {
        const state = get(appStateAtom);
        set(appStateAtom, {
            ...state,
            wins: {
                ...state.wins,
                [orbitHash]: winRecord,
            },
        });
    });
};
export const getWinCompletionForOrbitForDayAtom = (orbitEh, date) => {
    return atom((get) => {
        const state = get(appStateAtom);
        let hash = orbitEh;
        if (!hash.startsWith("uhCE")) {
            const eH = get(getOrbitEhFromId(orbitEh));
            if (!eH)
                return null;
            hash = eH;
        }
        const orbit = get(getOrbitNodeDetailsFromEhAtom(hash));
        const winData = state.wins[hash] || {};
        if (!orbit)
            return false;
        const winDataForDay = winData[date];
        const orbitFrequency = orbit.frequency;
        const isCompleted = orbitFrequency > 1
            ? winDataForDay?.every((val) => val)
            : typeof winDataForDay === "undefined"
                ? false
                : winDataForDay;
        return isCompleted;
    });
};
export const calculateCompletionStatusAtom = (orbitEh, date) => {
    return atom((get) => {
        const orbit = get(getOrbitNodeDetailsFromEhAtom(orbitEh));
        if (!orbit)
            return null;
        const isLeaf = get(isLeafNodeHashAtom(orbit.id));
        if (isLeaf) {
            return get(getWinCompletionForOrbitForDayAtom(orbitEh, date));
        }
        else {
            const leafDescendants = get(getDescendantLeafNodesAtom(orbitEh));
            if (!leafDescendants)
                return null;
            return leafDescendants.flat().every((leaf) => {
                return get(getWinCompletionForOrbitForDayAtom(leaf.content, date));
            });
        }
    });
};
export const calculateCurrentStreakAtom = (orbitHash) => {
    const orbitDetailsAtom = getOrbitNodeDetailsFromIdAtom(orbitHash);
    const calculateStreak = atom((get) => {
        const orbit = get(orbitDetailsAtom);
        if (!orbit)
            return null;
        const state = get(appStateAtom);
        const currentDate = DateTime.now().toLocaleString();
        const winData = state.wins[orbit.eH] || {};
        let streak = 0;
        let date = DateTime.fromFormat(currentDate, "dd/MM/yyyy");
        while (true) {
            const dateString = date.toFormat("dd/MM/yyyy");
            const winEntry = winData[dateString];
            if (winEntry === undefined)
                break;
            if (Array.isArray(winEntry)) {
                if (winEntry.every(Boolean)) {
                    streak++;
                }
                else {
                    break;
                }
            }
            else if (winEntry === true) {
                streak++;
            }
            else {
                break;
            }
            date = date.minus({ days: 1 });
        }
        return streak;
    });
    return calculateStreak;
};
export const calculateLongestStreakAtom = (orbitHash) => {
    const calculateLongestStreak = atom((get) => {
        const state = get(appStateAtom);
        const orbit = state.orbitNodes.byHash[orbitHash];
        if (!orbit)
            return null;
        const winData = state.wins[orbit.eH] || {};
        let longestStreak = 0;
        let currentStreak = 0;
        let previousDate = null;
        const sortedDates = Object.keys(winData).sort((a, b) => {
            const dateA = DateTime.fromFormat(a, "dd/MM/yyyy");
            const dateB = DateTime.fromFormat(b, "dd/MM/yyyy");
            return dateA.toMillis() - dateB.toMillis();
        });
        for (const date of sortedDates) {
            const winEntry = winData[date];
            const currentDate = DateTime.fromFormat(date, "dd/MM/yyyy");
            if (previousDate && currentDate.diff(previousDate, "days").days !== 1) {
                currentStreak = 0;
            }
            if (Array.isArray(winEntry)) {
                if (winEntry.every(Boolean)) {
                    currentStreak++;
                }
                else {
                    currentStreak = 0;
                }
            }
            else if (winEntry === true) {
                currentStreak++;
            }
            else {
                currentStreak = 0;
            }
            if (currentStreak > longestStreak) {
                longestStreak = currentStreak;
            }
            previousDate = currentDate;
        }
        return longestStreak;
    });
    return calculateLongestStreak;
};
//# sourceMappingURL=win.js.map