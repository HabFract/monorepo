import { atom } from "jotai";
import { appStateChangeAtom } from "./store";
import { getOrbitIdFromEh, getOrbitNodeDetailsFromEhAtom, getOrbitNodeDetailsFromIdAtom, } from "./orbit";
import { getDescendantLeafNodesAtom, isLeafNodeHashAtom } from "./hierarchy";
import { DateTime } from "luxon";
import { hierarchy } from "d3-hierarchy";
export const winDataArrayToWinRecord = (acc, { date, value: val }) => {
    acc[date] = "single" in val ? val.single : val.multiple;
    return acc;
};
const nonLeafNodeAtomCache = new Map();
const nonLeafNodeSubscriptionCache = new Map();
export const cleanupNonLeafNodeAtom = (orbitEh) => {
    nonLeafNodeAtomCache.delete(orbitEh);
    nonLeafNodeSubscriptionCache.delete(orbitEh);
};
export const decrementNonLeafNodeAtomRef = (orbitEh) => {
    const currentCount = nonLeafNodeSubscriptionCache.get(orbitEh) || 0;
    if (currentCount <= 1) {
        cleanupNonLeafNodeAtom(orbitEh);
    }
    else {
        nonLeafNodeSubscriptionCache.set(orbitEh, currentCount - 1);
    }
};
export const setWinDataAtom = atom(null, (get, set, { orbitHash, date, winData, }) => {
    const state = get(appStateChangeAtom);
    const currentWinData = state.wins[orbitHash] || {};
    set(appStateChangeAtom, {
        ...state,
        wins: {
            ...state.wins,
            [orbitHash]: {
                ...currentWinData,
                [date]: winData,
            },
        },
    });
});
export const winDataPerOrbitNodeAtom = (orbitHash) => {
    return atom((get) => {
        const state = get(appStateChangeAtom);
        return state.wins[orbitHash] || null;
    }, (get, set, winRecord) => {
        const state = get(appStateChangeAtom);
        set(appStateChangeAtom, {
            ...state,
            wins: {
                ...state.wins,
                [orbitHash]: winRecord,
            },
        });
    });
};
export const getWinCompletionForOrbitForDayAtom = (orbitEh, date) => {
    return atom((get) => {
        const state = get(appStateChangeAtom);
        let hash = orbitEh;
        if (hash.startsWith("uhCE")) {
            const id = get(getOrbitIdFromEh(orbitEh));
            if (!id)
                return null;
            hash = id;
        }
        const orbit = get(getOrbitNodeDetailsFromEhAtom(orbitEh));
        const winData = state.wins[hash] || {};
        if (!orbit)
            return false;
        const winDataForDay = winData[date];
        const orbitFrequency = orbit.frequency;
        const isCompleted = orbitFrequency > 1
            ? winDataForDay?.every((val) => val)
            : typeof winDataForDay === "undefined"
                ? false
                : winDataForDay;
        return isCompleted;
    });
};
export const calculateCompletionStatusAtom = (orbitEh, date) => {
    return atom((get) => {
        const orbit = get(getOrbitNodeDetailsFromEhAtom(orbitEh));
        if (!orbit)
            return null;
        const isLeaf = get(isLeafNodeHashAtom(orbit.id));
        if (isLeaf) {
            return get(getWinCompletionForOrbitForDayAtom(orbitEh, date));
        }
        else {
            const leafDescendants = get(getDescendantLeafNodesAtom(orbitEh));
            if (!leafDescendants)
                return null;
            return leafDescendants.flat().every((leaf) => {
                return get(getWinCompletionForOrbitForDayAtom(leaf.content, date));
            });
        }
    });
};
export const calculateWinDataForNonLeafNodeAtom = (orbitEh) => {
    if (nonLeafNodeAtomCache.has(orbitEh)) {
        nonLeafNodeSubscriptionCache.set(orbitEh, (nonLeafNodeSubscriptionCache.get(orbitEh) || 0) + 1);
        return nonLeafNodeAtomCache.get(orbitEh);
    }
    const newAtom = atom((get) => {
        const orbit = get(getOrbitNodeDetailsFromEhAtom(orbitEh));
        if (!orbit) {
            console.warn('No orbit found for:', orbitEh);
            return null;
        }
        const orbitHash = orbit.id;
        const hierarchies = get(appStateChangeAtom).hierarchies.byRootOrbitEntryHash;
        const hierarchyJson = Object.values(hierarchies).find(h => h.nodeHashes.includes(orbitHash) || h.nodeHashes.includes(orbitEh));
        if (!hierarchyJson) {
            console.warn('No hierarchy found for:', orbitEh);
            return null;
        }
        const tree = hierarchyJson.json && JSON.parse(hierarchyJson.json)?.[0];
        if (!tree)
            return null;
        const d3Hierarchy = hierarchy(tree);
        const currentNode = d3Hierarchy.find(node => node.data.content === orbitEh);
        if (!currentNode) {
            console.warn('Current node not found in hierarchy:', orbitEh);
            return null;
        }
        const leafDescendants = currentNode.leaves().map(node => node.data.content);
        if (!leafDescendants.length) {
            console.warn('No leaf descendants found for branch:', orbitEh);
            return null;
        }
        const today = DateTime.now();
        const startOfMonth = today.startOf('month');
        const endOfMonth = today.endOf('month');
        const winData = {};
        let currentDate = startOfMonth;
        while (currentDate <= endOfMonth) {
            const dateString = currentDate.toLocaleString();
            const completedLeafNodes = leafDescendants.filter(leaf => get(getWinCompletionForOrbitForDayAtom(leaf, dateString)));
            const completionArray = Array(leafDescendants.length).fill(false)
                .map((_, index) => index < completedLeafNodes.length);
            winData[dateString] = completionArray;
            currentDate = currentDate.plus({ days: 1 });
        }
        return winData;
    });
    nonLeafNodeAtomCache.set(orbitEh, newAtom);
    nonLeafNodeSubscriptionCache.set(orbitEh, 1);
    return newAtom;
};
export const calculateCurrentStreakAtom = (orbitHash) => {
    const orbitDetailsAtom = getOrbitNodeDetailsFromIdAtom(orbitHash);
    const calculateStreak = atom((get) => {
        const orbit = get(orbitDetailsAtom);
        if (!orbit)
            return null;
        const state = get(appStateChangeAtom);
        const currentDate = DateTime.now().toLocaleString();
        const winData = state.wins[orbit.eH] || {};
        let streak = 0;
        let date = DateTime.fromFormat(currentDate, "dd/MM/yyyy");
        while (true) {
            const dateString = date.toFormat("dd/MM/yyyy");
            const winEntry = winData[dateString];
            if (winEntry === undefined)
                break;
            if (Array.isArray(winEntry)) {
                if (winEntry.every(Boolean)) {
                    streak++;
                }
                else {
                    break;
                }
            }
            else if (winEntry === true) {
                streak++;
            }
            else {
                break;
            }
            date = date.minus({ days: 1 });
        }
        return streak;
    });
    return calculateStreak;
};
calculateCurrentStreakAtom.testId = "calculateCurrentStreakAtom";
export const calculateLongestStreakAtom = (orbitHash) => {
    const calculateLongestStreak = atom((get) => {
        const state = get(appStateChangeAtom);
        const orbit = state.orbitNodes.byHash[orbitHash];
        if (!orbit)
            return null;
        const winData = state.wins[orbit.eH] || {};
        let longestStreak = 0;
        let currentStreak = 0;
        let previousDate = null;
        const sortedDates = Object.keys(winData).sort((a, b) => {
            const dateA = DateTime.fromFormat(a, "dd/MM/yyyy");
            const dateB = DateTime.fromFormat(b, "dd/MM/yyyy");
            return dateA.toMillis() - dateB.toMillis();
        });
        for (const date of sortedDates) {
            const winEntry = winData[date];
            const currentDate = DateTime.fromFormat(date, "dd/MM/yyyy");
            if (previousDate && currentDate.diff(previousDate, "days").days !== 1) {
                currentStreak = 0;
            }
            if (Array.isArray(winEntry)) {
                if (winEntry.every(Boolean)) {
                    currentStreak++;
                }
                else {
                    currentStreak = 0;
                }
            }
            else if (winEntry === true) {
                currentStreak++;
            }
            else {
                currentStreak = 0;
            }
            if (currentStreak > longestStreak) {
                longestStreak = currentStreak;
            }
            previousDate = currentDate;
        }
        return longestStreak;
    });
    return calculateLongestStreak;
};
calculateLongestStreakAtom.testId = "calculateLongestStreakAtom";
//# sourceMappingURL=win.js.map