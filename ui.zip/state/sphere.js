import { atom } from "jotai";
import { appStateChangeAtom } from "./store";
import { nodeCache } from "./store";
import { getOrbitNodeDetailsFromEhAtom } from "./orbit";
export const currentSphereHashesAtom = atom((get) => {
    const state = get(appStateChangeAtom);
    const currentSphereHash = state.spheres.currentSphereHash;
    const currentSphere = state.spheres.byHash[currentSphereHash];
    return currentSphere
        ? {
            entryHash: currentSphere.details.entryHash,
            actionHash: currentSphereHash,
        }
        : null;
}, (get, set, newSphereActionHash) => {
    const prevState = get(appStateChangeAtom);
    if (!newSphereActionHash)
        return;
    const newState = {
        ...prevState,
        spheres: {
            ...prevState.spheres,
            currentSphereHash: newSphereActionHash
        },
    };
    set(appStateChangeAtom, newState);
});
currentSphereHashesAtom.testId = "currentSphereHashes";
export const currentSphereDetailsAtom = atom((get) => {
    const state = get(appStateChangeAtom);
    const currentSphereHash = state.spheres.currentSphereHash;
    return state.spheres.byHash[currentSphereHash]?.details || null;
});
currentSphereDetailsAtom.testId = "currentSphereDetailsAtom";
export const getSphereIdFromEhAtom = (sphereEh) => atom((get) => {
    const state = get(appStateChangeAtom);
    const sphere = Object.entries(state.spheres.byHash).find(([_id, sphereDetails]) => sphereDetails.details.entryHash == sphereEh);
    if (!sphere)
        return null;
    return sphere[0] || null;
});
export const currentSphereHasCachedNodesAtom = atom((get) => {
    const state = get(appStateChangeAtom);
    const sphereId = state.spheres.currentSphereHash;
    if (!sphereId)
        return false;
    return get(sphereHasCachedNodesAtom(sphereId));
});
export const sphereHasCachedNodesAtom = (sphereId) => atom((get) => {
    const state = get(appStateChangeAtom);
    const selectedSphere = state.spheres.byHash[sphereId];
    if (!selectedSphere)
        return null;
    const rootOrbitHashes = selectedSphere.hierarchyRootOrbitEntryHashes;
    if (!rootOrbitHashes || rootOrbitHashes.length == 0)
        return null;
    const sphereNodeDetailsCache = get(nodeCache.item(sphereId));
    if (!sphereNodeDetailsCache)
        return null;
    return rootOrbitHashes.every((nodeEh) => {
        const cacheItem = get(getOrbitNodeDetailsFromEhAtom(nodeEh));
        return !!cacheItem;
    });
});
//# sourceMappingURL=sphere.js.map