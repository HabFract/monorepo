import { atom } from "jotai";
import { appStateAtom } from "./store";
export const currentSphereHashesAtom = atom((get) => {
    const state = get(appStateAtom);
    const currentSphereHash = state.spheres.currentSphereHash;
    const currentSphere = state.spheres.byHash[currentSphereHash];
    return currentSphere
        ? {
            entryHash: currentSphere.details.entryHash,
            actionHash: currentSphereHash,
        }
        : {};
}, (_get, set, newSphereHashes) => {
    set(appStateAtom, (prevState) => {
        const newCurrentSphereHash = newSphereHashes.actionHash || '';
        console.log('newCurrentSphereHash :>> ', newCurrentSphereHash);
        return {
            ...prevState,
            spheres: {
                ...prevState.spheres,
                currentSphereHash: newCurrentSphereHash,
            },
        };
    });
});
export const currentSphereAtom = atom((get) => {
    const state = get(appStateAtom);
    const currentSphereHash = state.spheres.currentSphereHash;
    return state.spheres.byHash[currentSphereHash]?.details || null;
});
export const currentSphereHasCachedNodesAtom = atom((get) => {
    const state = get(appStateAtom);
    const currentSphereHash = state.spheres.currentSphereHash;
    const currentSphere = state.spheres.byHash[currentSphereHash];
    if (!currentSphere)
        return false;
    const rootOrbitHashes = currentSphere.hierarchyRootOrbitEntryHashes;
    return rootOrbitHashes.some((hash) => {
        const hierarchy = state.hierarchies.byRootOrbitEntryHash[hash];
        return hierarchy && hierarchy.nodeHashes.length > 0;
    });
});
//# sourceMappingURL=sphere.js.map