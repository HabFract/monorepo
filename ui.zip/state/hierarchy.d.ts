import { ActionHashB64 } from "@holochain/client";
import { NodeContent, SphereHierarchyBounds } from "./types/hierarchy";
import { EntryHashB64 } from "@holochain/client";
import { OrbitNodeDetails, RootOrbitEntryHash } from "./types/orbit";
import { Hierarchy } from "./types/hierarchy";
import { HierarchyNode } from "d3-hierarchy";
export declare const currentSphereHierarchyBounds: import("jotai").PrimitiveAtom<SphereHierarchyBounds> & {
    init: SphereHierarchyBounds;
};
export declare const currentSphereHierarchyIndices: import("jotai").PrimitiveAtom<import("./types").Coords> & {
    init: import("./types").Coords;
};
export declare const setCurrentBreadth: import("jotai").WritableAtom<null, [newBreadth: number], void> & {
    init: null;
};
export declare const setCurrentDepth: import("jotai").WritableAtom<null, [newDepth: number], void> & {
    init: null;
};
export declare const setDepths: import("jotai").WritableAtom<null, [id: string, [number, number]], void> & {
    init: null;
};
export declare const setBreadths: import("jotai").WritableAtom<null, [id: string, [number, number]], void> & {
    init: null;
};
export declare const newTraversalLevelIndexId: import("jotai").PrimitiveAtom<{
    id: EntryHashB64 | null;
    intermediateId?: EntryHashB64 | null;
    previousRenderSiblingIndex?: number;
    direction?: "up" | "down";
}> & {
    init: {
        id: EntryHashB64 | null;
        intermediateId?: EntryHashB64 | null;
        previousRenderSiblingIndex?: number;
        direction?: "up" | "down";
    };
};
export declare const getHierarchyAtom: (rootOrbitEntryHash: RootOrbitEntryHash) => import("jotai").Atom<Hierarchy | null>;
export declare const updateHierarchyAtom: import("jotai").WritableAtom<null, [newHierarchy: {
    rootData: HierarchyNode<NodeContent & {
        children?: HierarchyNode<NodeContent>;
    }>;
    each: Function;
    _json: string;
}], null | undefined> & {
    init: null;
};
export declare const isLeafNodeHashAtom: (nodeId: ActionHashB64) => import("jotai").Atom<boolean>;
export declare const getDescendantLeafNodesAtom: (orbitEh: EntryHashB64) => import("jotai").Atom<any[] | null>;
export declare const getHierarchyOrbitDetailsAtom: (rootOrbitEntryHash: RootOrbitEntryHash) => import("jotai").Atom<OrbitNodeDetails[] | null>;
//# sourceMappingURL=hierarchy.d.ts.map