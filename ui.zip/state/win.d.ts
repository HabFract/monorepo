import { Atom } from "jotai";
import { ActionHashB64, EntryHashB64 } from "@state/types";
import { FixedLengthArray, WinDataPerOrbitNode } from "./types";
export declare const winDataArrayToWinRecord: (acc: any, { date, value: val }: any) => any;
export declare const cleanupNonLeafNodeAtom: (orbitEh: EntryHashB64) => void;
export declare const decrementNonLeafNodeAtomRef: (orbitEh: EntryHashB64) => void;
export declare const setWinDataAtom: import("jotai").WritableAtom<null, [{
    orbitHash: ActionHashB64;
    date: string;
    winData: boolean | boolean[];
}], void> & {
    init: null;
};
export declare const winDataPerOrbitNodeAtom: (orbitHash: ActionHashB64) => import("jotai").WritableAtom<{
    [dayIndex: string]: boolean;
} | {
    [dayIndex: string]: FixedLengthArray<boolean, 2>;
} | {
    [dayIndex: string]: FixedLengthArray<boolean, 1>;
} | {
    [dayIndex: string]: FixedLengthArray<boolean, 22>;
} | {
    [dayIndex: string]: FixedLengthArray<boolean, 3>;
} | {
    [dayIndex: string]: FixedLengthArray<boolean, 4>;
} | {
    [dayIndex: string]: FixedLengthArray<boolean, 5>;
} | {
    [dayIndex: string]: FixedLengthArray<boolean, 6>;
} | {
    [dayIndex: string]: FixedLengthArray<boolean, 7>;
} | {
    [dayIndex: string]: FixedLengthArray<boolean, 8>;
} | {
    [dayIndex: string]: FixedLengthArray<boolean, 9>;
} | {
    [dayIndex: string]: FixedLengthArray<boolean, 10>;
} | {
    [dayIndex: string]: FixedLengthArray<boolean, 11>;
} | {
    [dayIndex: string]: FixedLengthArray<boolean, 12>;
} | {
    [dayIndex: string]: FixedLengthArray<boolean, 13>;
} | {
    [dayIndex: string]: FixedLengthArray<boolean, 14>;
} | {
    [dayIndex: string]: FixedLengthArray<boolean, 15>;
} | {
    [dayIndex: string]: FixedLengthArray<boolean, 16>;
} | {
    [dayIndex: string]: FixedLengthArray<boolean, 17>;
} | {
    [dayIndex: string]: FixedLengthArray<boolean, 18>;
} | {
    [dayIndex: string]: FixedLengthArray<boolean, 19>;
} | {
    [dayIndex: string]: FixedLengthArray<boolean, 20>;
} | {
    [dayIndex: string]: FixedLengthArray<boolean, 21>;
} | {
    [dayIndex: string]: FixedLengthArray<boolean, 23>;
} | {
    [dayIndex: string]: FixedLengthArray<boolean, 24>;
}, [winRecord: WinDataPerOrbitNode], void>;
export declare const getWinCompletionForOrbitForDayAtom: (orbitEh: EntryHashB64, date: string) => Atom<boolean | FixedLengthArray<boolean, 2> | FixedLengthArray<boolean, 1> | FixedLengthArray<boolean, 22> | FixedLengthArray<boolean, 3> | FixedLengthArray<boolean, 4> | FixedLengthArray<boolean, 5> | FixedLengthArray<boolean, 6> | FixedLengthArray<boolean, 7> | FixedLengthArray<boolean, 8> | FixedLengthArray<boolean, 9> | FixedLengthArray<boolean, 10> | FixedLengthArray<boolean, 11> | FixedLengthArray<boolean, 12> | FixedLengthArray<boolean, 13> | FixedLengthArray<boolean, 14> | FixedLengthArray<boolean, 15> | FixedLengthArray<boolean, 16> | FixedLengthArray<boolean, 17> | FixedLengthArray<boolean, 18> | FixedLengthArray<boolean, 19> | FixedLengthArray<boolean, 20> | FixedLengthArray<boolean, 21> | FixedLengthArray<boolean, 23> | FixedLengthArray<boolean, 24> | null>;
export declare const calculateCompletionStatusAtom: (orbitEh: EntryHashB64, date: string) => Atom<boolean | FixedLengthArray<boolean, 2> | FixedLengthArray<boolean, 1> | FixedLengthArray<boolean, 22> | FixedLengthArray<boolean, 3> | FixedLengthArray<boolean, 4> | FixedLengthArray<boolean, 5> | FixedLengthArray<boolean, 6> | FixedLengthArray<boolean, 7> | FixedLengthArray<boolean, 8> | FixedLengthArray<boolean, 9> | FixedLengthArray<boolean, 10> | FixedLengthArray<boolean, 11> | FixedLengthArray<boolean, 12> | FixedLengthArray<boolean, 13> | FixedLengthArray<boolean, 14> | FixedLengthArray<boolean, 15> | FixedLengthArray<boolean, 16> | FixedLengthArray<boolean, 17> | FixedLengthArray<boolean, 18> | FixedLengthArray<boolean, 19> | FixedLengthArray<boolean, 20> | FixedLengthArray<boolean, 21> | FixedLengthArray<boolean, 23> | FixedLengthArray<boolean, 24> | null>;
export declare const calculateWinDataForNonLeafNodeAtom: (orbitEh: EntryHashB64) => Atom<WinDataPerOrbitNode | null>;
export declare const calculateCurrentStreakAtom: (orbitHash: ActionHashB64) => Atom<number | null>;
export declare const calculateLongestStreakAtom: (orbitHash: ActionHashB64) => Atom<number | null>;
//# sourceMappingURL=win.d.ts.map