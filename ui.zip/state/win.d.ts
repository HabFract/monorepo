import { ActionHashB64, EntryHashB64 } from "@holochain/client";
import { WinDataPerOrbitNode } from "./types";
export declare const setWinDataAtom: import("jotai").WritableAtom<null, [{
    orbitHash: ActionHashB64;
    date: string;
    winData: boolean | boolean[];
}], void> & {
    init: null;
};
export declare const winDataPerOrbitNodeAtom: (orbitHash: ActionHashB64) => import("jotai").WritableAtom<{
    [dayIndex: string]: boolean;
} | {
    [dayIndex: string]: import("./types").FixedLengthArray<boolean, 2>;
} | {
    [dayIndex: string]: import("./types").FixedLengthArray<boolean, 1>;
} | {
    [dayIndex: string]: import("./types").FixedLengthArray<boolean, 22>;
} | {
    [dayIndex: string]: import("./types").FixedLengthArray<boolean, 3>;
} | {
    [dayIndex: string]: import("./types").FixedLengthArray<boolean, 4>;
} | {
    [dayIndex: string]: import("./types").FixedLengthArray<boolean, 5>;
} | {
    [dayIndex: string]: import("./types").FixedLengthArray<boolean, 6>;
} | {
    [dayIndex: string]: import("./types").FixedLengthArray<boolean, 7>;
} | {
    [dayIndex: string]: import("./types").FixedLengthArray<boolean, 8>;
} | {
    [dayIndex: string]: import("./types").FixedLengthArray<boolean, 9>;
} | {
    [dayIndex: string]: import("./types").FixedLengthArray<boolean, 10>;
} | {
    [dayIndex: string]: import("./types").FixedLengthArray<boolean, 11>;
} | {
    [dayIndex: string]: import("./types").FixedLengthArray<boolean, 12>;
} | {
    [dayIndex: string]: import("./types").FixedLengthArray<boolean, 13>;
} | {
    [dayIndex: string]: import("./types").FixedLengthArray<boolean, 14>;
} | {
    [dayIndex: string]: import("./types").FixedLengthArray<boolean, 15>;
} | {
    [dayIndex: string]: import("./types").FixedLengthArray<boolean, 16>;
} | {
    [dayIndex: string]: import("./types").FixedLengthArray<boolean, 17>;
} | {
    [dayIndex: string]: import("./types").FixedLengthArray<boolean, 18>;
} | {
    [dayIndex: string]: import("./types").FixedLengthArray<boolean, 19>;
} | {
    [dayIndex: string]: import("./types").FixedLengthArray<boolean, 20>;
} | {
    [dayIndex: string]: import("./types").FixedLengthArray<boolean, 21>;
} | {
    [dayIndex: string]: import("./types").FixedLengthArray<boolean, 23>;
} | {
    [dayIndex: string]: import("./types").FixedLengthArray<boolean, 24>;
}, [winRecord: WinDataPerOrbitNode], void>;
export declare const getWinCompletionForOrbitForDayAtom: (orbitEh: EntryHashB64, date: string) => import("jotai").Atom<boolean | import("./types").FixedLengthArray<boolean, 2> | import("./types").FixedLengthArray<boolean, 1> | import("./types").FixedLengthArray<boolean, 22> | import("./types").FixedLengthArray<boolean, 3> | import("./types").FixedLengthArray<boolean, 4> | import("./types").FixedLengthArray<boolean, 5> | import("./types").FixedLengthArray<boolean, 6> | import("./types").FixedLengthArray<boolean, 7> | import("./types").FixedLengthArray<boolean, 8> | import("./types").FixedLengthArray<boolean, 9> | import("./types").FixedLengthArray<boolean, 10> | import("./types").FixedLengthArray<boolean, 11> | import("./types").FixedLengthArray<boolean, 12> | import("./types").FixedLengthArray<boolean, 13> | import("./types").FixedLengthArray<boolean, 14> | import("./types").FixedLengthArray<boolean, 15> | import("./types").FixedLengthArray<boolean, 16> | import("./types").FixedLengthArray<boolean, 17> | import("./types").FixedLengthArray<boolean, 18> | import("./types").FixedLengthArray<boolean, 19> | import("./types").FixedLengthArray<boolean, 20> | import("./types").FixedLengthArray<boolean, 21> | import("./types").FixedLengthArray<boolean, 23> | import("./types").FixedLengthArray<boolean, 24> | null>;
export declare const calculateCompletionStatusAtom: (orbitEh: EntryHashB64, date: string) => import("jotai").Atom<boolean | import("./types").FixedLengthArray<boolean, 2> | import("./types").FixedLengthArray<boolean, 1> | import("./types").FixedLengthArray<boolean, 22> | import("./types").FixedLengthArray<boolean, 3> | import("./types").FixedLengthArray<boolean, 4> | import("./types").FixedLengthArray<boolean, 5> | import("./types").FixedLengthArray<boolean, 6> | import("./types").FixedLengthArray<boolean, 7> | import("./types").FixedLengthArray<boolean, 8> | import("./types").FixedLengthArray<boolean, 9> | import("./types").FixedLengthArray<boolean, 10> | import("./types").FixedLengthArray<boolean, 11> | import("./types").FixedLengthArray<boolean, 12> | import("./types").FixedLengthArray<boolean, 13> | import("./types").FixedLengthArray<boolean, 14> | import("./types").FixedLengthArray<boolean, 15> | import("./types").FixedLengthArray<boolean, 16> | import("./types").FixedLengthArray<boolean, 17> | import("./types").FixedLengthArray<boolean, 18> | import("./types").FixedLengthArray<boolean, 19> | import("./types").FixedLengthArray<boolean, 20> | import("./types").FixedLengthArray<boolean, 21> | import("./types").FixedLengthArray<boolean, 23> | import("./types").FixedLengthArray<boolean, 24> | null>;
export declare const calculateCurrentStreakAtom: (orbitHash: ActionHashB64) => import("jotai").Atom<number | null>;
export declare const calculateLongestStreakAtom: (orbitHash: ActionHashB64) => import("jotai").Atom<number | null>;
//# sourceMappingURL=win.d.ts.map