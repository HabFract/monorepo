import { ActionHashB64, EntryHashB64 } from "@holochain/client";
import { CurrentOrbitId, RootOrbitEntryHash } from "./orbit";
import { Scale } from "../../graphql/generated";
export interface HierarchyBounds {
    minBreadth: number;
    maxBreadth: number;
    minDepth: number;
    maxDepth: number;
}
export type NodeContent = {
    content: EntryHashB64;
};
export interface SphereHierarchyBounds {
    [sphereId: EntryHashB64]: HierarchyBounds;
}
export type Coords = {
    x: number;
    y: number;
};
export type HierarchyTraversalIndices = Coords;
export interface Hierarchy {
    rootNode: RootOrbitEntryHash;
    json: string;
    bounds?: HierarchyBounds;
    indices?: HierarchyTraversalIndices;
    currentNode?: CurrentOrbitId;
    nodeHashes: Array<ActionHashB64>;
    leafNodeHashes: Array<ActionHashB64>;
}
export interface ConsolidatedFlags {
    canGoUp: boolean;
    canGoDown: boolean;
    canGoLeft: boolean;
    canGoRight: boolean;
}
export interface ConsolidatedActions {
    goLeft: () => void;
    goRight: () => void;
    goUp: () => void;
    goDown: () => void;
}
export interface OrbitDescendant {
    id: ActionHashB64;
    eH: EntryHashB64;
    orbitName: string;
    orbitScale: Scale;
}
//# sourceMappingURL=hierarchy.d.ts.map