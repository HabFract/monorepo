export interface StateStore<T extends string | number | symbol> {
    currentState: T;
    params: any;
    connection: Connection | null;
    history: Array<{
        state: T;
        params: any;
    }>;
}
export type StateTransitions<T extends string | number | symbol> = {
    [K in T]?: T[];
};
export interface Connection {
    apolloClient?: any;
    dnaConfig: any;
    conductorUri: any;
}
export declare class StateMachine<T extends string | number | symbol, S extends StateStore<T>> {
    state: S;
    transitions: StateTransitions<T>;
    private handlers;
    constructor(initialState: S, transitions: StateTransitions<T>);
    on(state: T, handler: (state: S) => void): this;
    to(newState: T, params?: any): void;
    back(): boolean;
}
//# sourceMappingURL=stateMachine.d.ts.map