export type EntryHashB64 = string;
export type ActionHashB64 = string;
export type ActionHash = Uint8Array;
export type CellId = [Uint8Array, Uint8Array];
export type HoloHash = Uint8Array;
//# sourceMappingURL=holochain.d.ts.map