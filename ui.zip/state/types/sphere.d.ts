import { ActionHashB64, EntryHashB64 } from "@state/types";
import { OrbitHashes, OrbitNodeDetails, RootOrbitEntryHash } from "./orbit";
export interface SphereDetails {
    entryHash: EntryHashB64;
    name?: string;
    description?: string;
    hashtag?: string;
    image?: string;
}
export type SphereOrbitNodes = {
    [key: ActionHashB64]: OrbitHashes;
};
export type SphereOrbitNodeDetails = {
    [key: EntryHashB64]: OrbitNodeDetails;
};
export type AllSphereOrbitNodeDetails = {
    [key: ActionHashB64]: SphereOrbitNodeDetails;
};
export type SphereEntry = {
    details: SphereDetails;
    hierarchyRootOrbitEntryHashes: RootOrbitEntryHash[];
};
export interface SphereHashes {
    entryHash?: EntryHashB64;
    actionHash?: ActionHashB64;
}
//# sourceMappingURL=sphere.d.ts.map