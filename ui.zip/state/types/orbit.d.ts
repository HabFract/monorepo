import { Scale } from "./../../graphql/generated/index";
import { ActionHashB64, EntryHashB64 } from "@state/types";
export type ObjectValues<T extends Record<string, unknown>> = T[keyof T];
export declare namespace Frequency {
    const LESS_THAN_DAILY: {
        readonly WEEKLY: 0.143;
        readonly MONTHLY: 0.032;
        readonly QUARTERLY: 0.011;
    };
    const ONE_SHOT = 0;
    const DAILY_OR_MORE: {
        readonly DAILY: 1;
        readonly TWO: 2;
        readonly THREE: 3;
        readonly FOUR: 4;
        readonly FIVE: 5;
        readonly SIX: 6;
        readonly SEVEN: 7;
        readonly EIGHT: 8;
        readonly NINE: 9;
        readonly TEN: 10;
        readonly ELEVEN: 11;
        readonly TWELVE: 12;
        readonly THIRTEEN: 13;
        readonly FOURTEEN: 14;
        readonly FIFTEEN: 15;
        readonly SIXTEEN: 16;
        readonly SEVENTEEN: 17;
        readonly EIGHTEEN: 18;
        readonly NINETEEN: 19;
        readonly TWENTY: 20;
        readonly TWENTY_ONE: 21;
        readonly TWENTY_TWO: 22;
        readonly TWENTY_THREE: 23;
        readonly HOURLY: 24;
    };
    type LessThanDailyIncrements = keyof typeof LESS_THAN_DAILY;
    type LessThanDailyRationalRepresentation = ObjectValues<typeof LESS_THAN_DAILY>;
    type DailyOrMoreIncrements = keyof typeof DAILY_OR_MORE;
    type DailyOrMoreRationalRepresentation = ObjectValues<typeof DAILY_OR_MORE>;
    type Rationals = LessThanDailyRationalRepresentation | DailyOrMoreRationalRepresentation | typeof ONE_SHOT;
}
export interface OrbitHashes {
    id: ActionHashB64;
    eH: EntryHashB64;
    sphereHash: EntryHashB64;
    childEh?: EntryHashB64;
    parentEh?: EntryHashB64;
}
export interface OrbitDetails extends OrbitHashes {
    name: string;
    scale: Scale;
    frequency: Frequency.Rationals;
    sphereHash: EntryHashB64;
    startTime?: number;
    endTime?: number;
    description?: string;
}
export interface OrbitNodeDetails extends OrbitDetails {
    path?: string;
}
export type RootOrbitEntryHash = EntryHashB64;
export type CurrentOrbitId = ActionHashB64;
//# sourceMappingURL=orbit.d.ts.map