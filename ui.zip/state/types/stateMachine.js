export class StateMachine {
    state;
    transitions;
    callbacks;
    constructor(init, transitions) {
        this.state = init;
        this.transitions = transitions;
    }
    to(state, params) {
        if (this.transitions[this.state.currentState].findIndex((nState) => state == nState) >= 0) {
            this.state.currentState = state;
            this.state.params = params;
            this.go();
        }
        else {
            const currState = this.state.currentState;
            console.warn(`Could not set state to ${String(state)} while at current state ${String(currState)}.`);
        }
    }
    on(state, callback) {
        if (!this.callbacks) {
            this.callbacks = {};
        }
        this.callbacks[state] = callback;
    }
    go() {
        setTimeout(() => {
            const currState = this.state.currentState;
            this.callbacks[currState](this.state);
        });
    }
}
//# sourceMappingURL=stateMachine.js.map