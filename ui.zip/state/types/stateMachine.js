export class StateMachine {
    state;
    transitions;
    handlers = new Map();
    constructor(initialState, transitions) {
        this.state = initialState;
        this.transitions = transitions;
    }
    on(state, handler) {
        this.handlers.set(state, handler);
        return this;
    }
    to(newState, params = {}) {
        if (this.state.currentState) {
            this.state.history = [
                { state: this.state.currentState, params: this.state.params },
                ...(this.state.history || [])
            ].slice(0, 3);
        }
        this.state.currentState = newState;
        this.state.params = params;
        const handler = this.handlers.get(newState);
        if (handler) {
            handler(this.state);
        }
    }
    back() {
        if (this.state.history?.length > 0) {
            const [previousState, ...remainingHistory] = this.state.history;
            this.state.currentState = previousState.state;
            this.state.params = previousState.params;
            this.state.history = remainingHistory;
            const handler = this.handlers.get(previousState.state);
            if (handler) {
                handler(this.state);
            }
            return true;
        }
        return false;
    }
}
//# sourceMappingURL=stateMachine.js.map