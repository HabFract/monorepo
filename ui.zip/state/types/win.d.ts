import { ActionHashB64 } from "@state/types";
import { Frequency, OrbitNodeDetails } from "./orbit";
export type FixedLengthArray<T, L extends number> = [T, ...T[]] & {
    length: L;
};
export type WinData<F extends Frequency.Rationals> = F extends Frequency.DailyOrMoreRationalRepresentation ? {
    [dayIndex: string]: FixedLengthArray<boolean, F>;
} : {
    [dayIndex: string]: boolean;
};
export type WinDataPerOrbitNode = {
    [nodeId: ActionHashB64]: WinData<OrbitNodeDetails["frequency"]>;
};
export default WinDataPerOrbitNode;
//# sourceMappingURL=win.d.ts.map