export var Frequency;
(function (Frequency) {
    Frequency.LESS_THAN_DAILY = {
        WEEKLY: 0.143,
        MONTHLY: 0.032,
        QUARTERLY: 0.011,
    };
    Frequency.DAILY_OR_MORE = {
        DAILY: 1.000,
        TWO: 2.000,
        THREE: 3.000,
        FOUR: 4.000,
        FIVE: 5.000,
        SIX: 6.000,
        SEVEN: 7.000,
        EIGHT: 8.000,
        NINE: 9.000,
        TEN: 10.000,
        ELEVEN: 11.000,
        TWELVE: 12.000,
        THIRTEEN: 13.000,
        FOURTEEN: 14.000,
        FIFTEEN: 15.000,
        SIXTEEN: 16.000,
        SEVENTEEN: 17.000,
        EIGHTEEN: 18.000,
        NINETEEN: 19.000,
        TWENTY: 20.000,
        TWENTY_ONE: 21.000,
        TWENTY_TWO: 22.000,
        TWENTY_THREE: 23.000,
        HOURLY: 24.000,
    };
})(Frequency || (Frequency = {}));
//# sourceMappingURL=orbit.js.map