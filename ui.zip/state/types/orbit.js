export var Frequency;
(function (Frequency) {
    Frequency.LESS_THAN_DAILY = {
        WEEKLY: 0.143,
        MONTHLY: 0.032,
        QUARTERLY: 0.011,
    };
    Frequency.ONE_SHOT = 0;
    Frequency.DAILY_OR_MORE = {
        DAILY: 1.0,
        TWO: 2.0,
        THREE: 3.0,
        FOUR: 4.0,
        FIVE: 5.0,
        SIX: 6.0,
        SEVEN: 7.0,
        EIGHT: 8.0,
        NINE: 9.0,
        TEN: 10.0,
        ELEVEN: 11.0,
        TWELVE: 12.0,
        THIRTEEN: 13.0,
        FOURTEEN: 14.0,
        FIFTEEN: 15.0,
        SIXTEEN: 16.0,
        SEVENTEEN: 17.0,
        EIGHTEEN: 18.0,
        NINETEEN: 19.0,
        TWENTY: 20.0,
        TWENTY_ONE: 21.0,
        TWENTY_TWO: 22.0,
        TWENTY_THREE: 23.0,
        HOURLY: 24.0,
    };
})(Frequency || (Frequency = {}));
//# sourceMappingURL=orbit.js.map