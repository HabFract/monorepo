export declare const APP_WS_PORT: string;
export declare const ADMIN_WS_PORT: any;
export declare const NODE_ENV: any;
export declare const HAPP_ID = "habit_fract";
export declare const HAPP_DNA_NAME = "habits";
export declare const HAPP_ZOME_NAME_PERSONAL_HABITS = "personal";
export declare const HAPP_ZOME_NAME_PROFILES = "profiles";
export declare const ALPHA_RELEASE_DISCLAIMER = "Thank you for being an early tester of this app.\n\nThis is an alpha release, meaning, the software is still in the early stages and will sometimes behave weirdly!\n\nSome features are disabled/still being updated. \n\nIf you experience any problems, the best course of action is to reload the app. You can submit feedback or bug reports from the settings menu. Have fun!";
export declare const MODEL_DISPLAY_VALUES: {
    sphere: string;
    hierarchy: string;
    orbit: string;
    winRecord: string;
    astro: string;
    sub: string;
    atom: string;
};
export declare const INPUT_INFO_MODALS: {
    password: {
        placeholder: string;
        title: string;
        body: string;
        footer: string;
    };
    scales: {
        title: string;
        body: string;
        footer: string;
    };
    "planitt-name": {
        title: string;
        body: string;
        footer: string;
    };
};
export declare const ONBOARDING_FORM_TITLES: string[];
export declare const ONBOARDING_FORM_DESCRIPTIONS: string[];
export declare const ERROR_MESSAGES: {
    "password-empty": string;
    "password-short": string;
    "password-long": string;
    "sphere-name-empty": string;
    "sphere-description-short": string;
    "orbit-name-empty": string;
    "orbit-name-short": string;
    "orbit-name-long": string;
    "orbit-name-letters": string;
    "orbit-description-letters": string;
    "orbit-start-required": string;
};
export declare const PAGE_COPY: {
    slogan: string;
    "password-notice": string;
};
export declare const BUTTON_ACTION_TEXT: {
    "positive-spin-cta": string;
    "negative-spin-cta": string;
};
//# sourceMappingURL=constants.d.ts.map