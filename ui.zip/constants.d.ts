export declare const APP_WS_PORT: string;
export declare const ADMIN_WS_PORT: any;
export declare const NODE_ENV: any;
export declare const HAPP_ID = "habit_fract";
export declare const HAPP_DNA_NAME = "habits";
export declare const HAPP_ZOME_NAME_PERSONAL_HABITS = "personal";
export declare const HAPP_ZOME_NAME_PROFILES = "profiles";
export declare const ALPHA_RELEASE_DISCLAIMER = "Thank you for being an early tester of this app.\n\nThis is an alpha release, meaning, the software is still in the early stages and will sometimes behave weirdly!\n\nSome features are disabled/still being updated. \n\nIf you experience any problems, the best course of action is to reload the app. You can submit feedback or bug reports from the settings menu. Have fun!";
export declare const MODEL_DISPLAY_VALUES: {
    sphere: string;
    hierarchy: string;
    orbit: string;
    winRecord: string;
    astro: string;
    sub: string;
    atom: string;
};
export declare const ONBOARDING_FORM_TITLES: string[];
export declare const ONBOARDING_FORM_DESCRIPTIONS: string[];
//# sourceMappingURL=constants.d.ts.map