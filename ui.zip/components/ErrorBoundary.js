import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
import React, { useEffect } from 'react';
import { useToast } from '../contexts/toast';
import { Collapse } from 'antd';
import { Button } from 'habit-fract-design-system';
const ErrorToast = ({ error }) => {
    const { showToast } = useToast();
    useEffect(() => {
        showToast(`An error occurred: ${error.message}`, {
            actionButton: _jsx(Collapse, { size: "small", items: [{ key: '1', label: _jsx(Button, { type: "button", variant: "primary", onClick: () => console.log(error.stack), children: "Show Details" }), children: _jsx("p", { children: error.stack }) }] })
        });
    }, [error]);
    return null;
};
class ErrorBoundary extends React.Component {
    constructor(props) {
        super(props);
        this.state = { hasError: false, error: null };
    }
    static getDerivedStateFromError(error) {
        return { hasError: true, error };
    }
    componentDidCatch(error, errorInfo) {
        console.error("Caught an error:", error, errorInfo);
    }
    render() {
        if (this.state.hasError && this.state.error) {
            return (_jsxs(_Fragment, { children: [_jsx(ErrorToast, { error: this.state.error }), this.props.fallback] }));
        }
        return this.props.children;
    }
}
export default ErrorBoundary;
//# sourceMappingURL=ErrorBoundary.js.map