import { jsx as _jsx } from "react/jsx-runtime";
import React, { useCallback, useEffect, useState, useMemo, useRef } from "react";
import { useStateTransition } from "../hooks/useStateTransition";
import { GetOrbitsDocument, useGetSpheresQuery, } from "../graphql/generated";
import { extractEdges } from "../graphql/utils";
import { appStateAtom, nodeCache, store } from "../state/store";
import { mapToCacheObject } from "../state/orbit";
import { client } from "../graphql/client";
import { currentSphereHashesAtom } from "../state/sphere";
import { useSetAtom } from "jotai";
import { updateAppStateWithOrbit } from "../hooks/gql/utils";
import { sleep } from "./lists/OrbitSubdivisionList";
import { Spinner } from "habit-fract-design-system";
export class DataLoadingQueue {
    queue = [];
    isProcessing = false;
    enqueue(task) {
        return new Promise((resolve, reject) => {
            this.queue.push(async () => {
                try {
                    await task();
                    resolve();
                }
                catch (error) {
                    reject(error);
                }
            });
            if (!this.isProcessing) {
                this.processQueue();
            }
        });
    }
    async processQueue() {
        if (this.isProcessing)
            return;
        this.isProcessing = true;
        while (this.queue.length > 0) {
            const task = this.queue.shift();
            if (task) {
                await task();
            }
        }
        this.isProcessing = false;
    }
}
const PreloadAllData = ({ landingSphereEh, landingSphereId, landingPage, onPreloadComplete }) => {
    const [_, transition] = useStateTransition();
    const [preloadCompleted, setPreloadCompleted] = useState(false);
    const transitionInitiatedRef = useRef(false);
    const setAppState = useSetAtom(appStateAtom);
    const setNodeCache = useSetAtom(nodeCache.set);
    const setCurentSphere = useSetAtom(currentSphereHashesAtom);
    const { loading: loadingSpheres, error, data, } = useGetSpheresQuery({
        fetchPolicy: 'network-only',
    });
    const sphereNodes = useMemo(() => data ? extractEdges(data.spheres) : [], [data]);
    const dataLoadingQueue = useMemo(() => new DataLoadingQueue(), []);
    const fetchDataRef = useRef(false);
    const fetchData = useCallback(async () => {
        if (fetchDataRef.current)
            return;
        fetchDataRef.current = true;
        if (sphereNodes.length === 0) {
            setPreloadCompleted(true);
            return;
        }
        try {
            for (const { id, eH, name } of sphereNodes) {
                await dataLoadingQueue.enqueue(async () => {
                    const variables = { sphereEntryHashB64: eH };
                    const gql = await client;
                    const data = gql && (await gql.query({
                        query: GetOrbitsDocument,
                        variables,
                        fetchPolicy: "network-only",
                    }));
                    if (data && data?.data?.orbits) {
                        const orbits = extractEdges(data.data.orbits);
                        const indexedOrbitNodeDetails = Object.entries(orbits.map(mapToCacheObject)).map(([_idx, value]) => [value.eH, value]);
                        const orbitHashes = Object.entries(orbits.map(mapToCacheObject)).map(([_idx, value]) => ({
                            id: value.id,
                            eH: value.eH,
                            sphereHash: value.sphereHash,
                            childEh: value?.childEh,
                            parentEh: value?.parentEh,
                        }));
                        setNodeCache(id, Object.fromEntries(indexedOrbitNodeDetails));
                        const prevState = store.get(appStateAtom);
                        let updatedState = { ...prevState };
                        orbitHashes.sort((hashesA, hashesB) => {
                            return +((!!hashesB?.parentEh)) - (+(!!hashesA?.parentEh));
                        }).forEach(orbitHashes => {
                            updatedState = updateAppStateWithOrbit(updatedState, orbitHashes, true);
                        });
                        updatedState.spheres = {
                            ...updatedState.spheres,
                            currentSphereHash: id,
                            byHash: {
                                ...updatedState.spheres.byHash,
                                [id]: {
                                    ...updatedState.spheres.byHash[id],
                                    details: {
                                        ...updatedState.spheres.byHash[id]?.details,
                                        entryHash: eH,
                                        name: name
                                    },
                                    hierarchyRootOrbitEntryHashes: orbitHashes
                                        .filter(hashes => typeof hashes.parentEh == 'undefined')
                                        .reduce((acc, hashes) => {
                                        !acc.includes(hashes.eH) && acc.push(hashes.eH);
                                        return acc;
                                    }, []),
                                },
                            },
                        };
                        console.log('New app state:', updatedState);
                        setAppState(updatedState);
                        setCurentSphere({
                            actionHash: landingSphereId || id,
                            entryHash: landingSphereEh || eH,
                        });
                    }
                    await sleep(250);
                });
            }
            await dataLoadingQueue.enqueue(async () => {
                await sleep(500);
                setPreloadCompleted(true);
            });
        }
        catch (error) {
            console.error("Error in fetchData:", error);
        }
        finally {
            setPreloadCompleted(true);
            fetchDataRef.current = false;
        }
    }, [sphereNodes, dataLoadingQueue, setAppState, setNodeCache, setCurentSphere, landingSphereEh, landingSphereId]);
    useEffect(() => {
        if (loadingSpheres) {
            return;
        }
        if (error) {
            console.error('Error loading spheres:', error);
            setPreloadCompleted(true);
            return;
        }
        if (!data || sphereNodes.length === 0) {
            setPreloadCompleted(true);
            return;
        }
        if (!fetchDataRef.current) {
            fetchData();
        }
    }, [data, sphereNodes, loadingSpheres, error, fetchData]);
    useEffect(() => {
        if (!preloadCompleted || transitionInitiatedRef.current)
            return;
        if (onPreloadComplete) {
            onPreloadComplete();
        }
        else {
            transitionInitiatedRef.current = true;
            dataLoadingQueue.enqueue(async () => {
                transition(landingPage || "Vis", { currentSphereDetails: sphereNodes[0] || undefined });
            });
        }
    }, [preloadCompleted, dataLoadingQueue, transition, landingPage, sphereNodes, onPreloadComplete]);
    if (loadingSpheres) {
        return _jsx(Spinner, { "aria-label": "Loading spheres!" });
    }
    if (error) {
        return _jsx("div", { children: "Error loading data. Please try again." });
    }
    if (!data || sphereNodes.length === 0) {
        return _jsx("div", { children: "No spheres available. Please create a sphere first." });
    }
    return _jsx(Spinner, { "aria-label": "Loading!" });
};
export default React.memo(PreloadAllData, (prevProps, nextProps) => {
    return prevProps.landingSphereEh === nextProps.landingSphereEh &&
        prevProps.landingSphereId === nextProps.landingSphereId &&
        prevProps.landingPage === nextProps.landingPage;
});
//# sourceMappingURL=PreloadAllData.js.map