import { jsx as _jsx } from "react/jsx-runtime";
import "../App.css";
import React, { useCallback, useEffect, useState } from "react";
import { useStateTransition } from "../hooks/useStateTransition";
import { GetOrbitsDocument, useGetSpheresQuery, } from "../graphql/generated";
import { extractEdges, serializeAsyncActions } from "../graphql/utils";
import { appStateAtom, nodeCache, store } from "../state/store";
import { mapToCacheObject } from "../state/orbit";
import { client } from "../graphql/client";
import { currentSphereHashesAtom } from "../state/sphere";
import { Spinner } from "flowbite-react";
import { debounce } from "./vis/helpers";
import { useAtom, useSetAtom } from "jotai";
import { updateAppStateWithOrbit } from "../hooks/gql/utils";
import { sleep } from "./lists/OrbitSubdivisionList";
const PreloadAllData = ({ landingSphereEh, landingSphereId, onPreloadComplete }) => {
    const [_, transition] = useStateTransition();
    const [preloadCompleted, setPreloadCompleted] = useState(false);
    const [prevState, setAppState] = useAtom(appStateAtom);
    const setNodeCache = useSetAtom(nodeCache.set);
    const setCurentSphere = useSetAtom(currentSphereHashesAtom);
    const { loading: loadingSpheres, error, data, } = useGetSpheresQuery();
    const sphereNodes = data ? extractEdges(data.spheres) : [];
    const id = sphereNodes?.[0]?.id;
    const eH = sphereNodes?.[0]?.eH;
    const fetchData = useCallback(() => {
        try {
            serializeAsyncActions([
                ...sphereNodes.map(({ id, eH, name }) => async () => {
                    const variables = { sphereEntryHashB64: eH };
                    let data;
                    try {
                        const gql = await client;
                        data =
                            gql &&
                                (await gql.query({
                                    query: GetOrbitsDocument,
                                    variables,
                                    fetchPolicy: "network-only",
                                }));
                        if (data?.data?.orbits) {
                            const orbits = extractEdges(data.data.orbits);
                            const indexedOrbitNodeDetails = Object.entries(orbits.map(mapToCacheObject)).map(([_idx, value]) => [value.eH, value]);
                            const orbitHashes = Object.entries(orbits.map(mapToCacheObject)).map(([_idx, value]) => ({
                                id: value.id,
                                eH: value.eH,
                                sphereHash: value.sphereHash,
                                childEh: value?.childEh,
                                parentEh: value?.parentEh,
                            }));
                            setNodeCache(id, Object.fromEntries(indexedOrbitNodeDetails));
                            let updatedState = prevState;
                            orbitHashes.sort((hashesA, hashesB) => {
                                return +((!!hashesB?.parentEh)) - (+(!!hashesA?.parentEh));
                            }).forEach(orbitHashes => {
                                updatedState = updateAppStateWithOrbit(updatedState, orbitHashes, true);
                            });
                            updatedState.spheres = {
                                ...updatedState.spheres,
                                currentSphereHash: id,
                                byHash: {
                                    ...prevState.spheres.byHash,
                                    [id]: {
                                        details: {
                                            entryHash: eH,
                                            name
                                        },
                                        hierarchyRootOrbitEntryHashes: orbitHashes.filter(hashes => typeof hashes.parentEh == 'undefined').reduce((acc, hashes) => { !acc.includes(hashes.eH) && acc.push(hashes.eH); return acc; }, []),
                                    },
                                },
                            };
                            setAppState(updatedState);
                            sleep(100);
                            setCurentSphere({
                                actionHash: landingSphereId || id,
                                entryHash: landingSphereEh || eH,
                            });
                        }
                    }
                    catch (error) {
                        console.error(error);
                        return Promise.reject();
                    }
                }),
                async () => {
                    await sleep(100);
                    await setPreloadCompleted(true);
                    return Promise.resolve(console.log("Current cache: :>> ", store.get(nodeCache.entries)));
                },
            ]);
        }
        catch (error) {
            console.error(error);
            return Promise.reject();
        }
        return Promise.resolve(sleep(100));
    }, [sphereNodes]);
    const debouncedFetchData = debounce(fetchData, 3000);
    useEffect(() => {
        if (!data)
            return;
        if (data && !sphereNodes.length) {
            if (!preloadCompleted && onPreloadComplete) {
                console.log('No data preload was needed...');
                setPreloadCompleted(true);
                onPreloadComplete();
            }
            return;
        }
        debouncedFetchData();
    }, [sphereNodes, onPreloadComplete, data, fetchData, landingSphereEh, landingSphereId]);
    useEffect(() => {
        if (!preloadCompleted)
            return;
        console.log('preloadCompleted :>> ', preloadCompleted);
        if (onPreloadComplete) {
            onPreloadComplete();
        }
        else {
            transition("Vis");
        }
    }, [preloadCompleted]);
    return _jsx(Spinner, { "aria-label": "Loading!", size: "xl", className: "full-spinner" });
};
export default React.memo(PreloadAllData);
//# sourceMappingURL=PreloadAllData.js.map