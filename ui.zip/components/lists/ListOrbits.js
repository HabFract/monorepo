import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import "./common.css";
import PageHeader from "../header/PageHeader";
import ListSortFilter from "./ListSortFilter";
import { OrbitCard, SphereCard } from "habit-fract-design-system";
import { useDeleteOrbitMutation } from "../../graphql/generated";
import { useStateTransition } from "../../hooks/useStateTransition";
import { useFetchAndCacheSphereOrbits } from "../../hooks/useFetchAndCacheSphereOrbits";
import { useSortedOrbits } from "../../hooks/useSortedOrbits";
import { Spinner } from "flowbite-react";
import { useToast } from "../../contexts/toast";
import { sphereHasCachedNodesAtom, store } from "../../state";
const ListOrbits = ({ sphereAh, }) => {
    const [_state, transition] = useStateTransition();
    const { showToast, hideToast } = useToast();
    const [runDelete, { loading: loadingDelete, error: errorDelete, data: dataDelete },] = useDeleteOrbitMutation({
        refetchQueries: ["getOrbits"],
    });
    const { loading: loadingOrbits, error, data, } = useFetchAndCacheSphereOrbits({ sphereAh });
    const sortedOrbits = useSortedOrbits(data?.orbits);
    const loading = !sphereAh || loadingOrbits;
    if (loading)
        return _jsx(Spinner, { "aria-label": "Loading!", className: "full-spinner", size: "xl" });
    if (error)
        return _jsxs("p", { children: ["Error : ", error.message] });
    return (_jsxs("div", { className: "layout orbits", children: [_jsx(PageHeader, { title: "Orbit Breakdown " }), data?.sphere && (_jsx(SphereCard, { sphere: data.sphere, isHeader: true, transition: transition, orbitScales: data.orbits.map((orbit) => orbit?.scale), showToast: showToast, hasCachedNodes: store.get(sphereHasCachedNodesAtom(data?.sphere.id)) })), _jsx(ListSortFilter, { label: "" }), _jsx("div", { className: "orbits-list", children: sortedOrbits.map((orbit) => (_jsx(OrbitCard, { sphereEh: data.sphere.eH, transition: transition, orbit: orbit, runDelete: () => runDelete({ variables: { id: orbit.id } }) }, orbit.id))) })] }));
};
export default ListOrbits;
//# sourceMappingURL=ListOrbits.js.map