import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useMemo } from "react";
import "./common.css";
import { PlanittCard, ListSortFilter, Button, getIconSvg, Spinner } from "habit-fract-design-system";
import { useDeleteOrbitMutation, useGetOrbitsQuery } from "../../graphql/generated";
import { useSearchableList } from "../../hooks/useSearchableList";
import { extractEdges } from "../../graphql/utils";
import { useStateTransition } from "../../hooks/useStateTransition";
import { currentSphereDetailsAtom, store } from "../../state";
import { useModal } from "../../contexts/modal";
import { calculateCurrentStreakAtom, calculateLongestStreakAtom } from "../../state/win";
const ListOrbits = () => {
    const [state, transition, params] = useStateTransition();
    const { showModal } = useModal();
    const currentSphereDetails = store.get(currentSphereDetailsAtom);
    const { loading, error, data } = useGetOrbitsQuery({
        fetchPolicy: "network-only",
        variables: { sphereEntryHashB64: currentSphereDetails.entryHash }
    });
    const [runDelete] = useDeleteOrbitMutation({
        refetchQueries: ["getOrbits"],
    });
    const handleEditPlanitt = (orbit) => {
        transition("CreateOrbit", { sphereEh: orbit.eH, orbitToEditId: orbit?.id, editMode: true });
    };
    const handleDeletePlanitt = (orbit) => {
        showModal({
            title: "Are you sure?",
            message: "This action cannot be undone! This will also delete your Win history for this Planitt",
            onConfirm: () => {
                runDelete({ variables: { id: orbit.id } });
            },
            withCancel: true,
            withConfirm: true,
            destructive: true,
            confirmText: "Yes, do it",
            cancelText: "Cancel"
        });
    };
    const orbits = useMemo(() => {
        if (!data?.orbits)
            return [];
        return extractEdges(data.orbits);
    }, [data]);
    const { filteredItems: sortedOrbits, searchTerm, setSearchTerm, sortKey, setSortKey, sortOrder, toggleSortOrder } = useSearchableList({
        items: orbits,
        searchKeys: ['name', 'scale'],
        initialSortKey: 'name'
    });
    if (loading)
        return _jsx(Spinner, {});
    if (error)
        return _jsxs("p", { children: ["Error: ", error.message] });
    function routeToCreateOrbit() {
        transition("CreateOrbit", { sphereEh: currentSphereDetails.entryHash });
    }
    function routeToVis() {
        transition("Vis", { currentSphereDetails });
    }
    return (_jsxs("section", { className: "orbits-list", children: [_jsx(ListSortFilter, { searchTerm: searchTerm, onSearchChange: setSearchTerm, sortKey: sortKey, onSortKeyChange: setSortKey, sortOrder: sortOrder, onSortOrderChange: toggleSortOrder }), _jsxs(_Fragment, { children: [_jsx(Button, { onClick: routeToVis, isDisabled: sortedOrbits?.length == 0, type: "button", variant: "primary responsive", children: _jsxs(_Fragment, { children: [_jsx("span", { className: "w-6 h-6 mt-2", children: getIconSvg("tree-vis")({}) }), _jsx("span", { className: "block ml-4", children: "Visualise" })] }) }), _jsx(Button, { onClick: routeToCreateOrbit, type: "button", variant: "primary responsive", children: _jsxs(_Fragment, { children: [_jsx("span", { className: "w-auto h-auto", children: getIconSvg("plus")({}) }), _jsx("span", { className: "block ml-4", children: "Add Planitt" })] }) }), _jsx("div", { className: "orbits", children: sortedOrbits?.length > 0 ?
                            sortedOrbits.map((orbit) => (_jsx(PlanittCard, { currentStreak: store.get(calculateCurrentStreakAtom(orbit.id)), longestStreak: store.get(calculateLongestStreakAtom(orbit.id)), lastTrackedWinDate: "12/21/2023", orbit: orbit, handleEditPlanitt: () => handleEditPlanitt(orbit), runDelete: () => handleDeletePlanitt(orbit) }, orbit.id))) : _jsxs("div", { className: "warning-message flex flex-col items-center justify-center w-full h-full gap-4 pb-48", children: [_jsx("img", { className: "mb-2", src: "assets/icons/warning-icon.svg", alt: "warning icon" }), _jsxs("h1", { children: ["There are no Planitts", _jsx("br", {}), " in this System"] }), _jsx("h2", { children: "Add a Planitt to start tracking your behaviour" })] }) })] })] }));
};
export default ListOrbits;
//# sourceMappingURL=ListOrbits.js.map