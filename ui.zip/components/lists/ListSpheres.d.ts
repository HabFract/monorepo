import "./common.css";
export type nonLeafCompletionCalculationContext = {
    useRootFrequency: boolean;
    leafDescendants: number | undefined;
};
declare function ListSpheres(): import("react/jsx-runtime").JSX.Element;
export default ListSpheres;
//# sourceMappingURL=ListSpheres.d.ts.map