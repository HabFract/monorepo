import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { Field, Form, Formik, FieldArray } from 'formik';
import './common.css';
import * as Yup from 'yup';
import { Button, HelperText, TextInputField, SelectInputField, getIconForPlanetValue } from 'habit-fract-design-system';
import Split from '../icons/Split';
import Pencil from '../icons/Pencil';
import { MinusCircleFilled, PlusCircleFilled } from '@ant-design/icons';
import { useState } from 'react';
import { Frequency, Scale, useUpdateOrbitMutation } from '../../graphql/generated';
import { getDisplayName } from '../forms/CreateOrbit';
import { useCreateOrbitMutation } from '../../hooks/gql/useCreateOrbitMutation';
import { Label } from 'flowbite-react';
import { serializeAsyncActions } from '../../graphql/utils';
import { store } from '../../state/jotaiKeyValueStore';
import { Refinement } from '../forms/RefineOrbit';
import { OrbitFetcher } from '../forms/utils';
import { isSmallScreen } from '../vis/helpers';
import { currentSphereHashesAtom } from '../../state/sphere';
export const sleep = (ms) => new Promise((r) => setTimeout(() => r(null), ms));
const OrbitSubdivisionList = ({ submitBtn, refinementType, currentOrbitValues: { scale: currentScale, eH: currentHash, id } }) => {
    const ListValidationSchema = Yup.object().shape({
        list: Yup.array().of(Yup.object().shape({
            name: Yup.string()
                .matches(/(?!^\d+$)^.+$/, 'Name must contain letters.')
                .min(3, 'Must be 4 characters or more')
                .max(55, 'Must be 55 characters or less')
                .required('Required'),
        })),
        scale: Yup.mixed()
            .oneOf(Object.values(Scale))
            .required('Choose a scale'),
    });
    const [addOrbit] = useCreateOrbitMutation({});
    const [updateOrbit] = useUpdateOrbitMutation({});
    const [submitRefineBtnIsLoading, setSubmitRefineBtnIsLoading] = useState(false);
    return (_jsx("div", { className: 'layout orbit-subdivision-list', children: _jsx(Formik, { initialValues: refinementType == Refinement.Update ? { name: "" } : { list: [{ name: "" }], scale: Scale.Atom }, validationSchema: ListValidationSchema, onSubmit: async (values, { setSubmitting }) => {
                setSubmitting(false);
                delete values.childHash;
                const sphere = store.get(currentSphereHashesAtom);
                if (!sphere?.entryHash || !currentHash)
                    throw new Error("No sphere set or parent hash, cannot refine orbits");
                setSubmitRefineBtnIsLoading(true);
                try {
                    if (refinementType == Refinement.Update) {
                        await updateOrbit({ variables: { orbitFields: {
                                    name: values.name,
                                    id: values.id,
                                    startTime: values.startTime,
                                    endTime: values.endTime,
                                    frequency: values.frequency,
                                    scale: values.scale,
                                    parentHash: values.parentHash,
                                    sphereHash: sphere?.entryHash,
                                } } });
                        submitBtn.props.onClick.call(null);
                    }
                    else {
                        const { list, scale } = values;
                        serializeAsyncActions([
                            ...list.map((orbit) => async () => {
                                addOrbit({ variables: { variables: { name: orbit.name, scale, frequency: Frequency.Day, startTime: +(new Date()), sphereHash: sphere.entryHash, parentHash: currentHash } } });
                                await sleep(500);
                            }),
                            async () => Promise.resolve(console.log('New orbit subdivisions created! :>> ')),
                            async () => (submitBtn.props).onClick.call(null)
                        ]);
                    }
                }
                catch (error) {
                    setSubmitRefineBtnIsLoading(false);
                    console.error(error);
                }
            }, children: ({ values, errors, submitForm }) => {
                const refineTitle = refinementType == Refinement.Update ? "Refine Atomic Orbit Name" : "Break Up High Scale Orbits";
                const refineMessage = refinementType == Refinement.Update
                    ? "Since you have chosen the Atomic scale for your Orbit, it's best to make sure it is named in a way that is an <em>incremental action</em> - one that is quantifiable and achievable:"
                    : "Since you have chosen a big scale for your Orbit (shooting for the stars!) you can now break it up into smaller actions - so start by subdividing into Orbits of a smaller scale.";
                return (_jsxs(_Fragment, { children: [refinementType == Refinement.Update && _jsx(OrbitFetcher, { orbitToEditId: id }), _jsx(HelperText, { title: refineTitle, titleIcon: refinementType == Refinement.Update ? _jsx(Pencil, {}) : _jsx(Split, {}), withInfo: isSmallScreen(), onClickInfo: () => ({ title: refineTitle, body: refineMessage }), children: !isSmallScreen() && (refinementType == Refinement.Update
                                ? _jsxs("span", { children: ["Since you have chosen the Atomic scale for your Orbit, it's best to make sure it is named in a way that is an ", _jsx("em", { children: "incremental action" }), " - one that is quantifiable and achievable:"] })
                                : _jsxs("span", { children: ["Since you have chosen a big scale for your Orbit (shooting for the stars!) you can now ", _jsx("em", { children: "break it up" }), " into ", _jsx("em", { children: "smaller actions" }), " - so start by ", _jsx("em", { children: "subdividing" }), " into Orbits of a smaller scale."] })) }), !isSmallScreen() && refinementType == Refinement.Split && values.scale == Scale.Atom && RenamingHelperText(), _jsxs(Form, { noValidate: true, style: { gridColumn: "-2/-1", gridRow: "1/-1", }, children: [_jsx("div", { className: "flex flex-col gap-2 md:gap-4", children: refinementType == Refinement.Update
                                        ? _jsx(Field, { component: TextInputField, size: "base", name: "name", id: "atomic-name", icon: "tag", value: values.name, iconSide: "left", withInfo: false, required: true, labelValue: "Refined Name:", placeholder: "E.g. Run for 10 minutes" })
                                        : _jsxs(_Fragment, { children: [_jsx(Field, { component: SelectInputField, size: "base", name: "scale", id: "scale", icon: getIconForPlanetValue(values.scale), iconSide: "left", withInfo: false, options: chooseLowerScales(currentScale)?.sort((a, b) => a - b).map((scale) => {
                                                        return _jsx("option", { value: scale, children: getDisplayName(scale) }, scale);
                                                    }), required: true, labelValue: "Scale for New Orbits:" }), isSmallScreen() && refinementType == Refinement.Split && values.scale == Scale.Atom && RenamingHelperText(), _jsxs(Label, { htmlFor: 'list', children: ["New Orbit Names: ", _jsx("span", { className: "reqd", children: "*" })] }), _jsx(FieldArray, { name: "list", render: arrayHelpers => (_jsxs(_Fragment, { children: [values.list.map((item, index) => (_jsxs("div", { className: "flex gap-2", children: [_jsx(Field, { component: TextInputField, size: "base", name: `list[${index}].name`, value: item.name, id: `list[${index}].name`, icon: index == values.list.length - 1 ? "pencil" : "save", iconSide: "right", withInfo: false, required: false, isListItem: true, labelValue: `${index + 1}: `, placeholder: "E.g. Run for 10 minutes" }), _jsx("button", { style: { opacity: index > 0 ? 1 : 0 }, className: "flex flex-1 text-danger w-full flex justify-center hover:text-danger-500", type: "button", onClick: () => arrayHelpers.remove(index), children: _jsx(MinusCircleFilled, {}) })] }, index))), errors.list && _jsx(Label, { className: 'my-1 text-warn', children: "All names must be a valid length" }), values.list.length <= 3 && _jsx("button", { className: "flex flex-1 text-link w-8 mx-auto flex justify-center hover:text-primary", type: "button", onClick: () => arrayHelpers.push({ name: "" }), disabled: values.list.length >= 4, children: _jsx(PlusCircleFilled, {}) })] })) })] }) }), _jsx("span", { children: _jsx(Button, { type: 'onboarding', loading: submitRefineBtnIsLoading, onClick: () => submitForm(), children: refinementType == Refinement.Update ? "Update Name" : "Create Orbits" }) }), " "] })] }));
            } }) }));
};
export default OrbitSubdivisionList;
function RenamingHelperText() {
    return _jsx(HelperText, { title: "Refine Atomic Orbit Names", titleIcon: _jsx(Pencil, {}), withInfo: false, children: _jsxs("span", { children: ["Since you have chosen the Atomic scale for your new Orbits, it's best to make sure they are named in a way that is an ", _jsx("em", { children: "incremental action" }), " - one that is quantifiable and achievable."] }) });
}
function chooseLowerScales(scale) {
    switch (scale) {
        case Scale.Astro:
            return [Scale.Sub, Scale.Atom];
        case Scale.Sub:
            return [Scale.Atom];
        case Scale.Atom:
            return [];
        default:
            return [];
    }
}
//# sourceMappingURL=OrbitSubdivisionList.js.map