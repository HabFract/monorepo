import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useGetSpheresQuery, } from "../../graphql/generated";
import "./common.css";
import { Spinner, SystemCalendarCard } from "habit-fract-design-system";
import { extractEdges } from "../../graphql/utils";
import { useStateTransition } from "../../hooks/useStateTransition";
import { appStateChangeAtom, currentDayAtom, store } from "../../state";
import { useMemo } from "react";
import { AppMachine } from "../../main";
function ListSpheres() {
    const [_state, transition] = useStateTransition();
    const { loading, error, data } = useGetSpheresQuery();
    const spheres = useMemo(() => extractEdges(data.spheres), [data]);
    if (loading)
        return _jsx(Spinner, {});
    if (error)
        return _jsxs("p", { children: ["Error : ", error.message] });
    if (!spheres.length)
        return _jsx(_Fragment, {});
    function routeToCreatePlannit(sphereEh) {
        transition("CreateOrbit", { sphereEh });
    }
    function routeToPlannitList(sphereId) {
        transition("ListOrbits", { sphereAh: sphereId, currentSphereDetails: spheres.find(sphere => sphere.id == sphereId) });
    }
    function routeToVis(sphere) {
        AppMachine.state.currentState == "Vis";
        transition("Vis", { currentSphereDetails: { ...sphere, ...sphere.metadata } });
    }
    const handleSetCurrentSphere = (sphereId) => {
        const state = store.get(appStateChangeAtom);
        state.spheres.currentSphereHash = sphereId;
        store.set(appStateChangeAtom, state);
    };
    return (_jsx("div", { className: "spheres-list", children: spheres.map((sphere) => {
            return (_jsx(SystemCalendarCard, { currentDate: store.get(currentDayAtom), currentWins: {}, sphere: sphere, handleCreateAction: () => routeToCreatePlannit(sphere.eH), handleListAction: () => routeToPlannitList(sphere.id), handleVisAction: () => routeToVis(sphere), setSphereIsCurrent: () => handleSetCurrentSphere(sphere.id) }, sphere.id));
        }) }));
}
export default ListSpheres;
//# sourceMappingURL=ListSpheres.js.map