import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useDeleteSphereMutation, useGetSpheresQuery, } from "../../graphql/generated";
import "./common.css";
import PageHeader from "../header/PageHeader";
import { SphereCard } from "habit-fract-design-system";
import { extractEdges } from "../../graphql/utils";
import { useStateTransition } from "../../hooks/useStateTransition";
import { useToast } from "../../contexts/toast";
import { currentSphereHashesAtom, sphereHasCachedNodesAtom, store } from "../../state";
import { useSetAtom } from "jotai";
function ListSpheres() {
    const [_state, transition] = useStateTransition();
    const [runDelete, { loading: loadingDelete, error: errorDelete, data: dataDelete },] = useDeleteSphereMutation({
        refetchQueries: ["getSpheres"],
    });
    const { loading, error, data } = useGetSpheresQuery();
    const { showToast, hideToast } = useToast();
    const setCurrentSphere = useSetAtom(currentSphereHashesAtom);
    if (loading)
        return _jsx("p", { children: "Loading..." });
    if (error)
        return _jsxs("p", { children: ["Error : ", error.message] });
    const spheres = extractEdges(data.spheres);
    if (!spheres.length)
        return _jsx(_Fragment, {});
    return (_jsxs("div", { className: "layout spheres", children: [_jsx(PageHeader, { title: "Sphere Breakdown" }), _jsx("div", {}), _jsx("div", { className: "spheres-list", children: spheres.map((sphere) => {
                    const sphereHasCachedNodes = store.get(sphereHasCachedNodesAtom(sphere.id));
                    return (_jsx(SphereCard, { sphere: sphere, transition: transition, isHeader: false, orbitScales: [], runDelete: () => runDelete({ variables: { id: sphere.id } }), showToast: showToast, setSphereIsCurrent: () => {
                            setCurrentSphere({
                                entryHash: sphere.eH,
                                actionHash: sphere.id,
                            });
                        }, hasCachedNodes: sphereHasCachedNodes }, sphere.id));
                }) })] }));
}
export default ListSpheres;
//# sourceMappingURL=ListSpheres.js.map