import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useGetOrbitHierarchyLazyQuery, useGetSpheresQuery, } from "../../graphql/generated";
import "./common.css";
import { Spinner, SystemCalendarCard } from "habit-fract-design-system";
import { extractEdges, fetchWinDataForOrbit } from "../../graphql/utils";
import { useStateTransition } from "../../hooks/useStateTransition";
import { appStateChangeAtom, getOrbitIdFromEh, getOrbitNodeDetailsFromEhAtom, store, } from "../../state";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { AppMachine } from "../../main";
import { byStartTime, parseAndSortTrees } from "../vis/helpers";
import { hierarchy } from "d3-hierarchy";
import { VisCoverage } from "../vis/types";
import { generateQueryParams } from "../vis/tree-helpers";
import { DateTime } from "luxon";
const DEBUG = false;
const debugLog = (...args) => {
    if (DEBUG)
        console.log(...args);
};
const mapToObject = (map) => {
    return Array.from(map.entries()).reduce((obj, [key, value]) => {
        obj[key] = value;
        return obj;
    }, {});
};
function ListSpheres() {
    const [_state, transition, _params, client] = useStateTransition();
    const [loadingStates, setLoadingStates] = useState({});
    const loadingInitiatedRef = useRef(false);
    const winDataUpdatesRef = useRef(new Map());
    const orbitDataUpdatesRef = useRef({});
    const { loading, error, data } = useGetSpheresQuery();
    const [getHierarchy] = useGetOrbitHierarchyLazyQuery({
        fetchPolicy: "network-only",
    });
    const spheres = useMemo(() => extractEdges(data.spheres), [data]);
    const [spheresData, setSpheresData] = useState({});
    const loadSphereHierarchyData = useCallback(async (sphere) => {
        debugLog('Loading hierarchy data for sphere:', sphere.eH);
        setSpheresData(prev => {
            const newData = { ...prev };
            delete newData[sphere.eH];
            return newData;
        });
        setLoadingStates(prev => ({ ...prev, [sphere.eH]: true }));
        winDataUpdatesRef.current = new Map();
        orbitDataUpdatesRef.current = {};
        let d3Hierarchy = null;
        let parsedTrees = null;
        try {
            const state = store.get(appStateChangeAtom);
            const visCoverage = VisCoverage.CompleteSphere;
            const queryParams = generateQueryParams(visCoverage, sphere.eH)(0);
            if (!queryParams) {
                console.warn('Failed to generate query params for sphere:', sphere.eH);
                return;
            }
            const { data: hierarchyData } = await getHierarchy({
                variables: { params: queryParams }
            });
            if (!hierarchyData?.getOrbitHierarchy)
                return;
            const trees = JSON.parse(hierarchyData.getOrbitHierarchy);
            if (!trees)
                return;
            parsedTrees = parseAndSortTrees(trees);
            const rootOrbitEh = parsedTrees[0].content;
            d3Hierarchy = hierarchy(parsedTrees[0]).sort(byStartTime);
            const nodeHashes = [];
            const leafNodeHashes = [];
            const leaves = [];
            const batchSize = 50;
            const nodes = d3Hierarchy.descendants();
            for (let i = 0; i < nodes.length; i += batchSize) {
                const batch = nodes.slice(i, i + batchSize);
                batch.forEach(node => {
                    if (!node.data?.content)
                        return;
                    const actionHash = store.get(getOrbitIdFromEh(node.data.content));
                    nodeHashes.push(actionHash);
                    orbitDataUpdatesRef.current[actionHash] = {
                        eH: node.data.content,
                    };
                    if (!node.children || node.children.length === 0) {
                        leafNodeHashes.push(actionHash);
                        leaves.push(node);
                    }
                });
                await new Promise(resolve => setTimeout(resolve, 0));
            }
            const today = DateTime.now();
            for (let i = 0; i < leaves.length; i += batchSize) {
                const batch = leaves.slice(i, i + batchSize);
                await Promise.all(batch.map(async (node) => {
                    if (!node.data?.content)
                        return;
                    if (!winDataUpdatesRef.current)
                        return;
                    const actionHash = store.get(getOrbitIdFromEh(node.data.content));
                    const winData = await fetchWinDataForOrbit(client, node.data.content, today);
                    if (winData) {
                        winDataUpdatesRef.current.set(actionHash, winData);
                    }
                }));
                await new Promise(resolve => setTimeout(resolve, 0));
            }
            store.set(appStateChangeAtom, {
                ...state,
                spheres: {
                    ...state.spheres,
                    byHash: {
                        ...state.spheres.byHash,
                        [sphere.id]: {
                            details: { entryHash: sphere.eH, name: sphere.name },
                            hierarchyRootOrbitEntryHashes: [rootOrbitEh]
                        }
                    }
                },
                orbitNodes: {
                    ...state.orbitNodes,
                    byHash: {
                        ...state.orbitNodes.byHash,
                        ...orbitDataUpdatesRef.current
                    }
                },
                hierarchies: {
                    ...state.hierarchies,
                    byRootOrbitEntryHash: {
                        ...state.hierarchies.byRootOrbitEntryHash,
                        [rootOrbitEh]: {
                            rootNode: rootOrbitEh,
                            json: JSON.stringify(parsedTrees),
                            nodeHashes,
                            leafNodeHashes,
                            bounds: undefined,
                            indices: { x: 0, y: 0 },
                            currentNode: rootOrbitEh
                        }
                    }
                },
                wins: {
                    ...state.wins,
                    ...Object.fromEntries(winDataUpdatesRef.current)
                }
            });
            const rootOrbitDetails = store.get(getOrbitNodeDetailsFromEhAtom(rootOrbitEh));
            const winDataObject = mapToObject(winDataUpdatesRef.current);
            const calculateOptions = {
                useRootFrequency: d3Hierarchy?.height === 0,
                leafDescendants: leaves.length
            };
            debugLog('Setting sphere data:', {
                rootOrbitDetails,
                winData: winDataObject,
                calculateOptions
            });
            setSpheresData(prev => ({
                ...prev,
                [sphere.eH]: {
                    rootOrbitOrbitDetails: rootOrbitDetails,
                    winData: winDataObject,
                    calculateOptions
                }
            }));
        }
        catch (error) {
            console.error(`Error loading hierarchy data for sphere ${sphere.eH}:`, error);
        }
        finally {
            setLoadingStates(prev => ({ ...prev, [sphere.eH]: false }));
            setTimeout(() => {
                d3Hierarchy = null;
                parsedTrees = null;
                winDataUpdatesRef.current = new Map();
                orbitDataUpdatesRef.current = {};
            }, 0);
        }
    }, [getHierarchy, client]);
    useEffect(() => {
        if (!spheres.length || loadingInitiatedRef.current)
            return;
        loadingInitiatedRef.current = true;
        const processQueue = async () => {
            for (const sphere of spheres) {
                await loadSphereHierarchyData(sphere);
                const state = store.get(appStateChangeAtom);
                const sphereEntry = state.spheres.byHash[sphere.id];
                const rootOrbitEh = sphereEntry?.hierarchyRootOrbitEntryHashes?.[0];
                if (!rootOrbitEh || !state.hierarchies.byRootOrbitEntryHash[rootOrbitEh]) {
                    console.error(`Failed to verify data loading for sphere ${sphere.eH}`);
                    continue;
                }
            }
        };
        processQueue().finally(() => {
            loadingInitiatedRef.current = false;
        });
        return () => {
            loadingInitiatedRef.current = false;
        };
    }, [spheres]);
    const routeToCreatePlanitt = (sphereEh) => {
        transition("CreateOrbit", { sphereEh });
    };
    const routeToPlanittList = (sphereId) => {
        transition("ListOrbits", {
            sphereAh: sphereId,
            currentSphereDetails: spheres.find(sphere => sphere.id === sphereId)
        });
    };
    const routeToVis = (sphere) => {
        AppMachine.state.currentState = "Vis";
        transition("Vis", { currentSphereDetails: { ...sphere, ...sphere.metadata } });
    };
    const handleSetCurrentSphere = (sphereId) => {
        const state = store.get(appStateChangeAtom);
        state.spheres.currentSphereHash = sphereId;
        store.set(appStateChangeAtom, state);
    };
    useEffect(() => {
        debugLog('Spheres data updated:', spheresData);
    }, [spheresData]);
    if (loading)
        return _jsx(Spinner, { type: "full" });
    if (error)
        return _jsxs("p", { children: ["Error: ", error.message] });
    if (!spheres.length)
        return _jsx(_Fragment, {});
    return (_jsx("div", { className: "spheres-list", children: spheres.map((sphere) => {
            const isLoading = loadingStates[sphere.eH];
            const sphereData = spheresData[sphere.eH];
            debugLog('Rendering sphere:', sphere.eH, 'with data:', sphereData);
            const rootOrbitWinData = useMemo(() => {
                if (!sphereData?.winData || !sphereData.rootOrbitOrbitDetails)
                    return {};
                const leafWinData = sphereData.winData;
                const rootId = sphereData.rootOrbitOrbitDetails.id;
                const allDates = new Set();
                Object.entries(leafWinData).forEach(([key, winData]) => {
                    if (key !== rootId && winData && typeof winData === 'object') {
                        Object.keys(winData).forEach(date => allDates.add(date));
                    }
                });
                return Array.from(allDates).reduce((acc, date) => {
                    const completionStates = Object.entries(leafWinData)
                        .filter(([key]) => key !== rootId)
                        .map(([_, winData]) => {
                        const dayData = winData?.[date];
                        return Array.isArray(dayData)
                            ? dayData.every(Boolean)
                            : !!dayData;
                    });
                    acc[date] = completionStates;
                    return acc;
                }, {});
            }, [sphereData]);
            return (_jsx(SystemCalendarCard, { sphere: sphere, loading: isLoading, rootOrbitWinData: sphereData?.winData ? { ...rootOrbitWinData, ...sphereData.calculateOptions } : {}, rootOrbitOrbitDetails: sphereData?.rootOrbitOrbitDetails ?? null, setSphereIsCurrent: () => handleSetCurrentSphere(sphere.id), handleVisAction: () => routeToVis(sphere), handleCreateAction: () => routeToCreatePlanitt(sphere.eH), handleListAction: () => routeToPlanittList(sphere.id) }, sphere.id));
        }) }));
}
export default ListSpheres;
//# sourceMappingURL=ListSpheres.js.map