import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useDeleteSphereMutation, useGetSpheresQuery } from '../../graphql/generated';
import './common.css';
import PageHeader from '../header/PageHeader';
import { SphereCard } from 'habit-fract-design-system';
import { extractEdges } from '../../graphql/utils';
import { useStateTransition } from '../../hooks/useStateTransition';
function ListSpheres() {
    const [runDelete, { loading: loadingDelete, error: errorDelete, data: dataDelete }] = useDeleteSphereMutation({
        refetchQueries: [
            'getSpheres',
        ],
    });
    const { loading, error, data } = useGetSpheresQuery();
    const [_state, transition] = useStateTransition();
    if (loading)
        return _jsx("p", { children: "Loading..." });
    if (error)
        return _jsxs("p", { children: ["Error : ", error.message] });
    const spheres = extractEdges(data.spheres);
    if (!spheres.length)
        return _jsx(_Fragment, {});
    return (_jsxs("div", { className: 'layout spheres', children: [_jsx(PageHeader, { title: "Sphere Breakdown" }), _jsx("div", {}), _jsx("div", { className: "spheres-list", children: spheres.map((sphere) => _jsx(SphereCard, { sphere: sphere, transition: transition, isHeader: false, orbitScales: [], runDelete: () => runDelete({ variables: { id: sphere.id } }) }, sphere.id)) })] }));
}
export default ListSpheres;
//# sourceMappingURL=ListSpheres.js.map