import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState } from 'react';
import { Formik, Form, Field } from 'formik';
import { SortDescendingOutlined, SortAscendingOutlined, FilterOutlined } from '@ant-design/icons';
import { Modal, Radio } from 'flowbite-react';
import './common.css';
import { SortCriteria, SortOrder, listSortFilterAtom } from '../../state/ui';
import { store } from '../../state/jotaiKeyValueStore';
const ListSortFilter = ({ label }) => {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const toggleModal = () => setIsModalOpen(!isModalOpen);
    const listSortFilter = store.get(listSortFilterAtom);
    const toggleSortOrder = () => {
        store.set(listSortFilterAtom, {
            ...listSortFilter,
            sortOrder: listSortFilter.sortOrder === SortOrder.GreatestToLowest ? SortOrder.LowestToGreatest : SortOrder.GreatestToLowest
        });
    };
    return (_jsxs("div", { className: "list-sort-filter", children: [_jsxs("div", { className: "sort-icon-container text-gray-500 flex justify-end", children: [!!label && _jsx("span", { className: "sort-filter-label", children: label }), _jsxs("div", { className: "flex gap-2 text-2xl", children: [_jsx(FilterOutlined, { className: "sort-filter-icon", onClick: toggleModal }), listSortFilter.sortOrder === SortOrder.GreatestToLowest ? (_jsx(SortDescendingOutlined, { className: "sort-filter-icon", onClick: toggleSortOrder })) : (_jsx(SortAscendingOutlined, { className: "sort-filter-icon", onClick: toggleSortOrder }))] })] }), isModalOpen && (_jsxs(Modal, { show: isModalOpen, onClose: toggleModal, children: [_jsx(Modal.Header, { children: "Sort Criteria" }), _jsx(Modal.Body, { children: _jsx(Formik, { initialValues: {
                                sortCriteria: SortCriteria.Name,
                            }, onSubmit: (_values) => {
                                toggleModal();
                            }, children: ({ handleSubmit }) => (_jsxs(Form, { onSubmit: handleSubmit, children: [_jsx("div", { className: "space-y-4", children: _jsxs("div", { children: [_jsx("label", { className: "block mb-2 text-xl", children: "Sort by:" }), _jsxs("div", { className: "flex flex-col", children: [_jsxs("label", { className: 'text-xl lowercase capitalize', children: [_jsx(Field, { className: "text-primary m-2 p-2", onChange: (e) => store.set(listSortFilterAtom, { ...listSortFilter, sortCriteria: e.currentTarget.value }), checked: listSortFilter.sortCriteria == SortCriteria.Name, type: "radio", name: "sortCriteria", value: SortCriteria.Name, as: Radio }), "Name"] }), _jsxs("label", { className: 'text-xl lowercase capitalize', children: [_jsx(Field, { className: "text-primary m-2 p-2", onChange: (e) => store.set(listSortFilterAtom, { ...listSortFilter, sortCriteria: e.currentTarget.value }), checked: listSortFilter.sortCriteria == SortCriteria.Scale, type: "radio", name: "sortCriteria", value: SortCriteria.Scale, as: Radio }), "Scale"] })] })] }) }), _jsx("div", { className: "mt-4", children: _jsx("button", { type: "submit", className: "btn btn-primary", children: "Ok" }) })] })) }) })] }))] }));
};
export default ListSortFilter;
//# sourceMappingURL=ListSortFilter.js.map