import React from "react";
import "./common.css";
interface ListOrbitsProps {
}
declare const ListOrbits: React.FC<ListOrbitsProps>;
export default ListOrbits;
//# sourceMappingURL=ListOrbits.d.ts.map