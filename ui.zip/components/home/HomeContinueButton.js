import { jsx as _jsx } from "react/jsx-runtime";
import { Button } from 'habit-fract-design-system';
const HomeContinue = ({ onClick }) => {
    return (_jsx(Button, { type: "onboarding", onClick: onClick, children: "Start Tracking Habits" }));
};
export default HomeContinue;
//# sourceMappingURL=HomeContinueButton.js.map