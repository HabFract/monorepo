import { jsxs as _jsxs, jsx as _jsx } from "react/jsx-runtime";
import { Button } from "habit-fract-design-system";
import { AlertOutlined } from "@ant-design/icons";
import { NODE_ENV } from "../../constants";
import { isSmallScreen } from "../vis/helpers";
const VersionDisclaimer = ({ currentVersion, open }) => {
    return (_jsxs("div", { className: "app-version-disclaimer", children: [NODE_ENV !== "dev" && (_jsxs("div", { className: "version-number", children: ["v", currentVersion] })), _jsx(Button, { type: "button", variant: "secondary", onClick: open, children: isSmallScreen() ? _jsx(AlertOutlined, { className: "text-text dark:text-text-dark" }) : "Disclaimer" })] }));
};
export default VersionDisclaimer;
//# sourceMappingURL=VersionWithDisclaimerButton.js.map