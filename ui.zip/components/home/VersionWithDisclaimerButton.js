import { jsxs as _jsxs, jsx as _jsx } from "react/jsx-runtime";
import { Button } from "habit-fract-design-system";
import { AlertOutlined } from "@ant-design/icons";
import { NODE_ENV } from "../../constants";
import { isSmallScreen } from "../vis/helpers";
const VersionDisclaimer = ({ currentVersion, open, isFrontPage, }) => {
    return (_jsxs("div", { className: isFrontPage
            ? "app-version-disclaimer z-50 flex gap-2 fixed right-1 top-1"
            : "app-version-disclaimer z-60 flex gap-2 fixed right-1 bottom-1", children: [NODE_ENV !== "dev" && (_jsxs("div", { className: "version-number", children: ["v", currentVersion] })), _jsx(Button, { type: "secondary", onClick: open, children: isSmallScreen() ? _jsx(AlertOutlined, { className: "text-bg" }) : "Disclaimer" })] }));
};
export default VersionDisclaimer;
//# sourceMappingURL=VersionWithDisclaimerButton.js.map