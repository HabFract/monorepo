import { FC } from "react";
interface VersionDisclaimerProps {
    currentVersion: string | undefined;
    open: () => void;
}
declare const VersionDisclaimer: FC<VersionDisclaimerProps>;
export default VersionDisclaimer;
//# sourceMappingURL=VersionWithDisclaimerButton.d.ts.map