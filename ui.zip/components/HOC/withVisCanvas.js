import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useState } from 'react';
import "../vis/vis.css";
import { VisCoverage } from '../vis/types';
import { select } from "d3-selection";
import { useNodeTraversal } from '../../hooks/useNodeTraversal';
import { currentSphereHierarchyBounds, newTraversalLevelIndexId } from '../../state/hierarchy';
import { currentOrbitDetailsAtom, currentOrbitIdAtom, setOrbitWithEntryHashAtom } from '../../state/orbit';
import { store } from '../../state/jotaiKeyValueStore';
import VisModal from '../VisModal';
import TraversalButton from '../navigation/TraversalButton';
import { VisControls } from 'habit-fract-design-system';
import { currentDayAtom } from '../../state/date';
import { isSmallScreen } from '../vis/helpers';
import { useRedirect } from '../../hooks/useRedirect';
import { currentSphereHashesAtom } from '../../state/sphere';
import { byStartTime } from '../vis/OrbitTree';
const defaultMargins = {
    top: 0,
    right: 0,
    bottom: 0,
    left: 30,
};
const getCanvasDimensions = function () {
    const { height, width } = document.body.getBoundingClientRect();
    const canvasHeight = height - defaultMargins.top - defaultMargins.bottom;
    const canvasWidth = width - defaultMargins.right - defaultMargins.left;
    return { canvasHeight, canvasWidth };
};
const appendSvg = (mountingDivId, divId) => {
    return select(`#${divId}`).empty() &&
        select(`#${mountingDivId}`)
            .append("svg")
            .attr("id", `${divId}`)
            .attr("width", "100%")
            .attr("data-testid", "svg")
            .attr("height", "100%")
            .attr("style", "pointer-events: all");
};
function getTraversalConditions(queryType, newRootData) {
    const withTraversal = queryType !== VisCoverage.CompleteOrbit;
    const hasChild = newRootData?.data?.children && newRootData?.data?.children.length > 0;
    const hasOneChild = newRootData?.data?.children && newRootData?.data?.children.length == 1;
    const onlyChildParent = true;
    return { withTraversal, hasChild, hasOneChild, onlyChildParent };
}
export function withVisCanvas(Component) {
    const ComponentWithVis = (_visParams) => {
        useRedirect();
        const mountingDivId = 'vis-root';
        const svgId = 'vis';
        const [appendedSvg, setAppendedSvg] = useState(false);
        const selectedSphere = store.get(currentSphereHashesAtom);
        const cachedCurrentOrbit = store.get(currentOrbitDetailsAtom);
        useEffect(() => {
            if (document.querySelector(`#${mountingDivId} #${svgId}`))
                return;
            const appended = !!appendSvg(mountingDivId, svgId);
            setAppendedSvg(appended);
        }, [selectedSphere?.actionHash]);
        const { canvasHeight, canvasWidth } = getCanvasDimensions();
        const [isModalOpen, setIsModalOpen] = useState(false);
        const [currentParentOrbitEh, setCurrentParentOrbitEh] = useState();
        const [currentChildOrbitEh, setCurrentChildOrbitEh] = useState();
        const sphereHierarchyBounds = store.get(currentSphereHierarchyBounds);
        const { incrementBreadth, decrementBreadth, incrementDepth, decrementDepth, maxBreadth, setBreadthIndex, maxDepth } = useNodeTraversal(sphereHierarchyBounds[selectedSphere.entryHash]);
        const [currentDate, setCurrentDate] = useState(store.get(currentDayAtom));
        store.sub(currentDayAtom, () => {
            setCurrentDate(store.get(currentDayAtom));
        });
        return (_jsx(Component, { canvasHeight: canvasHeight, canvasWidth: canvasWidth, margin: defaultMargins, selectedSphere: selectedSphere, render: (currentVis, queryType, x, y, newRootData) => {
                const currentOrbitIsRoot = !!(cachedCurrentOrbit && cachedCurrentOrbit.eH === currentVis.rootData.data.content);
                const traversalConditions = getTraversalConditions(queryType, currentOrbitIsRoot ? currentVis.rootData : newRootData);
                if (appendedSvg) {
                    currentVis.modalOpen = setIsModalOpen;
                    currentVis.modalParentOrbitEh = setCurrentParentOrbitEh;
                    currentVis.modalChildOrbitEh = setCurrentChildOrbitEh;
                    currentVis?.render();
                }
                return (_jsxs(_Fragment, { children: [_jsx(VisControls, { currentDate: currentDate, setNewDate: (val) => { setCurrentDate(val); }, orbitDetails: cachedCurrentOrbit, setOrbitDetailsWin: (dateIndex, newValue) => {
                                store.set(setOrbitWithEntryHashAtom, {
                                    orbitEh: cachedCurrentOrbit.eH,
                                    update: {
                                        ...cachedCurrentOrbit,
                                    }
                                });
                            }, buttons: renderTraversalButtons(traversalConditions, { x, y }, currentVis, currentOrbitIsRoot) }), VisModal(isModalOpen, setIsModalOpen, selectedSphere, currentParentOrbitEh, currentChildOrbitEh, currentVis)] }));
            } }));
        function renderTraversalButtons(conditions, coords, currentVis, currentOrbitIsRoot) {
            const { withTraversal, hasChild, hasOneChild, onlyChildParent } = conditions;
            const { x, y } = coords;
            const data = currentVis.rootData.sort(byStartTime);
            const children = (isSmallScreen() ? data?.children?.reverse() : data?.children);
            const rootId = data.data.content;
            const currentId = store.get(currentOrbitIdAtom)?.id;
            const currentDetails = store.get(currentOrbitDetailsAtom);
            const canMove = !isSmallScreen() || (currentVis.coverageType == VisCoverage.CompleteSphere);
            const canMoveUp = canMove && rootId !== currentId;
            const canMoveRight = canMove && canMoveUp && children && children[children.length - 1].data.content !== currentId;
            const canMoveLeft = canMove && canMoveUp && children && children[0].data.content !== currentId;
            const canMoveDown = canMove && currentOrbitIsRoot && children && children.length !== 2;
            const canMoveDownLeft = canMove && currentOrbitIsRoot && children && !hasOneChild;
            const canMoveDownRight = canMove && currentOrbitIsRoot && children && !hasOneChild;
            const canTraverseDownMiddle = !!(children && children.slice(1, -1)?.find(child => child.children && child.children.length > 0)?.data.content == currentId);
            const canTraverseDown = children && hasOneChild && children[0].children && children[0].children.length == 1;
            const canTraverseLeft = x !== 0 && currentOrbitIsRoot;
            const canTraverseRight = currentOrbitIsRoot && maxBreadth && x < maxBreadth;
            const canTraverseDownLeft = !canMoveLeft && !currentOrbitIsRoot && children && !hasOneChild && children[0].children;
            const canTraverseDownRight = !canMoveRight && !currentOrbitIsRoot && maxDepth && (y < maxDepth) && children && !hasOneChild && !!children?.find(child => ((child?.data?.content == currentId) && !!child.children));
            const moveLeft = () => {
                const currentIndex = children?.findIndex(child => child.data.content == currentId);
                const newId = children[currentIndex - 1].data.content;
                store.set(currentOrbitIdAtom, newId);
            };
            const moveRight = () => {
                const currentIndex = children?.findIndex(child => child.data.content == currentId);
                const newId = children[currentIndex + 1].data.content;
                store.set(currentOrbitIdAtom, newId);
            };
            const moveDown = () => {
                const childrenMiddle = children.length > 0 ? Math.ceil(children.length / 2) - 1 : 0;
                const newId = children[childrenMiddle].data.content;
                store.set(currentOrbitIdAtom, newId);
            };
            const moveUp = () => {
                const orbit = store.get(currentOrbitDetailsAtom);
                const newId = orbit?.parentEh !== rootId ? orbit?.parentEh : rootId;
                store.set(currentOrbitIdAtom, newId);
            };
            const moveDownLeft = () => {
                const newId = children[0].data.content;
                store.set(currentOrbitIdAtom, newId);
            };
            const moveDownRight = () => {
                const newId = children[children.length - 1].data.content;
                store.set(currentOrbitIdAtom, newId);
            };
            const traverseDownRight = () => {
                const newX = children.length - 1;
                incrementDepth();
                const newChild = children && children?.find(child => ((child?.data?.content == currentId) && !!child.children))?.children?.[0];
                const newId = newChild && newChild.parent?.data?.content;
                store.set(newTraversalLevelIndexId, { id: newId });
                setBreadthIndex(newX);
            };
            const traverseDown = () => {
                incrementDepth();
                const newChild = children && children?.find(child => ((child?.data?.content == currentId) && !!child.children))?.children?.[0];
                const newId = newChild && newChild.parent?.data?.content;
                store.set(newTraversalLevelIndexId, { id: newId });
                setBreadthIndex(children?.findIndex(child => child?.data?.content == newId) || 0);
            };
            const traverseUp = () => {
                decrementDepth();
                store.set(newTraversalLevelIndexId, { id: currentDetails?.parentEh });
            };
            return [
                _jsx(TraversalButton, { condition: withTraversal && (y !== 0 || canMoveUp), iconType: "up", onClick: canMoveUp ? moveUp : traverseUp, dataTestId: "traversal-button-up" }),
                _jsx(TraversalButton, { condition: !!(withTraversal && (canTraverseDown || canTraverseDownMiddle || canMoveDown)), iconType: "down", onClick: canMoveDown ? moveDown : traverseDown, dataTestId: "traversal-button-down" }),
                _jsx(TraversalButton, { condition: !!(withTraversal && (canTraverseLeft || canMoveLeft)), iconType: "left", onClick: canMoveLeft ? moveLeft : decrementBreadth, dataTestId: "traversal-button-left" }),
                _jsx(TraversalButton, { condition: !!(withTraversal && (canTraverseDownLeft || canMoveDownLeft)), iconType: "down-left", onClick: canMoveDownLeft ? moveDownLeft : traverseDown, dataTestId: "traversal-button-down-left" }),
                _jsx(TraversalButton, { condition: !!(withTraversal && (canTraverseRight || canMoveRight)), iconType: "right", onClick: canMoveRight ? moveRight : incrementBreadth, dataTestId: "traversal-button-right" }),
                _jsx(TraversalButton, { condition: !!(withTraversal && (canTraverseDownRight || canMoveDownRight)), iconType: "down-right", onClick: canMoveDownRight ? moveDownRight : traverseDownRight, dataTestId: "traversal-button-down-right" })
            ];
        }
        ;
    };
    return _jsx(ComponentWithVis, {});
}
//# sourceMappingURL=withVisCanvas.js.map