import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import "../vis/vis.css";
import { VisCoverage } from "../vis/types";
import { useNodeTraversal } from "../../hooks/useNodeTraversal";
import { currentSphereHierarchyBounds, currentSphereHierarchyIndices, newTraversalLevelIndexId, } from "../../state/hierarchy";
import { currentOrbitDetailsAtom, currentOrbitIdAtom, currentOrbitIsLeafAtom, currentSphereOrbitNodeDetailsAtom, getOrbitNodeDetailsFromEhAtom, } from "../../state/orbit";
import { store } from "../../state/store";
import VisModal from "../VisModal";
import { OverlayLayout, Spinner } from "habit-fract-design-system";
import { currentDayAtom } from "../../state/date";
import { byStartTime, getCanvasDimensions, isSmallScreen } from "../vis/helpers";
import { currentSphereHashesAtom } from "../../state/sphere";
import { useCreateOrUpdateWinRecord } from "../../hooks/gql/useCreateOrUpdateWinRecord";
import { useAtom, useAtomValue } from "jotai";
import { isMoreThenDaily } from "../vis/tree-helpers";
import { useVisCanvas } from "../../hooks/useVisCanvas";
import { DEFAULT_MARGINS } from "../vis/constants";
import { useWinData } from "../../hooks/useWinData";
import { calculateCurrentStreakAtom, calculateLongestStreakAtom } from "../../state/win";
export function withVisCanvas(Component) {
    const ComponentWithVis = React.memo(() => {
        const currentOrbitDetails = useAtomValue(currentOrbitDetailsAtom);
        const currentOrbitIsLeaf = useAtomValue(currentOrbitIsLeafAtom);
        const currentOrbitStreakAtom = useMemo(() => calculateCurrentStreakAtom(currentOrbitDetails?.id), [currentOrbitDetails?.id]);
        const currentStreak = store.get(currentOrbitStreakAtom);
        const currentOrbitLongestStreakAtom = useMemo(() => calculateLongestStreakAtom(currentOrbitDetails?.id), [currentOrbitDetails?.id]);
        const longestStreak = store.get(currentOrbitLongestStreakAtom);
        const sphereHierarchyBounds = store.get(currentSphereHierarchyBounds);
        const currentHierarchyIndices = store.get(currentSphereHierarchyIndices);
        const selectedSphere = store.get(currentSphereHashesAtom);
        const { appendedSvg } = useVisCanvas(selectedSphere);
        const { canvasHeight, canvasWidth } = getCanvasDimensions();
        const { incrementBreadth, decrementBreadth, incrementDepth, decrementDepth, maxBreadth, setBreadthIndex, maxDepth, } = useNodeTraversal(sphereHierarchyBounds[selectedSphere.entryHash]);
        const [isModalOpen, setIsModalOpen] = useState(false);
        const allFirstChildDescendantOrbits = useRef(null);
        const [currentParentOrbitEh, setCurrentParentOrbitEh] = useState();
        const [currentChildOrbitEh, setCurrentChildOrbitEh] = useState();
        const resetModalParentChildStates = () => {
            setCurrentParentOrbitEh(undefined);
            setCurrentChildOrbitEh(undefined);
        };
        const [currentDate, setCurrentDate] = useAtom(currentDayAtom);
        const visRef = useRef(null);
        useEffect(() => {
            return () => {
                if (visRef.current) {
                    visRef.current.destroy();
                    visRef.current = null;
                }
            };
        }, []);
        const withWinData = useCallback(() => {
            return useWinData(currentOrbitDetails, currentDate);
        }, [currentOrbitDetails, currentDate]);
        const { workingWinDataForOrbit, handleUpdateWorkingWins } = withWinData();
        const skipFlag = !currentOrbitDetails?.eH || !currentOrbitDetails?.frequency || !workingWinDataForOrbit || typeof workingWinDataForOrbit !== 'object';
        const createOrUpdateWinRecord = useCreateOrUpdateWinRecord({
            variables: {
                winRecord: {
                    orbitEh: currentOrbitDetails?.eH,
                    winData: workingWinDataForOrbit !== null && Object.entries(workingWinDataForOrbit).map(([date, value]) => ({
                        date,
                        ...(isMoreThenDaily(currentOrbitDetails?.frequency || 0)
                            ? { multiple: value }
                            : { single: value })
                    }))
                }
            },
            skip: skipFlag
        });
        const handlePersistWins = useCallback(() => {
            if (typeof createOrUpdateWinRecord !== 'function')
                return;
            if (skipFlag) {
                console.error("Not enough details to persist.");
                return;
            }
            console.log("Persisting new win data...");
            if (currentOrbitIsLeaf) {
                createOrUpdateWinRecord();
            }
            else {
                console.log("Current orbit is not a leaf. Wins will be calculated from child nodes.");
            }
        }, [currentOrbitDetails, workingWinDataForOrbit, createOrUpdateWinRecord]);
        return (_jsx(Component, { canvasHeight: canvasHeight, canvasWidth: canvasWidth, margin: DEFAULT_MARGINS, render: (currentVis) => {
                if (!currentOrbitDetails?.eH)
                    return _jsx(Spinner, {});
                visRef.current = currentVis;
                const { consolidatedFlags, consolidatedActions, orbitDescendants, orbitSiblings } = getActionsAndDataForControls(currentVis, currentOrbitDetails?.eH);
                if (appendedSvg) {
                    currentVis.modalOpen = setIsModalOpen;
                    currentVis.modalParentOrbitEh = (val) => { console.log('Set parent id for new orbit in modal :>> ', val); setCurrentParentOrbitEh(val); };
                    currentVis.modalChildOrbitEh = setCurrentChildOrbitEh;
                    currentVis?.render();
                }
                return (_jsxs(_Fragment, { children: [isSmallScreen()
                            ? _jsx(OverlayLayout, { currentDate: currentDate, setNewDate: setCurrentDate, currentStreak: currentStreak, longestStreak: longestStreak, workingWinDataForOrbit: workingWinDataForOrbit, handleUpdateWorkingWins: handleUpdateWorkingWins, handlePersistWins: handlePersistWins, orbitFrequency: currentOrbitDetails?.frequency || 1.0, orbitSiblings: orbitSiblings, orbitDescendants: orbitDescendants, isLeafOrbit: !!currentOrbitIsLeaf, currentOrbitDetails: currentOrbitDetails, actions: consolidatedActions })
                            : null, VisModal(isModalOpen, setIsModalOpen, selectedSphere, currentParentOrbitEh, currentChildOrbitEh, resetModalParentChildStates, currentVis)] }));
            } }));
        function generateNavigationFlags(currentVis, currentId, rootId, children, x, y, maxBreadth, maxDepth) {
            const canMove = !isSmallScreen() || currentVis.coverageType == VisCoverage.CompleteSphere;
            const canMoveLeft = canMove && rootId !== currentId && children && children[0] && children[0].data.content !== currentId;
            const canMoveRight = canMove && rootId !== currentId && children && children[children.length - 1] && children[children.length - 1].data.content !== currentId;
            const currentOrbitIsRoot = currentId === rootId;
            const hasOneChild = children && children.length == 1;
            const canTraverseDownMiddle = !!(children &&
                children
                    ?.filter((child) => child.children && child.children.length > 0).map(node => node.data.content)
                    .includes(currentId));
            return {
                canMove,
                canMoveUp: canMove && rootId !== currentId,
                canTraverseUp: y !== 0,
                canMoveRight,
                canMoveLeft,
                canMoveDown: canMove && currentOrbitIsRoot && children?.length > 0,
                canMoveDownLeft: canMove && currentOrbitIsRoot && children && !hasOneChild,
                canMoveDownRight: canMove && currentOrbitIsRoot && children && !hasOneChild,
                canTraverseDownMiddle,
                canTraverseDown: children && hasOneChild && children[0].children && children[0].children.length == 1,
                canTraverseLeft: x !== 0 && currentOrbitIsRoot,
                canTraverseRight: currentOrbitIsRoot && maxBreadth && x < maxBreadth,
                canTraverseDownLeft: !canMoveLeft && !currentOrbitIsRoot && children && !hasOneChild && children[0]?.children,
                canTraverseDownRight: !canMoveRight && !currentOrbitIsRoot && maxDepth && y < maxDepth && children && !hasOneChild &&
                    !!children?.find((child) => child?.data?.content == currentId && !!child.children),
            };
        }
        function generateNavigationActions(currentVis, currentId, rootId, children, currentDetails, store) {
            return {
                moveToId: (newIndex) => {
                    if (typeof newIndex !== 'number')
                        return console.error("Cannot move without valid index ");
                    store.set(currentOrbitIdAtom, children[newIndex].data.content);
                },
                moveLeft: () => {
                    const currentIndex = children?.findIndex((child) => child.data.content == currentId);
                    if (currentIndex == -1)
                        return console.error("Couldn't calculate new index to move to");
                    const newId = children[currentIndex - 1].data.content;
                    store.set(currentOrbitIdAtom, newId);
                },
                moveRight: () => {
                    const currentIndex = children?.findIndex((child) => child.data.content == currentId);
                    if (currentIndex == -1)
                        return console.error("Couldn't calculate new index to move to");
                    const newId = children[currentIndex + 1].data.content;
                    store.set(currentOrbitIdAtom, newId);
                },
                traverseRight: () => {
                    console.log('Traversing right...');
                    incrementBreadth();
                },
                traverseLeft: () => {
                    console.log('Traversing left...');
                    decrementBreadth();
                },
                traverseDown: () => {
                    console.log('Traversing down...');
                    const grandChildren = children?.find(child => child.data.content == currentId)?.children;
                    const currentRenderSiblingIndex = children?.findIndex(child => child.data.content == currentId);
                    if (grandChildren && grandChildren.length > 0) {
                        const newId = grandChildren[0].data.content;
                        try {
                            (currentVis?.eventHandlers.memoizedhandleNodeZoom.call(currentVis, newId, undefined))
                                .on("end", () => {
                                incrementDepth();
                                const newChild = children &&
                                    children?.find((child) => child?.data?.content == currentId && !!child.children)?.children?.[0];
                                const newId = newChild && newChild.parent?.data?.content;
                                store.set(newTraversalLevelIndexId, { id: newId, direction: 'down', previousRenderSiblingIndex: currentRenderSiblingIndex });
                                setBreadthIndex(0);
                            });
                        }
                        catch (error) {
                            console.log('Could not complete zoom and traverse action.');
                        }
                    }
                },
                traverseUp: () => {
                    decrementDepth();
                    console.log('Traversing up... :>> ');
                    store.set(newTraversalLevelIndexId, {
                        id: currentDetails?.parentEh,
                        intermediateId: currentDetails?.id,
                        direction: 'up'
                    });
                },
                moveDown: (id) => {
                    store.set(currentOrbitIdAtom, id);
                },
                moveUp: () => {
                    const orbit = store.get(currentOrbitDetailsAtom);
                    const newId = (!!orbit && orbit?.parentEh !== rootId) ? orbit?.parentEh : rootId;
                    store.set(currentOrbitIdAtom, newId);
                    currentVis._lastRenderParentId = newId;
                    console.log("Moving up... to", newId);
                }
            };
        }
        function getActionsAndDataForControls(currentVis, currentId) {
            const rootId = currentVis.rootData.data.content;
            const children = ((currentVis.rootData.find(node => node.data.content == currentId)?.parent?.children || currentVis.rootData?.children) || []).sort(byStartTime);
            const sphereNodeDetails = store.get(currentSphereOrbitNodeDetailsAtom);
            const orbitSiblings = (currentId == rootId ? [currentVis.rootData] : children).map(node => {
                const orbitInfo = sphereNodeDetails[node.data.content];
                return {
                    id: orbitInfo.id,
                    eH: orbitInfo.eH,
                    orbitName: orbitInfo.name,
                    orbitScale: orbitInfo.scale,
                };
            });
            const orbitDescendants = [];
            if (!!currentOrbitDetails?.eH) {
                calculateFullLineage(currentOrbitDetails.eH);
                allFirstChildDescendantOrbits.current = orbitDescendants;
            }
            const flags = generateNavigationFlags(currentVis, currentId, rootId, children, currentHierarchyIndices.x, currentHierarchyIndices.y, maxBreadth, maxDepth);
            const actions = generateNavigationActions(currentVis, currentId, rootId, children, currentOrbitDetails, store);
            const consolidatedFlags = {
                canGoUp: !!(flags.canMoveUp || flags.canTraverseUp),
                canGoDown: !!(flags.canMoveDown || flags.canTraverseDownMiddle || flags.canTraverseDownLeft),
                canGoLeft: !!(flags.canMoveLeft || flags.canTraverseLeft),
                canGoRight: !!(flags.canMoveRight || flags.canTraverseRight),
            };
            const consolidatedActions = {
                goLeft: actions.moveToId,
                goRight: actions.moveToId,
                goUp: flags.canMoveUp ? actions.moveDown : actions.moveUp,
                goDown: flags.canMoveDown ? actions.moveDown : actions.moveDown
            };
            return {
                consolidatedFlags,
                consolidatedActions,
                orbitSiblings,
                orbitDescendants: allFirstChildDescendantOrbits.current
            };
            function calculateFullLineage(currentOrbitEh) {
                const ancestorLineage = [];
                let currentNode = currentOrbitDetails;
                while (currentNode && currentNode.parentEh) {
                    const parentInfo = store.get(getOrbitNodeDetailsFromEhAtom(currentNode.parentEh));
                    ancestorLineage.push({
                        id: parentInfo.id,
                        eH: parentInfo.eH,
                        orbitName: parentInfo.name,
                        orbitScale: parentInfo.scale,
                    });
                    currentNode = store.get(getOrbitNodeDetailsFromEhAtom(currentNode.parentEh));
                }
                orbitDescendants.push(...ancestorLineage.reverse());
                const currentOrbitInfo = store.get(getOrbitNodeDetailsFromEhAtom(currentOrbitEh));
                orbitDescendants.push({
                    id: currentOrbitInfo.id,
                    eH: currentOrbitInfo.eH,
                    orbitName: currentOrbitInfo.name,
                    orbitScale: currentOrbitInfo.scale,
                });
                const currentVisNode = currentVis.rootData.find(node => node.data.content === currentOrbitEh);
                if (currentVisNode && currentVisNode.children && currentVisNode.children.length > 0) {
                    addFirstChildLineage(currentVisNode.children[0]);
                }
            }
            function addFirstChildLineage(node) {
                const orbitInfo = store.get(getOrbitNodeDetailsFromEhAtom(node.data.content));
                orbitDescendants.push({
                    id: orbitInfo.id,
                    eH: orbitInfo.eH,
                    orbitName: orbitInfo.name,
                    orbitScale: orbitInfo.scale,
                });
                if (node.children && node.children.length > 0) {
                    addFirstChildLineage(node.children[0]);
                }
            }
        }
    });
    return _jsx(ComponentWithVis, {});
}
//# sourceMappingURL=withVisCanvas.js.map