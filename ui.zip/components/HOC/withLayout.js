import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import Breadcrumbs from "../navigation/Breadcrumbs";
import Home from "../layouts/Home";
import Onboarding from "../layouts/Onboarding";
import { AnimatePresence, motion } from "framer-motion";
import { AppMachine } from "../../main";
function withPageTransition(page) {
    return (_jsx(AnimatePresence, { mode: 'wait', children: _jsx(motion.div, { className: 'framer-motion', initial: { opacity: 0 }, animate: { opacity: 1 }, exit: { opacity: 0 }, children: page }, +(new Date)) }));
}
const withLayout = (component, state, transition, params) => {
    return (props) => {
        switch (true) {
            case !!(state.match("Onboarding")):
                return _jsx(Onboarding, { children: withPageTransition(component) });
            case ["Home", "PreloadAndCache"].includes(state):
                console.log('state :>> ', state, params);
                if (state == "Home" && props?.newUser)
                    return _jsx(Home, { firstVisit: false });
                return withPageTransition(component);
            default:
                return _jsxs("div", { className: 'p-1 w-full', children: [_jsx(Breadcrumbs, { state: AppMachine.state.currentState, transition: transition, currentSphere: props?.currentSphereDetails, isFormEditMode: params?.editMode }), component] });
        }
    };
};
export default withLayout;
//# sourceMappingURL=withLayout.js.map