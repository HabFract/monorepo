import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, memo, useCallback } from "react";
import Home from "../layouts/Home";
import Onboarding from "../layouts/Onboarding";
import { AnimatePresence, motion } from "framer-motion";
import { useDeleteSphereMutation } from "../../graphql/generated";
import VisLayout from "../layouts/VisLayout";
import FormLayout from "../layouts/FormLayout";
import ListLayout from "../layouts/List";
import { currentSphereHashesAtom, store } from "../../state";
import { useModal } from "../../contexts/modal";
import { AppMachine } from "../../main";
import { useStateTransition } from "../../hooks/useStateTransition";
import SettingsLayout from "../layouts/SettingsLayout";
import { useToast } from "../../contexts/toast";
import { VisProvider } from "../../contexts/vis";
const pageVariants = {
    initial: {
        opacity: 0,
        scale: 1
    },
    animate: {
        opacity: 1,
        scale: 1,
        transition: {
            duration: 0.3,
            ease: "easeOut"
        }
    },
    exit: {
        opacity: 0,
        scale: 1,
        transition: {
            duration: 0.4,
            ease: "easeIn"
        }
    }
};
function withPageTransition(page, state) {
    return (_jsx(AnimatePresence, { mode: "wait", children: _jsx(motion.div, { className: "framer-motion", variants: pageVariants, initial: "initial", animate: "animate", exit: "exit", transition: { duration: 0.4 }, children: page }, state) }));
}
const withLayout = (component) => {
    return memo(({ currentSphereDetails, newUser }) => {
        const state = AppMachine.state.currentState;
        const { showModal } = useModal();
        const [_, transition, params] = useStateTransition();
        const { hideToast } = useToast();
        const [runDeleteSphere] = useDeleteSphereMutation({
            refetchQueries: ["getSpheres"],
        });
        useEffect(() => {
            hideToast();
            return () => hideToast();
        }, [hideToast]);
        const handleDeleteSphere = useCallback(() => {
            const id = store.get(currentSphereHashesAtom)?.actionHash;
            if (!id)
                return;
            showModal({
                title: "Are you sure?",
                message: "This action cannot be undone...",
                onConfirm: () => {
                    runDeleteSphere({ variables: { id } });
                    transition("Home");
                },
                withCancel: true,
                withConfirm: true,
                destructive: true,
                confirmText: "Yes, do it",
                cancelText: "Cancel"
            });
        }, [showModal, runDeleteSphere, transition]);
        const getLayoutContent = useCallback(() => {
            switch (true) {
                case !!state.match("Onboarding"):
                    return _jsx(Onboarding, { children: component });
                case ["Home", "PreloadAndCache"].includes(state):
                    if (state === "Home") {
                        return withPageTransition(_jsx(Home, { firstVisit: newUser }), state);
                    }
                    return withPageTransition(component, state);
                case state === "Settings":
                    return withPageTransition(_jsx(SettingsLayout, { children: component }), state);
                case ["CreateOrbit", "CreateSphere"].includes(state):
                    return withPageTransition(_jsxs(FormLayout, { type: state.split('Create')[1], children: [" ", component, " "] }), state);
                case ["ListOrbits"].includes(state):
                    return withPageTransition(_jsx(ListLayout, { type: "orbit", title: currentSphereDetails?.name, primaryMenuAction: () => { }, secondaryMenuAction: handleDeleteSphere, children: component }), state);
                case state === "Vis":
                    return withPageTransition(_jsx(VisProvider, { children: _jsx(VisLayout, { title: currentSphereDetails?.name, handleDeleteSphere: handleDeleteSphere, children: component }) }), state);
                default:
                    return withPageTransition(component, state);
            }
        }, [state, component, currentSphereDetails, newUser, handleDeleteSphere]);
        return getLayoutContent();
    });
};
export default withLayout;
//# sourceMappingURL=withLayout.js.map