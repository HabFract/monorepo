import { jsx as _jsx, Fragment as _Fragment } from "react/jsx-runtime";
import Home from "../layouts/Home";
import Onboarding from "../layouts/Onboarding";
import { AnimatePresence, motion } from "framer-motion";
import { useDeleteSphereMutation } from "../../graphql/generated";
import VisLayout from "../layouts/VisLayout";
import FormLayout from "../layouts/FormLayout";
import ListLayout from "../layouts/List";
import { currentSphereHashesAtom, store } from "../../state";
import { useModal } from "../../contexts/modal";
import { AppMachine } from "../../main";
import { useStateTransition } from "../../hooks/useStateTransition";
import SettingsLayout from "../layouts/SettingsLayout";
function withPageTransition(page) {
    return (_jsx(AnimatePresence, { mode: "wait", children: _jsx(motion.div, { className: "framer-motion", initial: { opacity: 0 }, animate: { opacity: 1 }, exit: { opacity: 0 }, children: page }, +new Date()) }));
}
const withLayout = (component) => {
    return ((props) => {
        const state = AppMachine.state.currentState;
        const { showModal } = useModal();
        const [_, transition, params] = useStateTransition();
        const [runDeleteSphere, { loading: loadingDelete, error: errorDelete, data: dataDelete },] = useDeleteSphereMutation({
            refetchQueries: ["getSpheres"],
        });
        if (props?.currentSphereDetails?.eH && props.currentSphereDetails.eH !== store.get(currentSphereHashesAtom)?.entryHash) {
            const eH = props?.currentSphereDetails?.eH;
            const id = props?.currentSphereDetails?.id;
            console.log('set current Sphere to :>> ', { entryHash: eH, actionHash: id });
            store.set(currentSphereHashesAtom, id);
        }
        const handleDeleteSphere = () => {
            const id = store.get(currentSphereHashesAtom)?.actionHash;
            if (!id)
                return;
            showModal({
                title: "Are you sure?",
                message: "This action cannot be undone! This will not only delete your Space's details, but all Plannits linked to that Space, and the Win history of those Plannits!",
                onConfirm: () => {
                    runDeleteSphere({ variables: { id } });
                    transition("Home");
                },
                withCancel: true,
                withConfirm: true,
                destructive: true,
                confirmText: "Yes, do it",
                cancelText: "Cancel"
            });
        };
        switch (true) {
            case !!state.match("Onboarding"):
                return _jsx(Onboarding, { children: withPageTransition(component) });
            case ["Home", "PreloadAndCache"].includes(state):
                if (state == "Home")
                    return _jsx(Home, { firstVisit: props?.newUser });
                return withPageTransition(component);
            case state == "Settings":
                return _jsx(SettingsLayout, { children: component });
            case state == "Vis":
                return _jsx(VisLayout, { title: props.currentSphereDetails?.name, handleDeleteSphere: handleDeleteSphere, children: component });
            case ["CreateOrbit", "CreateSphere"].includes(state):
                return _jsx(FormLayout, { type: state.split('Create')[1], children: component });
            case ["ListOrbits"].includes(state):
                return _jsx(ListLayout, { type: 'orbit', title: props.currentSphereDetails?.name, primaryMenuAction: () => { }, secondaryMenuAction: () => { handleDeleteSphere(); }, children: component });
            default:
                return (_jsx(_Fragment, { children: component }));
        }
    });
};
export default withLayout;
//# sourceMappingURL=withLayout.js.map