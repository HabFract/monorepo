import { ReactNode, FC } from "react";
interface WithLayoutProps {
    currentSphereDetails: any;
    newUser: boolean;
}
declare const withLayout: (component: ReactNode) => FC<WithLayoutProps>;
export default withLayout;
//# sourceMappingURL=withLayout.d.ts.map