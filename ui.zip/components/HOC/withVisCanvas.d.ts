import { ComponentType, ReactNode } from "react";
import "../vis/vis.css";
import { VisProps, IVisualization } from "../vis/types";
export declare function withVisCanvas<T extends IVisualization>(Component: ComponentType<VisProps<T>>): ReactNode;
//# sourceMappingURL=withVisCanvas.d.ts.map