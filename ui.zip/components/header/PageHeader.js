import { jsx as _jsx } from "react/jsx-runtime";
import '../style.css';
const PageHeader = ({ title }) => (_jsx("div", { role: "heading", className: "page-header", children: _jsx("h1", { children: title }) }));
export default PageHeader;
//# sourceMappingURL=PageHeader.js.map