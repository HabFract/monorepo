import React from "react";
import "../style.css";
type PageHeaderProps = {
    title: string;
};
declare const PageHeader: React.FC<PageHeaderProps>;
export default PageHeader;
//# sourceMappingURL=PageHeader.d.ts.map