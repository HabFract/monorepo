declare const OnboardingHeader: React.ForwardRefExoticComponent<React.PropsWithoutRef<{}>>;
declare const getNextOnboardingState: (state: string) => string;
export { getNextOnboardingState };
export default OnboardingHeader;
//# sourceMappingURL=OnboardingHeader.d.ts.map