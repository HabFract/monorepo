import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { getIconSvg, HeaderAction, ProgressBar } from "habit-fract-design-system";
import { currentOrbitIdAtom } from "../../state/orbit";
import { store } from "../../state/store";
import { forwardRef } from "react";
import { currentSphereHashesAtom } from "../../state/sphere";
import { MODEL_DISPLAY_VALUES, ONBOARDING_FORM_TITLES } from "../../constants";
import { useStateTransition } from "../../hooks/useStateTransition";
const OnboardingHeader = forwardRef(({}, ref) => {
    const [state, transition, params] = useStateTransition();
    if (!state.match("Onboarding"))
        return _jsx(_Fragment, {});
    const returningUser = !!params?.spin;
    const handleBackAction = () => {
        const sphere = store.get(currentSphereHashesAtom);
        const orbit = store.get(currentOrbitIdAtom);
        const props = getLastOnboardingState(state).match("Onboarding1")
            ? { sphereToEditId: sphere?.actionHash }
            : getLastOnboardingState(state).match("Onboarding2")
                ? { sphereEh: sphere.entryHash, orbitToEditId: orbit?.id }
                : { orbitToEditId: orbit?.id };
        return transition(getLastOnboardingState(state), {
            editMode: true,
            ...props,
            ...params
        });
    };
    const currentStepNumber = +(state.match(/Onboarding(\d+)/)?.[1] || 0);
    return (_jsxs("header", { className: returningUser ? "returning-user" : "new-user", children: [_jsx(HeaderAction, { title: `Put a Plan in Motion`, icon1: getIconSvg('back'), icon2: null, handlePrimaryAction: handleBackAction }), _jsx("div", { ref: ref, children: _jsx(ProgressBar, { stepNames: !returningUser ? [
                        "Create Password",
                        `Create a ${MODEL_DISPLAY_VALUES['sphere']}`,
                        `Create a ${MODEL_DISPLAY_VALUES['orbit']}`,
                        `Break Up ${MODEL_DISPLAY_VALUES['orbit']}`,
                        "Visualise",
                    ] : [`Create a ${MODEL_DISPLAY_VALUES['sphere']}`,
                        `Create a ${MODEL_DISPLAY_VALUES['orbit']}`,
                        `Break Up ${MODEL_DISPLAY_VALUES['orbit']}`,
                        "Visualise",
                    ], currentStep: returningUser ? currentStepNumber - 1 : currentStepNumber }) }), _jsx("h1", { className: "onboarding-title", children: ONBOARDING_FORM_TITLES[currentStepNumber - 1] })] }));
});
function getLastOnboardingState(state) {
    if (state == "Onboarding1" || state.match(/Onboarding(\d+)/) == null)
        return "Home";
    return `Onboarding${+state.match(/Onboarding(\d+)/)[1] - 1}`;
}
const getNextOnboardingState = (state) => {
    if (state.match(/Onboarding(\d+)/) == null)
        return "Home";
    if (state == "Onboarding3")
        return "Vis";
    return `Onboarding${+state.match(/Onboarding(\d+)/)[1] + 1}`;
};
export { getNextOnboardingState };
export default OnboardingHeader;
//# sourceMappingURL=OnboardingHeader.js.map