import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Button, ProgressBar } from "habit-fract-design-system";
import { currentOrbitIdAtom } from "../../state/orbit";
import { store } from "../../state/store";
import BackCaret from "../icons/BackCaret";
import { forwardRef } from "react";
import { isSmallScreen } from "../vis/helpers";
import { currentSphereHashesAtom } from "../../state/sphere";
const OnboardingHeader = forwardRef(({ state, transition }, ref) => {
    if (!state.match("Onboarding"))
        return _jsx(_Fragment, {});
    return (_jsxs(_Fragment, { children: [_jsxs("div", { className: "flex w-full justify-between gap-2", children: [_jsx(Button, { type: "icon", icon: _jsx(BackCaret, {}), onClick: () => {
                            const sphere = store.get(currentSphereHashesAtom);
                            const orbit = store.get(currentOrbitIdAtom);
                            const props = getLastOnboardingState(state).match("Onboarding1")
                                ? { sphereToEditId: sphere?.actionHash }
                                : getLastOnboardingState(state).match("Onboarding2")
                                    ? { sphereEh: sphere.entryHash, orbitToEditId: orbit?.id }
                                    : { orbitToEditId: orbit?.id };
                            return transition(getLastOnboardingState(state), {
                                editMode: true,
                                ...props,
                            });
                        } }), _jsx("h1", { className: "onboarding-title", children: "Make a Positive Habit" })] }), _jsx("div", { ref: ref, children: _jsx(ProgressBar, { stepNames: isSmallScreen()
                        ? [
                            "Welcome",
                            "Create Sphere",
                            "Create Orbit",
                            "Refine Orbit",
                            "Visualize",
                        ]
                        : [
                            "Create Profile (N/A)",
                            "Create Sphere",
                            "Create Orbit",
                            "Refine Orbit",
                            "Visualize",
                        ], currentStep: +(state.match(/Onboarding(\d+)/)?.[1] || 0) }) })] }));
});
function getLastOnboardingState(state) {
    if (state == "Onboarding1" || state.match(/Onboarding(\d+)/) == null)
        return "Home";
    return `Onboarding${+state.match(/Onboarding(\d+)/)[1] - 1}`;
}
const getNextOnboardingState = (state) => {
    if (state.match(/Onboarding(\d+)/) == null)
        return "Home";
    if (state == "Onboarding3")
        return "PreloadAndCache";
    return `Onboarding${+state.match(/Onboarding(\d+)/)[1] + 1}`;
};
export { getNextOnboardingState };
export default OnboardingHeader;
//# sourceMappingURL=OnboardingHeader.js.map