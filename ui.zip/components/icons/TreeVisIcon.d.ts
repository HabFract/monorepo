import "../style.css";
declare const _default: () => import("react/jsx-runtime").JSX.Element;
export default _default;
//# sourceMappingURL=TreeVisIcon.d.ts.map