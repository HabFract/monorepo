declare const _default: () => import("react/jsx-runtime").JSX.Element;
export default _default;
//# sourceMappingURL=Split.d.ts.map