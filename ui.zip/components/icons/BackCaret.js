import { jsx as _jsx } from "react/jsx-runtime";
export default () => (_jsx("svg", { xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "-12 -12 48 48", strokeWidth: "1.5", stroke: "currentColor", className: "icon", children: _jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", d: "M9 15 3 9m0 0 6-6M3 9h12a6 6 0 0 1 0 12h-3" }) }));
//# sourceMappingURL=BackCaret.js.map