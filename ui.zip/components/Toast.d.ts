import React from "react";
declare const Toast: React.FC;
export default Toast;
//# sourceMappingURL=Toast.d.ts.map