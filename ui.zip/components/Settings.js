import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { Button, ActionCard } from "habit-fract-design-system";
import { useState } from "react";
import "./style.css";
import "../typo.css";
import { useAtom, useSetAtom } from "jotai";
import { nodeCache } from "../state/store";
import { useStateTransition } from "../hooks/useStateTransition";
import { useDeleteSphereMutation, useGetSpheresQuery, } from "../graphql/generated";
import { extractEdges } from "../graphql/utils";
import { sleep } from "./lists/OrbitSubdivisionList";
import { ask } from "@tauri-apps/plugin-dialog";
import { checkForAppUpdates } from "../update";
import { isSmallScreen } from "./vis/helpers";
import { DataLoadingQueue } from "./PreloadAllData";
import { handednessAtom, performanceModeAtom } from "@state/ui";
const Settings = ({}) => {
    const [_, transition] = useStateTransition();
    const clear = useSetAtom(nodeCache.clear);
    const [isDeleting, setIsDeleting] = useState(false);
    const [handedness, setHandedness] = useAtom(handednessAtom);
    const [performanceMode, setPerformanceMode] = useAtom(performanceModeAtom);
    const { loading: loadingSpheres, error, data: spheresData, } = useGetSpheresQuery();
    const sphereNodes = spheresData?.spheres?.edges && extractEdges(spheresData.spheres);
    const [runDelete, { loading: loadingDelete, error: errorDelete, data: dataDelete },] = useDeleteSphereMutation({
        refetchQueries: ["getSpheres"]
    });
    const deleteAllData = async () => {
        try {
            if (!sphereNodes || sphereNodes.length == 0)
                return;
            const deletionQueue = new DataLoadingQueue();
            setIsDeleting(true);
            clear();
            for (const sphere of sphereNodes) {
                await deletionQueue.enqueue(async () => {
                    console.log(`Deleting sphere: ${sphere.name}`);
                    const result = await runDelete({
                        variables: { id: sphere.id }
                    });
                    console.log('Delete mutation result:', {
                        sphere: sphere.name,
                        result,
                        error: errorDelete
                    });
                    await sleep(500);
                });
            }
            await deletionQueue.enqueue(async () => {
                console.log('All spheres deleted, cleaning up...');
                clear();
                await sleep(500);
            });
        }
        catch (error) {
            console.error('Error during deletion:', error);
        }
        finally {
            setIsDeleting(false);
        }
    };
    return (_jsxs(_Fragment, { children: [_jsx("section", { children: _jsx(ActionCard, { title: "Handedness", body: "Choose your preferred handedness for the UI.", variant: "button", button: _jsxs("div", { className: "button-group", children: [_jsx(Button, { variant: handedness === 'left' ? "primary" : "secondary", onClick: () => setHandedness('left'), children: "Left" }), _jsx(Button, { variant: handedness === 'right' ? "primary" : "secondary", onClick: () => setHandedness('right'), children: "Right" })] }) }) }), _jsxs("section", { children: [!isSmallScreen() && (_jsx(ActionCard, { title: "Check/Download", body: "Check for Updates", variant: "button", button: _jsx(Button, { onClick: () => checkForAppUpdates(true), variant: "primary responsive", type: "button", children: "Check" }) })), _jsx(ActionCard, { title: "Clear Cache", body: "Clear cache to reset tracked data, improve app speed, and free storage.", variant: "button", button: _jsx(Button, { onClick: () => {
                                clear();
                                transition("PreloadAndCache");
                            }, variant: "primary responsive", type: "button", children: "Clear" }) }), _jsx(ActionCard, { title: "Bugs/Feedback", body: `Report bugs or send feedback to help enhance your app experience and performance.`, variant: "button", button: _jsx(Button, { variant: "primary responsive", type: "button", onClick: ((e) => {
                                e.currentTarget.querySelector("a")?.click();
                            }), children: _jsx("a", { href: "https://habitfract.net/feedback/", className: "text-white", children: "Open Feedback Form" }) }) })] }), _jsx("section", { className: "danger-zone", children: _jsx(ActionCard, { title: "Delete All Data", body: "Reset your all data, removing all tracked progress and settings.", variant: "button", button: _jsx(Button, { isLoading: isDeleting, onClick: () => {
                            ask(`Reset data?`, {
                                title: "Confirm Resetting Data",
                                kind: "info",
                                okLabel: "Reset",
                                cancelLabel: "Cancel",
                            }).then((confirm) => {
                                if (confirm)
                                    deleteAllData();
                                transition("Home");
                            });
                        }, variant: "danger responsive outlined", type: "button", children: "Delete" }) }) })] }));
};
export default Settings;
//# sourceMappingURL=Settings.js.map