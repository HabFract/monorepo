import { SphereHashes } from "../state/types/sphere";
import { IVisualization } from "./vis/types";
export default function VisModal<T extends IVisualization>(isModalOpen: boolean, setIsModalOpen: React.Dispatch<React.SetStateAction<boolean>>, selectedSphere: SphereHashes, currentParentOrbitEh: string | undefined, currentChildOrbitEh: string | undefined, resetModalParentChildStates: () => void, setIsAppendingNode: any, currentVis: T): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=VisModal.d.ts.map