import React from "react";
import { ActionHashB64, EntryHashB64 } from "@holochain/client";
interface PreloadAllDataProps {
    landingSphereEh?: EntryHashB64;
    landingSphereId?: ActionHashB64;
    landingPage?: string;
    onPreloadComplete?: () => void;
}
export declare class DataLoadingQueue {
    private queue;
    private isProcessing;
    private taskId;
    enqueue(task: () => Promise<void>): Promise<void>;
    private processQueue;
}
declare const _default: React.NamedExoticComponent<PreloadAllDataProps>;
export default _default;
//# sourceMappingURL=PreloadAllData.d.ts.map