import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Modal } from "flowbite-react";
import { currentSphereOrbitNodeDetailsAtom } from "../state/orbit";
import { store } from "../state/store";
import { CreateOrbit } from "./forms";
export default function VisModal(isModalOpen, setIsModalOpen, selectedSphere, currentParentOrbitEh, currentChildOrbitEh, currentVis) {
    return (_jsxs(Modal, { show: isModalOpen, onClose: () => {
            setIsModalOpen(false);
        }, children: [_jsx(Modal.Header, { children: "Create Orbit" }), _jsx(Modal.Body, { children: _jsx(CreateOrbit, { editMode: false, inModal: true, sphereEh: selectedSphere.entryHash, parentOrbitEh: currentParentOrbitEh, childOrbitEh: currentChildOrbitEh, onCreateSuccess: () => {
                        setIsModalOpen(false);
                        currentVis.isModalOpen = false;
                        currentVis.nodeDetails = store.get(currentSphereOrbitNodeDetailsAtom);
                        setTimeout(() => {
                            currentVis.render();
                        }, 240);
                    } }) })] }));
}
//# sourceMappingURL=VisModal.js.map