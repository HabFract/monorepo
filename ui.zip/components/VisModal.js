import { jsxs as _jsxs, jsx as _jsx } from "react/jsx-runtime";
import { Modal } from "flowbite-react";
import { currentSphereOrbitNodeDetailsAtom } from "../state/orbit";
import { store } from "../state/store";
import { CreateOrbit } from "./forms";
import { useStateTransition } from "../hooks/useStateTransition";
export default function VisModal(isModalOpen, setIsModalOpen, selectedSphere, currentParentOrbitEh, currentChildOrbitEh, resetModalParentChildStates, setIsAppendingNode, currentVis) {
    const [_, transition, params] = useStateTransition();
    const editingParent = !!(currentParentOrbitEh && (currentChildOrbitEh == 'edit'));
    return (_jsxs(Modal, { size: "xl", show: isModalOpen, onClose: () => {
            setIsModalOpen(false);
            resetModalParentChildStates();
        }, children: [_jsxs(Modal.Header, { children: [editingParent ? "Update" : "Add", " Planitt"] }), _jsx(Modal.Body, { children: _jsx(CreateOrbit, { editMode: editingParent, inModal: true, sphereEh: selectedSphere.entryHash, parentOrbitEh: !editingParent ? currentParentOrbitEh : "", orbitToEditId: editingParent ? currentParentOrbitEh : undefined, childOrbitEh: currentChildOrbitEh, onCreateSuccess: () => {
                        setIsModalOpen(false);
                        currentVis.isModalOpen = false;
                        currentVis.nodeDetails = store.get(currentSphereOrbitNodeDetailsAtom);
                        setIsAppendingNode(true);
                    } }) })] }));
}
//# sourceMappingURL=VisModal.js.map