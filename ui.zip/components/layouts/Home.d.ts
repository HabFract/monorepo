import './common.css';
declare function HomeLayout({ firstVisit }: any): import("react/jsx-runtime").JSX.Element;
export default HomeLayout;
//# sourceMappingURL=Home.d.ts.map