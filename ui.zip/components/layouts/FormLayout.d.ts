import './common.css';
interface FormLayoutProps {
    children: React.ReactNode;
    type: string;
}
declare const FormLayout: import("react").MemoExoticComponent<({ children, type }: FormLayoutProps) => import("react/jsx-runtime").JSX.Element>;
export default FormLayout;
//# sourceMappingURL=FormLayout.d.ts.map