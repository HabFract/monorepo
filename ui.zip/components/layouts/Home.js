import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Field, Form, Formik } from 'formik';
import './common.css';
import { useStateTransition } from '../../hooks/useStateTransition';
import { object, string } from 'yup';
import { Button, getIconSvg, SwipeUpScreenTab, TextInputField } from 'habit-fract-design-system';
import { ListSpheres } from '../lists';
import { motion } from 'framer-motion';
import { Popover, ListGroup } from 'flowbite-react';
import { BUTTON_ACTION_TEXT, ERROR_MESSAGES, INPUT_INFO_MODALS, PAGE_COPY } from '../../constants';
function HomeLayout({ firstVisit = true }) {
    const [_, transition] = useStateTransition();
    const validationSchema = object({
        password: string()
            .min(8, ERROR_MESSAGES['password-short'])
            .max(18, ERROR_MESSAGES['password-long'])
            .required(ERROR_MESSAGES['password-empty'])
    });
    const routeToSettings = () => transition("Settings");
    return (_jsxs("section", { className: "home-layout", children: [firstVisit
                ? _jsxs("header", { className: "welcome-cta", children: [_jsx("img", { className: "logo", src: "assets/logo.svg", alt: 'Planitt logo' }), _jsx("h2", { children: PAGE_COPY['slogan'] }), _jsx("div", { className: "flex items-center justify-center w-full gap-4", children: [1, 2, 3, 4, 5].map(num => _jsx("img", { src: `/assets/icons/sphere-symbol-${num}.svg` }, num)) })] })
                : _jsxs("header", { className: "returning-cta", children: [_jsxs("div", { children: [_jsx("img", { className: "logo", src: "assets/logo.svg", alt: 'Planitt logo' }), _jsx("div", { className: "avatar-menu mt-2", children: _jsx(Popover, { content: _jsxs(ListGroup, { className: "list-group-override w-32", children: [_jsx(ListGroup.Item, { disabled: true, onClick: () => { }, icon: getIconSvg('user'), children: "Profile" }), _jsx(ListGroup.Item, { onClick: routeToSettings, icon: getIconSvg('settings'), children: "Settings" })] }), children: _jsx(Button, { type: 'button', variant: 'circle-icon-lg', children: _jsx("img", { src: "assets/icons/avatar-placeholder.svg", alt: 'Avatar Placeholder' }) }) }) })] }), _jsxs("span", { children: [_jsx("h1", { children: "Welcome back! \uD83D\uDC4B" }), _jsxs("h2", { children: [PAGE_COPY['slogan'], " ", _jsx("em", { children: "Plan to..." })] })] }), _jsxs("div", { className: "text-text dark:text-text-dark flex justify-around h-12 gap-4", children: [_jsxs(Button, { onClick: () => { transition("Onboarding1", { spin: 'positive' }); }, type: "button", variant: "primary responsive", children: [_jsx("svg", { className: "w-6 h-6 my-1 mr-2", width: "18", height: "18", viewBox: "0 0 18 18", fill: "none", xmlns: "http://www.w3.org/2000/svg", children: _jsx("path", { fillRule: "evenodd", clipRule: "evenodd", d: "M17.3333 9C17.3333 13.6024 13.6024 17.3333 8.99999 17.3333C4.39762 17.3333 0.666656 13.6024 0.666656 9C0.666656 4.39763 4.39762 0.666666 8.99999 0.666666C13.6024 0.666666 17.3333 4.39763 17.3333 9ZM8.99999 4.91667C9.4142 4.91667 9.74999 5.25245 9.74999 5.66667V8.25H12.3333C12.7475 8.25 13.0833 8.58579 13.0833 9C13.0833 9.41421 12.7475 9.75 12.3333 9.75H9.74999V12.3333C9.74999 12.7475 9.4142 13.0833 8.99999 13.0833C8.58578 13.0833 8.24999 12.7475 8.24999 12.3333V9.75H5.66666C5.25244 9.75 4.91666 9.41421 4.91666 9C4.91666 8.58579 5.25244 8.25 5.66666 8.25H8.24999V5.66667C8.24999 5.25245 8.58578 4.91667 8.99999 4.91667Z", fill: "white" }) }), BUTTON_ACTION_TEXT['positive-spin-cta']] }), _jsxs(Button, { isDisabled: true, onClick: () => { transition("CreateSphere", { spin: 'negative' }); }, type: "button", variant: "secondary responsive", children: [_jsx("svg", { className: 'w-6 h-6 my-1 mr-2', width: "18", height: "18", viewBox: "0 0 18 18", fill: "none", xmlns: "http://www.w3.org/2000/svg", children: _jsx("path", { fillRule: "evenodd", clipRule: "evenodd", d: "M8.99998 17.3333C13.6024 17.3333 17.3333 13.6023 17.3333 8.99997C17.3333 4.39758 13.6024 0.666615 8.99998 0.666615C4.39759 0.666615 0.666626 4.39758 0.666626 8.99997C0.666626 13.6023 4.39759 17.3333 8.99998 17.3333ZM12.3333 9.74994C12.7475 9.74994 13.0833 9.41415 13.0833 8.99994C13.0833 8.58573 12.7475 8.24994 12.3333 8.24994L5.66666 8.24994C5.25245 8.24994 4.91666 8.58573 4.91666 8.99994C4.91666 9.41415 5.25245 9.74994 5.66666 9.74994L12.3333 9.74994Z", fill: "white" }) }), BUTTON_ACTION_TEXT['negative-spin-cta']] })] })] }), firstVisit
                ? _jsx("div", { className: "login-options", children: _jsx(Formik, { initialValues: { password: "password" }, validationSchema: validationSchema, onSubmit: (values, { setSubmitting }) => {
                            try {
                                if (values.password) {
                                    transition("Onboarding1");
                                }
                            }
                            catch (error) {
                                console.error(error);
                            }
                            finally {
                                setSubmitting(false);
                            }
                        }, children: ({ isSubmitting, submitForm }) => {
                            return _jsxs(Form, { noValidate: true, children: [_jsxs("div", { className: "form-field gap-8", children: [_jsx(Field, { disabled: true, component: TextInputField, size: "base", name: "password", id: "password", withInfo: true, isPassword: true, onClickInfo: () => INPUT_INFO_MODALS['password'], required: true, labelValue: "Password:", placeholder: INPUT_INFO_MODALS['password'].placeholder }), _jsx(Button, { type: "button", isDisabled: isSubmitting, variant: "primary responsive", onClick: () => submitForm(), children: "Sign In" })] }), _jsxs("div", { className: "text-text dark:text-text-dark opacity-80 flex items-center justify-center gap-8 mt-2 text-base text-center", children: [_jsxs("div", { children: [_jsx("h3", { children: "Powered by" }), _jsx("img", { className: "w-80", src: "assets/holochain-logo.png", alt: 'Holochain logo' })] }), _jsx("p", { children: PAGE_COPY['password-notice'] })] })] });
                        } }) })
                :
                    _jsx(SwipeUpScreenTab, { verticalOffset: (12 * 16) + 8, useViewportHeight: false, children: ({ bindDrag }) => (_jsxs(motion.div, { ...bindDrag, className: "spaces-tab", children: [_jsx(motion.div, { className: "handle", ...bindDrag, style: { touchAction: 'none', cursor: 'grab' }, children: _jsx("span", {}) }), _jsx(ListSpheres, {})] })) })] }));
}
export default HomeLayout;
//# sourceMappingURL=Home.js.map