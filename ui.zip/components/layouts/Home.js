import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
function HomeLayout({ startBtn, firstVisit = true }) {
    return (_jsxs("div", { className: "home-layout", children: [_jsx("div", { className: "action", children: firstVisit && startBtn }), _jsxs("div", { className: "cta", children: [_jsx("img", { className: "w-64 pl-2 mb-2", src: "assets/logo-dark-transparent-horizontal.svg" }), _jsx("img", { className: "make-or-break-img", src: "assets/make-or-break.svg" }), _jsx("img", { className: firstVisit ? "spheres-girl-img" : "spheres-girl-img indented", src: "assets/home-life-spheres-girl.svg" })] })] }));
}
export default HomeLayout;
//# sourceMappingURL=Home.js.map