import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useStateTransition } from '../../hooks/useStateTransition';
import { MODEL_DISPLAY_VALUES } from '../../constants';
import './common.css';
import { getIconSvg, HeaderAction } from 'habit-fract-design-system';
import { memo, useCallback } from 'react';
const FormLayout = memo(({ children, type }) => {
    const [_, transition, params, __, goBack] = useStateTransition();
    const routeBack = useCallback(() => {
        if (!goBack()) {
            transition("Home");
        }
    }, [goBack, transition]);
    const title = `${params.editMode ? "Update" : "Add"} ${MODEL_DISPLAY_VALUES[type.toLowerCase()]}`;
    return (_jsxs("div", { className: "form-layout", children: [_jsx("div", { className: "header-action", children: _jsx(HeaderAction, { title: title, icon1: getIconSvg('back'), icon2: null, handlePrimaryAction: routeBack }) }), _jsx("div", { className: "form-content", children: children })] }));
});
FormLayout.displayName = 'FormLayout';
export default FormLayout;
//# sourceMappingURL=FormLayout.js.map