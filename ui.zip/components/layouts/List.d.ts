import './common.css';
interface ListLayoutProps {
    children: React.ReactNode;
    type: string;
    title?: string;
    primaryMenuAction: () => void;
    secondaryMenuAction: () => void;
}
declare const ListLayout: import("react").MemoExoticComponent<({ children, type, title, primaryMenuAction, secondaryMenuAction }: ListLayoutProps) => import("react/jsx-runtime").JSX.Element>;
export default ListLayout;
//# sourceMappingURL=List.d.ts.map