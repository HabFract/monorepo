import './common.css';
declare function OnboardingLayout({ children }: any): import("react/jsx-runtime").JSX.Element;
export default OnboardingLayout;
//# sourceMappingURL=Onboarding.d.ts.map