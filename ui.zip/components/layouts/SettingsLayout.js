import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useStateTransition } from '../../hooks/useStateTransition';
import './common.css';
import { getIconSvg, HeaderAction } from 'habit-fract-design-system';
function SettingsLayout({ children }) {
    const [state, transition, params] = useStateTransition();
    return (_jsxs("div", { className: "settings-layout", children: [_jsx("div", { className: "header-action", children: _jsx(HeaderAction, { title: "Settings", icon1: getIconSvg('back'), icon2: null, handlePrimaryAction: () => transition("Home") }) }), children] }));
}
export default SettingsLayout;
//# sourceMappingURL=SettingsLayout.js.map