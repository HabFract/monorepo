import './common.css';
declare function SettingsLayout({ children }: any): import("react/jsx-runtime").JSX.Element;
export default SettingsLayout;
//# sourceMappingURL=SettingsLayout.d.ts.map