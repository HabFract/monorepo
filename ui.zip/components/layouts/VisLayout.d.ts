import './common.css';
declare function VisLayout({ children, title, handleDeleteSphere }: any): import("react/jsx-runtime").JSX.Element;
export default VisLayout;
//# sourceMappingURL=VisLayout.d.ts.map