import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { ListGroup } from 'flowbite-react';
import { useStateTransition } from '../../hooks/useStateTransition';
import './common.css';
import { getIconSvg, HeaderAction } from 'habit-fract-design-system';
import { useCallback, useMemo } from 'react';
function VisLayout({ children, title, handleDeleteSphere }) {
    const [_, transition, params, __, goBack, history] = useStateTransition();
    const routeToCreatePlanitt = useCallback((sphereEh) => {
        transition("CreateOrbit", { sphereEh, editMode: false });
    }, [title, transition]);
    const routeToPlanittList = useCallback((currentSphereDetails) => {
        transition("ListOrbits", { sphereAh: currentSphereDetails.id, currentSphereDetails });
    }, [title, transition]);
    const routeBack = useCallback(() => {
        if (!history[0] || (history[0]?.state).match("PreloadAndCache") || (history[0]?.state).match("Onboarding") || (history[0]?.state == 'Vis') || !goBack()) {
            transition("Home");
        }
    }, [history, goBack, transition]);
    const actionMenu = useMemo(() => (_jsxs(ListGroup, { className: "no-auto-focus list-group-override w-48", children: [_jsx(ListGroup.Item, { onClick: () => routeToPlanittList(params.currentSphereDetails), icon: getIconSvg('list'), children: "List Planitts" }), _jsx(ListGroup.Item, { onClick: () => routeToCreatePlanitt(params.currentSphereDetails.eH), icon: getIconSvg('plus'), children: "Add Planitt" }), _jsx("span", { className: "list-item-danger text-danger", children: _jsx(ListGroup.Item, { onClick: handleDeleteSphere, color: "danger", icon: getIconSvg('trash'), children: "Delete Space" }) })] })), [params.currentSphereDetails, routeToPlanittList]);
    return (_jsxs("div", { className: "vis-layout", children: [_jsx("div", { className: "header-action", children: _jsx(HeaderAction, { title: title, icon1: getIconSvg('back'), icon2: getIconSvg('more'), handlePrimaryAction: routeBack, secondaryActionPopoverElement: actionMenu }) }), children] }));
}
export default VisLayout;
//# sourceMappingURL=VisLayout.js.map