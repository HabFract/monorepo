import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import './common.css';
import { getIconSvg, HeaderAction } from 'habit-fract-design-system';
function VisLayout({ children, currentSphereName, transition }) {
    return (_jsxs("div", { className: "vis-layout", children: [_jsx("div", { className: "header-action", children: _jsx(HeaderAction, { title: currentSphereName, icon1: getIconSvg('back'), icon2: getIconSvg('more'), handlePrimaryAction: () => transition("Home"), handleSecondaryAction: () => transition("LisSpheres") }) }), children] }));
}
export default VisLayout;
//# sourceMappingURL=VisLayout.js.map