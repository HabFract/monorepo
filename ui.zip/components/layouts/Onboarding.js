import { jsx as _jsx } from "react/jsx-runtime";
import './common.css';
function OnboardingLayout({ children }) {
    return (_jsx("div", { className: "onboarding-layout", children: _jsx("div", { className: "container", children: children }) }));
}
export default OnboardingLayout;
//# sourceMappingURL=Onboarding.js.map