import { jsx as _jsx } from "react/jsx-runtime";
function OnboardingLayout({ children }) {
    return (_jsx("div", { className: "onboarding-layout", children: _jsx("div", { className: "flex flex-col flex-around w-full", children: children }) }));
}
export default OnboardingLayout;
//# sourceMappingURL=Onboarding.js.map