import { Fragment as _Fragment, jsx as _jsx } from "react/jsx-runtime";
const TreeRenderer = ({ tree, render }) => {
    if (!tree || !tree.rootData) {
        return null;
    }
    try {
        return _jsx(_Fragment, { children: render(tree) });
    }
    catch (error) {
        console.error('Error rendering tree:', error);
        return null;
    }
};
export default TreeRenderer;
//# sourceMappingURL=TreeRenderer.js.map