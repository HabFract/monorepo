import { Fragment as _Fragment, jsx as _jsx } from "react/jsx-runtime";
const TreeRenderer = ({ tree, render }) => {
    return _jsx(_Fragment, { children: render(tree) });
};
export default TreeRenderer;
//# sourceMappingURL=TreeRenderer.js.map