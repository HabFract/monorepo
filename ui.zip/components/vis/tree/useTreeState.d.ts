import { TreeVisualization } from "../base-classes/TreeVis";
export declare const useTreeState: () => {
    currentOrbitTree: TreeVisualization | null;
    currentOrbitTreeRef: import("react").MutableRefObject<TreeVisualization | null>;
    setCurrentOrbitTree: (tree: TreeVisualization | null) => void;
};
//# sourceMappingURL=useTreeState.d.ts.map