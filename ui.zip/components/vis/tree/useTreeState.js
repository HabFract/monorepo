import { useState, useRef } from 'react';
export const useTreeState = () => {
    const [currentOrbitTree, setCurrentOrbitTreeState] = useState(null);
    const currentOrbitTreeRef = useRef(null);
    const setCurrentOrbitTree = (tree) => {
        currentOrbitTreeRef.current = tree;
        setCurrentOrbitTreeState(tree);
    };
    return {
        currentOrbitTree,
        currentOrbitTreeRef,
        setCurrentOrbitTree
    };
};
//# sourceMappingURL=useTreeState.js.map