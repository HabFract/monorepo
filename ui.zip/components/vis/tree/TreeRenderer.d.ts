import React from 'react';
import { TreeVisualization } from "../base-classes/TreeVis";
interface TreeRendererProps {
    tree: TreeVisualization;
    render: (tree: TreeVisualization) => React.ReactNode;
}
declare const TreeRenderer: React.FC<TreeRendererProps>;
export default TreeRenderer;
//# sourceMappingURL=TreeRenderer.d.ts.map