export declare const useD3Dependencies: () => {
    d3Modules: {
        hierarchy: typeof import("d3-hierarchy").hierarchy;
        select: typeof import("d3-selection").select;
    } | null;
    isLoading: boolean;
    error: Error | null;
};
//# sourceMappingURL=useD3Deps.d.ts.map