import React from 'react';
import { TreeVisualization } from "../base-classes/TreeVis";
interface TreeVisCoreProps {
    currentOrbitTree: TreeVisualization | null;
    loading: boolean;
    error: any;
    json: string | null;
    render: (tree: TreeVisualization) => React.ReactNode;
}
export declare const TreeVisCore: React.FC<TreeVisCoreProps>;
export {};
//# sourceMappingURL=TreeVisCore.d.ts.map