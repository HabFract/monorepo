import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { lazy, Suspense } from 'react';
const LazyTreeRenderer = lazy(() => import('./TreeRenderer'));
export const TreeVisCore = ({ currentOrbitTree, loading, error, json, render }) => {
    if (loading)
        return _jsx("span", { "data-testid": "loading-tree" });
    if (error || !json && currentOrbitTree && !currentOrbitTree?.rootData) {
        return _jsxs("div", { className: "top-10 warning-message fixed flex flex-col items-center justify-center w-full h-full gap-4 pb-48", children: [_jsx("img", { className: "mb-2", src: "assets/icons/warning-icon.svg", alt: "warning icon" }), _jsxs("h1", { children: ["There are no Planitts", _jsx("br", {}), " in this System"] }), _jsx("h2", { children: "Add a Planitt to start tracking your behaviour" })] });
    }
    return (_jsx(_Fragment, { children: !error && json && currentOrbitTree && (_jsx(Suspense, { fallback: _jsx(_Fragment, {}), children: _jsx(LazyTreeRenderer, { tree: currentOrbitTree, render: render }) })) }));
};
//# sourceMappingURL=TreeVisCore.js.map