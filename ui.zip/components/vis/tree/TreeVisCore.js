import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { lazy, Suspense } from 'react';
import { SpinnerFallback } from 'habit-fract-design-system';
import { motion, AnimatePresence } from "framer-motion";
import { ErrorBoundary } from 'react-error-boundary';
import { useEffect } from 'react';
import { useState } from 'react';
const LazyTreeRenderer = lazy(() => import('./TreeRenderer'));
const ErrorFallback = () => (_jsxs(motion.div, { initial: { opacity: 0 }, animate: { opacity: 1 }, exit: { opacity: 0 }, transition: { duration: 1 }, className: "flex flex-col items-center justify-center w-full h-full", children: [_jsx("h2", { children: "Something went wrong rendering the tree." }), _jsx("button", { onClick: () => window.location.reload(), children: "Try again" })] }, "error"));
const WarningMessage = () => (_jsxs(motion.div, { initial: { opacity: 0 }, animate: { opacity: 1 }, exit: { opacity: 0 }, transition: { duration: 1 }, className: "top-10 warning-message fixed flex flex-col items-center justify-center w-full h-full gap-4 pb-48", children: [_jsx("img", { className: "mb-2", src: "assets/icons/warning-icon.svg", alt: "warning icon" }), _jsxs("h1", { children: ["There are no Planitts", _jsx("br", {}), " in this System"] }), _jsx("h2", { children: "Add a Planitt to start tracking your behaviour" })] }, "warning"));
export const TreeVisCore = ({ currentOrbitTree, loading, error, json, render }) => {
    const [isMounted, setIsMounted] = useState(false);
    useEffect(() => {
        setIsMounted(true);
        return () => setIsMounted(false);
    }, []);
    return (_jsx(ErrorBoundary, { FallbackComponent: ErrorFallback, children: _jsx("div", { className: "relative w-full h-full", children: _jsx(AnimatePresence, { mode: "wait", children: loading && isMounted ? (_jsx(motion.div, { initial: { opacity: 0 }, animate: { opacity: 1 }, exit: { opacity: 0 }, transition: {
                        duration: 0.2,
                        ease: "easeInOut"
                    }, className: "absolute inset-0 flex items-center justify-center", children: _jsx(SpinnerFallback, {}) }, "loading-container")) : error || (!json && currentOrbitTree && !currentOrbitTree?.rootData) ? (_jsx(WarningMessage, {})) : !error && json && currentOrbitTree && isMounted ? (_jsx(motion.div, { initial: { opacity: 0 }, animate: { opacity: 1 }, exit: { opacity: 0 }, transition: {
                        duration: 2,
                        ease: "easeInOut"
                    }, className: "absolute inset-0", children: _jsx(Suspense, { fallback: _jsx(motion.div, { initial: { opacity: 0 }, animate: { opacity: 1 }, exit: { opacity: 0 }, transition: { duration: 0.2 }, className: "w-full h-full flex items-center justify-center", children: _jsx(SpinnerFallback, {}) }, "suspense-fallback"), children: _jsx(LazyTreeRenderer, { tree: currentOrbitTree, render: render }) }) }, "tree-container")) : null }) }) }));
};
//# sourceMappingURL=TreeVisCore.js.map