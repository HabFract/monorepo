import { EntryHashB64 } from "@state/types";
import { HierarchyNode } from "d3-hierarchy";
import { Selection } from "d3-selection";
import { D3ZoomEvent, ZoomBehavior } from "d3-zoom";
import { SphereOrbitNodeDetails } from "../../state/types/sphere";
import { NodeContent } from "../../state";
export declare enum VisType {
    Tree = "Tree",
    Cluster = "Cluster",
    Radial = "Radial"
}
export declare enum VisCoverage {
    Partial = "partial",
    CompleteOrbit = "complete-orbit",
    CompleteSphere = "complete-sphere"
}
export type WithVisCanvasProps = {};
export interface IVisualization {
    type: VisType;
    coverageType: VisCoverage;
    _svgId: string;
    rootData: HierarchyNode<NodeContent> | null;
    _viewConfig: ViewConfig;
    _zoomConfig: ZoomConfig;
    eventHandlers: EventHandlers;
    _hasRendered: boolean;
    _lastOrbitId: EntryHashB64 | null;
    modalOpen?: React.Dispatch<React.SetStateAction<boolean>>;
    isModalOpen: boolean;
    modalParentOrbitEh: React.Dispatch<React.SetStateAction<EntryHashB64 | undefined>>;
    modalChildOrbitEh: React.Dispatch<React.SetStateAction<EntryHashB64 | undefined>>;
    nodeDetails: SphereOrbitNodeDetails;
    skipMainRender: boolean;
    setNodeAndLinkGroups: () => void;
    setNodeAndLinkEnterSelections: () => void;
    setNodeAndLabelGroups: () => void;
    appendNodeVectors: () => void;
    appendLinkPath: () => void;
    bindEventHandlers: () => void;
    unbindEventHandlers: () => void;
    applyInitialTransform: () => void;
    initializeZoomConfig: () => ZoomConfig;
    initializeZoomer: () => ZoomBehavior<Element, unknown> | null;
    handleZoom: (event: MouseEvent) => void;
    render: () => void;
    destroy(): void;
}
export type VisProps<T extends IVisualization> = {
    canvasHeight: number;
    canvasWidth: number;
    margin: Margins;
    render: (currentVis: T) => React.ReactNode;
};
export interface EventHandlers {
    handleEditNode: ({ orbitEh }: {
        orbitEh: EntryHashB64;
    }) => void;
    handlePrependNode: ({ childOrbitEh }: {
        childOrbitEh: EntryHashB64;
    }) => void;
    handleAppendNode: ({ parentOrbitEh, }: {
        parentOrbitEh: EntryHashB64;
    }) => void;
    handleDeleteNode?: (event: React.MouseEvent, node: HierarchyNode<unknown>) => void;
    handleNodeZoom: (event: D3ZoomEvent<SVGSVGElement, unknown>, node: HierarchyNode<unknown>, forParent?: boolean) => Selection<SVGGElement, HierarchyNode<any>, SVGGElement, unknown> | null;
    memoizedhandleNodeZoom: (id: EntryHashB64, foundNode?: HierarchyNode<NodeContent>) => Selection<SVGGElement, HierarchyNode<any>, SVGGElement, unknown> | null;
    handleZoomOut: (event: D3ZoomEvent<SVGSVGElement, unknown>, node: HierarchyNode<unknown>, forParent?: boolean) => void;
    handleNodeFocus?: (event: React.MouseEvent, node: HierarchyNode<unknown>) => void;
    handleNodeClick?: (event: React.MouseEvent, node: HierarchyNode<unknown>) => void;
}
export interface ViewConfig {
    dx?: number;
    dy?: number;
    scale: number;
    margin: Margins;
    viewportX?: number;
    viewportY?: number;
    viewportW?: number;
    viewportH?: number;
    canvasHeight: number;
    canvasWidth: number;
    levelsHigh?: number;
    levelsWide?: number;
    defaultCanvasTranslateX: () => number;
    defaultCanvasTranslateY: () => number;
    isSmallScreen: () => boolean;
    defaultView: string;
}
export type Margins = {
    top: number;
    right: number;
    bottom: number;
    left: number;
};
export interface ZoomConfig {
    focusMode: boolean;
    previousRenderZoom: {
        event?: D3ZoomEvent<SVGSVGElement, unknown>;
        node?: HierarchyNode<NodeContent>;
        scale?: number;
    };
    zoomedInView: () => boolean;
    globalZoomScale?: number;
}
//# sourceMappingURL=types.d.ts.map