import { EntryHashB64 } from "@state/types";
import { hierarchy } from "d3-hierarchy";
import { OrbitHierarchyQueryParams } from "../../graphql/generated";
import { Frequency } from "../../state";
import { TreeVisualization } from "./base-classes/TreeVis";
import { VisCoverage } from "./types";
export declare const toYearDotMonth: (date: string) => string;
export declare const isMoreThenDaily: (frequency: Frequency.Rationals) => boolean;
export declare const loadD3Dependencies: () => Promise<{
    hierarchy: typeof hierarchy;
    select: typeof import("d3-selection").select;
}>;
export declare const curves: {
    curveCustomBezier: (context: any) => any;
};
export declare const getScaleForPlanet: (scale: any) => 2 | 0.8 | 1.75 | undefined;
export declare const getClassesForNodeVectorGroup: (selected: boolean, scale: any) => string;
export declare const getLabelScale: (scale: any) => 1.2 | 0.86 | 0.6 | undefined;
export declare const determineVisCoverage: (params: any, y: any) => VisCoverage;
export declare const generateQueryParams: (visCoverage: any, sphereHashB64: EntryHashB64) => (customDepth?: number) => OrbitHierarchyQueryParams | null;
export declare const deriveJsonData: (json: string, visCoverage: any, x: any) => any;
export declare const createTreeVisualization: ({ json, visCoverage, canvasHeight, canvasWidth, margin, transition, params, sphereNodeDetails, getJsonDerivation, setDepthBounds, }: {
    json: any;
    visCoverage: any;
    canvasHeight: any;
    canvasWidth: any;
    margin: any;
    transition: any;
    params: any;
    sphereNodeDetails: any;
    getJsonDerivation: any;
    setDepthBounds: any;
}) => TreeVisualization;
export declare const parseOrbitHierarchyData: (hierarchyData: string) => any;
export declare const fetchHierarchyDataForLevel: ({ error, depthBounds, getQueryParams, y, getHierarchy, client }: {
    error: any;
    depthBounds: any;
    getQueryParams: any;
    y: any;
    getHierarchy: any;
    client: any;
}) => Promise<any>;
export declare const handleZoomerInitialization: (currentOrbitTree: any, visCoverage: any) => void;
export declare const calculateAndSetBreadthBounds: (setBreadthBounds: any, params: any, visCoverage: any, sortedLength: any) => void;
export declare const checkNewDescendantsAdded: (sorted: any, currentOrbitTree: any) => boolean;
export declare const updateSphereHierarchyIndices: (newLevelXIndex: any, y: any) => void;
export declare const updateBreadthIndex: (setBreadthIndex: any, newLevelXIndex: any, currentBreadthIndex: any) => void;
//# sourceMappingURL=tree-helpers.d.ts.map