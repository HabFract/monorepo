export var VisType;
(function (VisType) {
    VisType["Tree"] = "Tree";
    VisType["Cluster"] = "Cluster";
    VisType["Radial"] = "Radial";
})(VisType || (VisType = {}));
export var VisCoverage;
(function (VisCoverage) {
    VisCoverage["Partial"] = "partial";
    VisCoverage["CompleteOrbit"] = "complete-orbit";
    VisCoverage["CompleteSphere"] = "complete-sphere";
})(VisCoverage || (VisCoverage = {}));
//# sourceMappingURL=types.js.map