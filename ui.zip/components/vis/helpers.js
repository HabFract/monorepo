import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
import { VisType } from "./types";
import { withVisCanvas } from "../HOC/withVisCanvas";
import { BASE_SCALE, DEFAULT_MARGINS, FOCUS_MODE_SCALE, PLANNIT_SPECIFIC_ZOOM_RESCALE_FACTOR_ASTRO, PLANNIT_SPECIFIC_ZOOM_RESCALE_FACTOR_ATOM, PLANNIT_SPECIFIC_ZOOM_RESCALE_FACTOR_SUB } from "./constants";
import { store } from "../../state/store";
import { getCurrentOrbitStartTimeFromEh } from "../../state/orbit";
import { newTraversalLevelIndexId } from "../../state";
import { Scale } from "../..//graphql/generated";
import { select } from "d3-selection";
export function getScaleDisplayName(scale) {
    switch (scale) {
        case Scale.Astro:
            return "Star";
        case Scale.Sub:
            return "Giant";
        case Scale.Atom:
            return "Dwarf";
    }
}
export const getCanvasDimensions = () => {
    const { height, width } = document.body.getBoundingClientRect();
    const canvasHeight = height - DEFAULT_MARGINS.top - DEFAULT_MARGINS.bottom;
    const canvasWidth = width - DEFAULT_MARGINS.right - DEFAULT_MARGINS.left;
    return { canvasHeight, canvasWidth };
};
export const appendSvg = (mountingDivId, divId) => {
    return (select(`#${divId}`).empty() &&
        select(`#${mountingDivId}`)
            .append("svg")
            .attr("id", `${divId}`)
            .attr("data-testid", "svg")
            .attr("style", "width: 100vw; height: 100vh; pointer-events: all"));
};
export const renderVis = (visComponent) => (_jsxs(_Fragment, { children: [_jsx("div", { id: "vis-root", className: "h-full" }), withVisCanvas(visComponent)] }));
export function byStartTime(a, b) {
    const getStartTime = store.get(getCurrentOrbitStartTimeFromEh);
    const getStartTimeFromNode = (node) => {
        if ('data' in node && node.data.content) {
            return getStartTime(node.data.content);
        }
        else if ('content' in node) {
            return getStartTime(node.content);
        }
        return 0;
    };
    const startTimeA = getStartTimeFromNode(a) ?? 0;
    const startTimeB = getStartTimeFromNode(b) ?? 0;
    if (startTimeA === startTimeB) {
        console.warn("Sorting was equal between nodes. This is likely an error!");
        return 0;
    }
    return startTimeA - startTimeB;
}
export function chooseZoomScaleForOrbit(orbit) {
    switch (orbit.scale) {
        case Scale.Astro:
            return PLANNIT_SPECIFIC_ZOOM_RESCALE_FACTOR_ASTRO;
        case Scale.Sub:
            return PLANNIT_SPECIFIC_ZOOM_RESCALE_FACTOR_SUB;
        case Scale.Atom:
            return PLANNIT_SPECIFIC_ZOOM_RESCALE_FACTOR_ATOM;
        default:
            return FOCUS_MODE_SCALE;
    }
}
export const parseAndSortTrees = (data) => {
    let parsedData = JSON.parse(data);
    while (typeof parsedData === "string") {
        parsedData = JSON.parse(parsedData);
    }
    const trees = parsedData?.result?.level_trees;
    if (!trees)
        console.error("Could not get an array of trees from parsed data");
    return trees.sort(byStartTime);
};
export const determineNewLevelIndex = (sortedTrees) => {
    const isNewLevelXIndex = store.get(newTraversalLevelIndexId);
    if (!isNewLevelXIndex?.id)
        return null;
    let newLevelXIndex = isNewLevelXIndex &&
        sortedTrees
            .map((d) => d.content)
            .findIndex((id) => id == isNewLevelXIndex.id);
    console.log('isNewLevelXIndex :>> ', newLevelXIndex);
    if (newLevelXIndex == -1)
        console.error("Could't pass forward new node index after traversal");
    return newLevelXIndex;
};
export const isTouchDevice = () => {
    return ("ontouchstart" in window || navigator.maxTouchPoints > 0);
};
export const isSmallScreen = () => {
    return document.body.getBoundingClientRect().width < 768;
};
export const isSuperSmallScreen = () => {
    return document.body.getBoundingClientRect().width < 340;
};
export const debounce = function (func, delay) {
    let timeout = null;
    let isExecuting = false;
    return async (...args) => {
        if (timeout) {
            clearTimeout(timeout);
        }
        if (!isExecuting) {
            isExecuting = true;
            try {
                const result = await func(...args);
                isExecuting = false;
                return result;
            }
            catch (error) {
                isExecuting = false;
                throw error;
            }
        }
        else {
            return new Promise((resolve, reject) => {
                timeout = setTimeout(async () => {
                    try {
                        const result = await func(...args);
                        resolve(result);
                    }
                    catch (error) {
                        reject(error);
                    }
                }, delay);
            });
        }
    };
};
export const getTransform = (node, xScale) => {
    if (typeof node === "undefined")
        return;
    var x = node.__data__ ? node.__data__.x : node.x;
    var y = node.__data__ ? node.__data__.y : node.y;
    var bx = x * xScale;
    var by = y * xScale;
    var tx = -bx;
    var ty = -by;
    return { translate: [tx, ty], scale: xScale };
};
const concatenateHierarchyNodeValues = (hierarchy) => hierarchy?.descendants && hierarchy.descendants().map((n) => n.value).join ``;
const checkAndResetCollapsed = (visObject) => {
    if (visObject.isCollapsed) {
        visObject.isCollapsed = false;
        return true;
    }
    return false;
};
export const hierarchyStateHasChanged = (currentHierarchy, visObject) => {
    const compareString = JSON.stringify(currentHierarchy.data);
    const currentHierNodeValueString = concatenateHierarchyNodeValues(currentHierarchy);
    return (JSON.stringify(visObject.rootData.data) !== compareString ||
        concatenateHierarchyNodeValues(visObject.rootData) !==
            currentHierNodeValueString);
};
export const updateVisRootData = (visObject, currentHierarchy) => {
    const visHasRenders = typeof visObject == "object" && !visObject.firstRender();
    if (visHasRenders &&
        (visObject.firstRender() ||
            hierarchyStateHasChanged(currentHierarchy, visObject) ||
            checkAndResetCollapsed(visObject))) {
        visObject._nextRootData = currentHierarchy;
        visObject.render();
        console.log("Rendered from component & updated ", {}, "!");
        return visObject;
    }
};
export const getInitialXTranslate = ({ levelsWide, defaultView }) => {
    const [_x, _y, w, _h] = defaultView.split ` `;
    return w / levelsWide / (BASE_SCALE * 2);
};
export const getInitialYTranslate = (type, { levelsHigh, defaultView }) => {
    const [_x, _y, _w, h] = defaultView.split ` `;
    switch (type) {
        default:
            return h / levelsHigh / 3.5;
    }
};
export const newXTranslate = (type, viewConfig, zoomConfig) => {
    const scale = zoomConfig.globalZoomScale || viewConfig.scale;
    switch (type) {
        case VisType.Tree:
            return -(zoomConfig.previousRenderZoom?.node?.x) * scale;
    }
};
export const newYTranslate = (type, viewConfig, zoomConfig) => {
    const scale = viewConfig.scale;
    switch (type) {
        case VisType.Tree:
            return -(zoomConfig.previousRenderZoom?.node?.y) * scale;
        default:
            return 1;
    }
};
export function expand(d) {
    var children = d.children ? d.children : d._children;
    if (d._children) {
        d.children = d._children;
        d._children = null;
    }
    if (children)
        children.forEach(expand);
}
export function collapse(d) {
    if (d.children) {
        d._children = d.children;
        d._children.forEach(collapse);
        d.children = null;
    }
}
export const cousins = (node, root) => {
    return root.descendants().filter((n) => n.depth == node.depth && n !== node);
};
export const greatAunts = (node, root) => root.descendants().filter((n) => !n.ancestors().includes(node?.parent));
export const nodesForCollapse = function (node, { cousinCollapse = true, auntCollapse = true }) {
    let minExpandedDepth = node.depth + 2;
    let descendantsToCollapse = node
        .descendants()
        .filter((n) => n.depth >= minExpandedDepth);
    let nodeCousins = [];
    if (cousinCollapse) {
        nodeCousins = cousins(node, this.rootData);
    }
    let aunts = [];
    if (node.depth > 1 && auntCollapse && this.rootData.children) {
        aunts = greatAunts(node, this.rootData).filter((n) => !node.ancestors().includes(n));
    }
    return descendantsToCollapse.concat(nodeCousins).concat(aunts);
};
//# sourceMappingURL=helpers.js.map