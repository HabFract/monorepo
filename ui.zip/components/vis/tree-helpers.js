import { hierarchy } from "d3-hierarchy";
import { GetOrbitHierarchyDocument, Scale } from "../../graphql/generated";
import { store, currentSphereHierarchyIndices } from "../../state";
import { TreeVisualization } from "./base-classes/TreeVis";
import { byStartTime, parseAndSortTrees } from "./helpers";
import { VisCoverage, VisType } from "./types";
import { NODE_ENV } from "../../constants";
export const toYearDotMonth = (date) => date.split("/").slice(1).reverse().join(".");
export const isMoreThenDaily = (frequency) => frequency > 1;
export const loadD3Dependencies = async () => {
    const [d3Hierarchy, d3Selection] = await Promise.all([
        import('d3-hierarchy'),
        import('d3-selection')
    ]);
    return {
        hierarchy: d3Hierarchy.hierarchy,
        select: d3Selection.select
    };
};
function CustomBezier(context) {
    this._context = context;
}
CustomBezier.prototype = {
    areaStart: function () {
        this._line = 0;
    },
    areaEnd: function () {
        this._line = NaN;
    },
    lineStart: function () {
        this._x = this._y = NaN;
        this._point = 0;
    },
    lineEnd: function () {
        if (this._point === 2)
            this._context.lineTo(this._x, this._y);
        if (this._line || (this._line !== 0 && this._point === 1))
            this._context.closePath();
        if (this._line >= 0)
            this._line = 1 - this._line;
    },
    point: function (x, y) {
        (x = +x), (y = +y);
        switch (this._point) {
            case 0:
                this._point = 1;
                this._context.moveTo(x, y);
                break;
            case 1:
                this._point = 2;
            default: {
                const dx = x - this._x;
                const dy = y - this._y;
                if (Math.abs(dx) > 1e-6) {
                    const x1 = this._x + (dx * 0.0002);
                    const y1 = this._y + (dy * 0.9999);
                    const x2 = x - (dx * 0.0002);
                    const y2 = y - (dy * 0.9999);
                    this._context.bezierCurveTo(x1, y1, x2, y2, x, y);
                }
                else {
                    this._context.lineTo(x, y);
                }
                break;
            }
        }
        (this._x = x), (this._y = y);
    }
};
export const curves = {
    curveCustomBezier: function (context) {
        return new CustomBezier(context);
    }
};
export const getScaleForPlanet = (scale) => {
    switch (scale) {
        case Scale.Astro:
            return 2;
        case Scale.Sub:
            return 1.75;
        case Scale.Atom:
            return 0.8;
    }
};
export const getClassesForNodeVectorGroup = (selected, scale) => {
    return `${selected ? " selected" : ""} ${scale.toString().toLowerCase()}`;
};
export const getLabelScale = (scale) => {
    switch (scale) {
        case Scale.Astro:
            return 1.2;
        case Scale.Sub:
            return 0.86;
        case Scale.Atom:
            return 0.6;
    }
};
export const determineVisCoverage = (params, y) => params?.orbitEh
    ? VisCoverage.CompleteOrbit
    : y == 0
        ? VisCoverage.CompleteSphere
        : VisCoverage.Partial;
export const generateQueryParams = (visCoverage, sphereHashB64) => (customDepth) => {
    return visCoverage == VisCoverage.CompleteOrbit
        ? { orbitEntryHashB64: null }
        : {
            levelQuery: {
                sphereHashB64: sphereHashB64,
                orbitLevel: customDepth || 0,
            },
        };
};
export const deriveJsonData = (json, visCoverage, x) => {
    try {
        const parsed = JSON.parse(json);
        if (parsed?.length && (x > parsed.length - 1))
            console.error("Tried to traverse out of hierarchy bounds");
        return visCoverage == VisCoverage.CompleteOrbit ? parsed : parsed[x];
    }
    catch (error) {
        console.error("Error deriving parsed JSON from data: ", error);
    }
};
export const createTreeVisualization = ({ json, visCoverage, canvasHeight, canvasWidth, margin, transition, params, sphereNodeDetails, getJsonDerivation, setDepthBounds, }) => {
    const currentTreeJson = getJsonDerivation(json);
    const hierarchyData = hierarchy(currentTreeJson).sort(byStartTime);
    setDepthBounds(params?.currentSphereEhB64, [
        0,
        visCoverage == VisCoverage.CompleteOrbit ? 100 : hierarchyData.height,
    ]);
    return new TreeVisualization(VisType.Tree, visCoverage, "vis", hierarchyData, canvasHeight, canvasWidth, margin, transition, params?.currentSphereEhB64, params?.currentSphereAhB64, sphereNodeDetails);
};
export const parseOrbitHierarchyData = (hierarchyData) => {
    const sortedTrees = parseAndSortTrees(hierarchyData);
    !(NODE_ENV == 'test') && console.log('Parsing result... :>> ', sortedTrees);
    return sortedTrees;
};
export const fetchHierarchyDataForLevel = async ({ error, depthBounds, getQueryParams, y, getHierarchy, client }) => {
    if (error)
        return;
    const query = depthBounds
        ? { ...getQueryParams(), orbitLevel: 0 }
        : getQueryParams(y);
    let cachedData;
    try {
        if (NODE_ENV !== 'test') {
            const gql = (await client);
            cachedData = gql.readQuery({
                query: GetOrbitHierarchyDocument,
                variables: { params: { ...query } },
            });
        }
    }
    catch (error) {
        console.error("Couldn't get client or data from Apollo cache");
    }
    if (cachedData) {
        console.log("Fetching current hierarchy level from Apollo cache...");
        return cachedData;
    }
    else {
        NODE_ENV !== 'test' && console.log("Fetching current hierarchy level from source chain: ", JSON.stringify({ variables: { params: { ...query } } }, null, 2));
        await getHierarchy({ variables: { params: { ...query } } });
    }
};
export const handleZoomerInitialization = (currentOrbitTree, visCoverage) => {
    if (currentOrbitTree) {
        visCoverage === VisCoverage.Partial
            ? currentOrbitTree.resetZoomer()
            : currentOrbitTree.initializeZoomer();
    }
};
export const calculateAndSetBreadthBounds = (setBreadthBounds, params, visCoverage, sortedLength) => {
    setBreadthBounds(params?.currentSphereEhB64, [
        0,
        visCoverage === VisCoverage.CompleteOrbit ? 100 : sortedLength - 1,
    ]);
};
export const checkNewDescendantsAdded = (sorted, currentOrbitTree) => {
    if (!currentOrbitTree.rootData)
        return false;
    const newHierarchyDescendants = hierarchy(sorted[0])?.sort(byStartTime)?.descendants()?.length;
    const oldHierarchyDescendants = currentOrbitTree?.rootData.descendants().length;
    return newHierarchyDescendants === oldHierarchyDescendants;
};
export const updateSphereHierarchyIndices = (newLevelXIndex, y) => {
    if (newLevelXIndex !== -1) {
        store.set(currentSphereHierarchyIndices, { x: newLevelXIndex, y });
    }
};
export const updateBreadthIndex = (setBreadthIndex, newLevelXIndex, currentBreadthIndex) => {
    setBreadthIndex(newLevelXIndex !== -1 ? newLevelXIndex : currentBreadthIndex);
};
//# sourceMappingURL=tree-helpers.js.map