import { HierarchyPointNode, TreeLayout } from "d3-hierarchy";
import { DefaultLinkObject, Link } from "d3-shape";
import { EventHandlers, Margins, ViewConfig } from "../types";
import { BaseVisualization } from "./BaseVis";
import { EntryHashB64 } from "@holochain/client/lib/types";
export declare class TreeVisualization extends BaseVisualization {
    layout: TreeLayout<unknown>;
    _lastOrbitId: EntryHashB64 | null;
    initializeViewConfig(canvasHeight: number, canvasWidth: number, margin: Margins, customScale?: number): ViewConfig;
    initializeEventHandlers(): EventHandlers;
    setupLayout(): void;
    getNextLayout(): HierarchyPointNode<unknown> | null;
    handleZoom(event: any): void;
    zoomOut(): void;
    appendLinkPath(): void;
    getLinkPathGenerator(): Link<any, DefaultLinkObject, [number, number]>;
    setNodeAndLinkEnterSelections(): void;
    setNodeAndLabelGroups(): void;
    appendNodeVectors(): void;
}
//# sourceMappingURL=TreeVis.d.ts.map