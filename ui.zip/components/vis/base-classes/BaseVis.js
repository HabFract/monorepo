import { select } from "d3-selection";
import { zoom } from "d3-zoom";
import { LG_LEVELS_HIGH, LG_LEVELS_WIDE, XS_LEVELS_HIGH, XS_LEVELS_WIDE } from "../constants";
import { VisCoverage } from "../types";
import { GetOrbitsDocument, Scale } from "../../../graphql/generated";
import { client } from "../../../graphql/client";
import { store, nodeCache } from "../../../state/jotaiKeyValueStore";
import { mapToCacheObject } from "../../../state/orbit";
import { extractEdges } from "../../../graphql/utils";
import { currentOrbitIdAtom } from "../../../state/orbit";
export class BaseVisualization {
    type;
    coverageType;
    rootData;
    nodeDetails;
    _nextRootData;
    _svgId;
    _canvas;
    _viewConfig;
    _zoomConfig;
    sphereEh;
    sphereAh;
    modalParentOrbitEh;
    modalChildOrbitEh;
    globalStateTransition;
    eventHandlers;
    zoomer;
    _gLink;
    _gNode;
    _gCircle;
    _gTooltip;
    _gButton;
    _enteringLinks;
    _enteringNodes;
    modalOpen;
    isModalOpen = false;
    skipMainRender = false;
    activeNode = null;
    isNewActiveNode = false;
    _hasRendered = false;
    constructor(type, coverageType, svgId, inputTree, canvasHeight, canvasWidth, margin, globalStateTransition, sphereEh, sphereAh, nodeDetails) {
        this.type = type;
        this.coverageType = coverageType;
        this._svgId = svgId;
        this.rootData = inputTree;
        this.globalStateTransition = globalStateTransition;
        this.sphereEh = sphereEh;
        this.sphereAh = sphereAh;
        this.nodeDetails = nodeDetails;
        this._nextRootData = null;
        this._viewConfig = this.initializeViewConfig(canvasHeight, canvasWidth, margin);
        this._zoomConfig = this.initializeZoomConfig();
        this.eventHandlers = this.initializeEventHandlers();
        if (this.coverageType !== VisCoverage.Partial) {
            this.initializeZoomer();
        }
    }
    async refetchOrbits() {
        const variables = { sphereEntryHashB64: this.sphereEh };
        let data;
        try {
            const gql = await client;
            data = await gql.query({ query: GetOrbitsDocument, variables, fetchPolicy: 'network-only' });
            if (data?.data?.orbits) {
                const orbits = extractEdges(data.data.orbits);
                const indexedOrbitData = Object.entries(orbits.map(mapToCacheObject))
                    .map(([_idx, value]) => [value.id, value]);
                this.cacheOrbits(indexedOrbitData);
            }
            console.log('refetched orbits :>> ', data);
        }
        catch (error) {
            console.error(error);
        }
    }
    async cacheOrbits(orbitEntries) {
        try {
            store.set(nodeCache.setMany, orbitEntries);
            this.nodeDetails = Object.entries(orbitEntries);
            console.log('Sphere orbits fetched and cached!');
        }
        catch (error) {
            console.error('error :>> ', error);
        }
    }
    setupCanvas() {
        if (this.noCanvas()) {
            this._canvas = select(`#${this._svgId}`)
                .append("g")
                .classed("canvas", true);
        }
    }
    setLevelsHighAndWide() {
        if (this._viewConfig.isSmallScreen()) {
            this._viewConfig.levelsHigh = XS_LEVELS_HIGH;
            this._viewConfig.levelsWide = XS_LEVELS_WIDE;
        }
        else {
            this._viewConfig.levelsHigh = LG_LEVELS_HIGH;
            this._viewConfig.levelsWide = LG_LEVELS_WIDE;
        }
    }
    calibrateViewPortAttrs() {
        this._viewConfig.viewportW =
            this._viewConfig.canvasWidth * this._viewConfig.levelsWide;
        this._viewConfig.viewportH =
            this._viewConfig.canvasHeight * this._viewConfig.levelsHigh;
        this._viewConfig.viewportX = 0;
        this._viewConfig.viewportY = 0;
        this._viewConfig.defaultView = `${this._viewConfig.viewportX} ${this._viewConfig.viewportY} ${this._viewConfig.viewportW} ${this._viewConfig.viewportH}`;
    }
    calibrateViewBox() {
        this.visBase()
            .attr("viewBox", this._viewConfig.defaultView)
            .attr("preserveAspectRatio", "xMidYMid meet")
            .on("dblclick.zoom", null);
    }
    setdXdY() {
        this._viewConfig.dx =
            this._viewConfig.canvasWidth / (this._viewConfig.levelsHigh * 2) -
                +(this._viewConfig.isSmallScreen()) * 250;
        this._viewConfig.dy =
            this._viewConfig.canvasHeight / (this._viewConfig.levelsWide * 6);
        this._viewConfig.dx *= this._viewConfig.isSmallScreen() ? 2.5 : 1.5;
        this._viewConfig.dy *= this._viewConfig.isSmallScreen() ? 2.5 : 3;
    }
    setNodeAndLinkGroups() {
        !this.firstRender() && this.clearNodesAndLinks();
        this._gLink = this._canvas
            .append("g")
            .classed("links", true);
        this._gNode = this._canvas
            .append("g")
            .classed("nodes", true);
    }
    render() {
        if (this.skipMainRender) {
            this.skipMainRender = false;
            return;
        }
        if (this.noCanvas()) {
            this.setupCanvas();
        }
        if (this.firstRender()) {
            this.setLevelsHighAndWide();
            this.calibrateViewPortAttrs();
            this.calibrateViewBox();
            this.setdXdY();
        }
        if (this.firstRender() || this.hasNextData()) {
            this.clearCanvas();
            if (this.hasNextData()) {
                this.rootData = this._nextRootData;
                this._nextRootData = null;
            }
            this.setupLayout();
            this.setNodeAndLinkGroups();
            this.setNodeAndLinkEnterSelections();
            this.setNodeAndLabelGroups();
            this.appendNodeVectors();
            this.appendLinkPath();
            this.applyInitialTransform();
            this._hasRendered = true;
        }
    }
    firstRender() {
        return !this._hasRendered;
    }
    hasNextData() {
        return this._nextRootData !== null;
    }
    visBase() {
        return select(`#${this._svgId}`);
    }
    noCanvas() {
        return (typeof this._canvas === "undefined" ||
            select(`#${this._svgId} .canvas`)._groups.length === 0);
    }
    clearNodesAndLinks() {
        this._canvas.selectAll('g.nodes').remove();
        this._canvas.selectAll('g.links').remove();
    }
    clearAndRedrawLabels() {
        !this.firstRender() && this._canvas.selectAll(".tooltip").remove();
        return this._enteringNodes
            .append("g")
            .classed("tooltip", true)
            .append("foreignObject")
            .attr("transform", (d) => {
            const cachedNode = this.nodeDetails[d.data.content];
            const { scale } = cachedNode;
            const getScale = () => {
                switch (scale) {
                    case Scale.Astro:
                        return 0.4;
                    case Scale.Sub:
                        return 0.3;
                    case Scale.Atom:
                        return 0.25;
                }
            };
            return `scale(${this._viewConfig.isSmallScreen() ? getScale() : .75})`;
        })
            .attr("x", "-375")
            .attr("y", (d) => {
            const cachedNode = this.nodeDetails[d.data.content];
            const { scale } = cachedNode;
            return scale == Scale.Atom ? "-150" : Scale.Sub ? "-60" : "-50";
        })
            .attr("width", "650")
            .style("overflow", "visible")
            .attr("height", "650")
            .html(this.appendLabelHtml);
    }
    resetZoomer() {
        const zoomer = zoom();
        this.visBase().call(zoomer);
    }
    clearCanvas() {
        select(".canvas").selectAll("*").remove();
    }
    appendLabelHtml = (d) => {
        if (!d?.data?.content || !this.nodeDetails[d.data.content])
            return "";
        const isCurrentOrbit = store.get(currentOrbitIdAtom)?.id === d.data.content;
        if (!isCurrentOrbit)
            return "";
        const cachedNode = this.nodeDetails[d.data.content];
        const { name, description, scale } = cachedNode;
        return `<div class="tooltip-inner">
      <div class="content">
      <span class="title">Name:</span>
      <p>${name}</p>
      <span class="title">Description:</span>
      <p>${description || "<br />"}</p>
      </div>
    </div>`;
    };
}
//# sourceMappingURL=BaseVis.js.map