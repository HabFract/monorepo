import { jsx as _jsx } from "react/jsx-runtime";
import { select } from "d3-selection";
import { zoom } from "d3-zoom";
import { easeLinear } from "d3-ease";
import { renderToStaticMarkup } from 'react-dom/server';
import { DX_RESCALE_FACTOR_MD_LG, DX_RESCALE_FACTOR_SM, DY_RESCALE_FACTOR_MD_LG, DY_RESCALE_FACTOR_SM, FOCUS_MODE_SCALE, LG_LEVELS_HIGH, LG_LEVELS_WIDE, XS_LEVELS_HIGH, XS_LEVELS_WIDE, } from "../constants";
import { VisCoverage, } from "../types";
import { Scale } from "../../../graphql/generated";
import { store } from "../../../state/store";
import { currentOrbitDetailsAtom } from "../../../state/orbit";
import { newTraversalLevelIndexId } from "../../../state/hierarchy";
import { currentOrbitIdAtom } from "../../../state/orbit";
import { NODE_ENV } from "../../../constants";
import { getLabelScale } from "../tree-helpers";
import { OrbitControls, OrbitLabel } from "habit-fract-design-system";
import { currentDayAtom } from "../../../state";
import { AppMachine } from "../../../main";
import { debounce } from "../helpers";
import memoizeOne from "memoize-one";
export class BaseVisualization {
    type;
    coverageType;
    rootData;
    nodeDetails;
    _nextRootData;
    _json;
    _originalRootData;
    _svgId;
    _canvas;
    _viewConfig;
    _zoomConfig;
    _lastOrbitId;
    _subscriptions;
    sphereEh;
    sphereAh;
    modalParentOrbitEh;
    modalChildOrbitEh;
    globalStateTransition;
    eventHandlers;
    zoomer;
    _gLink;
    _gNode;
    _gCircle;
    _gTooltip;
    _gButton;
    _enteringLinks;
    _enteringNodes;
    modalOpen;
    isModalOpen = false;
    skipMainRender = false;
    startInFocusMode = false;
    _lastRenderParentId = null;
    _hasRendered = false;
    constructor(type, coverageType, svgId, inputTree, canvasHeight, canvasWidth, margin, globalStateTransition, sphereEh, sphereAh, nodeDetails) {
        this.type = type;
        this.coverageType = coverageType;
        this._svgId = svgId;
        this.rootData = inputTree;
        this.globalStateTransition = globalStateTransition;
        this.sphereEh = sphereEh;
        this.sphereAh = sphereAh;
        this.nodeDetails = nodeDetails;
        this._subscriptions = [];
        this._nextRootData = null;
        this._viewConfig = this.initializeViewConfig(canvasHeight, canvasWidth, margin);
        this._zoomConfig = this.initializeZoomConfig();
        this.eventHandlers = this.initializeEventHandlers();
    }
    bindEventHandlers() {
        this.unbindEventHandlers();
        const memoizedHandleClick = memoizeOne((e, d) => {
            store.set(currentOrbitIdAtom, d.data.content);
            this.eventHandlers.handleNodeClick.call(this, e, d);
        });
        const debouncedZoom = debounce((nodeId) => Promise.resolve(this.eventHandlers.memoizedhandleNodeZoom.call(this, nodeId)), 1000);
        const handleOrbitIdChange = memoizeOne((newId) => {
            if (AppMachine.state.currentState !== "Vis")
                return;
            this.eventHandlers.handleNodeClick.call(this, {}, {});
            debouncedZoom(newId);
        });
        const handleNodeEvent = (event) => {
            const target = event.target;
            const nodeGroup = target.closest('.the-node');
            if (!nodeGroup)
                return;
            const d = nodeGroup.__data__;
            if (event.type === 'click') {
                memoizedHandleClick(event, d);
            }
        };
        const nodeContainer = this._canvas.select('g.nodes');
        nodeContainer.on('click', handleNodeEvent);
        const handleCurrentDayChange = () => {
            if (AppMachine.state.currentState !== "Vis")
                return;
            this.eventHandlers.handleNodeClick.call(this, {}, {});
        };
        const subOrbitId = store.sub(currentOrbitIdAtom, () => {
            const newId = store.get(currentOrbitDetailsAtom)?.eH;
            handleOrbitIdChange(newId);
        });
        const subCurrentDay = store.sub(currentDayAtom, handleCurrentDayChange);
        this._subscriptions.push(subOrbitId, subCurrentDay);
    }
    unbindEventHandlers() {
        if (this._canvas) {
            this._canvas.selectAll('*').on('.', null);
        }
        if (this._subscriptions) {
            this._subscriptions.forEach((unsub) => unsub());
            this._subscriptions = [];
        }
    }
    setupCanvas() {
        if (this.noCanvas()) {
            this._canvas = select(`#${this._svgId}`)
                .append("g")
                .classed("canvas", true);
        }
    }
    setLevelsHighAndWide() {
        if (this._viewConfig.isSmallScreen()) {
            this._viewConfig.levelsHigh = XS_LEVELS_HIGH;
            this._viewConfig.levelsWide = XS_LEVELS_WIDE;
        }
        else {
            this._viewConfig.levelsHigh = LG_LEVELS_HIGH;
            this._viewConfig.levelsWide = LG_LEVELS_WIDE;
        }
    }
    calibrateViewPortAttrs() {
        this._viewConfig.viewportW =
            this._viewConfig.canvasWidth * this._viewConfig.levelsWide;
        this._viewConfig.viewportH =
            this._viewConfig.canvasHeight * this._viewConfig.levelsHigh;
        this._viewConfig.viewportX = 0;
        this._viewConfig.viewportY = 0;
        this._viewConfig.defaultView = `${this._viewConfig.viewportX} ${this._viewConfig.viewportY} ${this._viewConfig.viewportW} ${this._viewConfig.viewportH}`;
    }
    calibrateViewBox() {
        this.visBase()
            .attr("viewBox", this._viewConfig.defaultView)
            .attr("preserveAspectRatio", "xMidYMid meet");
    }
    setdXdY() {
        this._viewConfig.dx =
            this._viewConfig.canvasWidth /
                (this._viewConfig.levelsHigh * 2) -
                +this._viewConfig.isSmallScreen() * 150;
        this._viewConfig.dy =
            this._viewConfig.canvasHeight /
                (this._viewConfig.levelsWide * 6);
        this._viewConfig.dx *= this._viewConfig.isSmallScreen() ? DX_RESCALE_FACTOR_SM : DX_RESCALE_FACTOR_MD_LG;
        this._viewConfig.dy *= this._viewConfig.isSmallScreen() ? DY_RESCALE_FACTOR_SM : DY_RESCALE_FACTOR_MD_LG;
    }
    setNodeAndLinkGroups() {
        !this.firstRender() && this.clearNodesAndLinks();
        this._gLink = this._canvas.append("g").classed("links", true)
            .attr("style", "transform: translateY(148px)");
        this._gNode = this._canvas.append("g").classed("nodes", true);
    }
    render() {
        if (this.skipMainRender) {
            this.skipMainRender = false;
            return;
        }
        if (!this.firstRender()) {
            this.unbindEventHandlers();
        }
        if (this.noCanvas()) {
            this.setupCanvas();
        }
        if (this.firstRender()) {
            this.setLevelsHighAndWide();
            this.calibrateViewPortAttrs();
            this.calibrateViewBox();
            this.setdXdY();
            this._originalRootData = this.rootData;
        }
        if (this.firstRender() || this.hasNextData()) {
            this.clearCanvas();
            let hasUpdated;
            if (this.hasNextData()) {
                this.rootData = this._nextRootData;
                this._nextRootData = null;
                hasUpdated = true;
            }
            this.setupLayout();
            this.setNodeAndLinkGroups();
            this.setNodeAndLinkEnterSelections();
            this.setNodeAndLabelGroups();
            this.appendNodeVectors();
            this.appendLinkPath();
            this._gTooltip = this.clearAndRedrawLabels();
            if (!hasUpdated) {
                this.applyInitialTransform();
                this.eventHandlers.memoizedhandleNodeZoom.call(this, this.rootData.data.content);
            }
            if (this.firstRender())
                this.bindEventHandlers();
            if (!(this.coverageType == VisCoverage.Partial || this.noCanvas())) {
                this.initializeZoomer();
            }
            const newRenderNodeDetails = store.get(newTraversalLevelIndexId);
            const finalNodeToFocus = newRenderNodeDetails?.id;
            if (this.startInFocusMode && hasUpdated) {
                this._lastOrbitId = null;
                const initialNodeZoomId = newRenderNodeDetails?.intermediateId || finalNodeToFocus || this._lastRenderParentId;
                let initialZoom = this.eventHandlers.memoizedhandleNodeZoom.call(this, initialNodeZoomId, this.rootData.find(node => node.data.content == initialNodeZoomId));
                if (newRenderNodeDetails?.intermediateId) {
                    initialZoom
                        .on("end", () => {
                        this.eventHandlers.memoizedhandleNodeZoom.call(this, finalNodeToFocus);
                        console.log('Using intermediate node :>> ', newRenderNodeDetails.intermediateId);
                    });
                }
                store.set(newTraversalLevelIndexId, { id: null, intermediateId: null });
                this.startInFocusMode = false;
            }
            this._hasRendered = true;
        }
    }
    firstRender() {
        return !this._hasRendered;
    }
    hasNextData() {
        return this._nextRootData !== null && this._nextRootData.descendants().length !== this.rootData.descendants().length;
    }
    visBase() {
        return select(`#${this._svgId}`);
    }
    noCanvas() {
        return (!this._canvas ||
            select(`#${this._svgId} .canvas`)._groups.length === 0);
    }
    clearNodesAndLinks() {
        this._canvas.selectAll("g.nodes").remove();
        this._canvas.selectAll("g.links").remove();
    }
    clearAndRedrawLabels() {
        !this.firstRender() && this._canvas.selectAll(".tooltip").remove();
        return this._enteringNodes.append("g")
            .classed("tooltip", true)
            .append("foreignObject")
            .attr("transform", (d) => {
            const cachedNode = this.nodeDetails[d.data.content];
            const { scale } = cachedNode;
            return `scale(${this._viewConfig.isSmallScreen() ? getLabelScale(scale) : 0.75})`;
        })
            .attr("y", (d) => {
            const cachedNode = this.nodeDetails[d.data.content];
            const { scale, parentEh } = cachedNode;
            return scale == Scale.Astro
                ? (!parentEh ? "-40" : "-30")
                : scale == Scale.Sub
                    ? (!parentEh ? "0" : "20")
                    : (!parentEh ? "55" : "75");
        })
            .attr("x", (d) => {
            const cachedNode = this.nodeDetails[d.data.content];
            const { scale, parentEh } = cachedNode;
            return !parentEh ? "-122" : "-90";
        })
            .attr("width", (d) => {
            const cachedNode = this.nodeDetails[d.data.content];
            const { scale, parentEh } = cachedNode;
            return !parentEh ? "246" : "220";
        })
            .attr("height", "300")
            .html(this.appendLabelHtml);
    }
    resetZoomer() {
        const zoomer = zoom();
        select("#vis") && select("#vis").call(zoomer);
        this.initializeZoomConfig();
    }
    applyInitialTransform(toSelection) {
        (toSelection || this._canvas).attr("transform", `scale(${this._viewConfig.scale}), translate(${this._viewConfig.defaultCanvasTranslateX()}, ${this._viewConfig.defaultCanvasTranslateY()})`);
    }
    initializeZoomConfig(focused = false) {
        return {
            focusMode: focused,
            previousRenderZoom: {},
            globalZoomScale: focused ? FOCUS_MODE_SCALE : this._viewConfig.scale,
            zoomedInView: function () {
                return Object.keys(this.previousRenderZoom).length !== 0;
            },
        };
    }
    initializeZoomer() {
        const zoomer = zoom()
            .scaleExtent([1, 1.5])
            .on("zoom", this.handleZoom.bind(this));
        select("#vis") && select("#vis").call(zoomer);
        return (this.zoomer = zoomer);
    }
    handleZoom(event) {
        let t = { ...event.transform };
        let scale;
        let x, y;
        if (this._zoomConfig.focusMode) {
            this._zoomConfig.focusMode = false;
            return;
        }
        else {
            scale = t.k;
            x = t.x * scale;
            y = t.y * scale;
        }
        !!(NODE_ENV !== 'test' && !this.noCanvas()) && this._canvas
            .transition()
            .ease(easeLinear)
            .duration(200)
            .attr("transform", `translate(${x},${y}), scale(${scale})`);
    }
    zoomOut() {
        if (!this._zoomConfig.focusMode)
            return;
        this._zoomConfig.focusMode = false;
        this._zoomConfig.globalZoomScale = this._viewConfig.scale;
        this.initializeZoomer();
        this.applyInitialTransform(this._canvas.transition().duration(750));
        this._zoomConfig.focusMode = false;
        this._zoomConfig.previousRenderZoom = {};
    }
    clearCanvas() {
        select(".canvas").selectAll("*").remove();
    }
    appendLabelHtml = (d) => {
        if (!d?.data?.content || !this.nodeDetails[d.data.content])
            return "";
        const isCurrentOrbit = store.get(currentOrbitIdAtom)?.id === d.data.content;
        if (!isCurrentOrbit)
            return "";
        const { name, description, frequency, eH } = this.nodeDetails[d.data.content];
        const controlsMarkup = renderToStaticMarkup(_jsx(OrbitControls, { handleAppendNode: () => { }, handleEdit: () => { }, nodeEh: eH }));
        const labelMarkup = renderToStaticMarkup(_jsx(OrbitLabel, { orbitDetails: { name, description, frequency } }));
        return `<div class="orbit-overlay-container">${controlsMarkup}${labelMarkup}</div>`;
    };
    destroy() {
        this.unbindEventHandlers();
        if (this.zoomer) {
            select("#vis").on('.zoom', null);
        }
        if (this._canvas) {
            this._canvas.selectAll('*').remove();
            this._canvas.remove();
        }
        if (this._svgId) {
            select(`#${this._svgId}`).remove();
        }
        select('body').selectAll('foreignObject').remove();
        this.rootData = null;
        this._nextRootData = null;
        this._originalRootData = null;
        this._canvas = null;
        this._gLink = null;
        this._gNode = null;
        this._gCircle = null;
        this._gTooltip = null;
        this._gButton = null;
        this._enteringLinks = null;
        this._enteringNodes = null;
        console.log('BaseVisualization destroyed');
    }
}
//# sourceMappingURL=BaseVis.js.map