import { tree } from "d3-hierarchy";
import { VisType, } from "../types";
import { BASE_SCALE, LG_TREE_PATH_OFFSET_X, LG_TREE_PATH_OFFSET_Y, LINK_COLOR, LINK_THICKNESS, NEGATIVE_ZOOM_Y_OFFSET_MD_LG, NEGATIVE_ZOOM_Y_OFFSET_SM_NONROOT, NEGATIVE_ZOOM_Y_OFFSET_SM_ROOT, NODE_RESCALE_FACTOR_MD_LG, NODE_RESCALE_FACTOR_SM, PLANNIT_ZOOM_TRANSITION_DURATION, XS_TREE_PATH_OFFSET_X, XS_TREE_PATH_OFFSET_Y, } from "../constants";
import { BaseVisualization } from "./BaseVis";
import { select } from "d3-selection";
import { easeCubicOut } from "d3-ease";
import { link } from "d3-shape";
import { store } from "../../../state/store";
import { ONE_CHILD, ONE_CHILD_XS, TWO_CHILDREN_LEFT, TWO_CHILDREN_RIGHT, TWO_CHILDREN_LEFT_XS, TWO_CHILDREN_RIGHT_XS, THREE_CHILDREN_LEFT, THREE_CHILDREN_RIGHT, THREE_CHILDREN_LEFT_XS, THREE_CHILDREN_RIGHT_XS, FOUR_CHILDREN_LEFT_1, FOUR_CHILDREN_LEFT_2, FOUR_CHILDREN_RIGHT_1, FOUR_CHILDREN_RIGHT_2, FOUR_CHILDREN_LEFT_1_XS, FOUR_CHILDREN_LEFT_2_XS, FOUR_CHILDREN_RIGHT_1_XS, FOUR_CHILDREN_RIGHT_2_XS, FIVE_CHILDREN_LEFT_1, FIVE_CHILDREN_LEFT_2, FIVE_CHILDREN_RIGHT_1, FIVE_CHILDREN_RIGHT_2, FIVE_CHILDREN_LEFT_1_XS, FIVE_CHILDREN_LEFT_2_XS, FIVE_CHILDREN_RIGHT_1_XS, FIVE_CHILDREN_RIGHT_2_XS, SIX_CHILDREN_LEFT_1, SIX_CHILDREN_LEFT_2, SIX_CHILDREN_LEFT_3, SIX_CHILDREN_RIGHT_1, SIX_CHILDREN_RIGHT_2, SIX_CHILDREN_RIGHT_3, SIX_CHILDREN_LEFT_1_XS, SIX_CHILDREN_LEFT_2_XS, SIX_CHILDREN_LEFT_3_XS, SIX_CHILDREN_RIGHT_1_XS, SIX_CHILDREN_RIGHT_2_XS, SIX_CHILDREN_RIGHT_3_XS, } from "../links/paths";
import { chooseZoomScaleForOrbit, getInitialXTranslate, getInitialYTranslate, newXTranslate, newYTranslate, } from "../helpers";
import { getOrbitIdFromEh, currentOrbitDetailsAtom } from "../../../state/orbit";
import { NODE_ENV } from "../../../constants";
import { curves, getClassesForNodeVectorGroup, getScaleForPlanet } from "../tree-helpers";
import { calculateCompletionStatusAtom } from "../../../state/win";
import { currentDayAtom } from "../../../state";
import { performanceModeAtom } from "@state/ui";
export class TreeVisualization extends BaseVisualization {
    layout;
    _lastOrbitId = null;
    initializeViewConfig(canvasHeight, canvasWidth, margin, customScale) {
        return {
            scale: customScale || BASE_SCALE,
            margin: { ...margin, top: -200 },
            canvasHeight,
            canvasWidth,
            defaultView: "",
            defaultCanvasTranslateX: () => {
                const initialX = getInitialXTranslate.call(this, {
                    defaultView: this._viewConfig.defaultView,
                    levelsWide: this._viewConfig.levelsWide,
                });
                return customScale || typeof this._zoomConfig.previousRenderZoom?.node?.x !==
                    "undefined"
                    ? initialX +
                        this._viewConfig.margin.left +
                        newXTranslate(this.type, this._viewConfig, this._zoomConfig)
                    : initialX +
                        this._viewConfig.margin.left;
            },
            defaultCanvasTranslateY: () => {
                const initialY = getInitialYTranslate.call(this, this.type, {
                    defaultView: this._viewConfig.defaultView,
                    levelsHigh: this._viewConfig.levelsHigh,
                });
                return customScale || typeof this._zoomConfig.previousRenderZoom?.node?.y !==
                    "undefined"
                    ? (this._viewConfig.margin.top +
                        initialY +
                        newYTranslate(this.type, this._viewConfig, this._zoomConfig))
                    : initialY + this._viewConfig.margin.top;
            },
            isSmallScreen: function () {
                return this.canvasWidth < 440;
            },
        };
    }
    initializeEventHandlers() {
        return {
            handleEditNode: function ({ orbitEh }) {
                this.modalChildOrbitEh('edit');
                const orbitId = store.get(getOrbitIdFromEh(orbitEh));
                if (!orbitId)
                    return;
                this.modalParentOrbitEh(orbitId);
                this.modalOpen(true);
                this.modalIsOpen = true;
            },
            handlePrependNode: function ({ childOrbitEh }) {
                this.modalChildOrbitEh(childOrbitEh);
                this.modalOpen(true);
                this.modalIsOpen = true;
            },
            handleAppendNode: function ({ parentOrbitEh }) {
                this.modalParentOrbitEh(parentOrbitEh);
                this.modalOpen(true);
                this.modalIsOpen = true;
            },
            handleNodeZoom: (event, node) => {
                if (typeof node == undefined || Number.isNaN(node.x) || Number.isNaN(node.y))
                    return null;
                const orbit = Object.values(this.nodeDetails).find(orbit => orbit.eH == node.data.content);
                const isRootNode = node.data.content == this._originalRootData?.data.content;
                const zoomOffsetY = -(this._viewConfig.isSmallScreen() ? (isRootNode ? NEGATIVE_ZOOM_Y_OFFSET_SM_ROOT : NEGATIVE_ZOOM_Y_OFFSET_SM_NONROOT) : NEGATIVE_ZOOM_Y_OFFSET_MD_LG);
                const scale = (this._viewConfig.isSmallScreen() ? NODE_RESCALE_FACTOR_SM : NODE_RESCALE_FACTOR_MD_LG) * (orbit && orbit.scale ? chooseZoomScaleForOrbit(orbit) : 1);
                const x = -node.x * scale + this._viewConfig.canvasWidth / 2;
                const y = -node.y * scale + this._viewConfig.canvasHeight / 2 + zoomOffsetY;
                this._zoomConfig.globalZoomScale = scale;
                this._zoomConfig.focusMode = true;
                this._zoomConfig.previousRenderZoom = { event, node, scale };
                if (isRootNode) {
                    this.initializeZoomer();
                }
                else {
                }
                return !!(NODE_ENV !== 'test' && !this.noCanvas()) && this._canvas
                    .transition()
                    .duration(this.startInFocusMode ? 0 : PLANNIT_ZOOM_TRANSITION_DURATION)
                    .ease(easeCubicOut)
                    .attr("transform", `translate(${x},${y}) scale(${scale})`);
            },
            memoizedhandleNodeZoom(id, foundNode) {
                if (id === this._lastOrbitId) {
                    return select(null);
                }
                ;
                this._lastOrbitId = id;
                const newId = foundNode?.data.content || id;
                if (!newId)
                    return select(null);
                let node = foundNode
                    || this.rootData.find(node => node.data.content == newId)
                    || this._originalRootData.find(node => node.data.content == newId)
                    || this._nextRootData?.find(node => node.data.content == newId);
                if (node && (typeof node?.x !== undefined) && (typeof node?.y !== undefined)) {
                    const e = {
                        sourceEvent: {
                            clientX: node.x,
                            clientY: node.y
                        },
                        transform: {
                            x: 0,
                            y: 0,
                            k: 1
                        }
                    };
                    return this.eventHandlers.handleNodeZoom.call(this, e, node);
                }
                else {
                    console.error("Tried to zoom to node that isn't in the hierarchy");
                    return null;
                }
            },
            handleZoomOut: () => {
                this.zoomOut();
            },
            handleNodeClick(e) {
                const target = e?.target;
                const currentOrbitId = store.get(currentOrbitDetailsAtom)?.eH;
                const isAppendNodeButtonTarget = !!(target && target.closest(".orbit-controls-container button:first-child"));
                this._enteringNodes.select(".tooltip foreignObject").html(this.appendLabelHtml);
                this._enteringNodes.select(".node-vector-group").attr("class", (d) => {
                    const selected = currentOrbitId && currentOrbitId == d.data.content;
                    const cachedNode = this.nodeDetails[d.data.content];
                    if (!cachedNode)
                        return "node-vector-group";
                    const { eH, scale, name } = cachedNode;
                    const currentDateString = store.get(currentDayAtom).toLocaleString();
                    const isWinning = store.get(calculateCompletionStatusAtom(eH, currentDateString));
                    return "node-vector-group" + (isWinning ? " winning" : "") + getClassesForNodeVectorGroup(selected, scale);
                });
                if (isAppendNodeButtonTarget) {
                    const nodeEh = target.closest(".orbit-controls-container").dataset?.nodeEntryHash;
                    this.eventHandlers.handleAppendNode.call(this, { parentOrbitEh: nodeEh });
                }
            },
        };
    }
    setupLayout() {
        this.layout = tree().size([
            this._viewConfig.canvasWidth / 2,
            this._viewConfig.canvasHeight / 2,
        ]);
        this.layout.nodeSize([
            this._viewConfig.dx,
            this._viewConfig.dy,
        ]);
        this.layout(this.rootData);
    }
    getNextLayout() {
        if (!this._nextRootData)
            return null;
        const layout = tree().size([
            this._viewConfig.canvasWidth / 2,
            this._viewConfig.canvasHeight / 2,
        ]);
        layout.nodeSize([
            this._viewConfig.dx,
            this._viewConfig.dy,
        ]);
        return layout(this._nextRootData);
    }
    handleZoom(event) {
        if (this._zoomConfig.focusMode) {
            const currentScale = event.transform.k;
            if (currentScale < this._zoomConfig.globalZoomScale) {
                this.zoomOut();
            }
            this._zoomConfig.focusMode = false;
        }
        else {
            super.handleZoom(event);
        }
    }
    zoomOut() {
        super.zoomOut();
        if (!this._zoomConfig.focusMode)
            return;
    }
    appendLinkPath() {
        const rootNodeId = this.rootData.data.content;
        const cacheItem = this.nodeDetails[rootNodeId];
        if (!cacheItem || !cacheItem?.path)
            return;
        console.log('Got cache item for path:', cacheItem);
        const newPath = select(".canvas")
            .selectAll("g.links")
            .append("path")
            .attr("d", cacheItem.path)
            .classed("link", true)
            .classed("appended-path", true)
            .attr("stroke-width", LINK_THICKNESS)
            .attr("stroke", LINK_COLOR)
            .attr("data-testid", getTestId(cacheItem.path));
        const pathElement = newPath?._groups?.[0]?.[0];
        if (!pathElement)
            return;
        const { height, width } = pathElement.getBoundingClientRect();
        select(pathElement).attr("transform", `translate(${getPathXTranslation(cacheItem.path, width, (this._viewConfig.isSmallScreen()
            ? XS_TREE_PATH_OFFSET_X
            : LG_TREE_PATH_OFFSET_X) / this._viewConfig.scale) * this._viewConfig.scale},${-((height +
            (this._viewConfig.isSmallScreen()
                ? XS_TREE_PATH_OFFSET_Y
                : LG_TREE_PATH_OFFSET_Y)))})`);
        console.log('Finished appending link paths...');
        function getPathXTranslation(path, width, offset) {
            switch (path) {
                case ONE_CHILD:
                    return 0;
                case ONE_CHILD_XS:
                    return 0;
                case TWO_CHILDREN_LEFT:
                    return width + offset * 1.7;
                case TWO_CHILDREN_RIGHT:
                    return -(width + offset * 1.7);
                case TWO_CHILDREN_LEFT_XS:
                    return width + offset;
                case TWO_CHILDREN_RIGHT_XS:
                    return -(width + offset);
                case THREE_CHILDREN_LEFT:
                    return width + offset * 2;
                case THREE_CHILDREN_RIGHT:
                    return -(width + offset * 2);
                case THREE_CHILDREN_LEFT_XS:
                    return width + offset * 2;
                case THREE_CHILDREN_RIGHT_XS:
                    return -(width + offset * 2);
                case FOUR_CHILDREN_LEFT_1:
                    return width + offset * 3.35;
                case FOUR_CHILDREN_LEFT_2:
                    return width + offset * 1.1;
                case FOUR_CHILDREN_RIGHT_1:
                    return -(width + offset * 1.1);
                case FOUR_CHILDREN_RIGHT_2:
                    return -(width + offset * 3.45);
                case FOUR_CHILDREN_LEFT_1_XS:
                    return width + offset * 3;
                case FOUR_CHILDREN_LEFT_2_XS:
                    return width + offset;
                case FOUR_CHILDREN_RIGHT_1_XS:
                    return -(width + offset);
                case FOUR_CHILDREN_RIGHT_2_XS:
                    return -(width + offset * 3);
                case FIVE_CHILDREN_LEFT_1:
                    return width + offset * 4;
                case FIVE_CHILDREN_LEFT_2:
                    return width + offset * 2;
                case FIVE_CHILDREN_RIGHT_1:
                    return -(width + offset * 2);
                case FIVE_CHILDREN_RIGHT_2:
                    return -(width + offset * 4);
                case FIVE_CHILDREN_LEFT_1_XS:
                    return width + offset * 4;
                case FIVE_CHILDREN_LEFT_2_XS:
                    return width + offset * 2;
                case FIVE_CHILDREN_RIGHT_1_XS:
                    return -(width + offset * 2);
                case FIVE_CHILDREN_RIGHT_2_XS:
                    return -(width + offset * 4);
                case SIX_CHILDREN_LEFT_1:
                    return width + offset * 5;
                case SIX_CHILDREN_LEFT_2:
                    return width + offset * 2;
                case SIX_CHILDREN_LEFT_3:
                    return width + offset * 2;
                case SIX_CHILDREN_RIGHT_1:
                    return -(width + offset * 2);
                case SIX_CHILDREN_RIGHT_2:
                    return -(width + offset * 2);
                case SIX_CHILDREN_RIGHT_3:
                    return -(width + offset * 5);
                case SIX_CHILDREN_LEFT_1_XS:
                    return width + offset * 5;
                case SIX_CHILDREN_LEFT_2_XS:
                    return width + offset * 2;
                case SIX_CHILDREN_LEFT_3_XS:
                    return width + offset * 2;
                case SIX_CHILDREN_RIGHT_1_XS:
                    return -(width + offset * 2);
                case SIX_CHILDREN_RIGHT_2_XS:
                    return -(width + offset * 2);
                case SIX_CHILDREN_RIGHT_3_XS:
                    return -(width + offset * 5);
                default:
                    return 0;
            }
        }
        function getTestId(path) {
            switch (path) {
                case ONE_CHILD:
                    return "path-parent-one-child";
                case ONE_CHILD_XS:
                    return "path-parent-one-child";
                case TWO_CHILDREN_LEFT_XS:
                    return "path-parent-two-children-0";
                case TWO_CHILDREN_RIGHT_XS:
                    return "path-parent-two-children-1";
                case THREE_CHILDREN_LEFT_XS:
                    return "path-parent-three-children-0";
                case THREE_CHILDREN_RIGHT_XS:
                    return "path-parent-three-children-2";
                default:
                    return "none";
            }
        }
    }
    getLinkPathGenerator() {
        return link(curves.curveCustomBezier)
            .x((d) => d.x)
            .y((d) => d.y);
    }
    setNodeAndLinkEnterSelections() {
        const nodes = this._gNode.selectAll("g.node").data(this.rootData
            .descendants()
            .reverse()
            .filter((d) => {
            return true;
        }), (d) => d.data.content);
        nodes.exit().remove();
        this._enteringNodes = nodes
            .enter()
            .append("g")
            .attr("class", "the-node")
            .attr("data-testid", (d, i) => "test-node")
            .attr("transform", (d) => {
            return this.type == VisType.Cluster
                ? `translate(${d.y},${d.x})`
                : `translate(${d.x},${d.y})`;
        });
        const links = this._gLink.selectAll("line.link")
            .data(this.rootData.links());
        this._enteringLinks = links
            .enter()
            .append("path")
            .classed("link", true)
            .attr("stroke-width", LINK_THICKNESS)
            .attr("stroke", LINK_COLOR)
            .attr("d", this.getLinkPathGenerator());
    }
    setNodeAndLabelGroups() {
        this._gCircle = this._enteringNodes.append("g")
            .classed("node-subgroup", true);
    }
    appendNodeVectors() {
        this._gCircle
            .append('foreignObject')
            .attr("transform", (d) => {
            const cachedNode = this.nodeDetails[d.data.content];
            const { scale } = cachedNode;
            return `scale(${this._viewConfig.isSmallScreen() ? getScaleForPlanet(scale) : 0.75})`;
        })
            .attr("width", "100")
            .attr("height", "100")
            .attr("x", "-50")
            .attr("y", (d) => {
            if (!d?.data?.content || !this.nodeDetails[d.data.content])
                return "";
            const { scale } = this.nodeDetails[d.data.content];
            switch (scale) {
                case "Astro":
                    return "-5";
                case "Sub":
                    return "10";
                case "Atom":
                    return "100";
            }
        })
            .append("xhtml:div")
            .classed("node-vector-group", true)
            .append("xhtml:div")
            .classed("node-vector", true)
            .attr("xmlns", "http://www.w3.org/1999/xhtml")
            .attr("style", (d) => {
            if (!d?.data?.content || !this.nodeDetails[d.data.content])
                return "";
            const mode = store.get(performanceModeAtom);
            const { scale } = this.nodeDetails[d.data.content];
            const imageVersion = mode == 'snancy' ? "1" : mode == 'snappy' ? "2" : "";
            console.log('mode, imageVersion :>> ', mode, imageVersion);
            switch (scale) {
                case "Atom":
                    return `background: url(assets/moon${imageVersion}.svg);background-position: bottom;background-size: cover;background-repeat: no-repeat;width: 100%;height: 100%;`;
                case "Astro":
                    return `background: url(assets/sun${imageVersion}.svg);background-position: bottom;background-size: cover;background-repeat: no-repeat;width: 100%;height: 100%;`;
                case "Sub":
                    return `background: url(assets/planet${imageVersion}.svg);background-position: bottom;background-size: cover;background-repeat: no-repeat;width: 100%;height: 100%;`;
            }
        });
    }
}
//# sourceMappingURL=TreeVis.js.map