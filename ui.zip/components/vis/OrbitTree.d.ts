import React, { ComponentType } from "react";
import { VisProps } from "./types";
import { TreeVisualization } from "./base-classes/TreeVis";
export declare const OrbitTree: ComponentType<VisProps<TreeVisualization>>;
declare const _default: React.NamedExoticComponent<VisProps<TreeVisualization>>;
export default _default;
//# sourceMappingURL=OrbitTree.d.ts.map