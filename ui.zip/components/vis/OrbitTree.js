import { jsx as _jsx, Fragment as _Fragment, jsxs as _jsxs } from "react/jsx-runtime";
import React, { useEffect, useState } from 'react';
import { VisCoverage, VisType } from './types';
import { hierarchy } from "d3-hierarchy";
import { useGetLowestSphereHierarchyLevelQuery, useGetOrbitHierarchyLazyQuery } from '../../graphql/generated';
import { useAtom, useAtomValue } from 'jotai';
import { useStateTransition } from '../../hooks/useStateTransition';
import { nodeCache, store } from '../../state/jotaiKeyValueStore';
import { currentSphereHierarchyBounds, currentSphereHierarchyIndices, setBreadths, setDepths } from '../../state/hierarchy';
import { currentOrbitIdAtom } from '../../state/orbit';
import { newTraversalLevelIndexId } from '../../state/hierarchy';
import { useFetchOrbitsAndCacheHierarchyPaths } from '../../hooks/useFetchOrbitsAndCacheHierarchyPaths';
import { TreeVisualization } from './base-classes/TreeVis';
import { currentSphereOrbitNodesAtom } from '../../state/orbit';
import { isSmallScreen } from './helpers';
import { useNodeTraversal } from '../../hooks/useNodeTraversal';
export const OrbitTree = ({ selectedSphere: sphere, canvasHeight, canvasWidth, margin, render }) => {
    const [_state, transition, params] = useStateTransition();
    const nodeDetailsCache = Object.fromEntries(useAtomValue(nodeCache.entries));
    const nodes = useAtomValue(currentSphereOrbitNodesAtom);
    const needToUpdateCache = !nodes || typeof nodes !== 'object' || Object.keys(nodes).length === 0;
    const sphereNodeDetails = !needToUpdateCache
        ? Object.fromEntries(Object.entries(nodes).map(([_, nodeDetails]) => [nodeDetails.eH, nodeDetails]))
        : {};
    const hierarchyBounds = useAtomValue(currentSphereHierarchyBounds);
    const [, setBreadthBounds] = useAtom(setBreadths);
    const [depthBounds, setDepthBounds] = useAtom(setDepths);
    const { x, y } = useAtomValue(currentSphereHierarchyIndices);
    const { breadthIndex, setBreadthIndex } = useNodeTraversal(hierarchyBounds[sphere.entryHash]);
    const visCoverage = params?.orbitEh ? VisCoverage.CompleteOrbit : y == 0 ? VisCoverage.CompleteSphere : VisCoverage.Partial;
    const getQueryParams = (customDepth) => visCoverage == VisCoverage.CompleteOrbit
        ? { orbitEntryHashB64: params.orbitEh }
        : { levelQuery: { sphereHashB64: params?.currentSphereEhB64, orbitLevel: customDepth || 0 } };
    const getJsonDerivation = (json) => { return visCoverage == VisCoverage.CompleteOrbit ? JSON.parse(json) : JSON.parse(json)[x]; };
    const [getHierarchy, { data, loading, error }] = useGetOrbitHierarchyLazyQuery({
        fetchPolicy: "network-only"
    });
    const [json, setJson] = useState(null);
    const [currentOrbitTree, setCurrentOrbitTree] = useState(null);
    const { data: dataLevel, loading: loadLevel, error: errorLevel } = useGetLowestSphereHierarchyLevelQuery({ variables: { sphereEntryHashB64: sphere.entryHash } });
    const [hasCached, setHasCached] = useState(false);
    const { loading: loadCache, error: errorCache, cache } = useFetchOrbitsAndCacheHierarchyPaths({ params: getQueryParams(dataLevel?.getLowestSphereHierarchyLevel || 0), hasCached, currentSphereId: sphere.actionHash, bypass: true });
    const fetchHierarchyData = () => {
        if (error)
            return;
        const query = depthBounds
            ? { ...getQueryParams(), orbitLevel: 0 }
            : getQueryParams(y);
        getHierarchy({ variables: { params: { ...query } } });
    };
    const instantiateVisObject = () => {
        if (!error && json && !currentOrbitTree && nodeDetailsCache[params?.currentSphereAhB64]) {
            const currentTreeJson = getJsonDerivation(json);
            const hierarchyData = hierarchy(currentTreeJson).sort(byStartTime);
            setDepthBounds(params?.currentSphereEhB64, [0, visCoverage == VisCoverage.CompleteOrbit ? 100 : hierarchyData.height]);
            const orbitVis = new TreeVisualization(VisType.Tree, visCoverage, 'vis', hierarchyData, canvasHeight, canvasWidth, margin, transition, params?.currentSphereEhB64, params?.currentSphereAhB64, sphereNodeDetails);
            setCurrentOrbitTree(orbitVis);
        }
    };
    useEffect(() => {
        if (!hasCached && cache !== null) {
            try {
                cache();
                setHasCached(true);
            }
            catch (error) {
                console.error(error);
            }
        }
    }, [cache, data]);
    useEffect(fetchHierarchyData, [y]);
    useEffect(() => {
        if (!error && typeof data?.getOrbitHierarchy === 'string') {
            let parsedData = JSON.parse(data.getOrbitHierarchy);
            while (typeof parsedData === 'string') {
                parsedData = JSON.parse(parsedData);
            }
            if (!!currentOrbitTree) {
                visCoverage == VisCoverage.Partial ? currentOrbitTree.resetZoomer() : currentOrbitTree.initializeZoomer();
            }
            console.log('parsedData.result.level_trees.length :>> ', parsedData.result);
            setBreadthBounds(params?.currentSphereEhB64, [0, visCoverage == VisCoverage.CompleteOrbit ? 100 : parsedData.result.level_trees.length - 1]);
            const sorted = isSmallScreen() ? parsedData.result.level_trees.sort(byStartTime).reverse() : parsedData.result.level_trees.sort(byStartTime);
            const isNewLevelXIndex = store.get(newTraversalLevelIndexId);
            let newLevelXIndex = isNewLevelXIndex && sorted.map(d => d.content).findIndex(id => id == store.get(newTraversalLevelIndexId).id);
            if (isNewLevelXIndex) {
                store.set(newTraversalLevelIndexId, { id: null });
            }
            const newHierarchyDescendants = hierarchy(sorted[0])?.sort(byStartTime)?.descendants()?.length;
            const oldHierarchyDescendants = currentOrbitTree?.rootData.descendants().length;
            setHasCached(newHierarchyDescendants == oldHierarchyDescendants);
            setJson(JSON.stringify(visCoverage == VisCoverage.CompleteOrbit ? parsedData.result : sorted));
            const rootNode = visCoverage == VisCoverage.CompleteOrbit ? parsedData.result : sorted[newLevelXIndex !== -1 ? newLevelXIndex : 0];
            store.set(currentOrbitIdAtom, rootNode?.content);
            if (newLevelXIndex !== -1) {
                store.set(currentSphereHierarchyIndices, { x: newLevelXIndex, y });
            }
            setBreadthIndex(newLevelXIndex !== -1 ? newLevelXIndex : breadthIndex);
        }
    }, [data]);
    useEffect(instantiateVisObject, [json]);
    useEffect(() => {
        if (!error && typeof data?.getOrbitHierarchy === 'string' && currentOrbitTree) {
            currentOrbitTree._nextRootData = hierarchy(getJsonDerivation(json)).sort(byStartTime);
            store.set(currentOrbitIdAtom, currentOrbitTree._nextRootData.data.content);
            currentOrbitTree.render();
        }
    }, [json, x, y, data]);
    return (_jsxs(_Fragment, { children: [loading || needToUpdateCache && _jsx("span", { "data-testid": 'vis-spinner' }), !error && json && currentOrbitTree && render(currentOrbitTree, visCoverage, x, y, hierarchy(getJsonDerivation(json)))] }));
};
export default React.memo(OrbitTree);
export function byStartTime(a, b) {
    const idA = a?.data?.content || a?.content;
    const idB = b?.data?.content || b?.content;
    const nodeDetailsCache = store.get(currentSphereOrbitNodesAtom);
    if ((nodeDetailsCache?.[idB]?.startTime || 0) - (nodeDetailsCache?.[idA]?.startTime || 0) == 0) {
        console.error("Sorting error!");
        return 0;
    }
    return isSmallScreen()
        ? (nodeDetailsCache?.[idB]?.startTime || 0) - (nodeDetailsCache?.[idA]?.startTime || 0)
        : (nodeDetailsCache?.[idA]?.startTime || 0) - (nodeDetailsCache?.[idB]?.startTime || 0);
}
//# sourceMappingURL=OrbitTree.js.map