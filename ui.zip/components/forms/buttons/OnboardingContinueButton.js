import { jsx as _jsx } from "react/jsx-runtime";
import { Button } from "habit-fract-design-system";
const OnboardingContinue = ({ onClick, ...props }) => {
    return (_jsx("div", { className: "onboarding-continue", children: _jsx(Button, { isLoading: props.loading, type: "submit", variant: "primary responsive", onClick: onClick, ...props, children: "Save & Continue" }) }));
};
export default OnboardingContinue;
//# sourceMappingURL=OnboardingContinueButton.js.map