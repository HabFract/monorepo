import { jsx as _jsx } from "react/jsx-runtime";
import { Button } from 'habit-fract-design-system';
const OnboardingContinue = ({ onClick }) => {
    return (_jsx(Button, { loading: false, type: "onboarding", onClick: onClick, children: "Save & Continue" }));
};
export default OnboardingContinue;
//# sourceMappingURL=OnboardingContinueButton.js.map