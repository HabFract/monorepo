import { FC } from "react";
interface OnboardingContinueProps {
    onClick: () => void;
    touched?: object;
    errors?: object;
    loading?: boolean;
}
declare const OnboardingContinue: FC<OnboardingContinueProps>;
export default OnboardingContinue;
//# sourceMappingURL=OnboardingContinueButton.d.ts.map