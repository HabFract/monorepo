declare const DefaultSubmitBtn: ({ loading, errors, touched, editMode, onClick, }: {
    loading: boolean;
    errors: object;
    touched: object;
    editMode: boolean;
    onClick: () => void;
}) => import("react/jsx-runtime").JSX.Element;
export default DefaultSubmitBtn;
//# sourceMappingURL=DefaultSubmitButton.d.ts.map