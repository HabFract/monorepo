import { jsx as _jsx } from "react/jsx-runtime";
import { Button } from "habit-fract-design-system";
const DefaultSubmitBtn = ({ loading, errors, touched, editMode, onClick, }) => {
    return (_jsx(Button, { type: "submit", isLoading: loading, variant: editMode ? "warn responsive" : "primary responsive", isDisabled: loading ||
            !!Object.values(errors).length ||
            !!(Object.values(touched).filter((value) => value).length < 1), onClick: onClick, children: editMode ? ("Update") : ("Create") }));
};
export default DefaultSubmitBtn;
//# sourceMappingURL=DefaultSubmitButton.js.map