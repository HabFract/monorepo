import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import React, { useMemo, useState } from "react";
import { Formik, Form, Field } from "formik";
import * as Yup from "yup";
import { DateTime } from "luxon";
import { Frequency, GetOrbitHierarchyDocument, Scale, useGetOrbitsQuery, } from "../../graphql/generated";
import { extractEdges } from "../../graphql/utils";
import { useCreateOrbitMutation } from "../../hooks/gql/useCreateOrbitMutation";
import { useStateTransition } from "../../hooks/useStateTransition";
import { currentOrbitIdAtom, decodeFrequency, getOrbitNodeDetailsFromEhAtom } from "../../state/orbit";
import { store } from "../../state/store";
import DefaultSubmitBtn from "./buttons/DefaultSubmitButton";
import { TextAreaField, TextInputField, SelectInputField, getIconForPlanetValue, HelperText, getFrequencyDisplayNameLong, } from "habit-fract-design-system";
import { OrbitFetcher } from "./utils";
import { currentSphereDetailsAtom, currentSphereHashesAtom } from "../../state/sphere";
import { currentSphereHierarchyIndices, newTraversalLevelIndexId } from "../../state/hierarchy";
import { useUpdateOrbitMutation } from "../../hooks/gql/useUpdateOrbitMutation";
import { getScaleDisplayName } from "../vis/helpers";
import { ERROR_MESSAGES, INPUT_INFO_MODALS, ONBOARDING_FORM_DESCRIPTIONS } from "../../constants";
import Collapse from "antd/es/collapse";
export const OrbitValidationSchema = Yup.object().shape({
    name: Yup.string()
        .min(4, ERROR_MESSAGES['orbit-name-short'])
        .max(55, ERROR_MESSAGES['orbit-name-long'])
        .matches(/(?!^\d+$)^.+$/, ERROR_MESSAGES['orbit-name-letters'])
        .required(ERROR_MESSAGES['orbit-name-empty']),
    description: Yup.string()
        .matches(/(?!^\d+$)^.+$/, ERROR_MESSAGES['orbit-description-letters']),
    startTime: Yup.number()
        .min(0)
        .required(ERROR_MESSAGES['orbit-start-required']),
    endTime: Yup.number(),
    frequency: Yup.mixed()
        .oneOf(Object.values(Frequency))
        .required(ERROR_MESSAGES['orbit-frequency-required']),
    scale: Yup.mixed()
        .oneOf(Object.values(Scale))
        .required(ERROR_MESSAGES['orbit-scale-required']),
    parentHash: Yup.string().nullable("Can be null"),
    childHash: Yup.string().nullable("Can be null"),
    archival: Yup.boolean(),
});
const CreateOrbit = ({ editMode = false, inModal = false, orbitToEditId, sphereEh, parentOrbitEh, childOrbitEh, onCreateSuccess, headerDiv, submitBtn, }) => {
    const [state, transition, params] = useStateTransition();
    const selectedSphere = store.get(currentSphereHashesAtom);
    const selectedSphereDetails = store.get(currentSphereDetailsAtom);
    const { _x, y } = store.get(currentSphereHierarchyIndices);
    const inOnboarding = state.match("Onboarding");
    const originPage = inOnboarding
        ? "Onboarding2"
        : !!(parentOrbitEh || childOrbitEh)
            ? "Vis"
            : "ListOrbits";
    const [addOrbit] = useCreateOrbitMutation({
        awaitRefetchQueries: !inOnboarding,
        refetchQueries: () => [
            {
                query: GetOrbitHierarchyDocument,
                variables: {
                    params: { levelQuery: { sphereHashB64: sphereEh, orbitLevel: y } },
                },
            },
        ],
        update() {
            if (typeof onCreateSuccess !== "undefined") {
                onCreateSuccess.call(this);
            }
        },
    });
    const [updateOrbit] = useUpdateOrbitMutation({
        refetchQueries: inOnboarding ? [] : ["getOrbits"],
    });
    const { data: orbits, loading: getAllLoading, error, } = useGetOrbitsQuery({
        skip: !sphereEh,
        fetchPolicy: "network-only",
        variables: { sphereEntryHashB64: sphereEh },
    });
    const loading = getAllLoading;
    const [currentOrbitValues, _] = useState({
        name: "",
        description: "",
        startTime: DateTime.now().toMillis(),
        endTime: DateTime.now().toMillis(),
        frequency: Frequency.DailyOrMore_1d,
        scale: undefined,
        archival: false,
        parentHash: !!childOrbitEh ? "root" : parentOrbitEh || null,
        childHash: childOrbitEh || null,
    });
    const orbitEdges = extractEdges(orbits?.orbits);
    const parentNodeAtom = useMemo(() => getOrbitNodeDetailsFromEhAtom(currentOrbitValues?.parentHash), [currentOrbitValues.parentHash]);
    const parentNodeDetails = !(editMode && state.match("Onboarding")) &&
        currentOrbitValues.parentHash !== null &&
        store.get(parentNodeAtom);
    const descriptionParts = ONBOARDING_FORM_DESCRIPTIONS[1].split('[em]');
    return (_jsx(Formik, { initialValues: currentOrbitValues, validationSchema: OrbitValidationSchema, onSubmit: async (values, { setSubmitting, validateForm }) => {
            try {
                const errors = await validateForm();
                if (Object.keys(errors).length === 0) {
                    if (!values.archival)
                        delete values.endTime;
                    delete values.archival;
                    delete values.eH;
                    if (editMode)
                        delete values.childHash;
                    let response = editMode
                        ? await updateOrbit({
                            variables: {
                                orbitFields: {
                                    id: orbitToEditId,
                                    ...values,
                                    sphereHash: sphereEh,
                                    parentHash: parentOrbitEh
                                        ? parentOrbitEh
                                        : values.parentHash || undefined,
                                },
                            },
                        })
                        : await addOrbit({
                            variables: {
                                variables: {
                                    ...values,
                                    sphereHash: sphereEh,
                                    parentHash: parentOrbitEh
                                        ? parentOrbitEh
                                        : values.parentHash || undefined,
                                    childHash: values.childHash || undefined,
                                },
                            },
                        });
                    setSubmitting(false);
                    if (!response.data)
                        return;
                    const payload = response.data;
                    if (originPage == "Vis" && !editMode) {
                        store.set(newTraversalLevelIndexId, { id: payload.createOrbit.eH, direction: "new" });
                        transition("Vis", {
                            currentSphereEhB64: sphereEh,
                            currentSphereAhB64: selectedSphere.actionHash,
                            currentSphereDetails: selectedSphereDetails
                        });
                    }
                    else {
                        const orbitAh = editMode
                            ? payload.updateOrbit.id
                            : payload.createOrbit.id;
                        const props = inOnboarding
                            ? { refiningOrbitAh: orbitAh, spin: params?.spin }
                            : { sphereAh: selectedSphere.actionHash, currentSphereDetails: selectedSphereDetails };
                        store.set(currentOrbitIdAtom, orbitAh);
                        transition(inOnboarding ? "Onboarding3" : "ListOrbits", props);
                    }
                }
            }
            catch (error) {
                console.error(error);
            }
        }, children: ({ values, errors, touched, setFieldValue, validateForm, submitForm }) => {
            const handleSubmit = () => {
                try {
                    submitForm();
                    Object.values(errors).length == 0 && submitBtn.props.onClick.call(null);
                }
                catch (error) {
                    console.log('error :>> ', error);
                }
            };
            const submitButton = submitBtn ? (React.cloneElement(submitBtn, {
                loading,
                errors,
                touched,
                disabled: Object.keys(errors).length > 0 && Object.keys(touched).length > 0,
                onClick: handleSubmit
            })) : (_jsx(DefaultSubmitBtn, { loading: loading, editMode: editMode, errors: errors, touched: touched, onClick: handleSubmit }));
            const cannotBeAstro = !(editMode && state.match("Onboarding")) &&
                values.parentHash !== null &&
                values.parentHash !== "root";
            const cannotBeSub = parentNodeDetails && parentNodeDetails.scale == Scale.Atom;
            const scaleDefault = cannotBeSub
                ? Scale.Atom
                : cannotBeAstro
                    ? Scale.Sub
                    : Scale.Astro;
            if (!values?.scale) {
                setFieldValue("scale", scaleDefault);
            }
            function getExampleForScale(scale) {
                switch (scale) {
                    case "Star":
                        return `"Plan to run a marathon" in the Health and Fitness space.`;
                    case "Giant":
                        return `"I commit to starting a training plan" in the Health and Fitness space.`;
                    case "Dwarf":
                        return `"Warm up for 5 minutes" in the Health and Fitness space.`;
                }
            }
            return (_jsxs("section", { children: [!inModal ? headerDiv : null, _jsxs("div", { className: "content", children: [state.match("Onboarding") && _jsxs(_Fragment, { children: [_jsxs("div", { className: "form-description", children: [descriptionParts[0], "\u00A0", _jsx(Collapse, { size: "small", items: [{ key: '1', label: _jsx("em", { children: descriptionParts[1] }), children: _jsxs(_Fragment, { children: [_jsxs("p", { children: [descriptionParts[2], _jsx("em", { children: descriptionParts[3] }), "."] }), _jsx("p", { children: descriptionParts[4] })] }) }] })] }), _jsxs("figure", { children: [_jsx("figcaption", { className: "figure-captions", children: ['Star', 'Giant', 'Dwarf'].map(scale => _jsx(HelperText, { withInfo: true, onClickInfo: () => ({
                                                        title: `Planitt Scales`,
                                                        label: `${scale}`,
                                                        body: scale,
                                                        footer: `Example: 
                        ${getExampleForScale(scale)}`
                                                    }), children: scale }, scale)) }), _jsx("div", { className: "figure-images", children: ['sun', 'planet', 'moon'].map(scale => _jsx("div", { className: "figure-image-container", children: _jsx("img", { src: `assets/${scale}.svg`, alt: `${scale} figure`, style: { width: "100%" } }, scale) }, scale)) })] })] }), _jsxs(Form, { noValidate: true, onSubmit: async (e) => {
                                    e.preventDefault();
                                    const errors = await validateForm();
                                    if (Object.keys(errors).length === 0) {
                                        submitForm();
                                    }
                                }, children: [!parentOrbitEh && !inOnboarding && (_jsx("div", { className: "form-field flex", children: _jsx(Field, { component: SelectInputField, size: "base", name: "parentHash", id: "parent-hash", withInfo: true, onClickInfo: () => ({
                                                title: "Good Parenting",
                                                body: "Choose the parent which describes behaviour of a bigger scope. //For instance, if the name of your Planitt is 'Run a 10k', maybe the parent is the Plannet with the scope 'Run a 20k'. //Setting your parent to 'None' will make it the top of a new hierarchy.",
                                            }), onBlur: () => {
                                                setFieldValue("scale", scaleDefault);
                                            }, options: [
                                                ...(orbitEdges.length == 0
                                                    ? [_jsx("option", { value: "root", children: "None" })]
                                                    : (childOrbitEh
                                                        ? []
                                                        : orbitEdges.map((orbit, i) => (_jsx("option", { value: orbit.eH, children: orbit.name }, i))))),
                                            ], required: true, disabled: !!editMode, labelValue: "Parent Planitt:" }) })), editMode && _jsx(OrbitFetcher, { orbitToEditId: orbitToEditId }), _jsx("div", { className: "form-field flex", children: _jsx(Field, { component: SelectInputField, size: "base", name: "scale", value: values?.scale || scaleDefault, id: "scale", icon: (() => {
                                                const currentValue = values.scale || scaleDefault;
                                                return getIconForPlanetValue(cannotBeAstro && cannotBeSub
                                                    ? Scale.Atom
                                                    : currentValue == Scale.Astro && cannotBeAstro
                                                        ? Scale.Sub
                                                        : currentValue);
                                            })(), iconSide: "left", disabled: !editMode &&
                                                !parentOrbitEh &&
                                                !state.match("Onboarding") &&
                                                !(touched?.parentHash || touched?.childHash) &&
                                                parentOrbitEh !== null, withInfo: true, onClickInfo: () => INPUT_INFO_MODALS['scales'], options: [
                                                ...Object.values(Scale).map((scale) => {
                                                    return (cannotBeAstro && scale == Scale.Astro) ||
                                                        (cannotBeSub && scale == Scale.Sub) ? null : (_jsx("option", { value: scale, children: getScaleDisplayName(scale) }, scale));
                                                }),
                                            ].filter((el) => el !== null), required: true, labelValue: "Scale:" }) }), state.match("Onboarding") && _jsxs("p", { style: { alignSelf: 'flex-start' }, children: [descriptionParts[5], _jsx("em", { children: descriptionParts[6] }), descriptionParts[7]] }), _jsx("div", { className: "form-field flex", children: _jsx(Field, { component: TextInputField, size: "base", name: "name", id: "name", icon: "tag", iconSide: "left", withInfo: true, onClickInfo: () => INPUT_INFO_MODALS['planitt-name'], required: true, value: editMode ? values.name : undefined, labelValue: "Name:", placeholder: "E.g. Run for 10 minutes" }) }), _jsx("div", { className: "form-field flex", children: _jsx(Field, { component: TextAreaField, size: "base", name: "description", id: "description", required: false, labelValue: "Intention:", placeholder: "E.g. Give some more details..." }) }), _jsx("div", { className: "form-field flex", children: _jsx(Field, { component: SelectInputField, size: "base", name: "frequency", value: values?.frequency, id: "frequency", icon: (() => {
                                                const currentValue = values.frequency || 1;
                                                return currentValue;
                                            })(), iconSide: "left", disabled: false, options: [
                                                ...Object.values(Frequency).filter((frequency) => frequency.startsWith('D')).map((frequency) => {
                                                    return (_jsx("option", { value: frequency, children: getFrequencyDisplayNameLong(decodeFrequency(frequency)) }, frequency));
                                                }),
                                            ].filter((el) => el !== null), required: true, labelValue: "Frequency:" }) }), inModal
                                        ? _jsx("div", { className: "modal-submit-btn bottom-4 absolute", children: submitButton })
                                        : _jsx(_Fragment, { children: submitButton })] })] })] }));
        } }));
};
export default CreateOrbit;
//# sourceMappingURL=CreateOrbit.js.map