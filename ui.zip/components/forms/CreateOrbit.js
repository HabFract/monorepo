import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import React, { useMemo, useState } from "react";
import { Formik, Form, Field } from "formik";
import * as Yup from "yup";
import { DateTime } from "luxon";
import { Frequency, GetOrbitHierarchyDocument, Scale, useGetOrbitsQuery, } from "../../graphql/generated";
import { extractEdges } from "../../graphql/utils";
import { useCreateOrbitMutation } from "../../hooks/gql/useCreateOrbitMutation";
import { useStateTransition } from "../../hooks/useStateTransition";
import { currentOrbitIdAtom, getOrbitNodeDetailsFromEhAtom } from "../../state/orbit";
import { store } from "../../state/store";
import DefaultSubmitBtn from "./buttons/DefaultSubmitButton";
import { TextAreaField, TextInputField, SelectInputField, getIconForPlanetValue, } from "habit-fract-design-system";
import { OrbitFetcher } from "./utils";
import { currentSphereHashesAtom } from "../../state/sphere";
import { currentSphereHierarchyIndices, newTraversalLevelIndexId } from "../../state/hierarchy";
import { useUpdateOrbitMutation } from "../../hooks/gql/useUpdateOrbitMutation";
export const OrbitValidationSchema = Yup.object().shape({
    name: Yup.string()
        .min(3, "Must be 4 characters or more")
        .max(55, "Must be 55 characters or less")
        .matches(/(?!^\d+$)^.+$/, "Name must contain letters.")
        .required("Name is required"),
    description: Yup.string().matches(/(?!^\d+$)^.+$/, "Description must contain letters."),
    startTime: Yup.number().min(0).required("Start date/time is required"),
    endTime: Yup.number(),
    frequency: Yup.mixed()
        .oneOf(Object.values(Frequency))
        .required("Choose a frequency"),
    scale: Yup.mixed().oneOf(Object.values(Scale)).required("Choose a scale"),
    parentHash: Yup.string().nullable("Can be null"),
    childHash: Yup.string().nullable("Can be null"),
    archival: Yup.boolean(),
});
const CreateOrbit = ({ editMode = false, inModal = false, orbitToEditId, sphereEh, parentOrbitEh, childOrbitEh, onCreateSuccess, headerDiv, submitBtn, }) => {
    const [state, transition] = useStateTransition();
    const selectedSphere = store.get(currentSphereHashesAtom);
    const { _x, y } = store.get(currentSphereHierarchyIndices);
    const inOnboarding = state.match("Onboarding");
    const originPage = inOnboarding
        ? "Onboarding2"
        : !!(parentOrbitEh || childOrbitEh)
            ? "Vis"
            : "ListOrbits";
    const [addOrbit] = useCreateOrbitMutation({
        awaitRefetchQueries: !inOnboarding && !!(parentOrbitEh || childOrbitEh),
        refetchQueries: () => [
            {
                query: GetOrbitHierarchyDocument,
                variables: {
                    params: { levelQuery: { sphereHashB64: sphereEh, orbitLevel: y } },
                },
            },
        ],
        update() {
            if (typeof onCreateSuccess !== "undefined") {
                onCreateSuccess.call(this);
            }
        },
    });
    const [updateOrbit] = useUpdateOrbitMutation({
        refetchQueries: inOnboarding ? [] : ["getOrbits"],
    });
    const { data: orbits, loading: getAllLoading, error, } = useGetOrbitsQuery({
        fetchPolicy: "network-only",
        variables: { sphereEntryHashB64: sphereEh },
    });
    const loading = getAllLoading;
    const [currentOrbitValues, _] = useState({
        name: "",
        description: "",
        startTime: DateTime.now().toMillis(),
        endTime: DateTime.now().toMillis(),
        frequency: Frequency.DailyOrMore_1d,
        scale: undefined,
        archival: false,
        parentHash: !!childOrbitEh ? "root" : parentOrbitEh || null,
        childHash: childOrbitEh || null,
    });
    const orbitEdges = extractEdges(orbits?.orbits);
    const parentNodeAtom = useMemo(() => getOrbitNodeDetailsFromEhAtom(currentOrbitValues?.parentHash), [currentOrbitValues.parentHash]);
    const parentNodeDetails = !(editMode && state.match("Onboarding")) &&
        currentOrbitValues.parentHash !== null &&
        store.get(parentNodeAtom);
    return (_jsx(Formik, { initialValues: currentOrbitValues, validationSchema: OrbitValidationSchema, onSubmit: async (values, { setSubmitting }) => {
            try {
                if (!values.archival)
                    delete values.endTime;
                delete values.archival;
                delete values.eH;
                if (editMode)
                    delete values.childHash;
                let response = editMode
                    ? await updateOrbit({
                        variables: {
                            orbitFields: {
                                id: orbitToEditId,
                                ...values,
                                sphereHash: sphereEh,
                                parentHash: parentOrbitEh
                                    ? parentOrbitEh
                                    : values.parentHash || undefined,
                            },
                        },
                    })
                    : await addOrbit({
                        variables: {
                            variables: {
                                ...values,
                                sphereHash: sphereEh,
                                parentHash: parentOrbitEh
                                    ? parentOrbitEh
                                    : values.parentHash || undefined,
                                childHash: values.childHash || undefined,
                            },
                        },
                    });
                setSubmitting(false);
                if (!response.data)
                    return;
                const payload = response.data;
                if (originPage == "Vis") {
                    store.set(newTraversalLevelIndexId, { id: payload.createOrbit.eH, direction: "new" });
                    transition("Vis", {
                        currentSphereEhB64: sphereEh,
                        currentSphereAhB64: selectedSphere.actionHash,
                    });
                }
                else {
                    const orbitAh = editMode
                        ? payload.updateOrbit.id
                        : payload.createOrbit.id;
                    const props = inOnboarding
                        ? { refiningOrbitAh: orbitAh }
                        : { sphereAh: selectedSphere.actionHash };
                    store.set(currentOrbitIdAtom, orbitAh);
                    transition(inOnboarding ? "Onboarding3" : "ListOrbits", props);
                }
            }
            catch (error) {
                console.error(error);
            }
        }, children: ({ values, errors, touched, setFieldValue }) => {
            const cannotBeAstro = !(editMode && state.match("Onboarding")) &&
                values.parentHash !== null &&
                values.parentHash !== "root";
            const cannotBeSub = parentNodeDetails && parentNodeDetails.scale == Scale.Atom;
            const scaleDefault = cannotBeSub
                ? Scale.Atom
                : cannotBeAstro
                    ? Scale.Sub
                    : Scale.Astro;
            if (!values?.scale) {
                setFieldValue("scale", scaleDefault);
            }
            return (_jsxs("div", { className: inModal ? "px-2 w-full" : "px-1", children: [!inModal ? headerDiv : null, !inModal && (_jsx("h2", { className: "onboarding-subtitle hidden-sm;", children: editMode ? "Edit Orbit Details" : "Create an Orbit" })), _jsxs("p", { className: "form-description", children: ["An orbit is a ", _jsx("em", { children: "specific life action" }), " that your wish to track over time."] }), _jsxs(Form, { noValidate: true, children: [editMode && _jsx(OrbitFetcher, { orbitToEditId: orbitToEditId }), _jsx("div", { className: "flex form-field", children: _jsx(Field, { component: TextInputField, size: "base", name: "name", id: "name", icon: "tag", iconSide: "left", withInfo: true, onClickInfo: () => ({
                                        title: "The name should be scale-appropriate",
                                        body: "Try to make the name in line with the scale of the Orbit. For example, an Atomic Orbit might be called 'Meditate for 10 minutes'",
                                    }), required: true, value: editMode ? values.name : undefined, labelValue: "Name:", placeholder: "E.g. Run for 10 minutes" }) }), _jsx("div", { className: "flex form-field", children: _jsx(Field, { component: TextAreaField, size: "base", name: "description", id: "description", required: false, labelValue: "Description:", placeholder: "E.g. Give some more details..." }) }), !parentOrbitEh && !inOnboarding && (_jsx("div", { className: "flex form-field", children: _jsx(Field, { component: SelectInputField, size: "base", name: "parentHash", id: "parent-hash", withInfo: true, onClickInfo: () => ({
                                        title: "Good Parenting",
                                        body: "Choose the parent which describes behaviour of a bigger scope. For instance, if the name of your Orbit is 'Run a 10k', maybe the next biggest scope is 'Run a 20k'. Setting your parent to 'None' will make it the top of a new hierarchy.",
                                    }), onBlur: () => {
                                        setFieldValue("scale", scaleDefault);
                                    }, options: [
                                        _jsx("option", { value: "root", children: "None" }),
                                        ...(childOrbitEh
                                            ? []
                                            : orbitEdges.map((orbit, i) => (_jsx("option", { value: orbit.eH, children: orbit.name }, i)))),
                                    ], required: true, disabled: !!editMode, labelValue: "Parent Orbit:" }) })), _jsx("div", { className: "flex form-field", children: _jsx(Field, { component: SelectInputField, size: "base", name: "scale", value: values?.scale || scaleDefault, id: "scale", icon: (() => {
                                        const currentValue = values.scale || scaleDefault;
                                        return getIconForPlanetValue(cannotBeAstro && cannotBeSub
                                            ? Scale.Atom
                                            : currentValue == Scale.Astro && cannotBeAstro
                                                ? Scale.Sub
                                                : currentValue);
                                    })(), iconSide: "left", disabled: !editMode &&
                                        !parentOrbitEh &&
                                        !state.match("Onboarding") &&
                                        !(touched?.parentHash || touched?.childHash) &&
                                        parentOrbitEh !== null, withInfo: true, onClickInfo: () => ({
                                        title: "Scales, Explained",
                                        body: "This refers to the magnitude of your behaviour. Astronomic goes well with anything vast, like running a marathon. Atomic is for small, incremental actions, like putting on your running shoes. Sub-astronomic is anything inbetween!",
                                    }), options: [
                                        ...Object.values(Scale).map((scale) => {
                                            return (cannotBeAstro && scale == Scale.Astro) ||
                                                (cannotBeSub && scale == Scale.Sub) ? null : (_jsx("option", { value: scale, children: getDisplayName(scale) }, scale));
                                        }),
                                    ].filter((el) => el !== null), required: true, labelValue: "Scale:" }) }), _jsx("div", { className: "flex form-field", children: _jsx(Field, { component: SelectInputField, size: "base", name: "frequency", value: values?.frequency, id: "frequency", icon: (() => {
                                        const currentValue = values.frequency || Frequency.DailyOrMore_1d;
                                        return currentValue;
                                    })(), iconSide: "left", disabled: false, options: [
                                        ...Object.values(Frequency).map((frequency) => {
                                            return (_jsx("option", { value: frequency, children: getFrequencyDisplayName(frequency) }, frequency));
                                        }),
                                    ].filter((el) => el !== null), required: true, labelValue: "Frequency:" }) }), (submitBtn &&
                                React.cloneElement(submitBtn, {
                                    loading,
                                    errors,
                                    touched,
                                })) || (_jsx(DefaultSubmitBtn, { loading: loading, editMode: editMode, errors: errors, touched: touched }))] })] }));
        } }));
};
export default CreateOrbit;
export function getDisplayName(scale) {
    switch (scale) {
        case Scale.Astro:
            return "Astronomic";
        case Scale.Sub:
            return "Sub-astronomic";
        case Scale.Atom:
            return "Atomic";
    }
}
export function getFrequencyDisplayName(freq) {
    switch (freq) {
        case Frequency.DailyOrMore_10d:
            return "10/day";
        default:
            return freq;
    }
}
//# sourceMappingURL=CreateOrbit.js.map