import React from "react";
import { ActionHashB64 } from "@state/types";
interface RefineOrbitProps {
    refiningOrbitAh: ActionHashB64;
    submitBtn?: React.ReactNode;
    headerDiv?: React.ReactNode;
}
export declare enum Refinement {
    Update = "update",
    Split = "split",
    AddList = "add-list"
}
declare const RefineOrbitOnboarding: React.FC<RefineOrbitProps>;
export default RefineOrbitOnboarding;
//# sourceMappingURL=RefineOrbit.d.ts.map