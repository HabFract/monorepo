export declare const OrbitFetcher: ({ orbitToEditId }: {
    orbitToEditId: any;
}) => null | undefined;
export declare const SphereFetcher: ({ sphereToEditId, setValues }: {
    sphereToEditId: any;
    setValues: any;
}) => null;
//# sourceMappingURL=utils.d.ts.map