import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Formik } from "formik";
import { Scale } from "../../graphql/generated";
import { OrbitSubdivisionList } from "../lists";
import { OrbitFetcher } from "./utils";
import { OrbitValidationSchema } from "./CreateOrbit";
;
import { currentOrbitIdAtom, store } from "../../state";
import { MODEL_DISPLAY_VALUES } from "../../constants";
export var Refinement;
(function (Refinement) {
    Refinement["Update"] = "update";
    Refinement["Split"] = "split";
    Refinement["AddList"] = "add-list";
})(Refinement || (Refinement = {}));
const RefineOrbitOnboarding = ({ refiningOrbitAh, headerDiv, submitBtn, }) => {
    refiningOrbitAh ||= store.get(currentOrbitIdAtom)?.id;
    return (_jsx(Formik, { style: "max-width: 28rem;", initialValues: {}, validationSchema: OrbitValidationSchema, onSubmit: async (_values, { setSubmitting }) => {
        }, children: ({ values, errors, touched }) => {
            return (_jsxs("section", { children: [refiningOrbitAh && (_jsx(OrbitFetcher, { orbitToEditId: refiningOrbitAh })), headerDiv, _jsxs("div", { className: "content", children: [_jsxs("div", { className: "form-description", children: ["This is your chance to divide a large scale ", MODEL_DISPLAY_VALUES['orbit'].toLowerCase(), " into several smaller ", _jsx("em", { children: "agreements or actions" }), " that will simplify carrying out your plan."] }), _jsx(OrbitSubdivisionList, { submitBtn: submitBtn, currentOrbitValues: values, refinementType: values.scale == Scale.Atom
                                    ? Refinement.Update
                                    : Refinement.Split })] })] }));
        } }));
};
export default RefineOrbitOnboarding;
//# sourceMappingURL=RefineOrbit.js.map