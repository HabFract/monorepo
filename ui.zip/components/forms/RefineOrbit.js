import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Formik } from "formik";
import { Scale } from "../../graphql/generated";
import { OrbitSubdivisionList } from "../lists";
import { OrbitFetcher } from "./utils";
import { OrbitValidationSchema } from "./CreateOrbit";
;
import { currentOrbitIdAtom, store } from "../../state";
import { MODEL_DISPLAY_VALUES } from "../../constants";
export var Refinement;
(function (Refinement) {
    Refinement["Update"] = "update";
    Refinement["Split"] = "split";
    Refinement["AddList"] = "add-list";
})(Refinement || (Refinement = {}));
const RefineOrbitOnboarding = ({ refiningOrbitAh, headerDiv, submitBtn, }) => {
    refiningOrbitAh ||= store.get(currentOrbitIdAtom)?.id;
    return (_jsx(Formik, { style: "max-width: 28rem;", initialValues: {}, validationSchema: OrbitValidationSchema, onSubmit: async (_values, { setSubmitting }) => {
        }, children: ({ values, errors, touched }) => {
            return (_jsxs("section", { children: [refiningOrbitAh && (_jsx(OrbitFetcher, { orbitToEditId: refiningOrbitAh })), headerDiv, _jsxs("div", { className: "content", children: [_jsx("div", { className: "form-description", children: values.scale !== Scale.Atom
                                    ? `This is your chance to divide a large scale ${MODEL_DISPLAY_VALUES['orbit'].toLowerCase()} into several smaller commitments or actions that will simplify carrying out your plan.`
                                    : `This is your chance to ensure you chose the correct name for your ${MODEL_DISPLAY_VALUES['orbit'].toLowerCase()}: it should be an easy and short step to tick off. If you can, add a specific time/place!` }), _jsx(OrbitSubdivisionList, { submitBtn: submitBtn, currentOrbitValues: values, refinementType: values.scale == Scale.Atom
                                    ? Refinement.Update
                                    : Refinement.Split })] })] }));
        } }));
};
export default RefineOrbitOnboarding;
//# sourceMappingURL=RefineOrbit.js.map