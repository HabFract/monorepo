import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { Formik } from 'formik';
import { Scale } from '../../graphql/generated';
import { OrbitCard } from 'habit-fract-design-system';
import { OrbitSubdivisionList } from '../lists';
import { OrbitFetcher } from './utils';
import { OrbitValidationSchema } from './CreateOrbit';
export var Refinement;
(function (Refinement) {
    Refinement["Update"] = "update";
    Refinement["Split"] = "split";
    Refinement["AddList"] = "add-list";
})(Refinement || (Refinement = {}));
const RefineOrbitOnboarding = ({ refiningOrbitAh, headerDiv, submitBtn }) => {
    return (_jsx(Formik, { style: "max-width: 28rem;", initialValues: {}, validationSchema: OrbitValidationSchema, onSubmit: async (_values, { setSubmitting }) => {
        }, children: ({ values, errors, touched }) => {
            return (_jsxs(_Fragment, { children: [refiningOrbitAh && _jsx(OrbitFetcher, { orbitToEditId: refiningOrbitAh }), headerDiv, _jsx("h2", { className: 'onboarding-subtitle', children: "Refine Your Orbit" }), values?.name &&
                        _jsx(OrbitCard, { displayOnly: true, sphereEh: values.sphereHash, orbit: {
                                id: values.id,
                                eH: values.eH,
                                sphereHash: values.sphereHash,
                                name: values.name,
                                scale: values.scale,
                                frequency: values.frequency,
                                metadata: {
                                    description: values.description,
                                    timeframe: {
                                        startTime: values.startTime,
                                        endTime: values.endTime,
                                    }
                                }
                            } }), _jsx("p", { className: 'form-description mb-2', children: values.scale == Scale.Atom
                            ? _jsx("span", { children: "Make sure that you have been thoughtful about the best name for your Atomic Orbit before you continue" })
                            : _jsxs("span", { children: ["Make sure that you have ", _jsx("em", { children: "sub-divided" }), " your Orbit into smaller scales (as desired) before you are ready to start tracking!"] }) }), _jsx(OrbitSubdivisionList, { submitBtn: submitBtn, currentOrbitValues: values, refinementType: values.scale == Scale.Atom ? Refinement.Update : Refinement.Split })] }));
        } }));
};
export default RefineOrbitOnboarding;
//# sourceMappingURL=RefineOrbit.js.map