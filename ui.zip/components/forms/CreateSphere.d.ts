import React from "react";
import { ActionHashB64 } from "@state/types";
interface CreateSphereProps {
    editMode: boolean;
    sphereToEditId?: ActionHashB64;
    headerDiv?: React.ReactNode;
    submitBtn?: React.ReactNode;
}
declare const CreateSphere: React.FC<CreateSphereProps>;
export default CreateSphere;
//# sourceMappingURL=CreateSphere.d.ts.map