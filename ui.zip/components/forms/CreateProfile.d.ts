import React from "react";
import "./common.css";
export interface IProfileForm {
    editMode: boolean;
}
declare const ProfileForm: React.FunctionComponent<IProfileForm>;
export default ProfileForm;
//# sourceMappingURL=CreateProfile.d.ts.map