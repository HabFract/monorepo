import React from "react";
import * as Yup from "yup";
import { ActionHashB64 } from "@state/types";
export declare const OrbitValidationSchema: Yup.ObjectSchema<{
    name: string;
    description: string | undefined;
    startTime: number;
    endTime: number | undefined;
    frequency: {};
    scale: {};
    parentHash: string | null | undefined;
    childHash: string | null | undefined;
    archival: boolean | undefined;
}, Yup.AnyObject, {
    name: undefined;
    description: undefined;
    startTime: undefined;
    endTime: undefined;
    frequency: undefined;
    scale: undefined;
    parentHash: undefined;
    childHash: undefined;
    archival: undefined;
}, "">;
interface CreateOrbitProps {
    editMode: boolean;
    inModal: boolean;
    onCreateSuccess?: Function;
    orbitToEditId?: ActionHashB64;
    sphereEh: string;
    parentOrbitEh: string | undefined;
    childOrbitEh?: string | undefined;
    headerDiv?: React.ReactNode;
    submitBtn?: React.ReactNode;
    forwardTo?: string;
}
declare const CreateOrbit: React.FC<CreateOrbitProps>;
export default CreateOrbit;
//# sourceMappingURL=CreateOrbit.d.ts.map