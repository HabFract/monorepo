import { Fragment as _Fragment, jsx as _jsx } from "react/jsx-runtime";
import './common.css';
import { useMyProfile } from '../../hooks/useMyProfile';
const ProfileForm = ({ editMode, }) => {
    const [profile, _] = useMyProfile();
    const initialValues = editMode && !!profile
        ? {
            nickname: profile.nickname,
            location: profile.fields.location,
            avatar: profile.fields.avatar,
            isPublic: profile.fields.isPublic,
        }
        : {
            nickname: '',
            location: '',
            avatar: '',
            isPublic: false,
        };
    return (_jsx(_Fragment, {}));
};
export default ProfileForm;
//# sourceMappingURL=CreateProfile.js.map