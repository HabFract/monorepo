import { jsx as _jsx } from "react/jsx-runtime";
import { Form, DatePicker } from "antd";
import { DateTime } from "luxon";
import luxonGenerateConfig from 'rc-picker/lib/generate/luxon';
const MyDatePicker = DatePicker.generatePicker(luxonGenerateConfig);
const FormItem = Form.Item;
const dateFormat = "YYYY/MM/DD";
const DateInput = ({ field, form: { touched, errors, setFieldValue, values }, ...props }) => {
    const errorMsg = touched[field.name] && errors[field.name];
    const validateStatus = errorMsg
        ? "error"
        : touched[field.name] && !errors[field.name]
            ? "success"
            : undefined;
    return (_jsx("div", { children: _jsx(FormItem, { help: errorMsg, validateStatus: validateStatus, hasFeedback: true, children: _jsx(MyDatePicker, { format: dateFormat, placeholder: typeof values[field.name] == 'number' ? DateTime.fromMillis(values[field.name]).toJSDate().toLocaleDateString('en-us', { year: "numeric", month: "numeric", day: "numeric" }) : props.placeholder, disabled: props.disabled, picker: values.frequency.toLowerCase(), onChange: async (_date, dateString) => setFieldValue(field.name, DateTime.local(...(dateString).split('/').map(n => +n)).ts) }) }) }));
};
export default DateInput;
//# sourceMappingURL=DatePicker.js.map