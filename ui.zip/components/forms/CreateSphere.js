import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import React, { useEffect, useState } from 'react';
import { Formik, Form, Field } from 'formik';
import * as Yup from 'yup';
import { Label } from 'flowbite-react';
import { useGetSphereQuery, useUpdateSphereMutation } from '../../graphql/generated';
import { ImageUpload } from './input';
import { useStateTransition } from '../../hooks/useStateTransition';
import DefaultSubmitBtn from './buttons/DefaultSubmitButton';
import { TextAreaField, TextInputField } from 'habit-fract-design-system';
import { useCreateSphereMutation } from '../../hooks/gql/useCreateSphereMutation';
const SphereValidationSchema = Yup.object().shape({
    name: Yup.string().required('Name is a required field'),
    description: Yup.string().min(5, 'A description needs to be at least 5 characters'),
    image: Yup.string().trim().matches(/^data:((?:\w+\/(?:(?!;).)+)?)((?:;[\w=]*[^;])*),(.+)$/, "Image must be a valid data URI"),
});
const SphereFetcher = ({ sphereToEditId, setValues }) => {
    const { data: getData, error: getError, loading: getLoading } = useGetSphereQuery({
        variables: {
            id: sphereToEditId
        },
        skip: !sphereToEditId
    });
    useEffect(() => {
        if (!getData)
            return;
        const { name, metadata: { description, image } } = getData?.sphere;
        setValues({
            name, description, image
        });
    }, [getData]);
    return null;
};
const CreateSphere = ({ editMode = false, sphereToEditId, headerDiv, submitBtn }) => {
    const [state, transition] = useStateTransition();
    const [currentSphereValues, setCurrentSphereValues] = useState({
        name: '',
        description: '',
        image: '',
    });
    const [addSphere, { loading }] = useCreateSphereMutation();
    const [updateSphere] = useUpdateSphereMutation({
        refetchQueries: [
            'getSpheres',
        ]
    });
    return (_jsx(Formik, { enableReinitialize: true, initialValues: currentSphereValues, validationSchema: SphereValidationSchema, onSubmit: async (values, { setSubmitting }) => {
            try {
                let response = editMode
                    ? await updateSphere({ variables: { sphere: { id: sphereToEditId, name: values.name, description: values.description, image: values.image } } })
                    : await addSphere({ variables: { variables: { name: values.name, description: values.description, image: values.image } } });
                setSubmitting(false);
                if (!response.data)
                    return;
                const payload = response.data;
                const eH = payload?.createSphere?.entryHash || payload?.updateSphere?.entryHash;
                const aH = payload?.createSphere?.actionHash || payload?.updateSphere?.actionHash;
                const props = state == 'Onboarding1'
                    ? { sphereEh: eH }
                    : { sphereAh: aH };
                transition(state == 'Onboarding1' ? 'Onboarding2' : 'ListSpheres', props);
            }
            catch (error) {
                console.error(error);
            }
        }, children: ({ values, errors, touched }) => {
            return (_jsxs("div", { className: "px-1", children: [headerDiv, _jsx("h2", { className: 'onboarding-subtitle', children: "Create a Sphere" }), _jsxs("p", { className: 'form-description', children: ["A sphere is an ", _jsx("em", { children: "area of your life" }), " where you want to track repeated actions."] }), _jsxs(Form, { noValidate: true, children: [editMode && _jsx(SphereFetcher, { sphereToEditId: sphereToEditId, setValues: setCurrentSphereValues }), _jsx("div", { className: "form-field", children: _jsx(Field, { component: TextInputField, size: "base", name: "name", id: "name", icon: "tag", value: editMode ? values.name : undefined, iconSide: "left", required: true, labelValue: "Name:", placeholder: "E.g. Health and Fitness" }) }), _jsx("div", { className: "form-field", children: _jsx(Field, { component: TextAreaField, name: "description", id: "description", labelValue: "Description:", placeholder: "E.g. I am aiming to run a marathon this year" }) }), _jsxs("div", { className: "field row sphere-image", children: [_jsx(Label, { htmlFor: 'image', children: "Image:" }), _jsx("div", { className: "form-field", children: _jsx(Field, { component: ImageUpload, name: "image", id: "image" }) })] }), submitBtn && React.cloneElement(submitBtn, { loading, errors, touched }) || _jsx(DefaultSubmitBtn, { loading: loading, editMode: editMode, errors: errors, touched: touched })] })] }));
        } }));
};
export default CreateSphere;
//# sourceMappingURL=CreateSphere.js.map