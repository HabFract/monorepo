import React from "react";
import "./style.css";
import "../typo.css";
declare const Settings: React.FC<{}>;
export default Settings;
//# sourceMappingURL=Settings.d.ts.map