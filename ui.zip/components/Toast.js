import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useToast } from "../contexts/toast";
import { WarningOutlined } from "@ant-design/icons";
const Toast = () => {
    const { toastText, isToastVisible, hideToast } = useToast();
    if (!isToastVisible)
        return null;
    return (_jsxs("div", { className: "toast left-2 flex m-2 p-2 gap-2 fixed top-2 right-2 z-100 rounded-xl bg-menu-bg", style: { zIndex: 200, maxWidth: "24rem" }, children: [_jsx("div", { className: "flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-secondary text-title", children: _jsx(WarningOutlined, { className: "h-6 w-6 grid place-content-center" }) }), _jsx("div", { className: "toast-text", children: toastText }), _jsx("button", { onClick: hideToast, className: "toast-close text-3xl mr-4 hover:text-primary", children: "\u00D7" })] }));
};
export default Toast;
//# sourceMappingURL=Toast.js.map