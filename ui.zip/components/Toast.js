import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useToast } from "../contexts/toast";
import { WarningOutlined } from "@ant-design/icons";
const Toast = () => {
    const { toastText, isToastVisible, hideToast, actionButton } = useToast();
    if (!isToastVisible)
        return null;
    return (_jsxs("div", { className: "toast left-16 top-16 right-2 z-100 rounded-xl dark:bg-surface-top-dark fixed flex gap-2 p-2 m-2 mt-4", style: { zIndex: 200, maxWidth: "24rem" }, children: [_jsx("div", { className: "shrink-0 bg-secondary dark:bg-secondary-500 dark:text-gray-500 text-title flex items-center justify-center w-8 h-8 mt-1 ml-1 rounded-lg", children: _jsx(WarningOutlined, { className: "place-content-center grid w-6 h-6" }) }), _jsxs("div", { className: "flex flex-col items-baseline justify-center gap-2 ml-auto", children: [_jsx("div", { className: "toast-text", children: toastText }), actionButton] }), _jsx("button", { onClick: hideToast, className: "toast-close hover:text-primary text-text dark:text-text-dark flex mr-2 text-3xl", children: "\u00D7" })] }));
};
export default Toast;
//# sourceMappingURL=Toast.js.map