import "../style.css";
export interface INav {
    setSideNavExpanded: Function;
    sideNavExpanded: boolean;
}
declare const Nav: React.FC<INav>;
export default Nav;
//# sourceMappingURL=Nav.d.ts.map