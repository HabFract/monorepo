import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import "../style.css";
import TreeVisIcon from "../icons/TreeVisIcon";
import { UnorderedListOutlined, AppstoreOutlined, PlusCircleOutlined, SettingFilled, } from "@ant-design/icons";
import Menu from "antd/es/menu/menu";
import { useEffect, useRef, useState } from "react";
import { getIconSvg, Button as DSButton, Spinner } from "habit-fract-design-system";
import { useGetSpheresQuery } from "../../graphql/generated";
import { Button } from "flowbite-react";
import useSideMenuToggle from "../../hooks/useSideMenuToggle";
import { useToast } from "../../contexts/toast";
import { store } from "../../state/store";
import { currentSphereOrbitNodesAtom } from "../../state/orbit";
import { extractEdges } from "../../graphql/utils";
import { AppMachine } from "../../main";
import { useAtomValue, useSetAtom } from "jotai";
import { currentSphereHasCachedNodesAtom, currentSphereHashesAtom, sphereHasCachedNodesAtom, } from "../../state/sphere";
import { currentSphereHierarchyIndices } from "../../state/hierarchy";
import { useStateTransition } from "../../hooks/useStateTransition";
var Page;
(function (Page) {
    Page["CreateSphere"] = "CreateSphere";
    Page["ListSpheres"] = "ListSpheres";
    Page["CreateOrbit"] = "CreateOrbit";
    Page["ListOrbits"] = "ListOrbits";
    Page["Dashboard"] = "Dashboard";
    Page["Vis"] = "Vis";
    Page["Home"] = "Home";
})(Page || (Page = {}));
const Nav = ({ sideNavExpanded, setSideNavExpanded, }) => {
    const { loading: loadingSpheres, error, data: spheres, } = useGetSpheresQuery();
    const [state, transition, params] = useStateTransition();
    const [_, setCurrentPage] = useState(Page.Home);
    const currentPage = AppMachine.state.currentState;
    const sideMenuRef = useRef(null);
    useSideMenuToggle(sideMenuRef, setSideNavExpanded);
    const setCurrentSphereActionHash = useSetAtom(currentSphereHashesAtom);
    const { showToast, hideToast } = useToast();
    let loading = loadingSpheres || !spheres;
    const spheresArray = loading ? [] : extractEdges(spheres.spheres);
    const [menuItems, setMenuItems] = useState(createSphereMenuItems({ spheres: spheresArray }));
    useEffect(() => {
        spheresArray &&
            setMenuItems(createSphereMenuItems({ spheres: spheresArray }));
    }, [spheres, currentPage]);
    store.sub(currentSphereHashesAtom, () => {
        spheresArray &&
            setMenuItems(createSphereMenuItems({ spheres: spheresArray }));
    });
    const sphereOrbitsCached = useAtomValue(currentSphereOrbitNodesAtom);
    const tooltipMsg = `You need to ${spheresArray.length == 0 ? "create" : spheresArray.length >= 4 ? "delete" : "select"} a Space `;
    const sphere = (sphereAh) => spheresArray.find((sphere) => (sphereAh || store.get(currentSphereHashesAtom)?.actionHash) ==
        sphere.id);
    const onClick = (e) => {
        switch (true) {
            case e.key == "add-sphere":
                if (spheresArray.length >= 4) {
                    showToast(tooltipMsg +
                        "before you can add another Space. These are the 4 burners of your habit life!");
                    return;
                }
                setSideNavExpanded(false);
                transition("Onboarding1", { spin: "positive" });
                break;
            case e.key == "list-spheres":
                if (spheresArray.length == 0) {
                    showToast(tooltipMsg + "before you can view the Spheres list");
                    return;
                }
                setCurrentPage(Page.ListSpheres);
                transition("ListSpheres");
                if (sideNavExpanded)
                    setSideNavExpanded(false);
                break;
            default:
                if ([Page.Vis].includes(currentPage)) {
                    if (e.key == store.get(currentSphereHashesAtom).actionHash) {
                    }
                    else {
                        const checkCachedOrbits = store.get(sphereHasCachedNodesAtom(e.key));
                        if (checkCachedOrbits) {
                            console.log('set sphere from nav :>> ');
                            setCurrentSphereActionHash(e.key);
                            setSideNavExpanded(false);
                        }
                        const transitionParams = {
                            currentSphereDetails: sphere(e.key),
                            currentSphereEhB64: sphere(e.key)?.eH,
                            currentSphereAhB64: e.key,
                        };
                        transition("Vis", transitionParams);
                    }
                }
                else if ([Page.ListSpheres].includes(currentPage)) {
                    if (!(e.key == store.get(currentSphereHashesAtom).actionHash)) {
                        console.log('set sphere from nav :>> ');
                        setCurrentSphereActionHash(e.key);
                    }
                }
                else {
                    hideToast();
                    if (store.get(currentSphereHashesAtom)?.actionHash == e.key)
                        console.log('set sphere from nav :>> ');
                    setCurrentSphereActionHash(e.key);
                    const pageString = currentPage;
                    if (currentPage == Page.Home)
                        return;
                    transition(pageString, pageString == "ListOrbits"
                        ? { sphereAh: e.key }
                        : pageString == "CreateOrbit"
                            ? { sphereEh: sphere(e.key).eH }
                            : {
                                currentSphereEhB64: store.get(currentSphereHashesAtom)
                                    .entryHash,
                                currentSphereAhB64: e.key,
                            });
                }
                break;
        }
    };
    function buttonWithTooltipHandling(type) {
        return (_jsx(Button, { type: "button", onClick: (_e) => {
                goToPage(type);
            }, disabled: spheresArray.length == 0 ||
                !store.get(currentSphereHashesAtom)?.actionHash ||
                (currentPage == Page.Vis && !sphereOrbitsCached), className: `btn btn-sq btn-${type} ` + (isCurrentPage(type) ? "nohover" : ""), style: {
                cursor: isCurrentPage(type) ? "initial" : "pointer",
                borderColor: "transparent",
                outlineOffset: "1px",
                outline: isCurrentPage(type) ? "3px solid rgb(17 24 39 / 1)" : "",
            }, children: getIcon(type) }));
        function goToPage(type) {
            switch (type) {
                case "neutral":
                    hideToast();
                    setCurrentPage(Page.ListOrbits);
                    transition("ListOrbits", { sphereAh: sphere().id });
                    setSideNavExpanded(false);
                    return;
                case "primary":
                    if (!store.get(currentSphereHasCachedNodesAtom)) {
                        showToast("Select a Space with existing Plannits to enable Visualisation", 100000);
                        return;
                    }
                    store.set(currentSphereHierarchyIndices, { x: 0, y: 0 });
                    setCurrentPage(Page.Vis);
                    transition("Vis", {
                        currentSphereEhB64: sphere().eH,
                        currentSphereAhB64: sphere().id,
                    });
                    setSideNavExpanded(false);
                    return;
                case "secondary":
                    hideToast();
                    setCurrentPage(Page.CreateOrbit);
                    transition("CreateOrbit", { sphereEh: sphere().eH });
                    setSideNavExpanded(false);
                    return;
            }
        }
        function isCurrentPage(type) {
            switch (type) {
                case "neutral":
                    return currentPage == Page.ListOrbits;
                case "primary":
                    return currentPage == Page.Vis;
                case "secondary":
                    return currentPage == Page.CreateOrbit;
            }
        }
        function getIcon(type) {
            switch (type) {
                case "neutral":
                    return _jsx(UnorderedListOutlined, {});
                case "primary":
                    return _jsx(TreeVisIcon, {});
                case "secondary":
                    return _jsx(PlusCircleOutlined, {});
            }
        }
    }
    return (_jsx(_Fragment, { children: _jsx("nav", { ref: sideMenuRef, className: sideNavExpanded ? "side-nav expanded" : "side-nav off-screen", children: loading ? (_jsx(Spinner, {})) : (_jsxs(_Fragment, { children: [_jsx(Menu, { inlineCollapsed: !sideNavExpanded, onClick: onClick, style: { width: !sideNavExpanded ? 72 : 256 }, mode: "inline", items: menuItems }), _jsx("div", { className: "off-screen-toggle-button", children: _jsx("button", { type: "button", onClick: () => { sideMenuRef.current?.classList?.toggle("off-screen"); }, className: "off-screen-icon-button text-text dark:text-text-dark p-2", children: getIconSvg('arrow-right')({}) }) }), _jsx("div", { className: "main-actions-menu", children: _jsxs("div", { style: { display: !sideNavExpanded ? "none" : "flex" }, className: "sphere-context-actions", "data-tooltip-target": "tooltip-left", "data-tooltip-placement": "left", children: [buttonWithTooltipHandling("neutral"), buttonWithTooltipHandling("secondary"), buttonWithTooltipHandling("primary")] }) })] })) }) }));
    function getItem(label, key, icon, children, type, disabled) {
        return {
            key,
            icon,
            children,
            label,
            type,
            disabled,
        };
    }
    function createFixedMenuItems() {
        return [
            getItem("Sphere Breakdown", "list-spheres", _jsx(AppstoreOutlined, {})),
            getItem("Settings", "settings", _jsx(SettingFilled, {})),
        ];
    }
    function createSphereMenuItems({ spheres }) {
        return [
            spheresArray.length < 4 ? getItem("New Sphere", "add-sphere", _jsx(DSButton, { onClick: () => { }, variant: "circle-icon btn-primary", icon: getIconSvg("plus")({}) }), undefined, undefined, false) : null,
            ...spheres.map((sphere, _idx) => {
                return getItem(`${sphere.name}`, sphere.id, _jsx("img", { className: store.get(currentSphereHashesAtom)?.actionHash == sphere.id
                        ? "selected"
                        : "", src: sphere.metadata.image }));
            }),
        ];
    }
};
export default Nav;
//# sourceMappingURL=Nav.js.map