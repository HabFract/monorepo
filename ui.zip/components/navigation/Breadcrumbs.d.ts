declare function Breadcrumbs({ currentSphere, state, transition, isFormEditMode, }: any): import("react/jsx-runtime").JSX.Element;
export default Breadcrumbs;
//# sourceMappingURL=Breadcrumbs.d.ts.map