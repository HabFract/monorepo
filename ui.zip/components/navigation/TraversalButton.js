import { jsx as _jsx } from "react/jsx-runtime";
import { UpCircleTwoTone, DownCircleTwoTone, RightCircleTwoTone, LeftCircleTwoTone } from '@ant-design/icons';
import "./common.css";
const TraversalButton = ({ condition, iconType, onClick, dataTestId }) => {
    if (!condition)
        return _jsx("span", { className: "spacer absolute" });
    const IconComponent = (() => {
        switch (iconType) {
            case 'up':
                return _jsx(UpCircleTwoTone, { twoToneColor: '#4E5454', "data-testid": dataTestId, className: 'traversal-button up', onClick: onClick });
            case 'left':
                return _jsx(LeftCircleTwoTone, { twoToneColor: '#4E5454', "data-testid": dataTestId, className: 'traversal-button left', onClick: onClick });
            case 'down-left':
                return _jsx(DownCircleTwoTone, { style: { transform: 'rotate(45deg)' }, twoToneColor: '#4E5454', "data-testid": dataTestId, className: 'traversal-button d-left', onClick: onClick });
            case 'right':
                return _jsx(RightCircleTwoTone, { twoToneColor: '#4E5454', "data-testid": dataTestId, className: 'traversal-button right', onClick: onClick });
            case 'down':
                return _jsx(DownCircleTwoTone, { twoToneColor: '#4E5454', "data-testid": dataTestId, className: 'traversal-button down', onClick: onClick });
            case 'down-right':
                return _jsx(DownCircleTwoTone, { style: { transform: 'rotate(-45deg)' }, twoToneColor: '#4E5454', "data-testid": dataTestId, className: 'traversal-button d-right', onClick: onClick });
            default:
                return null;
        }
    })();
    return IconComponent;
};
export default TraversalButton;
//# sourceMappingURL=TraversalButton.js.map