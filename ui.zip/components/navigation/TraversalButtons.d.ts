declare const TraversalButtons: ({ canGoUp, canGoDown, canGoLeft, canGoRight, actions }: {
    canGoUp: any;
    canGoDown: any;
    canGoLeft: any;
    canGoRight: any;
    actions: any;
}) => import("react/jsx-runtime").JSX.Element;
export default TraversalButtons;
//# sourceMappingURL=TraversalButtons.d.ts.map