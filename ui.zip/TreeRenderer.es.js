import { j as e } from "./index.es.js";
const s = ({ tree: r, render: t }) => /* @__PURE__ */ e.jsx(e.Fragment, { children: t(r) });
export {
  s as default
};
