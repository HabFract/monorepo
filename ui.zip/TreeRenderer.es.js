import { j as e } from "./index.es.js";
const a = ({ tree: r, render: n }) => {
  if (!r || !r.rootData)
    return null;
  try {
    return /* @__PURE__ */ e.jsx(e.Fragment, { children: n(r) });
  } catch (t) {
    return console.error("Error rendering tree:", t), null;
  }
};
export {
  a as default
};
