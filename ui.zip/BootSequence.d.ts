import "./App.css";
import React from "react";
declare const _default: React.NamedExoticComponent<{}>;
export default _default;
//# sourceMappingURL=BootSequence.d.ts.map