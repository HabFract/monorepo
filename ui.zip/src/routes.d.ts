import { StateTransitions } from './state/types/stateMachine';
export type AppState = 'Home' | 'PreloadAndCache' | 'Onboarding1' | 'Onboarding2' | 'Onboarding3' | 'Vis' | 'CreateSphere' | 'ListSpheres' | 'CreateOrbit' | 'ListOrbits';
export type Routes = {
    [key in AppState]: React.ReactNode;
};
export type AppStateStore = {
    currentState: AppState;
    params?: object;
    client: any;
};
export declare const initialState: AppStateStore;
export declare const routes: Routes;
export declare const AppTransitions: StateTransitions<AppState>;
