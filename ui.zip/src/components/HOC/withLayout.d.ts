import { ReactNode, FC } from 'react';
import { SphereDetails } from '../../state/types/sphere';
interface WithLayoutProps {
    currentSphereDetails: SphereDetails;
    newUser: boolean;
}
declare const withLayout: (component: ReactNode, state: any, transition: any, params: any) => FC<WithLayoutProps>;
export default withLayout;
