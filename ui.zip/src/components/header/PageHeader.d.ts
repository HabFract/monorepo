import { default as React } from 'react';
type PageHeaderProps = {
    title: string;
};
declare const PageHeader: React.FC<PageHeaderProps>;
export default PageHeader;
