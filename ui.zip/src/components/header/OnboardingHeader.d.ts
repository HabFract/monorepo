type OnboardingHeaderProps = {
    state: string;
    transition: Function;
};
declare const OnboardingHeader: React.ForwardRefExoticComponent<React.PropsWithoutRef<OnboardingHeaderProps>>;
declare const getNextOnboardingState: (state: string) => string;
export { getNextOnboardingState };
export default OnboardingHeader;
