import { default as React, ComponentType } from 'react';
import { VisProps } from './types';
import { HierarchyNode } from 'd3-hierarchy';
import { TreeVisualization } from './base-classes/TreeVis';
export declare const OrbitTree: ComponentType<VisProps<TreeVisualization>>;
declare const _default: React.NamedExoticComponent<VisProps<TreeVisualization>>;
export default _default;
export declare function byStartTime(a: (HierarchyNode<unknown> | {
    content: string;
}), b: (HierarchyNode<unknown> | {
    content: string;
})): number;
