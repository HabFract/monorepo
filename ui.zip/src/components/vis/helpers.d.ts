import { ViewConfig, VisProps, VisType, ZoomConfig } from './types';
import { ReactNode } from 'react';
export declare const renderVis: (visComponent: React.ComponentType<VisProps>) => ReactNode;
export declare const isTouchDevice: () => boolean;
export declare const isSmallScreen: () => boolean;
export declare const isSuperSmallScreen: () => boolean;
export declare const debounce: (func: any, delay: any) => (...args: any[]) => void;
export declare const getTransform: (node: any, xScale: any) => {
    translate: number[];
    scale: any;
} | undefined;
export declare const hierarchyStateHasChanged: (currentHierarchy: any, visObject: any) => boolean;
export declare const updateVisRootData: (visObject: any, currentHierarchy: any) => any;
export declare const getInitialXTranslate: ({ levelsWide, defaultView }: {
    levelsWide: any;
    defaultView: any;
}) => number;
export declare const getInitialYTranslate: (type: VisType, { levelsHigh, defaultView }: {
    levelsHigh: any;
    defaultView: any;
}) => number;
export declare const newXTranslate: (type: VisType, viewConfig: ViewConfig, zoomConfig: ZoomConfig) => number | undefined;
export declare const newYTranslate: (type: VisType, viewConfig: ViewConfig, zoomConfig: ZoomConfig) => number;
export declare const oppositeStatus: (current: any) => "true" | "false";
export declare const notOOB: (node: any) => boolean;
export declare const sumChildrenValues: (node: any, hidden?: boolean) => any;
export declare const nodeWithoutHabitDate: (data: any, store: any) => any;
export declare const isALeaf: (node: any) => any;
export declare function expand(d: any): void;
export declare function collapse(d: any): void;
export declare const cousins: (node: any, root: any) => any;
export declare const greatAunts: (node: any, root: any) => any;
export declare const nodesForCollapse: (node: any, { cousinCollapse, auntCollapse }: {
    cousinCollapse?: boolean | undefined;
    auntCollapse?: boolean | undefined;
}) => any;
