import { TreeLayout } from 'd3-hierarchy';
import { DefaultLinkObject, Link } from 'd3-shape';
import { ZoomBehavior } from 'd3-zoom';
import { EventHandlers, Margins, ViewConfig, ZoomConfig } from '../types';
import { BaseVisualization } from './BaseVis';
export declare class TreeVisualization extends BaseVisualization {
    layout: TreeLayout<unknown>;
    initializeViewConfig(canvasHeight: number, canvasWidth: number, margin: Margins): ViewConfig;
    initializeZoomConfig(): ZoomConfig;
    initializeEventHandlers(): EventHandlers;
    initializeZoomer(): ZoomBehavior<Element, unknown>;
    setupLayout(): void;
    applyInitialTransform(): void;
    appendLinkPath(): void;
    getLinkPathGenerator(): Link<any, DefaultLinkObject, [number, number]>;
    setNodeAndLinkEnterSelections(): void;
    bindEventHandlers(selection: any): void;
    setNodeAndLabelGroups(): void;
    appendNodeVectors(): void;
}
