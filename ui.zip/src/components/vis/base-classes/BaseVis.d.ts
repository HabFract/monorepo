import { Selection } from 'd3-selection';
import { ZoomBehavior } from 'd3-zoom';
import { HierarchyLink, HierarchyNode } from 'd3-hierarchy';
import { EventHandlers, IVisualization, Margins, ViewConfig, VisCoverage, VisType, ZoomConfig } from '../types';
import { ActionHashB64, EntryHashB64 } from '@holochain/client';
import { OrbitNodeDetails } from '../../../state/types';
import { SphereOrbitNodes } from '../../../state/types/sphere';
/**
 * Base class for creating D3 hierarchical visualizations.
 * This class handles the setup and rendering of the visualization.
 * Extend this class to implement specific types of visualizations.
 */
export declare abstract class BaseVisualization implements IVisualization {
    type: VisType;
    coverageType: VisCoverage;
    rootData: HierarchyNode<any>;
    nodeDetails: SphereOrbitNodes;
    _nextRootData: HierarchyNode<any> | null;
    _svgId: string;
    _canvas: Selection<SVGGElement, unknown, HTMLElement, any> | undefined;
    _viewConfig: ViewConfig;
    _zoomConfig: ZoomConfig;
    sphereEh: EntryHashB64;
    sphereAh: ActionHashB64;
    modalParentOrbitEh: React.Dispatch<React.SetStateAction<EntryHashB64 | undefined>>;
    modalChildOrbitEh: React.Dispatch<React.SetStateAction<EntryHashB64 | undefined>>;
    globalStateTransition: Function;
    eventHandlers: EventHandlers;
    zoomer: ZoomBehavior<Element, unknown>;
    _gLink?: typeof this._canvas;
    _gNode?: typeof this._canvas;
    _gCircle?: Selection<SVGGElement, HierarchyNode<any>, SVGGElement, unknown>;
    _gTooltip?: Selection<SVGForeignObjectElement, HierarchyNode<any>, SVGGElement, unknown>;
    _gButton?: Selection<SVGForeignObjectElement, HierarchyNode<any>, SVGGElement, unknown>;
    _enteringLinks?: Selection<SVGPathElement, HierarchyLink<any>, SVGGElement, unknown>;
    _enteringNodes?: Selection<SVGGElement, HierarchyNode<any>, SVGGElement, unknown>;
    abstract setNodeAndLinkEnterSelections(): void;
    abstract appendNodeVectors(): void;
    abstract setNodeAndLabelGroups(): void;
    abstract appendLinkPath(): void;
    abstract bindEventHandlers(selection: any): void;
    abstract getLinkPathGenerator(): void;
    abstract initializeViewConfig(canvasHeight: number, canvasWidth: number, margin: Margins): ViewConfig;
    abstract initializeZoomConfig(): ZoomConfig;
    abstract initializeEventHandlers(): EventHandlers;
    abstract initializeZoomer(): ZoomBehavior<Element, unknown>;
    modalOpen?: React.Dispatch<React.SetStateAction<boolean>>;
    isModalOpen: boolean;
    skipMainRender: boolean;
    activeNode: any;
    isNewActiveNode: boolean;
    _hasRendered: boolean;
    /**
     * Constructor for the BaseVisualization class.
     * @param type - The type of visualization.
     * @param svgId - The ID of the SVG element.
     * @param inputTree - The input data for the tree.
     * @param canvasHeight - The height of the canvas.
     * @param canvasWidth - The width of the canvas.
     * @param margin - The margins for the canvas.
     * @param globalStateTransition - Function to handle global state transitions.
     * @param sphereEh - Entry hash for the sphere.
     * @param sphereAh - Action hash for the sphere.
     * @param nodeDetails - Details of the nodes in the sphere (from the cache).
     */
    constructor(type: VisType, coverageType: VisCoverage, svgId: string, inputTree: HierarchyNode<any>, canvasHeight: number, canvasWidth: number, margin: Margins, globalStateTransition: (newState: string, params: object) => void, sphereEh: EntryHashB64, sphereAh: ActionHashB64, nodeDetails: SphereOrbitNodes);
    /**
     * Fetches Orbit data for a given Sphere.
     */
    refetchOrbits(): Promise<void>;
    /**
     * Caches Orbit data for a given Sphere.
     */
    cacheOrbits(orbitEntries: Array<[ActionHashB64, OrbitNodeDetails]>): Promise<void>;
    /**
     * Set up the canvas for rendering.
     */
    setupCanvas(): void;
    /**
     * Set up the layout for the visualization.
     */
    abstract setupLayout(): void;
    /**
     * Applies the initial transform to the visualization.
     * This method should be implemented by subclasses to set up the initial view of the visualization.
     * TODO: implement
     */
    abstract applyInitialTransform(): void;
    /**
     * Set width/height view config variables from constants
     */
    setLevelsHighAndWide(): void;
    /**
     * Set up SVG viewport attributes
     */
    calibrateViewPortAttrs(): void;
    /**
     * Set up SVG viewbox attributes
     */
    calibrateViewBox(): void;
    /**
     * Set up x/y differential needed for the vis layout
     */
    setdXdY(): void;
    /**
     * Set up node and link groups.
     */
    setNodeAndLinkGroups(): void;
    /**
     * Render the visualization.
     */
    render(): void;
    /**
     * Determines if this is the first render of the visualization.
     * @returns {boolean} True if this is the first render, false otherwise.
     */
    firstRender(): boolean;
    /**
     * Checks if there is new data to be rendered.
     * @returns {boolean} True if there is new data (_nextRootData is not null), false otherwise.
     */
    hasNextData(): boolean;
    /**
     * Get a base/mounting element for the svg
     * @returns {Selection<SVGForeignObjectElement, HierarchyNode<any>, HTMLElement, any>} A d3 selection of the base HTML element
     */
    visBase(): Selection<SVGForeignObjectElement, HierarchyNode<any>, HTMLElement, any>;
    /**
     * Checks if the canvas element exists in the DOM.
     * @returns {boolean} True if the canvas doesn't exist or is empty, false otherwise.
     */
    noCanvas(): boolean;
    /** Clear just nodes and links from the canvas **/
    clearNodesAndLinks(): void;
    /** Clear labels and re-append  **/
    clearAndRedrawLabels(): Selection<SVGForeignObjectElement, HierarchyNode<any>, SVGGElement, unknown>;
    /**
     * Reset the zoom on the vis base
     */
    resetZoomer(): void;
    /**
     * Clears all child elements from the canvas.
     * This is typically called before re-rendering the visualization with new data.
     */
    clearCanvas(): void;
    appendLabelHtml: (d: any) => string;
}
