import { FC } from 'react';
interface HomeContinueProps {
    onClick: () => void;
}
declare const HomeContinue: FC<HomeContinueProps>;
export default HomeContinue;
