import { FC } from 'react';
interface VersionDisclaimerProps {
    currentVersion: string | undefined;
    open: () => void;
    isFrontPage?: boolean;
}
declare const VersionDisclaimer: FC<VersionDisclaimerProps>;
export default VersionDisclaimer;
