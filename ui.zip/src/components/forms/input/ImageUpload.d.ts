declare const ImageUpload: ({ field, form: { touched, errors, setFieldValue, values }, ...props }: {
    [x: string]: any;
    field: any;
    form: {
        touched: any;
        errors: any;
        setFieldValue: any;
        values: any;
    };
}) => import("react/jsx-runtime").JSX.Element;
export default ImageUpload;
