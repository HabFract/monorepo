export declare const OrbitFetcher: ({ orbitToEditId }: {
    orbitToEditId: any;
}) => null | undefined;
