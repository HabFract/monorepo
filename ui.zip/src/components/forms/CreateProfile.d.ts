import { default as React } from 'react';
export interface IProfileForm {
    editMode: boolean;
}
declare const ProfileForm: React.FunctionComponent<IProfileForm>;
export default ProfileForm;
