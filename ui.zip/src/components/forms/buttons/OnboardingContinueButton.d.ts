import { FC } from 'react';
interface OnboardingContinueProps {
    onClick: () => void;
}
declare const OnboardingContinue: FC<OnboardingContinueProps>;
export default OnboardingContinue;
