declare const DefaultSubmitBtn: ({ loading, errors, touched, editMode }: {
    loading: boolean;
    errors: object;
    touched: object;
    editMode: boolean;
}) => import("react/jsx-runtime").JSX.Element;
export default DefaultSubmitBtn;
