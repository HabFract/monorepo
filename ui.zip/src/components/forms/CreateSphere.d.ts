import { default as React } from 'react';
import { ActionHashB64 } from '@holochain/client';
interface CreateSphereProps {
    editMode: boolean;
    sphereToEditId?: ActionHashB64;
    headerDiv?: React.ReactNode;
    submitBtn?: React.ReactNode;
}
declare const CreateSphere: React.FC<CreateSphereProps>;
export default CreateSphere;
