import { default as React } from 'react';
import { ActionHashB64 } from '@holochain/client';
interface RefineOrbitProps {
    refiningOrbitAh: ActionHashB64;
    submitBtn?: React.ReactNode;
    headerDiv?: React.ReactNode;
}
export declare enum Refinement {
    Update = "update",
    Split = "split",
    AddList = "add-list"
}
declare const RefineOrbitOnboarding: React.FC<RefineOrbitProps>;
export default RefineOrbitOnboarding;
