import { default as React } from 'react';
import { SphereConnection } from '../graphql/generated';
type SettingsProps = {
    spheres: SphereConnection;
    setIsModalOpen: Function;
    setIsSettingsOpen: Function;
    version: string;
};
declare const Settings: React.FC<SettingsProps>;
export default Settings;
