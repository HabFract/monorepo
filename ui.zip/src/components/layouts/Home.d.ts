declare function HomeLayout({ startBtn, firstVisit }: any): import("react/jsx-runtime").JSX.Element;
export default HomeLayout;
