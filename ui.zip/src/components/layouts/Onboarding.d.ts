declare function OnboardingLayout({ children }: any): import("react/jsx-runtime").JSX.Element;
export default OnboardingLayout;
