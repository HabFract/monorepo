import { default as React } from 'react';
import { Orbit } from '../../graphql/generated';
import { Refinement } from '../forms/RefineOrbit';
interface OrbitSubdivisionListProps {
    currentOrbitValues: Orbit;
    refinementType: Refinement;
    submitBtn?: React.ReactNode;
}
export declare const sleep: (ms: number) => Promise<unknown>;
declare const OrbitSubdivisionList: React.FC<OrbitSubdivisionListProps>;
export default OrbitSubdivisionList;
