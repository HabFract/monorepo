import { default as React } from 'react';
import { ActionHashB64 } from '@holochain/client';
interface ListOrbitsProps {
    sphereAh?: ActionHashB64;
}
declare const ListOrbits: React.FC<ListOrbitsProps>;
export default ListOrbits;
