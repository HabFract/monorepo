declare const ListSortFilter: ({ label }: {
    label: string;
}) => import("react/jsx-runtime").JSX.Element;
export default ListSortFilter;
