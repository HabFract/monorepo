declare function ListSpheres(): import("react/jsx-runtime").JSX.Element;
export default ListSpheres;
