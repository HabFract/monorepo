import { default as React } from 'react';
interface TraversalButtonProps {
    condition: boolean;
    iconType: 'up' | 'left' | 'down-left' | 'right' | 'down' | 'down-right';
    onClick: () => void;
    dataTestId: string;
}
declare const TraversalButton: React.FC<TraversalButtonProps>;
export default TraversalButton;
