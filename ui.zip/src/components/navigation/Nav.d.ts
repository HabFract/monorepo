export interface INav {
    transition: (newState: string, params?: object) => void;
    setSideNavExpanded: Function;
    setSettingsOpen: Function;
    sideNavExpanded: boolean;
}
declare const Nav: React.FC<INav>;
export default Nav;
