import { default as React } from 'react';
import { ActionHashB64, EntryHashB64 } from '@holochain/client';
type PreloadOrbitDataProps = {
    landingSphereEh?: EntryHashB64;
    landingSphereId?: ActionHashB64;
};
declare const PreloadOrbitData: React.FC<PreloadOrbitDataProps>;
export default PreloadOrbitData;
