declare function BootScreen({ children }: any): import("react/jsx-runtime").JSX.Element;
export default BootScreen;
