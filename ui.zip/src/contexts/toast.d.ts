import { default as React, ReactNode } from 'react';
interface ToastContextProps {
    showToast: (text: string, timeout?: number, bypass?: boolean) => void;
    hideToast: () => void;
    toastText: string;
    isToastVisible: boolean;
}
export declare const ToastProvider: React.FC<{
    children: ReactNode;
}>;
export declare const useToast: () => ToastContextProps;
export {};
