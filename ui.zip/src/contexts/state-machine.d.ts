import { default as React } from 'react';
export declare const StateMachineContext: React.Context<null>;
