export declare const MyProfileContext: import('react').Context<null>;
export declare const MyProfileProvider: (props: any) => import("react/jsx-runtime").JSX.Element;
