export declare function checkForAppUpdates(onUserClick?: boolean): Promise<void>;
