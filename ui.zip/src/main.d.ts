import { default as React } from 'react';
import { StateMachine } from './state/types/stateMachine';
import { AppState, AppStateStore } from './routes';
export declare const AppMachine: StateMachine<AppState, AppStateStore>;
export declare function renderComponent(component: React.ReactNode): Promise<void>;
export declare const WithCacheStore: (component: React.ReactNode) => import("react/jsx-runtime").JSX.Element;
