import { OrbitHierarchyQueryParams } from '../graphql/generated';
import { ActionHashB64 } from '@holochain/client';
interface UseFetchAndCacheRootHierarchyOrbitPathsProps {
    params: OrbitHierarchyQueryParams;
    hasCached?: boolean;
    currentSphereId: ActionHashB64;
    bypass: boolean;
}
interface UseFetchAndCacheRootHierarchyOrbitPathsReturn {
    loading: boolean;
    error?: Error;
    cache: Function | null;
}
export declare const useFetchOrbitsAndCacheHierarchyPaths: ({ params, hasCached, currentSphereId, bypass }: UseFetchAndCacheRootHierarchyOrbitPathsProps) => UseFetchAndCacheRootHierarchyOrbitPathsReturn;
export {};
