import { Orbit, Sphere } from '../graphql/generated';
import { ActionHashB64 } from '@holochain/client';
interface UseFetchAndCacheSphereOrbitsProps {
    sphereAh?: ActionHashB64;
}
interface UseFetchAndCacheSphereOrbitsReturn {
    loading: boolean;
    error?: Error;
    data?: {
        sphere: Sphere;
        orbits: Orbit[];
    };
}
export declare const useFetchAndCacheSphereOrbits: ({ sphereAh }: UseFetchAndCacheSphereOrbitsProps) => UseFetchAndCacheSphereOrbitsReturn;
export {};
