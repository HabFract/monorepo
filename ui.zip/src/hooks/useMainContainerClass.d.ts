export declare function useMainContainerClass(): string;
