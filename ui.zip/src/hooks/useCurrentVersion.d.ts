export declare function useCurrentVersion(): string | undefined;
