export declare function useStateTransition(): any[];
