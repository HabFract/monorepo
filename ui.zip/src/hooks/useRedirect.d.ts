export declare const useRedirect: (bypass?: boolean) => void;
