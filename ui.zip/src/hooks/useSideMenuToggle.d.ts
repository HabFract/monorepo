import { RefObject } from 'react';
declare const useSideMenuToggle: (ref: RefObject<HTMLElement>, setSideNavExpanded: Function) => void;
export default useSideMenuToggle;
