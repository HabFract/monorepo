import { RefObject } from 'react';
export declare function useOnboardingScroll(state: string, progressBarRef: RefObject<HTMLDivElement>, mainPageRef: RefObject<HTMLDivElement>): void;
