import { HierarchyBounds } from '../state/types/hierarchy';
export declare const useNodeTraversal: (hierarchyBounds: HierarchyBounds) => {
    depthIndex: any;
    setDepthIndex: (newDepth: number) => void;
    breadthIndex: any;
    setBreadthIndex: (newBreadth: number) => void;
    incrementBreadth: () => void;
    decrementBreadth: () => void;
    incrementDepth: () => any;
    decrementDepth: () => void;
    maxBreadth: number;
    maxDepth: number;
};
