export declare const useMyProfile: () => any;
