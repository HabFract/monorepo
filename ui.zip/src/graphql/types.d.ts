import { AppSignalCb, CellId } from '@holochain/client';
import { HAPP_DNA_NAME } from '../constants';
export interface DNAIdMappings {
    [HAPP_DNA_NAME]?: object[];
}
export type { CellId };
export interface ResolverOptions {
    dnaConfig: DNAIdMappings;
    conductorUri: string;
    traceAppSignals?: AppSignalCb;
}
export interface ReadParams {
    address: AddressableIdentifier;
}
export interface ById {
    id: AddressableIdentifier;
}
export type AddressableIdentifier = string;
export type APIOptions = ResolverOptions;
type ObjDecorator<T> = (obj: T) => T;
type Resolver<T> = (root: any, args: any) => Promise<T>;
export declare function addTypename<T>(name: string): ObjDecorator<T>;
export declare function injectTypename<T>(name: string, fn: Resolver<T>): Resolver<T>;
