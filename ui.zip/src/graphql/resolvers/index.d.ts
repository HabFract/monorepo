import { ResolverOptions } from '../types.js';
declare const _default: (options: ResolverOptions) => Promise<{
    Query: {
        orbit: (_: any, args: any) => Promise<import('../generated').Orbit>;
        orbits: (_: any, args: any) => Promise<import('../generated').OrbitConnection>;
        getOrbitHierarchy: (_: any, args: any) => Promise<String>;
        sphere: (_: any, args: any) => Promise<Partial<import('../generated').Sphere>>;
        spheres: () => Promise<Partial<import('../generated').SphereConnection>>;
        getLowestSphereHierarchyLevel: (_: any, args: any) => Promise<Number>;
    };
    Mutation: {
        createSphere: import('../mutations/sphere').createHandler;
        updateSphere: import('../mutations/sphere').updateHandler;
        deleteSphere: import('../mutations/sphere').deleteHandler;
        createOrbit: import('../mutations/orbit').createHandler;
        updateOrbit: import('../mutations/orbit').updateHandler;
        deleteOrbit: import('../mutations/orbit').deleteHandler;
    };
}>;
export default _default;
