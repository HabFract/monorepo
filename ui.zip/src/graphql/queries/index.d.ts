import { DNAIdMappings } from '../types';
declare const _default: (dnaConfig: DNAIdMappings, conductorUri: string) => {
    orbit: (_: any, args: any) => Promise<import('../generated').Orbit>;
    orbits: (_: any, args: any) => Promise<import('../generated').OrbitConnection>;
    getOrbitHierarchy: (_: any, args: any) => Promise<String>;
    sphere: (_: any, args: any) => Promise<Partial<import('../generated').Sphere>>;
    spheres: () => Promise<Partial<import('../generated').SphereConnection>>;
    getLowestSphereHierarchyLevel: (_: any, args: any) => Promise<Number>;
};
export default _default;
