import { DNAIdMappings } from '../../types';
import { Sphere, SphereConnection } from '../../generated';
declare const _default: (dnaConfig: DNAIdMappings, conductorUri: string) => {
    sphere: (_: any, args: any) => Promise<Partial<Sphere>>;
    spheres: () => Promise<Partial<SphereConnection>>;
    getLowestSphereHierarchyLevel: (_: any, args: any) => Promise<Number>;
};
export default _default;
