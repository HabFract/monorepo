import { APIOptions, DNAIdMappings } from '.';
import { InMemoryCache, ApolloClient } from '@apollo/client';
interface AutoConnectionOptions {
    dnaConfig?: DNAIdMappings;
}
export type ClientOptions = APIOptions & AutoConnectionOptions;
export declare const cache: InMemoryCache;
export declare function initGraphQLClient({ dnaConfig, conductorUri }: {
    dnaConfig: any;
    conductorUri: any;
}): Promise<ApolloClient<import('@apollo/client').NormalizedCacheObject>>;
export declare const client: false | Promise<ApolloClient<import('@apollo/client').NormalizedCacheObject>>;
export {};
