export declare const extractEdges: <T>(withEdges: {
    edges: {
        node: T;
    }[];
}) => T[];
export declare const createEdges: <T>(nodes: T[]) => {
    edges: {
        node: T;
    }[];
};
export declare function serializeAsyncActions<T>(actions: Array<() => Promise<T>>): void;
