import { DNAIdMappings } from '../../types';
import { CreateResponsePayload, SphereCreateParams, SphereUpdateParams } from '../../generated';
import { ActionHashB64 } from '@holochain/client';
export type createArgs = {
    sphere: SphereCreateParams;
};
export type updateArgs = {
    sphere: SphereUpdateParams;
};
export type createHandler = (root: any, args: createArgs) => Promise<CreateResponsePayload>;
export type updateHandler = (root: any, args: updateArgs) => Promise<CreateResponsePayload>;
export type deleteHandler = (root: any, args: {
    sphereHash: ActionHashB64;
}) => Promise<ActionHashB64>;
declare const _default: (dnaConfig: DNAIdMappings, conductorUri: string) => {
    createSphere: createHandler;
    updateSphere: updateHandler;
    deleteSphere: deleteHandler;
};
export default _default;
