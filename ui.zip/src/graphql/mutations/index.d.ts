import { DNAIdMappings } from '../types';
declare const _default: (dnaConfig: DNAIdMappings, conductorUri: string) => {
    createSphere: import('./sphere').createHandler;
    updateSphere: import('./sphere').updateHandler;
    deleteSphere: import('./sphere').deleteHandler;
    createOrbit: import('./orbit').createHandler;
    updateOrbit: import('./orbit').updateHandler;
    deleteOrbit: import('./orbit').deleteHandler;
};
export default _default;
