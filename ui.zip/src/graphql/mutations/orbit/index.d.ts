import { DNAIdMappings } from '../../types';
import { CreateResponsePayload, OrbitCreateParams, OrbitUpdateParams } from '../../generated';
import { ActionHashB64 } from '@holochain/client';
import { OrbitDetails } from '../../../state/types/orbit';
export type createArgs = {
    orbit: OrbitCreateParams;
};
export type updateArgs = {
    orbit: OrbitUpdateParams;
};
export type createHandler = (root: any, args: createArgs) => Promise<OrbitDetails>;
export type updateHandler = (root: any, args: updateArgs) => Promise<CreateResponsePayload>;
export type deleteHandler = (root: any, args: {
    orbitHash: ActionHashB64;
}) => Promise<ActionHashB64>;
declare const _default: (dnaConfig: DNAIdMappings, conductorUri: string) => {
    createOrbit: createHandler;
    updateOrbit: updateHandler;
    deleteOrbit: deleteHandler;
};
export default _default;
