import { mapZomeFn, autoConnect, openConnection, sniffHolochainAppCells } from './connection.js';
import { default as generateResolvers } from './resolvers';
import { APIOptions, DNAIdMappings, CellId } from './types.js';
export { generateResolvers, autoConnect, openConnection, sniffHolochainAppCells, mapZomeFn, };
export type { DNAIdMappings, CellId, APIOptions, };
/**
 * A schema generator ready to be plugged in to a GraphQL client
 *
 * Required options: conductorUri, dnaConfig
 *
 * @return GraphQLSchema
 */
declare const _default: (options: APIOptions) => Promise<GraphQLSchema>;
export default _default;
