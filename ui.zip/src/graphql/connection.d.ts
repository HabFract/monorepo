import { DNAIdMappings } from './types';
import { AppAuthenticationToken, AppWebsocket, CellId, CellInfo } from '@holochain/client';
export declare function getCellId(cellInfo: CellInfo): CellId;
export declare function autoConnect(conductorUri?: string): Promise<any>;
export declare const openConnection: (token?: AppAuthenticationToken) => Promise<AppWebsocket>;
export declare const getConnection: () => Promise<any>;
/**
 * Introspect an active Holochain connection's app cells to determine cell IDs
 * for mapping to the schema resolvers.
 */
export declare function sniffHolochainAppCells(conn: AppWebsocket, appID?: string): Promise<{
    habits: any;
}>;
export declare function deserializeHash(hash: string): Uint8Array;
export declare function serializeHash(hash: Uint8Array): string;
export declare function remapCellId(originalId: any, newCellId: any): string;
export type BoundZomeFn<InputType, OutputType> = (args: InputType) => OutputType;
/**
 * External API for accessing zome methods, passing them through an optional intermediary DNA ID mapping
 *
 * @param mappings  DNAIdMappings to use for this collaboration space.
 *                  `instance` must be present in the mapping, and the mapped CellId will be used instead of `instance` itself.
 * @param socketURI If provided, connects to the Holochain conductor on a different URI.
 *
 * @return bound async zome function which can be called directly
 */
export declare const mapZomeFn: <InputType, OutputType>(mappings: DNAIdMappings, socketURI: string, instance: string, zome: string, fn: string, skipEncodeDecode?: boolean) => BoundZomeFn<InputType, Promise<OutputType>>;
