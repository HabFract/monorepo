declare function App({ children: pageComponent }: {
    children: any;
}): import("react/jsx-runtime").JSX.Element;
export default App;
