export declare const APP_WS_PORT: string;
export declare const ADMIN_WS_PORT: any;
export declare const NODE_ENV: any;
export declare const HAPP_ID = "habit_fract";
export declare const HAPP_DNA_NAME = "habits";
export declare const HAPP_ZOME_NAME_PERSONAL_HABITS = "personal";
export declare const HAPP_ZOME_NAME_PROFILES = "profiles";
export declare const ALPHA_RELEASE_DISCLAIMER = "Thank you for being an early tester of this habit tracking app.\n\nPlease note that this is an alpha release. This means the software is still in the early stages of development and may not be fully featured.\n\nNotably:\n  - You cannot permanently store habit completion across time. It will reset your progress when you leave!\n  - Profiles, social interaction, etc., will come later.\n  - There is no password protection, and locally cached data is not encrypted. Please don't store sensitive information if others may access the device.\n\n***\nYou may encounter bugs or unexpected behavior while using the app!\n***\n\nIf you experience any issues, the best course of action is to reload the app. If you want to be super helpful, you could report the bug using the form on the Habit/Fract website. Click the feedback button on the settings menu (accessible from Home/Visualize pages) for a link.\n\nWe are actively working on improvements and appreciate your patience and feedback during this phase..\n";
