import { SphereDetails, SphereHashes } from './types/sphere';
/**
 * Read-write atom for the current sphere's hashes
 * @returns {SphereHashes | {}}
 */
export declare const currentSphereHashesAtom: import('jotai').WritableAtom<{
    entryHash: string;
    actionHash: string;
} | {
    entryHash?: undefined;
    actionHash?: undefined;
}, [newSphereHashes: SphereHashes], void>;
/**
 * Derived atom for the current sphere details
 * @returns {SphereDetails | null} The current sphere object or null if no sphere is selected
 */
export declare const currentSphereAtom: import('jotai').Atom<SphereDetails | null>;
/**
 * Derived atom to check if a Sphere has cached nodes
 * @returns {boolean} True if the current sphere has cached nodes, false otherwise
 */
export declare const currentSphereHasCachedNodesAtom: import('jotai').Atom<boolean>;
