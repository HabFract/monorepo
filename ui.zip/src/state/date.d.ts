import { DateTime } from 'luxon';
export declare const currentDayAtom: import('jotai').PrimitiveAtom<DateTime<true>> & {
    init: DateTime<true>;
};
