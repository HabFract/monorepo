import { ActionHashB64 } from '@holochain/client';
import { Frequency, OrbitNodeDetails } from './orbit';
type FixedLengthArray<T, L extends number> = [T, ...T[]] & {
    length: L;
};
export type WinData<F extends Frequency.Rationals> = F extends number & (F extends Frequency.DailyOrMoreRationalRepresentation ? F : never) ? {
    [dayIndex: string]: FixedLengthArray<boolean, F>;
} : {
    [dayIndex: string]: boolean;
};
export type WinState = {
    [nodeId: ActionHashB64]: WinData<OrbitNodeDetails['frequency']>;
};
export default WinState;
