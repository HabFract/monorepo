export type State = string | number | symbol;
export type StateTransitions<S extends State> = Record<S, Array<S>>;
export type StateStore<S extends State> = {
    currentState: S;
    params?: object;
};
export type StateTransitionCallback<S extends State> = (_: StateStore<S>) => Promise<void>;
export type Callbacks<S extends State> = Record<S, StateTransitionCallback<S>>;
/**
 * The main mechanism for maintaining app loading state
 */
export declare class StateMachine<S extends State, T extends StateStore<S>> {
    state: T;
    transitions: StateTransitions<S>;
    callbacks?: Callbacks<S>;
    constructor(init: T, transitions: StateTransitions<S>);
    to(state: S, params: object): void;
    on(state: S, callback: StateTransitionCallback<S>): void;
    go(): void;
}
