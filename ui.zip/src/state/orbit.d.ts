import { ActionHashB64, EntryHashB64 } from '@holochain/client';
import { SphereOrbitNodes } from './types/sphere';
import { Frequency, OrbitNodeDetails } from './types/orbit';
import { Orbit, Frequency as Freq } from '../graphql/generated';
import { WinData } from './types/win';
export declare const decodeFrequency: (frequency: Freq) => Frequency.Rationals;
/**
 * Transforms from graphQL repsonses into a form expected by state management
 * @returns {OrbitNodeDetails} A record of orbit nodes for the current sphere or null if no sphere is selected
 */
export declare const mapToCacheObject: (orbit: Orbit) => OrbitNodeDetails;
/**
 * Derived atom for current SphereOrbitNodes
 * @returns {SphereOrbitNodes | null} A record of orbit nodes for the current sphere or null if no sphere is selected
 */
export declare const currentSphereOrbitNodesAtom: import('jotai').Atom<SphereOrbitNodes | null>;
/**
 * Derived atom for current OrbitNodeDetails
 * @returns {OrbitNodeDetails | null} Details of the current Orbit's Node
 */
export declare const currentOrbitDetailsAtom: import('jotai').Atom<OrbitNodeDetails | null>;
/**
 * Read-write atom for the current orbit ID
 * Reads from and writes to the global app state
 * @returns {{id: ActionHashB64} | null} Details of the current Orbit's Node
 */
export declare const currentOrbitIdAtom: import('jotai').WritableAtom<{
    id: string;
} | null, [newOrbitId: string], void>;
/**
 * Atom factory that creates an atom for getting orbit details by ID.
 *
 * @param orbitId - The ActionHashB64 of the orbit to retrieve.
 * @returns An atom that, when read, returns the OrbitNodeDetails for the specified orbitId, or null if not found.
 */
export declare const getOrbitAtom: (orbitId: ActionHashB64) => import('jotai').Atom<OrbitNodeDetails | null>;
/**
 * Write-only atom for updating orbit details using its entry hash.
 *
 * @param {EntryHashB64} params.orbitEh - The entry hash of the orbit to update.
 * @param {Partial<OrbitNodeDetails>} params.update - The partial orbit details to update.
 *
 * This atom directly updates the orbit details in the global app state.
 * If the orbit is not found, no update occurs.
 */
export declare const setOrbitWithEntryHashAtom: import('jotai').WritableAtom<null, [{
    orbitEh: EntryHashB64;
    update: Partial<OrbitNodeDetails>;
}], void> & {
    init: null;
};
/**
 * Gets the frequency of a given Orbit from the AppState
 * @param orbitHash The ActionHash of the orbit
 * @returns An atom that resolves to the frequency of the orbit, or null if the orbit doesn't exist
 */
export declare const getOrbitFrequency: (orbitHash: ActionHashB64) => import('jotai').Atom<Frequency.Rationals | null>;
/**
 * Gets the win data for a specific orbit
 * @param orbitHash The ActionHash of the orbit
 * @returns An atom that resolves to the win data for the orbit, or an empty object if no data exists
 */
export declare const orbitWinDataAtom: (orbitHash: ActionHashB64) => import('jotai').Atom<WinData<Frequency.Rationals>>;
/**
 * Sets a win for a specific orbit on a given date
 * @param orbitHash The ActionHash of the orbit
 * @param date The date for the win
 * @param winIndex The index of the win (for frequencies > 1)
 * @param hasWin Whether the win is achieved or not
 */
export declare const setWinForOrbit: import('jotai').WritableAtom<null, [{
    orbitHash: ActionHashB64;
    date: string;
    winIndex?: number;
    hasWin: boolean;
}], void> & {
    init: null;
};
/**
 * Calculates the streak information for a specific orbit
 * @param orbitHash The ActionHash of the orbit
 * @returns An atom that resolves to the streak count, or null if the orbit doesn't exist
 */
export declare const calculateStreakAtom: (orbitHash: ActionHashB64) => import('jotai').Atom<number | null>;
