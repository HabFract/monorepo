import { SphereHierarchyBounds, Hierarchy } from './types/hierarchy';
import { ActionHashB64 } from '@holochain/client';
import { OrbitNodeDetails, RootOrbitEntryHash } from './types/orbit';
/**
 * Calculates the overall completion status for a specific orbit
 * @param orbitHash The ActionHash of the orbit
 * @returns An atom that resolves to the completion status (as a percentage), or null if the orbit doesn't exist
 */
export declare const calculateCompletionStatusAtom: (orbitHash: ActionHashB64) => import('jotai').Atom<number | null>;
/**
 * Gets the hierarchy for a given root orbit entry hash
 * @param rootOrbitEntryHash The EntryHash of the root orbit
 * @returns An atom that resolves to the hierarchy, or null if it doesn't exist
 */
export declare const getHierarchyAtom: (rootOrbitEntryHash: RootOrbitEntryHash) => import('jotai').Atom<Hierarchy | null>;
/**
 * Gets all orbits for a given hierarchy
 * @param rootOrbitEntryHash The EntryHash of the root orbit
 * @returns An atom that resolves to an array of orbit details
 */
export declare const getHierarchyOrbitsAtom: (rootOrbitEntryHash: RootOrbitEntryHash) => import('jotai').Atom<OrbitNodeDetails[]>;
/**
 * Atom representing the hierarchy bounds for each sphere.
 * @type {Atom<SphereHierarchyBounds>}
 */
export declare const currentSphereHierarchyBounds: import('jotai').PrimitiveAtom<SphereHierarchyBounds> & {
    init: SphereHierarchyBounds;
};
/**
 * Atom representing the current indices for hierarchy traversal.
 * @type {Atom<HierarchyTraversalIndices>}
 */
export declare const currentSphereHierarchyIndices: import('jotai').PrimitiveAtom<import('./types/hierarchy').Coords> & {
    init: import('./types/hierarchy').Coords;
};
/**
 * Atom for setting the current breadth in the hierarchy.
 * @type {WritableAtom<null, [number], void>}
 */
export declare const setCurrentBreadth: import('jotai').WritableAtom<null, [newBreadth: number], void> & {
    init: null;
};
/**
 * Atom for setting the current depth in the hierarchy.
 * @type {WritableAtom<null, [number], void>}
 */
export declare const setCurrentDepth: import('jotai').WritableAtom<null, [newDepth: number], void> & {
    init: null;
};
/**
 * Atom for setting the depth range for a specific hierarchy.
 * @type {WritableAtom<null, [string, [number, number]], void>}
 */
export declare const setDepths: import('jotai').WritableAtom<null, [id: string, [number, number]], void> & {
    init: null;
};
/**
 * Atom for setting the breadth range for a specific hierarchy.
 * @type {WritableAtom<null, [string, [number, number]], void>}
 */
export declare const setBreadths: import('jotai').WritableAtom<null, [id: string, [number, number]], void> & {
    init: null;
};
/**
 * Primitive atom for passing vis traversal context to the next render.
 */
export declare const newTraversalLevelIndexId: import('jotai').PrimitiveAtom<{
    id: ActionHashB64 | null;
}> & {
    init: {
        id: ActionHashB64 | null;
    };
};
