export declare const RAISIN_BLACK = "rgba(36, 36, 36, 1)";
export declare const KEPPEL = "rgba(54, 175, 152, 1)";
export declare const DEEP_SPACE = "rgba(69, 97, 95, 1)";
export declare const MAJORELLE_BLUE = "#6069df";
export declare const PURPLE = "#8b67e5";
export declare const BLUE_CYAN = "#5380e5";
export declare const SEA_GREEN = "rgba(11,254,184, 1)";
export declare const RIPE_MANGO = "rgba(251,200,43, 1)";
export declare const DEEP_CARMINE = "rgba(231,50,50, 1)";
export declare const OPAL = "rgba(169,189,182, 1)";
export declare const CHINESE_WHITE = "rgba(219,228,226, 1)";
export declare const WHITE = "rgb(255, 255, 255)";
export declare const BLUE_GRAY = "#688acc";
export declare const MOSS_GREEN = "#c0dea9";
export declare const AMETHYST = "#9e5fcb";
export declare const CEIL = "#92a8d4";
export declare const BURNT_SIENNA = "#f16d53";
export declare const SUNRAY = "#e2b657";
export declare const LAVENDER_GRAY = "#c0c7ce";
export declare const SPANISH_GRAY = "#909896";
export declare const DAVYS_GRAY = "#505554";
export declare const ONYX = "#37383a";
export declare const RICH_BLACK = "#00120f";
/**
 * Changes the opacity of an RGBA color string.
 * @param color The original RGBA color string.
 * @param newOpacity The new opacity level (between 0 and 1).
 * @returns The RGBA color string with the updated opacity.
 */
export declare function changeOpacity(color: string, newOpacity: number): string;
