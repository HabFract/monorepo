import React from "react";
import "broadcastchannel-polyfill";
import { StateMachine, StateStore } from "./state/types/stateMachine";
import { AppState } from "./routes";
export declare const AppMachine: StateMachine<AppState, StateStore<AppState>>;
export declare const withJotaiStore: (component: React.ReactNode) => import("react/jsx-runtime").JSX.Element;
export declare function renderPage(page: React.ReactNode, client: any): Promise<() => void>;
//# sourceMappingURL=main.d.ts.map