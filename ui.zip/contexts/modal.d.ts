import React, { ReactNode } from "react";
interface ModalContextProps {
    showModal: (config: ModalConfig) => void;
    hideModal: () => void;
    isModalVisible: boolean;
}
interface ModalConfig {
    title?: string;
    message: string;
    withCancel?: boolean;
    withConfirm?: boolean;
    destructive?: boolean;
    onConfirm?: () => void;
    onCancel?: () => void;
    confirmText?: string;
    cancelText?: string;
    size?: "sm" | "md" | "lg";
}
export declare const ModalProvider: React.FC<{
    children: ReactNode;
}>;
export declare const useModal: () => ModalContextProps;
export {};
//# sourceMappingURL=modal.d.ts.map