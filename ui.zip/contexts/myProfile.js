import { jsx as _jsx } from "react/jsx-runtime";
import { useState, useMemo, createContext } from "react";
export const MyProfileContext = createContext(null);
export const MyProfileProvider = (props) => {
    const [profile, setProfile] = useState(props?.value);
    const value = useMemo(() => [profile, setProfile], [profile]);
    return _jsx(MyProfileContext.Provider, { ...props, value: value });
};
//# sourceMappingURL=myProfile.js.map