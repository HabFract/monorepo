import { createContext, useCallback } from 'react';
const winDataCache = new WeakMap();
export const WinDataContext = createContext({
    getWinData: () => undefined,
    setWinData: () => { },
});
export const useWinDataCache = () => {
    const getWinData = useCallback((orbitKey) => {
        return winDataCache.get(orbitKey);
    }, []);
    const setWinData = useCallback((orbitKey, data) => {
        winDataCache.set(orbitKey, data);
    }, []);
    return { getWinData, setWinData };
};
//# sourceMappingURL=windata.js.map