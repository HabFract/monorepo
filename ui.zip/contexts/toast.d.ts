import React, { ReactNode } from "react";
interface ToastContextProps {
    showToast: (text: string, options?: {
        timeout?: number;
        bypass?: boolean;
        actionButton?: ReactNode;
    }) => void;
    hideToast: () => void;
    toastText: string;
    isToastVisible: boolean;
    actionButton?: ReactNode;
}
export declare const ToastProvider: React.FC<{
    children: ReactNode;
}>;
export declare const useToast: () => ToastContextProps;
export {};
//# sourceMappingURL=toast.d.ts.map