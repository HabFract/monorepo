import { WinDataPerOrbitNode } from '../state/types';
type WinDataContextType = {
    getWinData: (orbitKey: object) => WinDataPerOrbitNode | undefined;
    setWinData: (orbitKey: object, data: WinDataPerOrbitNode) => void;
};
export declare const WinDataContext: import("react").Context<WinDataContextType>;
export declare const useWinDataCache: () => {
    getWinData: (orbitKey: object) => WinDataPerOrbitNode | undefined;
    setWinData: (orbitKey: object, data: WinDataPerOrbitNode) => void;
};
export {};
//# sourceMappingURL=windata.d.ts.map