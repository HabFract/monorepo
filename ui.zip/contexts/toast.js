import { jsx as _jsx } from "react/jsx-runtime";
import { createContext, useContext, useState } from "react";
const TOOLTIP_TIMEOUT = 4500;
const ToastContext = createContext(undefined);
export const ToastProvider = ({ children, }) => {
    const [toastText, setToastText] = useState("");
    const [isToastVisible, setIsToastVisible] = useState(false);
    const showToast = (text, timeout = TOOLTIP_TIMEOUT, bypass) => {
        if (bypass)
            return;
        setToastText(text);
        setIsToastVisible(true);
        setTimeout(() => {
            setIsToastVisible(false);
        }, timeout);
    };
    const hideToast = () => {
        setIsToastVisible(false);
    };
    return (_jsx(ToastContext.Provider, { value: { showToast, hideToast, toastText, isToastVisible }, children: children }));
};
export const useToast = () => {
    const context = useContext(ToastContext);
    if (!context) {
        throw new Error("useToast must be used within a ToastProvider");
    }
    return context;
};
//# sourceMappingURL=toast.js.map