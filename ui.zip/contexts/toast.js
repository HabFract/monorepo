import { jsx as _jsx } from "react/jsx-runtime";
import { createContext, useContext, useState } from "react";
const TOOLTIP_TIMEOUT = 10000;
const ToastContext = createContext(undefined);
export const ToastProvider = ({ children, }) => {
    const [toastText, setToastText] = useState("");
    const [isToastVisible, setIsToastVisible] = useState(false);
    const [actionButton, setActionButton] = useState();
    const showToast = (text, options) => {
        if (options?.bypass)
            return;
        setToastText(text);
        setIsToastVisible(true);
        setActionButton(options?.actionButton);
        setTimeout(() => {
            setIsToastVisible(false);
            setActionButton(undefined);
        }, options?.timeout ?? TOOLTIP_TIMEOUT);
    };
    const hideToast = () => {
        setIsToastVisible(false);
        setActionButton(undefined);
    };
    return (_jsx(ToastContext.Provider, { value: { showToast, hideToast, toastText, isToastVisible, actionButton }, children: children }));
};
export const useToast = () => {
    const context = useContext(ToastContext);
    if (!context) {
        throw new Error("useToast must be used within a ToastProvider");
    }
    return context;
};
//# sourceMappingURL=toast.js.map