import React from 'react';
interface VisContextType {
    isAppendingNode: boolean;
    setIsAppendingNode: (value: boolean) => void;
    visRef: any;
}
export declare const VisContext: React.Context<VisContextType | undefined>;
export declare const VisProvider: React.FC<React.PropsWithChildren<{}>>;
export declare const useVisContext: () => VisContextType;
export {};
//# sourceMappingURL=vis.d.ts.map