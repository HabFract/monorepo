import React from 'react';
export const StateMachineContext = React.createContext(null);
//# sourceMappingURL=state-machine.js.map