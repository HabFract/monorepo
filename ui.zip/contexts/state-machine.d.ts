import React from "react";
import { StateMachine, StateStore } from "../state/types/stateMachine";
import { AppState } from "../routes";
export declare const StateMachineContext: React.Context<StateMachine<AppState, StateStore<AppState>> | null>;
//# sourceMappingURL=state-machine.d.ts.map