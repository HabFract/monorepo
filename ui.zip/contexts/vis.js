import { jsx as _jsx } from "react/jsx-runtime";
import React, { useRef } from 'react';
export const VisContext = React.createContext(undefined);
export const VisProvider = ({ children }) => {
    const [isAppendingNode, setIsAppendingNode] = React.useState(false);
    const visRef = useRef(null);
    return (_jsx(VisContext.Provider, { value: { isAppendingNode, setIsAppendingNode, visRef }, children: children }));
};
export const useVisContext = () => {
    const context = React.useContext(VisContext);
    if (context === undefined) {
        throw new Error('useVisContext must be used within a VisProvider');
    }
    return context;
};
//# sourceMappingURL=vis.js.map