import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { createContext, useContext, useState } from "react";
import { Button, Modal } from "habit-fract-design-system";
const ModalContext = createContext(undefined);
export const ModalProvider = ({ children, }) => {
    const [isModalVisible, setIsModalVisible] = useState(false);
    const [modalConfig, setModalConfig] = useState(null);
    const showModal = (config) => {
        setModalConfig(config);
        setIsModalVisible(true);
    };
    const hideModal = () => {
        setIsModalVisible(false);
        setModalConfig(null);
    };
    const handleConfirm = () => {
        modalConfig?.onConfirm?.();
        hideModal();
    };
    const handleCancel = () => {
        modalConfig?.onCancel?.();
        hideModal();
    };
    return (_jsxs(ModalContext.Provider, { value: { showModal, hideModal, isModalVisible }, children: [_jsx("div", { className: !!(modalConfig?.confirmText) ? "with-confirm-dialog hidden" : "with-dialog hidden" }), children, modalConfig && (_jsx(Modal, { isModalOpen: isModalVisible, onClose: handleCancel, title: modalConfig.title || "Confirmation", size: !!modalConfig.confirmText ? 'sm' : modalConfig.size || "md", footerElement: _jsxs("div", { className: "flex justify-end w-full gap-2", children: [modalConfig?.withCancel && _jsx(Button, { type: "button", variant: modalConfig?.destructive ? "neutral" : "danger", onClick: handleCancel, children: modalConfig.cancelText || "Cancel" }), modalConfig?.withConfirm && _jsx(Button, { type: "button", variant: modalConfig?.destructive ? "danger" : "primary", onClick: handleConfirm, children: modalConfig.confirmText || "Confirm" })] }), children: _jsx("p", { className: "confirmation-message", children: modalConfig.message }) }))] }));
};
export const useModal = () => {
    const context = useContext(ModalContext);
    if (!context) {
        throw new Error("useModal must be used within a ModalProvider");
    }
    return context;
};
//# sourceMappingURL=modal.js.map