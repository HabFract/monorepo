import { useMemo, useState } from 'react';
const SCALE_ORDER = [
    'Astro',
    'Sub',
    'Atom'
];
export function useSearchableList({ items, searchKeys, initialSortKey }) {
    const [searchTerm, setSearchTerm] = useState('');
    const [sortKey, setSortKey] = useState(initialSortKey || null);
    const [sortOrder, setSortOrder] = useState('asc');
    const filteredItems = useMemo(() => {
        let result = [...items];
        if (searchTerm) {
            result = result.filter(item => searchKeys.some(key => String(item[key])
                .toLowerCase()
                .includes(searchTerm.toLowerCase())));
        }
        if (sortKey) {
            result.sort((a, b) => {
                if (sortKey === 'scale') {
                    const indexA = SCALE_ORDER.indexOf(a[sortKey]);
                    const indexB = SCALE_ORDER.indexOf(b[sortKey]);
                    return sortOrder === 'asc' ? indexA - indexB : indexB - indexA;
                }
                const aVal = String(a[sortKey]).toLowerCase();
                const bVal = String(b[sortKey]).toLowerCase();
                const comparison = aVal < bVal ? -1 : aVal > bVal ? 1 : 0;
                return sortOrder === 'asc' ? comparison : -comparison;
            });
        }
        return result;
    }, [items, searchTerm, searchKeys, sortKey, sortOrder]);
    const toggleSortOrder = () => {
        setSortOrder(current => current === 'asc' ? 'desc' : 'asc');
    };
    return {
        filteredItems,
        searchTerm,
        setSearchTerm,
        sortKey,
        setSortKey,
        sortOrder,
        toggleSortOrder
    };
}
//# sourceMappingURL=useSearchableList.js.map