import { Orbit } from "../graphql/generated";
export declare const useSortedOrbits: (orbits: Orbit[] | undefined) => Orbit[];
//# sourceMappingURL=useSortedOrbits.d.ts.map