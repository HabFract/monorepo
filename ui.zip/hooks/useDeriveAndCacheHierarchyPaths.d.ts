import { ActionHashB64 } from "@state/types";
import { TreeVisualization } from "../components/vis/base-classes/TreeVis";
interface UseFetchAndCacheRootHierarchyOrbitPathsProps {
    currentTree: TreeVisualization;
    currentSphereId: ActionHashB64;
    bypassEntirely: boolean;
}
interface UseFetchAndCacheRootHierarchyOrbitPathsReturn {
    cache: Function | null;
}
export declare const useDeriveAndCacheHierarchyPaths: ({ currentTree, currentSphereId, bypassEntirely, }: UseFetchAndCacheRootHierarchyOrbitPathsProps) => UseFetchAndCacheRootHierarchyOrbitPathsReturn;
export {};
//# sourceMappingURL=useDeriveAndCacheHierarchyPaths.d.ts.map