import { SphereHierarchyBounds, SphereOrbitNodeDetails } from "../state";
export declare const useOrbitTreeData: (sphereHashes: any) => {
    nodeDetailsCache: SphereOrbitNodeDetails;
    hasNodes: boolean | null;
    hierarchyBounds: SphereHierarchyBounds;
    setBreadthBounds: (id: string, args_1: [number, number]) => void;
    depthBounds: null;
    setDepthBounds: (id: string, args_1: [number, number]) => void;
    x: number;
    y: number;
    breadthIndex: any;
    setBreadthIndex: (newBreadth: number) => void;
    setNewRenderTraversalDetails: (args_0: {
        id: import("../state").EntryHashB64 | null;
        intermediateId?: import("../state").EntryHashB64 | null;
        previousRenderSiblingIndex?: number;
        direction?: "up" | "down";
    } | ((prev: {
        id: import("../state").EntryHashB64 | null;
        intermediateId?: import("../state").EntryHashB64 | null;
        previousRenderSiblingIndex?: number;
        direction?: "up" | "down";
    }) => {
        id: import("../state").EntryHashB64 | null;
        intermediateId?: import("../state").EntryHashB64 | null;
        previousRenderSiblingIndex?: number;
        direction?: "up" | "down";
    })) => void;
    setNewHierarchyIndices: (args_0: import("../state").Coords | ((prev: import("../state").Coords) => import("../state").Coords)) => void;
};
//# sourceMappingURL=useOrbitTreeData.d.ts.map