import { useAtomValue, useAtom, useSetAtom } from "jotai";
import { nodeCache, currentSphereHierarchyBounds, setBreadths, setDepths, currentSphereHierarchyIndices, currentSphereHasCachedNodesAtom, newTraversalLevelIndexId, } from "../state";
import { useNodeTraversal } from "./useNodeTraversal";
export const useOrbitTreeData = (sphereHashes) => {
    const hasNodes = useAtomValue(currentSphereHasCachedNodesAtom);
    const hierarchyBounds = useAtomValue(currentSphereHierarchyBounds);
    const [, setBreadthBounds] = useAtom(setBreadths);
    const [depthBounds, setDepthBounds] = useAtom(setDepths);
    const setNewRenderTraversalDetails = useSetAtom(newTraversalLevelIndexId);
    const { x, y } = useAtomValue(currentSphereHierarchyIndices);
    const setNewHierarchyIndices = useSetAtom(currentSphereHierarchyIndices);
    const { breadthIndex, setBreadthIndex } = useNodeTraversal(hierarchyBounds[sphereHashes.entryHash]);
    const nodeDetailsCache = useAtomValue(nodeCache.item(sphereHashes.actionHash));
    return {
        nodeDetailsCache,
        hasNodes,
        hierarchyBounds,
        setBreadthBounds,
        depthBounds,
        setDepthBounds,
        x,
        y,
        breadthIndex,
        setBreadthIndex,
        setNewRenderTraversalDetails,
        setNewHierarchyIndices,
    };
};
//# sourceMappingURL=useOrbitTreeData.js.map