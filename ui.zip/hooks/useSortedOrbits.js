import { useAtomValue } from 'jotai';
import { listSortFilterAtom } from '../state/ui';
export const useSortedOrbits = (orbits) => {
    const listSortFilter = useAtomValue(listSortFilterAtom);
    const scaleValues = { Sub: 1, Atom: 2, Astro: 3 };
    const sortOrbits = (a, b) => {
        let propertyA;
        let propertyB;
        if (listSortFilter.sortCriteria === 'name') {
            propertyA = a ? a[listSortFilter.sortCriteria] : 0;
            propertyB = b ? b[listSortFilter.sortCriteria] : 0;
        }
        else {
            propertyA = a[listSortFilter.sortCriteria];
            propertyB = b[listSortFilter.sortCriteria];
            propertyA = scaleValues[propertyA] || 0;
            propertyB = scaleValues[propertyB] || 0;
        }
        if (listSortFilter.sortOrder === 'lowestToGreatest') {
            return propertyA < propertyB ? -1 : propertyA > propertyB ? 1 : 0;
        }
        else {
            return propertyA > propertyB ? -1 : propertyA < propertyB ? 1 : 0;
        }
    };
    return orbits ? orbits.sort(sortOrbits) : [];
};
//# sourceMappingURL=useSortedOrbits.js.map