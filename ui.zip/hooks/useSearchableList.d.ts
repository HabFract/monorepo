import { Orbit } from '../graphql/generated';
type SortableKeys = keyof Pick<Orbit, 'name' | 'scale'>;
interface UseSearchableListProps<T> {
    items: T[];
    searchKeys: (keyof T)[];
    initialSortKey?: SortableKeys;
}
interface UseSearchableListReturn<T> {
    filteredItems: T[];
    searchTerm: string;
    setSearchTerm: (term: string) => void;
    sortKey: SortableKeys | null;
    setSortKey: (key: SortableKeys) => void;
    sortOrder: 'asc' | 'desc';
    toggleSortOrder: () => void;
}
export declare function useSearchableList<T extends Orbit>({ items, searchKeys, initialSortKey }: UseSearchableListProps<T>): UseSearchableListReturn<T>;
export {};
//# sourceMappingURL=useSearchableList.d.ts.map