import { useEffect } from "react";
export function useOnboardingScroll(state, progressBarRef, mainPageRef) {
    useEffect(() => {
        const stage = +(state.match(/Onboarding(\d+)/)?.[1] || 0);
        if (!stage || progressBarRef.current == null)
            return;
        setTimeout(() => {
            progressBarRef.current
                .querySelector(".onboarding-progress")
                .scrollTo((stage + 2) * 60, 0);
        }, 500);
    }, [state, progressBarRef]);
    useEffect(() => {
        if (mainPageRef.current == null)
            return;
        setTimeout(() => {
            mainPageRef.current
                ?.querySelector(".onboarding-layout")
                ?.scrollTo(0, 0);
        }, 500);
    }, [state, mainPageRef]);
}
//# sourceMappingURL=useOnboardingScroll.js.map