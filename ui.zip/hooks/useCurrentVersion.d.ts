export declare function useCurrentVersion(): string | undefined;
//# sourceMappingURL=useCurrentVersion.d.ts.map