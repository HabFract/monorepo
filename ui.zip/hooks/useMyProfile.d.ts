export declare const useMyProfile: () => any;
//# sourceMappingURL=useMyProfile.d.ts.map