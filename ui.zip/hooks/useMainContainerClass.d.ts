export declare function useMainContainerClass(): string;
//# sourceMappingURL=useMainContainerClass.d.ts.map