export declare function useStateTransition(): any[];
//# sourceMappingURL=useStateTransition.d.ts.map