import { SphereHashes } from "../state";
export declare const useVisCanvas: (selectedSphere: SphereHashes) => {
    appendedSvg: boolean;
};
//# sourceMappingURL=useVisCanvas.d.ts.map