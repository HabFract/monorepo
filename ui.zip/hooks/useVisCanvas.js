import { useState, useEffect } from "react";
import { appendSvg } from "../components/vis/helpers";
export const useVisCanvas = (selectedSphere) => {
    const [appendedSvg, setAppendedSvg] = useState(false);
    useEffect(() => {
        if (document.querySelector(`#vis-root #vis`))
            return;
        const appended = !!appendSvg("vis-root", "vis");
        setAppendedSvg(appended);
    }, [selectedSphere?.actionHash]);
    return { appendedSvg };
};
//# sourceMappingURL=useVisCanvas.js.map