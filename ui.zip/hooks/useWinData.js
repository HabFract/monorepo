import { useCallback, useEffect, useMemo, useRef } from "react";
import { useGetWinRecordForOrbitForMonthLazyQuery, } from "../graphql/generated";
import { toYearDotMonth } from "habit-fract-design-system";
import { isMoreThenDaily } from "../components/vis/tree-helpers";
import { useAtom, useAtomValue } from "jotai";
import { calculateWinDataForNonLeafNodeAtom, winDataPerOrbitNodeAtom, } from "../state/win";
import { isLeafNodeHashAtom } from "../state";
export const winDataArrayToWinRecord = (acc, { date, value: val }) => {
    acc[date] = "single" in val ? val.single : val.multiple;
    return acc;
};
export function useWinData(currentOrbitDetails, currentDate) {
    const currentYearDotMonth = toYearDotMonth(currentDate.toLocaleString());
    const skipFlag = !currentOrbitDetails || !currentOrbitDetails.eH;
    const orbitHash = currentOrbitDetails?.eH;
    const isLeaf = useAtomValue(useMemo(() => isLeafNodeHashAtom(currentOrbitDetails?.id || ""), [currentOrbitDetails?.id]));
    const winDataAtom = useMemo(() => {
        console.log('Creating winDataAtom:', {
            orbitHash,
            isLeaf,
            currentOrbitDetails,
            skipFlag
        });
        if (!orbitHash) {
            console.log('No orbit hash, returning empty atom');
            return winDataPerOrbitNodeAtom('');
        }
        if (!isLeaf) {
            const calculatedAtom = calculateWinDataForNonLeafNodeAtom(orbitHash);
            console.log('Created calculation atom for non-leaf:', {
                orbitHash,
                calculatedAtom
            });
            return calculatedAtom;
        }
        return winDataPerOrbitNodeAtom(orbitHash);
    }, [orbitHash, isLeaf]);
    const prevWinDataRef = useRef(null);
    const [workingWinDataForOrbit, setWorkingWinDataForOrbit] = useAtom(winDataAtom);
    useEffect(() => {
        if (prevWinDataRef.current !== workingWinDataForOrbit) {
            console.log('Win data changed:', {
                from: prevWinDataRef.current,
                to: workingWinDataForOrbit,
                orbitHash,
                isLeaf
            });
            prevWinDataRef.current = workingWinDataForOrbit;
        }
    }, [workingWinDataForOrbit, orbitHash, isLeaf]);
    const [getWinRecord, { data, loading, error }] = useGetWinRecordForOrbitForMonthLazyQuery();
    useEffect(() => {
        if (!orbitHash || skipFlag || !isLeaf || workingWinDataForOrbit)
            return;
        getWinRecord({
            variables: {
                params: {
                    yearDotMonth: currentYearDotMonth,
                    orbitEh: orbitHash,
                },
            },
        });
    }, [orbitHash, skipFlag, isLeaf, workingWinDataForOrbit, currentYearDotMonth]);
    useEffect(() => {
        if (!currentOrbitDetails || !data?.getWinRecordForOrbitForMonth || !isLeaf)
            return;
        const newWinData = data.getWinRecordForOrbitForMonth.winData.reduce(winDataArrayToWinRecord, {});
        setWorkingWinDataForOrbit(newWinData);
    }, [data, isLeaf, currentOrbitDetails]);
    useEffect(() => {
        if (loading ||
            !currentOrbitDetails ||
            !currentDate ||
            (!data && !error) ||
            (data?.getWinRecordForOrbitForMonth?.winData?.length && data?.getWinRecordForOrbitForMonth?.winData.length > 0) ||
            !isLeaf ||
            workingWinDataForOrbit?.[currentDate.toLocaleString()])
            return;
        const newData = {
            ...(workingWinDataForOrbit || {}),
            [currentDate.toLocaleString()]: isMoreThenDaily(currentOrbitDetails.frequency)
                ? new Array(currentOrbitDetails.frequency).fill(false)
                : false,
        };
        setWorkingWinDataForOrbit(newData);
    }, [data, currentDate, loading, error, isLeaf, currentOrbitDetails]);
    const handleUpdateWorkingWins = useCallback((newWinCount) => {
        if (!workingWinDataForOrbit || !currentOrbitDetails || !isLeaf)
            return;
        const updatedData = {
            ...workingWinDataForOrbit,
            [currentDate.toLocaleString()]: currentOrbitDetails.frequency > 1
                ? Array(currentOrbitDetails.frequency)
                    .fill(false)
                    .map((_, i) => i < newWinCount)
                : !!newWinCount,
        };
        setWorkingWinDataForOrbit(updatedData);
    }, [workingWinDataForOrbit, currentOrbitDetails, currentDate, isLeaf]);
    return {
        workingWinDataForOrbit,
        handleUpdateWorkingWins,
        isLeaf,
    };
}
//# sourceMappingURL=useWinData.js.map