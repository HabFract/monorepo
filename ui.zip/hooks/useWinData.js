import { useCallback, useEffect, useMemo } from "react";
import { useGetWinRecordForOrbitForMonthLazyQuery, } from "../graphql/generated";
import { toYearDotMonth } from "habit-fract-design-system";
import { isMoreThenDaily } from "../components/vis/tree-helpers";
import { useAtom } from "jotai";
import { winDataPerOrbitNodeAtom } from "../state/win";
export const winDataArrayToWinRecord = (acc, { date, value: val }) => {
    acc[date] = "single" in val ? val.single : val.multiple;
    return acc;
};
export function useWinData(currentOrbitDetails, currentDate) {
    const currentYearDotMonth = toYearDotMonth(currentDate.toLocaleString());
    const skipFlag = !currentOrbitDetails || !currentOrbitDetails.eH;
    const orbitHash = currentOrbitDetails?.eH;
    const [workingWinDataForOrbit, setWorkingWinDataForOrbit] = useAtom(useMemo(() => winDataPerOrbitNodeAtom(orbitHash), [orbitHash]));
    const [getWinRecord, { data, loading, error }] = useGetWinRecordForOrbitForMonthLazyQuery();
    useEffect(() => {
        if (!orbitHash)
            return;
        if (!skipFlag && !workingWinDataForOrbit) {
            getWinRecord({
                variables: {
                    params: {
                        yearDotMonth: currentYearDotMonth,
                        orbitEh: currentOrbitDetails?.eH,
                    },
                },
            });
        }
    }, [currentOrbitDetails?.eH, workingWinDataForOrbit]);
    useEffect(() => {
        if (currentOrbitDetails == null || !data?.getWinRecordForOrbitForMonth)
            return;
        const newWinData = data.getWinRecordForOrbitForMonth.winData.reduce(winDataArrayToWinRecord, {});
        setWorkingWinDataForOrbit(newWinData);
    }, [data, orbitHash]);
    useEffect(() => {
        if (loading ||
            currentOrbitDetails == null ||
            !currentDate ||
            (!data && !error) ||
            (data?.getWinRecordForOrbitForMonth &&
                data.getWinRecordForOrbitForMonth.winData.length > 0))
            return;
        if (!workingWinDataForOrbit ||
            !(currentDate.toLocaleString() in workingWinDataForOrbit)) {
            const newData = {
                ...workingWinDataForOrbit,
                [currentDate.toLocaleString()]: isMoreThenDaily(currentOrbitDetails.frequency)
                    ? new Array(currentOrbitDetails.frequency).fill(false)
                    : false,
            };
            setWorkingWinDataForOrbit(newData);
        }
    }, [data, currentDate, orbitHash]);
    const handleUpdateWorkingWins = useCallback((newWinCount) => {
        if (workingWinDataForOrbit == null || currentOrbitDetails == null)
            return;
        const updatedData = {
            ...workingWinDataForOrbit,
            [currentDate.toLocaleString()]: currentOrbitDetails.frequency > 1
                ? Array(currentOrbitDetails.frequency)
                    .fill(false)
                    .map((_, i) => i < newWinCount)
                : !!newWinCount,
        };
        setWorkingWinDataForOrbit(updatedData);
    }, [
        workingWinDataForOrbit,
        currentOrbitDetails,
        currentDate,
        setWorkingWinDataForOrbit,
    ]);
    return { workingWinDataForOrbit, handleUpdateWorkingWins };
}
//# sourceMappingURL=useWinData.js.map