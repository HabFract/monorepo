import { DateTime } from "luxon";
import { NodeContent, OrbitNodeDetails, WinDataPerOrbitNode } from "../state/types";
import { HierarchyNode } from "d3-hierarchy";
export declare function useWinData(currentOrbitDetails: OrbitNodeDetails | null, currentDate: DateTime, isLeafNode: boolean, rootHierarchy: HierarchyNode<NodeContent>): {
    workingWinDataForOrbit: WinDataPerOrbitNode | null;
    handleUpdateWorkingWins: (newWinCount: number) => void;
    handlePersistWins: () => void;
    numberOfLeafOrbitDescendants: number | null;
    isLeaf: boolean;
    currentStreak: number;
    longestStreak: number;
};
//# sourceMappingURL=useWinData.d.ts.map