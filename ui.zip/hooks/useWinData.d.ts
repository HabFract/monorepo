import { OrbitNodeDetails, FixedLengthArray } from "../state/types";
import { DateTime } from "luxon";
export declare const winDataArrayToWinRecord: (acc: any, { date, value: val }: any) => any;
export declare function useWinData(currentOrbitDetails: OrbitNodeDetails | null, currentDate: DateTime): {
    workingWinDataForOrbit: {
        [dayIndex: string]: boolean;
    } | {
        [dayIndex: string]: FixedLengthArray<boolean, 1>;
    } | {
        [dayIndex: string]: FixedLengthArray<boolean, 2>;
    } | {
        [dayIndex: string]: FixedLengthArray<boolean, 22>;
    } | {
        [dayIndex: string]: FixedLengthArray<boolean, 3>;
    } | {
        [dayIndex: string]: FixedLengthArray<boolean, 4>;
    } | {
        [dayIndex: string]: FixedLengthArray<boolean, 5>;
    } | {
        [dayIndex: string]: FixedLengthArray<boolean, 6>;
    } | {
        [dayIndex: string]: FixedLengthArray<boolean, 7>;
    } | {
        [dayIndex: string]: FixedLengthArray<boolean, 8>;
    } | {
        [dayIndex: string]: FixedLengthArray<boolean, 9>;
    } | {
        [dayIndex: string]: FixedLengthArray<boolean, 10>;
    } | {
        [dayIndex: string]: FixedLengthArray<boolean, 11>;
    } | {
        [dayIndex: string]: FixedLengthArray<boolean, 12>;
    } | {
        [dayIndex: string]: FixedLengthArray<boolean, 13>;
    } | {
        [dayIndex: string]: FixedLengthArray<boolean, 14>;
    } | {
        [dayIndex: string]: FixedLengthArray<boolean, 15>;
    } | {
        [dayIndex: string]: FixedLengthArray<boolean, 16>;
    } | {
        [dayIndex: string]: FixedLengthArray<boolean, 17>;
    } | {
        [dayIndex: string]: FixedLengthArray<boolean, 18>;
    } | {
        [dayIndex: string]: FixedLengthArray<boolean, 19>;
    } | {
        [dayIndex: string]: FixedLengthArray<boolean, 20>;
    } | {
        [dayIndex: string]: FixedLengthArray<boolean, 21>;
    } | {
        [dayIndex: string]: FixedLengthArray<boolean, 23>;
    } | {
        [dayIndex: string]: FixedLengthArray<boolean, 24>;
    };
    handleUpdateWorkingWins: (newWinCount: number) => void;
};
//# sourceMappingURL=useWinData.d.ts.map