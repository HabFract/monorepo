export declare const useGetOrbitsQuery: (opts: any) => {
    isLoading: boolean;
    error: import("@apollo/client").ApolloError | undefined;
    refetch: (variables?: Partial<import("../../graphql/generated").Exact<{
        sphereEntryHashB64?: import("../../graphql/generated").InputMaybe<import("../../graphql/generated").Scalars["String"]["input"]>;
    }>> | undefined) => Promise<import("@apollo/client").ApolloQueryResult<import("../../graphql/generated").GetOrbitsQuery>>;
    client: import("@apollo/client").ApolloClient<any>;
    observable: import("@apollo/client").ObservableQuery<import("../../graphql/generated").GetOrbitsQuery, import("../../graphql/generated").Exact<{
        sphereEntryHashB64?: import("../../graphql/generated").InputMaybe<import("../../graphql/generated").Scalars["String"]["input"]>;
    }>>;
    data: import("../../graphql/generated").GetOrbitsQuery | undefined;
    previousData?: import("../../graphql/generated").GetOrbitsQuery | undefined;
    errors?: ReadonlyArray<import("graphql").GraphQLFormattedError>;
    loading: boolean;
    networkStatus: import("@apollo/client").NetworkStatus;
    called: boolean;
    startPolling: (pollInterval: number) => void;
    stopPolling: () => void;
    subscribeToMore: <TSubscriptionData = import("../../graphql/generated").GetOrbitsQuery, TSubscriptionVariables extends import("@apollo/client").OperationVariables = import("../../graphql/generated").Exact<{
        sphereEntryHashB64?: import("../../graphql/generated").InputMaybe<import("../../graphql/generated").Scalars["String"]["input"]>;
    }>>(options: import("@apollo/client").SubscribeToMoreOptions<import("../../graphql/generated").GetOrbitsQuery, TSubscriptionVariables, TSubscriptionData>) => () => void;
    updateQuery: <TVars extends import("@apollo/client").OperationVariables = import("../../graphql/generated").Exact<{
        sphereEntryHashB64?: import("../../graphql/generated").InputMaybe<import("../../graphql/generated").Scalars["String"]["input"]>;
    }>>(mapFn: (previousQueryResult: {
        __typename?: "Query" | undefined;
        orbits: {
            __typename?: "OrbitConnection" | undefined;
            edges: {
                __typename?: "OrbitEdge" | undefined;
                node: {
                    __typename?: "Orbit" | undefined;
                    id: string;
                    eH: string;
                    name: string;
                    sphereHash: string;
                    parentHash?: string | null | undefined;
                    frequency: import("../../graphql/generated").Frequency;
                    scale: import("../../graphql/generated").Scale;
                    metadata?: {
                        __typename?: "OrbitMetaData" | undefined;
                        description?: string | null | undefined;
                        timeframe: {
                            __typename?: "TimeFrame" | undefined;
                            startTime: number;
                            endTime?: number | null | undefined;
                        };
                    } | null | undefined;
                };
            }[];
        };
    }, options: Pick<import("@apollo/client").WatchQueryOptions<TVars, import("../../graphql/generated").GetOrbitsQuery>, "variables">) => {
        __typename?: "Query" | undefined;
        orbits: {
            __typename?: "OrbitConnection" | undefined;
            edges: {
                __typename?: "OrbitEdge" | undefined;
                node: {
                    __typename?: "Orbit" | undefined;
                    id: string;
                    eH: string;
                    name: string;
                    sphereHash: string;
                    parentHash?: string | null | undefined;
                    frequency: import("../../graphql/generated").Frequency;
                    scale: import("../../graphql/generated").Scale;
                    metadata?: {
                        __typename?: "OrbitMetaData" | undefined;
                        description?: string | null | undefined;
                        timeframe: {
                            __typename?: "TimeFrame" | undefined;
                            startTime: number;
                            endTime?: number | null | undefined;
                        };
                    } | null | undefined;
                };
            }[];
        };
    }) => void;
    reobserve: (newOptions?: Partial<import("@apollo/client").WatchQueryOptions<import("../../graphql/generated").Exact<{
        sphereEntryHashB64?: import("../../graphql/generated").InputMaybe<import("../../graphql/generated").Scalars["String"]["input"]>;
    }>, import("../../graphql/generated").GetOrbitsQuery>> | undefined, newNetworkStatus?: import("@apollo/client").NetworkStatus) => Promise<import("@apollo/client").ApolloQueryResult<import("../../graphql/generated").GetOrbitsQuery>>;
    variables: import("../../graphql/generated").Exact<{
        sphereEntryHashB64?: import("../../graphql/generated").InputMaybe<import("../../graphql/generated").Scalars["String"]["input"]>;
    }> | undefined;
    fetchMore: <TFetchData = import("../../graphql/generated").GetOrbitsQuery, TFetchVars extends import("@apollo/client").OperationVariables = import("../../graphql/generated").Exact<{
        sphereEntryHashB64?: import("../../graphql/generated").InputMaybe<import("../../graphql/generated").Scalars["String"]["input"]>;
    }>>(fetchMoreOptions: import("@apollo/client").FetchMoreQueryOptions<TFetchVars, TFetchData> & {
        updateQuery?: ((previousQueryResult: {
            __typename?: "Query" | undefined;
            orbits: {
                __typename?: "OrbitConnection" | undefined;
                edges: {
                    __typename?: "OrbitEdge" | undefined;
                    node: {
                        __typename?: "Orbit" | undefined;
                        id: string;
                        eH: string;
                        name: string;
                        sphereHash: string;
                        parentHash?: string | null | undefined;
                        frequency: import("../../graphql/generated").Frequency;
                        scale: import("../../graphql/generated").Scale;
                        metadata?: {
                            __typename?: "OrbitMetaData" | undefined;
                            description?: string | null | undefined;
                            timeframe: {
                                __typename?: "TimeFrame" | undefined;
                                startTime: number;
                                endTime?: number | null | undefined;
                            };
                        } | null | undefined;
                    };
                }[];
            };
        }, options: {
            fetchMoreResult: import("@apollo/client").Unmasked<TFetchData>;
            variables: TFetchVars;
        }) => {
            __typename?: "Query" | undefined;
            orbits: {
                __typename?: "OrbitConnection" | undefined;
                edges: {
                    __typename?: "OrbitEdge" | undefined;
                    node: {
                        __typename?: "Orbit" | undefined;
                        id: string;
                        eH: string;
                        name: string;
                        sphereHash: string;
                        parentHash?: string | null | undefined;
                        frequency: import("../../graphql/generated").Frequency;
                        scale: import("../../graphql/generated").Scale;
                        metadata?: {
                            __typename?: "OrbitMetaData" | undefined;
                            description?: string | null | undefined;
                            timeframe: {
                                __typename?: "TimeFrame" | undefined;
                                startTime: number;
                                endTime?: number | null | undefined;
                            };
                        } | null | undefined;
                    };
                }[];
            };
        }) | undefined;
    }) => Promise<import("@apollo/client").ApolloQueryResult<import("@apollo/client").MaybeMasked<TFetchData>>>;
};
export declare const useGetOrbitsLazyQuery: (opts?: any) => readonly [(options?: any) => Promise<import("@apollo/client").QueryResult<import("../../graphql/generated").GetOrbitsQuery, import("../../graphql/generated").Exact<{
    sphereEntryHashB64?: import("../../graphql/generated").InputMaybe<import("../../graphql/generated").Scalars["String"]["input"]>;
}>>>, {
    readonly isLoading: boolean;
    readonly error: import("@apollo/client").ApolloError | undefined;
    readonly refetch: (variables?: Partial<import("../../graphql/generated").Exact<{
        sphereEntryHashB64?: import("../../graphql/generated").InputMaybe<import("../../graphql/generated").Scalars["String"]["input"]>;
    }>> | undefined) => Promise<import("@apollo/client").ApolloQueryResult<import("../../graphql/generated").GetOrbitsQuery>>;
    readonly client: import("@apollo/client").ApolloClient<any>;
    readonly observable: import("@apollo/client").ObservableQuery<import("../../graphql/generated").GetOrbitsQuery, import("../../graphql/generated").Exact<{
        sphereEntryHashB64?: import("../../graphql/generated").InputMaybe<import("../../graphql/generated").Scalars["String"]["input"]>;
    }>>;
    readonly data: import("../../graphql/generated").GetOrbitsQuery | undefined;
    readonly previousData?: import("../../graphql/generated").GetOrbitsQuery | undefined;
    readonly errors?: ReadonlyArray<import("graphql").GraphQLFormattedError>;
    readonly loading: boolean;
    readonly networkStatus: import("@apollo/client").NetworkStatus;
    readonly called: boolean;
    readonly startPolling: (pollInterval: number) => void;
    readonly stopPolling: () => void;
    readonly subscribeToMore: <TSubscriptionData = import("../../graphql/generated").GetOrbitsQuery, TSubscriptionVariables extends import("@apollo/client").OperationVariables = import("../../graphql/generated").Exact<{
        sphereEntryHashB64?: import("../../graphql/generated").InputMaybe<import("../../graphql/generated").Scalars["String"]["input"]>;
    }>>(options: import("@apollo/client").SubscribeToMoreOptions<import("../../graphql/generated").GetOrbitsQuery, TSubscriptionVariables, TSubscriptionData>) => () => void;
    readonly updateQuery: <TVars extends import("@apollo/client").OperationVariables = import("../../graphql/generated").Exact<{
        sphereEntryHashB64?: import("../../graphql/generated").InputMaybe<import("../../graphql/generated").Scalars["String"]["input"]>;
    }>>(mapFn: (previousQueryResult: {
        __typename?: "Query" | undefined;
        orbits: {
            __typename?: "OrbitConnection" | undefined;
            edges: {
                __typename?: "OrbitEdge" | undefined;
                node: {
                    __typename?: "Orbit" | undefined;
                    id: string;
                    eH: string;
                    name: string;
                    sphereHash: string;
                    parentHash?: string | null | undefined;
                    frequency: import("../../graphql/generated").Frequency;
                    scale: import("../../graphql/generated").Scale;
                    metadata?: {
                        __typename?: "OrbitMetaData" | undefined;
                        description?: string | null | undefined;
                        timeframe: {
                            __typename?: "TimeFrame" | undefined;
                            startTime: number;
                            endTime?: number | null | undefined;
                        };
                    } | null | undefined;
                };
            }[];
        };
    }, options: Pick<import("@apollo/client").WatchQueryOptions<TVars, import("../../graphql/generated").GetOrbitsQuery>, "variables">) => {
        __typename?: "Query" | undefined;
        orbits: {
            __typename?: "OrbitConnection" | undefined;
            edges: {
                __typename?: "OrbitEdge" | undefined;
                node: {
                    __typename?: "Orbit" | undefined;
                    id: string;
                    eH: string;
                    name: string;
                    sphereHash: string;
                    parentHash?: string | null | undefined;
                    frequency: import("../../graphql/generated").Frequency;
                    scale: import("../../graphql/generated").Scale;
                    metadata?: {
                        __typename?: "OrbitMetaData" | undefined;
                        description?: string | null | undefined;
                        timeframe: {
                            __typename?: "TimeFrame" | undefined;
                            startTime: number;
                            endTime?: number | null | undefined;
                        };
                    } | null | undefined;
                };
            }[];
        };
    }) => void;
    readonly reobserve: (newOptions?: Partial<import("@apollo/client").WatchQueryOptions<import("../../graphql/generated").Exact<{
        sphereEntryHashB64?: import("../../graphql/generated").InputMaybe<import("../../graphql/generated").Scalars["String"]["input"]>;
    }>, import("../../graphql/generated").GetOrbitsQuery>> | undefined, newNetworkStatus?: import("@apollo/client").NetworkStatus) => Promise<import("@apollo/client").ApolloQueryResult<import("../../graphql/generated").GetOrbitsQuery>>;
    readonly variables: import("../../graphql/generated").Exact<{
        sphereEntryHashB64?: import("../../graphql/generated").InputMaybe<import("../../graphql/generated").Scalars["String"]["input"]>;
    }> | undefined;
    readonly fetchMore: <TFetchData = import("../../graphql/generated").GetOrbitsQuery, TFetchVars extends import("@apollo/client").OperationVariables = import("../../graphql/generated").Exact<{
        sphereEntryHashB64?: import("../../graphql/generated").InputMaybe<import("../../graphql/generated").Scalars["String"]["input"]>;
    }>>(fetchMoreOptions: import("@apollo/client").FetchMoreQueryOptions<TFetchVars, TFetchData> & {
        updateQuery?: ((previousQueryResult: {
            __typename?: "Query" | undefined;
            orbits: {
                __typename?: "OrbitConnection" | undefined;
                edges: {
                    __typename?: "OrbitEdge" | undefined;
                    node: {
                        __typename?: "Orbit" | undefined;
                        id: string;
                        eH: string;
                        name: string;
                        sphereHash: string;
                        parentHash?: string | null | undefined;
                        frequency: import("../../graphql/generated").Frequency;
                        scale: import("../../graphql/generated").Scale;
                        metadata?: {
                            __typename?: "OrbitMetaData" | undefined;
                            description?: string | null | undefined;
                            timeframe: {
                                __typename?: "TimeFrame" | undefined;
                                startTime: number;
                                endTime?: number | null | undefined;
                            };
                        } | null | undefined;
                    };
                }[];
            };
        }, options: {
            fetchMoreResult: import("@apollo/client").Unmasked<TFetchData>;
            variables: TFetchVars;
        }) => {
            __typename?: "Query" | undefined;
            orbits: {
                __typename?: "OrbitConnection" | undefined;
                edges: {
                    __typename?: "OrbitEdge" | undefined;
                    node: {
                        __typename?: "Orbit" | undefined;
                        id: string;
                        eH: string;
                        name: string;
                        sphereHash: string;
                        parentHash?: string | null | undefined;
                        frequency: import("../../graphql/generated").Frequency;
                        scale: import("../../graphql/generated").Scale;
                        metadata?: {
                            __typename?: "OrbitMetaData" | undefined;
                            description?: string | null | undefined;
                            timeframe: {
                                __typename?: "TimeFrame" | undefined;
                                startTime: number;
                                endTime?: number | null | undefined;
                            };
                        } | null | undefined;
                    };
                }[];
            };
        }) | undefined;
    }) => Promise<import("@apollo/client").ApolloQueryResult<import("@apollo/client").MaybeMasked<TFetchData>>>;
}];
//# sourceMappingURL=useGetOrbitsQuery.d.ts.map