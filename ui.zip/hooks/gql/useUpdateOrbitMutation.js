import { useAtom } from "jotai";
import { appStateAtom, store } from "../../state/store";
import { useUpdateOrbitMutation as useUpdateOrbitMutationGenerated, } from "../../graphql/generated";
import { updateNodeCache, updateAppStateWithOrbit, invalidateOrbitHierarchyCache, } from "./utils";
import { decodeFrequency, getOrbitEhFromId } from "../../state/orbit";
export const useUpdateOrbitMutation = (opts) => {
    const [prevState, setAppState] = useAtom(appStateAtom);
    return useUpdateOrbitMutationGenerated({
        ...opts,
        update(_cache, { data }, { variables }) {
            if (!data?.updateOrbit)
                return;
            const updatedOrbit = data.updateOrbit;
            const updatedOrbitHashes = {
                id: updatedOrbit.id,
                eH: updatedOrbit.eH,
                sphereHash: updatedOrbit.sphereHash,
                parentEh: updatedOrbit?.parentHash,
            };
            const updatedOrbitDetails = {
                ...updatedOrbitHashes,
                name: updatedOrbit.name,
                scale: updatedOrbit.scale,
                frequency: decodeFrequency(updatedOrbit.frequency),
                startTime: updatedOrbit.metadata.timeframe.startTime,
                endTime: updatedOrbit.metadata.timeframe.endTime,
                description: updatedOrbit.metadata.description,
            };
            const oldOrbitId = store.get(getOrbitEhFromId(variables.orbitFields.id));
            console.log("oldOrbitId :>> ", oldOrbitId);
            updateNodeCache(updatedOrbitDetails, oldOrbitId);
            const updatedState = updateAppStateWithOrbit(prevState, updatedOrbitHashes, false, oldOrbitId);
            setAppState(updatedState);
            console.warn("Cache update from useUpdateOrbit");
            invalidateOrbitHierarchyCache(updatedOrbit.sphereHash);
            opts?.update && opts.update();
        },
    });
};
//# sourceMappingURL=useUpdateOrbitMutation.js.map