import { useAtom } from "jotai";
import { appStateAtom } from "../../state/store";
import { useCreateOrbitMutation as useCreateOrbitMutationGenerated, } from "../../graphql/generated";
import { decodeFrequency } from "../../state/orbit";
import { invalidateOrbitHierarchyCache, updateAppStateWithOrbit, updateNodeCache, } from "./utils";
export const useCreateOrbitMutation = (opts) => {
    const [prevState, setAppState] = useAtom(appStateAtom);
    return useCreateOrbitMutationGenerated({
        ...opts,
        update(_cache, { data }) {
            if (!data?.createOrbit)
                return;
            const newOrbit = data.createOrbit;
            const newOrbitHashes = {
                id: newOrbit.id,
                eH: newOrbit.eH,
                sphereHash: newOrbit.sphereHash,
                parentEh: newOrbit?.parentHash,
            };
            const newOrbitDetails = {
                ...newOrbitHashes,
                name: newOrbit.name,
                scale: newOrbit.scale,
                frequency: decodeFrequency(newOrbit.frequency),
                startTime: newOrbit.metadata.timeframe.startTime,
                endTime: newOrbit.metadata.timeframe.endTime,
                description: newOrbit.metadata.description,
            };
            updateNodeCache(newOrbitDetails);
            const updatedState = updateAppStateWithOrbit(prevState, newOrbitHashes, true);
            setAppState(updatedState);
            console.warn("Cache update from useCreateOrbit");
            invalidateOrbitHierarchyCache(newOrbit.sphereHash);
            opts?.update && opts.update();
        },
    });
};
//# sourceMappingURL=useCreateOrbitMutation.js.map