import { useAtom } from "jotai";
import { appStateAtom } from "../../state/store";
import { useGetOrbitsQuery as useGetOrbitsQueryGenerated, useGetOrbitsLazyQuery as useGetOrbitsLazyQueryGenerated, } from "../../graphql/generated";
import { updateNodeCache, updateAppStateWithOrbit } from "./utils";
import { decodeFrequency } from "../../state/orbit";
import { extractEdges } from "../../graphql/utils";
export const useGetOrbitsQuery = (opts) => {
    const [prevState, setAppState] = useAtom(appStateAtom);
    const result = useGetOrbitsQueryGenerated({
        ...opts,
        onCompleted: (data) => {
            if (data?.orbits) {
                extractEdges(data.orbits).forEach((orbit) => {
                    const orbitHashes = {
                        id: orbit.id,
                        eH: orbit.eH,
                        sphereHash: orbit.sphereHash,
                        parentEh: orbit?.parentHash,
                    };
                    const orbitDetails = {
                        ...orbitHashes,
                        name: orbit.name,
                        scale: orbit.scale,
                        frequency: decodeFrequency(orbit.frequency),
                        startTime: orbit.metadata.timeframe.startTime,
                        endTime: orbit.metadata.timeframe.endTime,
                        description: orbit.metadata.description,
                    };
                    updateNodeCache(orbitDetails);
                    const updatedState = updateAppStateWithOrbit(prevState, orbitHashes, false);
                    setAppState(updatedState);
                    console.warn("Cache update from useGetOrbits");
                });
            }
            opts?.onCompleted && opts.onCompleted(data);
        },
    });
    return {
        ...result,
        isLoading: result.loading,
        error: result.error,
        refetch: result.refetch,
    };
};
export const useGetOrbitsLazyQuery = (opts) => {
    const [prevState, setAppState] = useAtom(appStateAtom);
    const [getOrbits, result] = useGetOrbitsLazyQueryGenerated({
        ...opts,
        onCompleted: (data) => {
            if (data?.orbits) {
                extractEdges(data.orbits).forEach((orbit) => {
                    const orbitHashes = {
                        id: orbit.id,
                        eH: orbit.eH,
                        sphereHash: orbit.sphereHash,
                        parentEh: orbit?.parentHash,
                    };
                    const orbitDetails = {
                        ...orbitHashes,
                        name: orbit.name,
                        scale: orbit.scale,
                        frequency: decodeFrequency(orbit.frequency),
                        startTime: orbit.metadata.timeframe.startTime,
                        endTime: orbit.metadata.timeframe.endTime,
                        description: orbit.metadata.description,
                    };
                    updateNodeCache(orbitDetails);
                    const updatedState = updateAppStateWithOrbit(prevState, orbitHashes, false);
                    setAppState(updatedState);
                });
            }
            opts?.onCompleted && opts.onCompleted(data);
        },
    });
    const wrappedGetOrbits = (options) => {
        return getOrbits({
            ...options,
            onCompleted: (data) => {
                if (data?.orbits) {
                    extractEdges(data.orbits).forEach((orbit) => {
                        const orbitHashes = {
                            id: orbit.id,
                            eH: orbit.eH,
                            sphereHash: orbit.sphereHash,
                            parentEh: orbit?.parentHash,
                        };
                        const orbitDetails = {
                            ...orbitHashes,
                            name: orbit.name,
                            scale: orbit.scale,
                            frequency: decodeFrequency(orbit.frequency),
                            startTime: orbit.metadata.timeframe.startTime,
                            endTime: orbit.metadata.timeframe.endTime,
                            description: orbit.metadata.description,
                        };
                        updateNodeCache(orbitDetails);
                        const updatedState = updateAppStateWithOrbit(prevState, orbitHashes, false);
                        setAppState(updatedState);
                    });
                }
                options?.onCompleted && options.onCompleted(data);
            },
        });
    };
    return [
        wrappedGetOrbits,
        {
            ...result,
            isLoading: result.loading,
            error: result.error,
            refetch: result.refetch,
        },
    ];
};
//# sourceMappingURL=useGetOrbitsQuery.js.map