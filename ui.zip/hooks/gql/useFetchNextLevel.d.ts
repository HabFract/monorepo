import { OrbitHierarchyQueryParams } from "../../graphql/generated";
declare const usePrefetchNextLevel: (queryParams: OrbitHierarchyQueryParams, client: any, bypass?: boolean) => Promise<void>;
export default usePrefetchNextLevel;
//# sourceMappingURL=useFetchNextLevel.d.ts.map