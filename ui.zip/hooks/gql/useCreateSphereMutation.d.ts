export declare const useCreateSphereMutation: () => import("@apollo/client").MutationTuple<import("../../graphql/generated").CreateSphereMutation, import("../../graphql/generated").Exact<{
    variables: import("../../graphql/generated").SphereCreateParams;
}>, import("@apollo/client").DefaultContext, import("@apollo/client").ApolloCache<any>>;
//# sourceMappingURL=useCreateSphereMutation.d.ts.map