import { nodeCache, store, } from "../../state";
import { currentSphereHashesAtom, } from "../../state/sphere";
import { client } from "../../graphql/client";
export const invalidateOrbitHierarchyCache = async (sphereHashB64) => {
    return client.then((client) => {
        const normalizedId = client.cache.identify({
            __typename: "Query",
            id: "ROOT_QUERY",
            fieldName: "getOrbitHierarchy",
            args: {
                params: {
                    levelQuery: {
                        sphereHashB64,
                        orbitLevel: 0,
                    },
                },
            },
        });
        console.log("Evicting cache with id :>> ", normalizedId);
        client.cache.evict({ id: normalizedId });
        client.cache.gc();
    });
};
export const updateNodeCache = (orbitDetails, oldOrbitEh) => {
    const sphere = store.get(currentSphereHashesAtom);
    const existingNodes = store.get(nodeCache.item(sphere.actionHash)) || {};
    const newSphereOrbitNodeDetails = {
        ...existingNodes,
        [orbitDetails.eH]: orbitDetails,
    };
    if (oldOrbitEh && oldOrbitEh !== orbitDetails.eH) {
        delete newSphereOrbitNodeDetails[oldOrbitEh];
    }
    store.set(nodeCache.set, sphere.actionHash, newSphereOrbitNodeDetails);
};
export const updateAppStateWithOrbit = (prevState, orbitDetails, isNewOrbit, oldOrbitId) => {
    const updatedState = { ...prevState };
    updatedState.orbitNodes = {
        ...prevState.orbitNodes,
        byHash: {
            ...prevState.orbitNodes.byHash,
            [orbitDetails.id]: orbitDetails,
        },
    };
    if (oldOrbitId && oldOrbitId !== orbitDetails.id) {
        delete updatedState.orbitNodes.byHash[oldOrbitId];
    }
    if (!orbitDetails.parentEh) {
        const sphereHash = orbitDetails.sphereHash;
        const sphereId = Object.entries(updatedState.spheres.byHash).find(([_id, sphere]) => sphere?.details?.entryHash === sphereHash)?.[0];
        if (sphereId &&
            updatedState.spheres.byHash[sphereId]?.hierarchyRootOrbitEntryHashes) {
            if (isNewOrbit) {
                updatedState.spheres.byHash[sphereId].hierarchyRootOrbitEntryHashes.push(orbitDetails.eH);
            }
            else if (oldOrbitId) {
                const index = updatedState.spheres.byHash[sphereId].hierarchyRootOrbitEntryHashes.indexOf(oldOrbitId);
                if (index !== -1) {
                    updatedState.spheres.byHash[sphereId].hierarchyRootOrbitEntryHashes[index] = orbitDetails.eH;
                }
            }
            const newHierarchy = {
                rootNode: orbitDetails.eH,
                json: "",
                bounds: {
                    minBreadth: 0,
                    maxBreadth: 0,
                    minDepth: 0,
                    maxDepth: 0,
                },
                indices: { x: 0, y: 0 },
                currentNode: orbitDetails.eH,
                nodeHashes: [orbitDetails.eH],
                leafNodeHashes: [],
            };
            updatedState.hierarchies.byRootOrbitEntryHash = {
                [orbitDetails.eH]: newHierarchy,
            };
            if (oldOrbitId && oldOrbitId !== orbitDetails.eH) {
                delete updatedState.hierarchies.byRootOrbitEntryHash[oldOrbitId];
            }
        }
    }
    else {
        delete updatedState.hierarchies.byRootOrbitEntryHash[orbitDetails.eH];
    }
    return updatedState;
};
//# sourceMappingURL=utils.js.map