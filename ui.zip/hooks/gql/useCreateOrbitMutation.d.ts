export declare const useCreateOrbitMutation: (opts: any) => import("@apollo/client").MutationTuple<import("../../graphql/generated").CreateOrbitMutation, import("../../graphql/generated").Exact<{
    variables: import("../../graphql/generated").OrbitCreateParams;
}>, import("@apollo/client").DefaultContext, import("@apollo/client").ApolloCache<any>>;
//# sourceMappingURL=useCreateOrbitMutation.d.ts.map