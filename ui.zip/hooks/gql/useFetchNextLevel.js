import { GetOrbitHierarchyDocument, } from "../../graphql/generated";
const usePrefetchNextLevel = async (queryParams, client, bypass = false) => {
    const gql = (await client);
    try {
        await gql.query({
            query: GetOrbitHierarchyDocument,
            variables: { params: { ...queryParams } },
        });
    }
    catch (error) {
        console.error("Error pre-fetching next level:", error);
    }
};
export default usePrefetchNextLevel;
//# sourceMappingURL=useFetchNextLevel.js.map