export declare const useUpdateOrbitMutation: (opts: any) => import("@apollo/client").MutationTuple<import("../../graphql/generated").UpdateOrbitMutation, import("../../graphql/generated").Exact<{
    orbitFields: import("../../graphql/generated").OrbitUpdateParams;
}>, import("@apollo/client").DefaultContext, import("@apollo/client").ApolloCache<any>>;
//# sourceMappingURL=useUpdateOrbitMutation.d.ts.map