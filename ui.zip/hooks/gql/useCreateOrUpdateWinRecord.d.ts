export declare const useCreateOrUpdateWinRecord: (opts?: any) => (opts: any) => void;
//# sourceMappingURL=useCreateOrUpdateWinRecord.d.ts.map