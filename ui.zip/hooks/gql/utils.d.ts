import { AppState } from "../../state/types/store";
import { OrbitHashes, OrbitNodeDetails } from "../../state";
import { EntryHashB64 } from "@state/types";
export declare const invalidateOrbitHierarchyCache: (sphereHashB64: string) => Promise<void>;
export declare const updateNodeCache: (orbitDetails: OrbitNodeDetails, oldOrbitEh?: EntryHashB64) => void;
export declare const updateAppStateWithOrbit: (prevState: AppState, orbitDetails: OrbitHashes, isNewOrbit: boolean, oldOrbitId?: string) => AppState;
//# sourceMappingURL=utils.d.ts.map