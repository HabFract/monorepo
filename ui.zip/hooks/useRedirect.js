import { useEffect } from "react";
import { useStateTransition } from "./useStateTransition";
import { useAtomValue } from "jotai";
import { currentSphereHasCachedNodesAtom, currentSphereHashesAtom, } from "../state/sphere";
export const useRedirect = (bypass) => {
    const [state, transition] = useStateTransition();
    const sphere = useAtomValue(currentSphereHashesAtom);
    const sphereHasCachedOrbits = useAtomValue(currentSphereHasCachedNodesAtom);
    useEffect(() => {
        if (bypass || sphereHasCachedOrbits)
            return;
        if (!sphere?.actionHash || !sphereHasCachedOrbits) {
            console.log('sphereHasCachedOrbits :>> ', sphereHasCachedOrbits);
            transition('PreloadAndCache');
        }
    }, [bypass, sphere, sphereHasCachedOrbits, transition]);
};
//# sourceMappingURL=useRedirect.js.map