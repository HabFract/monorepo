import { RefObject } from "react";
export declare function useOnboardingScroll(state: string, progressBarRef: RefObject<HTMLDivElement>, mainPageRef: RefObject<HTMLDivElement>, returningUser?: boolean): void;
//# sourceMappingURL=useOnboardingScroll.d.ts.map