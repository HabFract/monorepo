import { useContext, useState } from "react";
import { StateMachineContext } from "../contexts/state-machine";
export function useStateTransition() {
    const stateMachine = useContext(StateMachineContext);
    if (!stateMachine) {
        throw new Error("useStateTransition must be used within a StateMachineProvider");
    }
    const [state, setState] = useState(stateMachine.state.currentState);
    const transition = (newState, params) => {
        stateMachine.to(newState, params);
        setState(newState);
    };
    return [
        state,
        transition,
        stateMachine.state.params,
        stateMachine.state?.connection?.apolloClient,
    ];
}
//# sourceMappingURL=useStateTransition.js.map