import { useEffect } from "react";
const useSideMenuToggle = (ref, setSideNavExpanded) => {
    useEffect(() => {
        const handleClick = (event) => {
            if (event.target instanceof Node &&
                event.target.isConnected &&
                !ref.current?.contains(event.target)) {
                setSideNavExpanded(false);
            }
            const domNode = event.target;
            const iconBtn = !!domNode.closest(".toggle-expanded-menu");
            const subMenuSelected = domNode
                .closest(".ant-menu-sub")
                ?.classList?.contains("ant-menu-vertical");
            const bottomMenuSelected = !!domNode.closest(".main-actions-menu");
            const plusSelected = !!domNode.closest(".side-nav > .ant-menu-root .ant-menu-item:first-of-type");
            if (!iconBtn && (subMenuSelected || bottomMenuSelected || plusSelected)) {
                removeOtherActiveNavItemStates();
            }
        };
        document.addEventListener("click", handleClick, true);
        return () => {
            document.removeEventListener("click", handleClick, true);
        };
    }, [ref]);
    function removeOtherActiveNavItemStates() {
        [...document.querySelectorAll(".ant-menu-item-selected")]?.forEach((item) => item.classList.remove("ant-menu-item-selected"));
    }
};
export default useSideMenuToggle;
//# sourceMappingURL=useSideMenuToggle.js.map