import { useEffect } from 'react';
import { useGetSphereQuery, useGetOrbitsLazyQuery } from '../graphql/generated';
import { extractEdges } from '../graphql/utils';
import { mapToCacheObject } from '../state/orbit';
import { nodeCache, store } from '../state/jotaiKeyValueStore';
export const useFetchAndCacheSphereOrbits = ({ sphereAh }) => {
    const { loading: loadingSphere, data: dataSphere, error: errorSphere } = useGetSphereQuery({
        variables: { id: sphereAh },
        skip: !sphereAh,
    });
    const sphereEh = dataSphere?.sphere?.eH;
    const [getOrbits, { loading: loadingOrbits, error: errorOrbits, data }] = useGetOrbitsLazyQuery({
        fetchPolicy: 'network-only',
        variables: { sphereEntryHashB64: sphereEh },
    });
    useEffect(() => {
        if (sphereEh && dataSphere) {
            getOrbits();
        }
    }, [dataSphere, loadingSphere, sphereEh]);
    useEffect(() => {
        if (data) {
            let orbits = extractEdges(data.orbits);
            let indexedOrbitData = Object.entries(orbits.map(mapToCacheObject))
                .map(([_idx, value]) => [value.id, value]);
            let indexedSphereData = {};
            const entries = indexedOrbitData.reduce((cacheObject, [_id, entry], idx) => {
                const indexKey = (entry).eH;
                if (idx === 0) {
                    (cacheObject)[sphereAh] = { [indexKey]: entry };
                }
                cacheObject[sphereAh][indexKey] = entry;
                return cacheObject;
            }, indexedSphereData);
            store.set(nodeCache.setMany, Object.entries(entries));
        }
    }, [data, sphereAh]);
    return {
        loading: loadingSphere || loadingOrbits,
        error: errorSphere || errorOrbits,
        data: dataSphere && data ? { sphere: dataSphere.sphere, orbits: extractEdges(data.orbits) } : undefined,
    };
};
//# sourceMappingURL=useFetchAndCacheSphereOrbits.js.map