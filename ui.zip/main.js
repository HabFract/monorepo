import { jsx as _jsx } from "react/jsx-runtime";
import React from 'react';
import ReactDOM from 'react-dom/client';
import BootScreen from './BootScreen';
import 'broadcastchannel-polyfill';
import App from './App';
import { StateMachine } from './state/types/stateMachine';
import { AppTransitions, initialState, routes } from './routes';
import { Provider } from 'jotai';
import { store } from './state/jotaiKeyValueStore';
export const AppMachine = new StateMachine(initialState, AppTransitions);
Object.entries(routes).forEach(([routeName, component]) => {
    AppMachine.on(routeName, async (state) => {
        const ComponentWithProps = React.cloneElement(component, {
            ...state.params,
            key: JSON.stringify(state.params),
        });
        renderComponent(ComponentWithProps);
    });
});
const root = ReactDOM.createRoot(document.getElementById('root'));
export async function renderComponent(component) {
    root.render(_jsx(React.StrictMode, { children: _jsx(BootScreen, { children: _jsx(App, { children: component }) }) }));
}
AppMachine.go();
export const WithCacheStore = (component) => {
    return (_jsx(Provider, { store: store, children: component }));
};
//# sourceMappingURL=main.js.map