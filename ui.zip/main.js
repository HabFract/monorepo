import { jsx as _jsx } from "react/jsx-runtime";
import React from "react";
import ReactDOM from "react-dom/client";
import "broadcastchannel-polyfill";
import App from "./App";
import { StateMachine } from "./state/types/stateMachine";
import { AppTransitions, initialState, routes, } from "./routes";
import { Provider } from "jotai";
import { store } from "./state/store";
import { ToastProvider } from "./contexts/toast";
import { StateMachineContext } from "./contexts/state-machine";
import BootSequence from "./BootSequence";
import { ApolloProvider } from "@apollo/client";
export const AppMachine = new StateMachine(initialState, AppTransitions);
Object.entries(routes).forEach(([routeName, component]) => {
    AppMachine.on(routeName, async (state) => {
        const PageComponentWithProps = React.cloneElement(component, {
            ...state.params,
            key: JSON.stringify(state.params),
        });
        renderPage(PageComponentWithProps, AppMachine.state.connection.apolloClient);
    });
});
const root = ReactDOM.createRoot(document.getElementById("root"));
export const withJotaiStore = (component) => {
    return _jsx(Provider, { store: store, children: component });
};
export async function renderPage(page, client) {
    root.render(_jsx(React.StrictMode, { children: _jsx(ApolloProvider, { client: client, children: _jsx(StateMachineContext.Provider, { value: AppMachine, children: _jsx(ToastProvider, { children: withJotaiStore(_jsx(App, { children: page })) }) }) }) }));
}
const Main = () => {
    return (_jsx(StateMachineContext.Provider, { value: AppMachine, children: _jsx(BootSequence, {}) }));
};
root.render(_jsx(React.StrictMode, { children: _jsx(Main, {}) }));
//# sourceMappingURL=main.js.map