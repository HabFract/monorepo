import { N as an, c as fn } from "./index.es4.js";
import { h as Kn } from "./index.es4.js";
import { t as Xn } from "./index.es.js";
function ln(n, r) {
  return n.parent === r.parent ? 1 : 2;
}
function cn(n) {
  return n.reduce(sn, 0) / n.length;
}
function sn(n, r) {
  return n + r.x;
}
function hn(n) {
  return 1 + n.reduce(on, 0);
}
function on(n, r) {
  return Math.max(n, r.y);
}
function gn(n) {
  for (var r; r = n.children; ) n = r[0];
  return n;
}
function dn(n) {
  for (var r; r = n.children; ) n = r[r.length - 1];
  return n;
}
function En() {
  var n = ln, r = 1, e = 1, i = !1;
  function t(u) {
    var f, h = 0;
    u.eachAfter(function(a) {
      var g = a.children;
      g ? (a.x = cn(g), a.y = hn(g)) : (a.x = f ? h += n(a, f) : 0, a.y = 0, f = a);
    });
    var l = gn(u), s = dn(u), c = l.x - n(l, s) / 2, o = s.x + n(s, l) / 2;
    return u.eachAfter(i ? function(a) {
      a.x = (a.x - u.x) * r, a.y = (u.y - a.y) * e;
    } : function(a) {
      a.x = (a.x - c) / (o - c) * r, a.y = (1 - (u.y ? a.y / u.y : 1)) * e;
    });
  }
  return t.separation = function(u) {
    return arguments.length ? (n = u, t) : n;
  }, t.size = function(u) {
    return arguments.length ? (i = !1, r = +u[0], e = +u[1], t) : i ? null : [r, e];
  }, t.nodeSize = function(u) {
    return arguments.length ? (i = !0, r = +u[0], e = +u[1], t) : i ? [r, e] : null;
  }, t;
}
function L(n) {
  return n == null ? null : Q(n);
}
function Q(n) {
  if (typeof n != "function") throw new Error();
  return n;
}
function A() {
  return 0;
}
function E(n) {
  return function() {
    return n;
  };
}
const pn = 1664525, yn = 1013904223, X = 4294967296;
function P() {
  let n = 1;
  return () => (n = (pn * n + yn) % X) / X;
}
function mn(n) {
  return typeof n == "object" && "length" in n ? n : Array.from(n);
}
function xn(n, r) {
  let e = n.length, i, t;
  for (; e; )
    t = r() * e-- | 0, i = n[e], n[e] = n[t], n[t] = i;
  return n;
}
function Nn(n) {
  return U(n, P());
}
function U(n, r) {
  for (var e = 0, i = (n = xn(Array.from(n), r)).length, t = [], u, f; e < i; )
    u = n[e], f && B(f, u) ? ++e : (f = wn(t = vn(t, u)), e = 0);
  return f;
}
function vn(n, r) {
  var e, i;
  if ($(r, n)) return [r];
  for (e = 0; e < n.length; ++e)
    if (z(r, n[e]) && $(N(n[e], r), n))
      return [n[e], r];
  for (e = 0; e < n.length - 1; ++e)
    for (i = e + 1; i < n.length; ++i)
      if (z(N(n[e], n[i]), r) && z(N(n[e], r), n[i]) && z(N(n[i], r), n[e]) && $(nn(n[e], n[i], r), n))
        return [n[e], n[i], r];
  throw new Error();
}
function z(n, r) {
  var e = n.r - r.r, i = r.x - n.x, t = r.y - n.y;
  return e < 0 || e * e < i * i + t * t;
}
function B(n, r) {
  var e = n.r - r.r + Math.max(n.r, r.r, 1) * 1e-9, i = r.x - n.x, t = r.y - n.y;
  return e > 0 && e * e > i * i + t * t;
}
function $(n, r) {
  for (var e = 0; e < r.length; ++e)
    if (!B(n, r[e]))
      return !1;
  return !0;
}
function wn(n) {
  switch (n.length) {
    case 1:
      return Mn(n[0]);
    case 2:
      return N(n[0], n[1]);
    case 3:
      return nn(n[0], n[1], n[2]);
  }
}
function Mn(n) {
  return {
    x: n.x,
    y: n.y,
    r: n.r
  };
}
function N(n, r) {
  var e = n.x, i = n.y, t = n.r, u = r.x, f = r.y, h = r.r, l = u - e, s = f - i, c = h - t, o = Math.sqrt(l * l + s * s);
  return {
    x: (e + u + l / o * c) / 2,
    y: (i + f + s / o * c) / 2,
    r: (o + t + h) / 2
  };
}
function nn(n, r, e) {
  var i = n.x, t = n.y, u = n.r, f = r.x, h = r.y, l = r.r, s = e.x, c = e.y, o = e.r, a = i - f, g = i - s, d = t - h, m = t - c, p = l - u, y = o - u, w = i * i + t * t - u * u, _ = w - f * f - h * h + l * l, v = w - s * s - c * c + o * o, x = g * d - a * m, M = (d * v - m * _) / (x * 2) - i, R = (m * p - d * y) / x, q = (g * _ - a * v) / (x * 2) - t, k = (a * y - g * p) / x, S = R * R + k * k - 1, I = 2 * (u + M * R + q * k), W = M * M + q * q - u * u, V = -(Math.abs(S) > 1e-6 ? (I + Math.sqrt(I * I - 4 * S * W)) / (2 * S) : W / I);
  return {
    x: i + M + R * V,
    y: t + q + k * V,
    r: V
  };
}
function Y(n, r, e) {
  var i = n.x - r.x, t, u, f = n.y - r.y, h, l, s = i * i + f * f;
  s ? (u = r.r + e.r, u *= u, l = n.r + e.r, l *= l, u > l ? (t = (s + l - u) / (2 * s), h = Math.sqrt(Math.max(0, l / s - t * t)), e.x = n.x - t * i - h * f, e.y = n.y - t * f + h * i) : (t = (s + u - l) / (2 * s), h = Math.sqrt(Math.max(0, u / s - t * t)), e.x = r.x + t * i - h * f, e.y = r.y + t * f + h * i)) : (e.x = r.x + e.r, e.y = r.y);
}
function H(n, r) {
  var e = n.r + r.r - 1e-6, i = r.x - n.x, t = r.y - n.y;
  return e > 0 && e * e > i * i + t * t;
}
function Z(n) {
  var r = n._, e = n.next._, i = r.r + e.r, t = (r.x * e.r + e.x * r.r) / i, u = (r.y * e.r + e.y * r.r) / i;
  return t * t + u * u;
}
function b(n) {
  this._ = n, this.next = null, this.previous = null;
}
function en(n, r) {
  if (!(u = (n = mn(n)).length)) return 0;
  var e, i, t, u, f, h, l, s, c, o, a;
  if (e = n[0], e.x = 0, e.y = 0, !(u > 1)) return e.r;
  if (i = n[1], e.x = -i.r, i.x = e.r, i.y = 0, !(u > 2)) return e.r + i.r;
  Y(i, e, t = n[2]), e = new b(e), i = new b(i), t = new b(t), e.next = t.previous = i, i.next = e.previous = t, t.next = i.previous = e;
  n: for (l = 3; l < u; ++l) {
    Y(e._, i._, t = n[l]), t = new b(t), s = i.next, c = e.previous, o = i._.r, a = e._.r;
    do
      if (o <= a) {
        if (H(s._, t._)) {
          i = s, e.next = i, i.previous = e, --l;
          continue n;
        }
        o += s._.r, s = s.next;
      } else {
        if (H(c._, t._)) {
          e = c, e.next = i, i.previous = e, --l;
          continue n;
        }
        a += c._.r, c = c.previous;
      }
    while (s !== c.next);
    for (t.previous = e, t.next = i, e.next = i.previous = i = t, f = Z(e); (t = t.next) !== i; )
      (h = Z(t)) < f && (e = t, f = h);
    i = e.next;
  }
  for (e = [i._], t = i; (t = t.next) !== i; ) e.push(t._);
  for (t = U(e, r), l = 0; l < u; ++l) e = n[l], e.x -= t.x, e.y -= t.y;
  return t.r;
}
function zn(n) {
  return en(n, P()), n;
}
function _n(n) {
  return Math.sqrt(n.value);
}
function bn() {
  var n = null, r = 1, e = 1, i = A;
  function t(u) {
    const f = P();
    return u.x = r / 2, u.y = e / 2, n ? u.eachBefore(j(n)).eachAfter(C(i, 0.5, f)).eachBefore(F(1)) : u.eachBefore(j(_n)).eachAfter(C(A, 1, f)).eachAfter(C(i, u.r / Math.min(r, e), f)).eachBefore(F(Math.min(r, e) / (2 * u.r))), u;
  }
  return t.radius = function(u) {
    return arguments.length ? (n = L(u), t) : n;
  }, t.size = function(u) {
    return arguments.length ? (r = +u[0], e = +u[1], t) : [r, e];
  }, t.padding = function(u) {
    return arguments.length ? (i = typeof u == "function" ? u : E(+u), t) : i;
  }, t;
}
function j(n) {
  return function(r) {
    r.children || (r.r = Math.max(0, +n(r) || 0));
  };
}
function C(n, r, e) {
  return function(i) {
    if (t = i.children) {
      var t, u, f = t.length, h = n(i) * r || 0, l;
      if (h) for (u = 0; u < f; ++u) t[u].r += h;
      if (l = en(t, e), h) for (u = 0; u < f; ++u) t[u].r -= h;
      i.r = l + h;
    }
  };
}
function F(n) {
  return function(r) {
    var e = r.parent;
    r.r *= n, e && (r.x = e.x + n * r.x, r.y = e.y + n * r.y);
  };
}
function rn(n) {
  n.x0 = Math.round(n.x0), n.y0 = Math.round(n.y0), n.x1 = Math.round(n.x1), n.y1 = Math.round(n.y1);
}
function T(n, r, e, i, t) {
  for (var u = n.children, f, h = -1, l = u.length, s = n.value && (i - r) / n.value; ++h < l; )
    f = u[h], f.y0 = e, f.y1 = t, f.x0 = r, f.x1 = r += f.value * s;
}
function Ln() {
  var n = 1, r = 1, e = 0, i = !1;
  function t(f) {
    var h = f.height + 1;
    return f.x0 = f.y0 = e, f.x1 = n, f.y1 = r / h, f.eachBefore(u(r, h)), i && f.eachBefore(rn), f;
  }
  function u(f, h) {
    return function(l) {
      l.children && T(l, l.x0, f * (l.depth + 1) / h, l.x1, f * (l.depth + 2) / h);
      var s = l.x0, c = l.y0, o = l.x1 - e, a = l.y1 - e;
      o < s && (s = o = (s + o) / 2), a < c && (c = a = (c + a) / 2), l.x0 = s, l.y0 = c, l.x1 = o, l.y1 = a;
    };
  }
  return t.round = function(f) {
    return arguments.length ? (i = !!f, t) : i;
  }, t.size = function(f) {
    return arguments.length ? (n = +f[0], r = +f[1], t) : [n, r];
  }, t.padding = function(f) {
    return arguments.length ? (e = +f, t) : e;
  }, t;
}
var qn = { depth: -1 }, G = {}, D = {};
function kn(n) {
  return n.id;
}
function Rn(n) {
  return n.parentId;
}
function Tn() {
  var n = kn, r = Rn, e;
  function i(t) {
    var u = Array.from(t), f = n, h = r, l, s, c, o, a, g, d, m, p = /* @__PURE__ */ new Map();
    if (e != null) {
      const y = u.map((v, x) => In(e(v, x, t))), w = y.map(J), _ = new Set(y).add("");
      for (const v of w)
        _.has(v) || (_.add(v), y.push(v), w.push(J(v)), u.push(D));
      f = (v, x) => y[x], h = (v, x) => w[x];
    }
    for (c = 0, l = u.length; c < l; ++c)
      s = u[c], g = u[c] = new an(s), (d = f(s, c, t)) != null && (d += "") && (m = g.id = d, p.set(m, p.has(m) ? G : g)), (d = h(s, c, t)) != null && (d += "") && (g.parent = d);
    for (c = 0; c < l; ++c)
      if (g = u[c], d = g.parent) {
        if (a = p.get(d), !a) throw new Error("missing: " + d);
        if (a === G) throw new Error("ambiguous: " + d);
        a.children ? a.children.push(g) : a.children = [g], g.parent = a;
      } else {
        if (o) throw new Error("multiple roots");
        o = g;
      }
    if (!o) throw new Error("no root");
    if (e != null) {
      for (; o.data === D && o.children.length === 1; )
        o = o.children[0], --l;
      for (let y = u.length - 1; y >= 0 && (g = u[y], g.data === D); --y)
        g.data = null;
    }
    if (o.parent = qn, o.eachBefore(function(y) {
      y.depth = y.parent.depth + 1, --l;
    }).eachBefore(fn), o.parent = null, l > 0) throw new Error("cycle");
    return o;
  }
  return i.id = function(t) {
    return arguments.length ? (n = L(t), i) : n;
  }, i.parentId = function(t) {
    return arguments.length ? (r = L(t), i) : r;
  }, i.path = function(t) {
    return arguments.length ? (e = L(t), i) : e;
  }, i;
}
function In(n) {
  n = `${n}`;
  let r = n.length;
  return O(n, r - 1) && !O(n, r - 2) && (n = n.slice(0, -1)), n[0] === "/" ? n : `/${n}`;
}
function J(n) {
  let r = n.length;
  if (r < 2) return "";
  for (; --r > 1 && !O(n, r); ) ;
  return n.slice(0, r);
}
function O(n, r) {
  if (n[r] === "/") {
    let e = 0;
    for (; r > 0 && n[--r] === "\\"; ) ++e;
    if (!(e & 1)) return !0;
  }
  return !1;
}
function K(n, r, e, i, t) {
  for (var u = n.children, f, h = -1, l = u.length, s = n.value && (t - e) / n.value; ++h < l; )
    f = u[h], f.x0 = r, f.x1 = i, f.y0 = e, f.y1 = e += f.value * s;
}
var tn = (1 + Math.sqrt(5)) / 2;
function un(n, r, e, i, t, u) {
  for (var f = [], h = r.children, l, s, c = 0, o = 0, a = h.length, g, d, m = r.value, p, y, w, _, v, x, M; c < a; ) {
    g = t - e, d = u - i;
    do
      p = h[o++].value;
    while (!p && o < a);
    for (y = w = p, x = Math.max(d / g, g / d) / (m * n), M = p * p * x, v = Math.max(w / M, M / y); o < a; ++o) {
      if (p += s = h[o].value, s < y && (y = s), s > w && (w = s), M = p * p * x, _ = Math.max(w / M, M / y), _ > v) {
        p -= s;
        break;
      }
      v = _;
    }
    f.push(l = { value: p, dice: g < d, children: h.slice(c, o) }), l.dice ? T(l, e, i, t, m ? i += d * p / m : u) : K(l, e, i, m ? e += g * p / m : t, u), m -= p, c = o;
  }
  return f;
}
const An = function n(r) {
  function e(i, t, u, f, h) {
    un(r, i, t, u, f, h);
  }
  return e.ratio = function(i) {
    return n((i = +i) > 1 ? i : 1);
  }, e;
}(tn);
function Vn() {
  var n = An, r = !1, e = 1, i = 1, t = [0], u = A, f = A, h = A, l = A, s = A;
  function c(a) {
    return a.x0 = a.y0 = 0, a.x1 = e, a.y1 = i, a.eachBefore(o), t = [0], r && a.eachBefore(rn), a;
  }
  function o(a) {
    var g = t[a.depth], d = a.x0 + g, m = a.y0 + g, p = a.x1 - g, y = a.y1 - g;
    p < d && (d = p = (d + p) / 2), y < m && (m = y = (m + y) / 2), a.x0 = d, a.y0 = m, a.x1 = p, a.y1 = y, a.children && (g = t[a.depth + 1] = u(a) / 2, d += s(a) - g, m += f(a) - g, p -= h(a) - g, y -= l(a) - g, p < d && (d = p = (d + p) / 2), y < m && (m = y = (m + y) / 2), n(a, d, m, p, y));
  }
  return c.round = function(a) {
    return arguments.length ? (r = !!a, c) : r;
  }, c.size = function(a) {
    return arguments.length ? (e = +a[0], i = +a[1], c) : [e, i];
  }, c.tile = function(a) {
    return arguments.length ? (n = Q(a), c) : n;
  }, c.padding = function(a) {
    return arguments.length ? c.paddingInner(a).paddingOuter(a) : c.paddingInner();
  }, c.paddingInner = function(a) {
    return arguments.length ? (u = typeof a == "function" ? a : E(+a), c) : u;
  }, c.paddingOuter = function(a) {
    return arguments.length ? c.paddingTop(a).paddingRight(a).paddingBottom(a).paddingLeft(a) : c.paddingTop();
  }, c.paddingTop = function(a) {
    return arguments.length ? (f = typeof a == "function" ? a : E(+a), c) : f;
  }, c.paddingRight = function(a) {
    return arguments.length ? (h = typeof a == "function" ? a : E(+a), c) : h;
  }, c.paddingBottom = function(a) {
    return arguments.length ? (l = typeof a == "function" ? a : E(+a), c) : l;
  }, c.paddingLeft = function(a) {
    return arguments.length ? (s = typeof a == "function" ? a : E(+a), c) : s;
  }, c;
}
function $n(n, r, e, i, t) {
  var u = n.children, f, h = u.length, l, s = new Array(h + 1);
  for (s[0] = l = f = 0; f < h; ++f)
    s[f + 1] = l += u[f].value;
  c(0, h, n.value, r, e, i, t);
  function c(o, a, g, d, m, p, y) {
    if (o >= a - 1) {
      var w = u[o];
      w.x0 = d, w.y0 = m, w.x1 = p, w.y1 = y;
      return;
    }
    for (var _ = s[o], v = g / 2 + _, x = o + 1, M = a - 1; x < M; ) {
      var R = x + M >>> 1;
      s[R] < v ? x = R + 1 : M = R;
    }
    v - s[x - 1] < s[x] - v && o + 1 < x && --x;
    var q = s[x] - _, k = g - q;
    if (p - d > y - m) {
      var S = g ? (d * k + p * q) / g : p;
      c(o, x, q, d, m, S, y), c(x, a, k, S, m, p, y);
    } else {
      var I = g ? (m * k + y * q) / g : y;
      c(o, x, q, d, m, p, I), c(x, a, k, d, I, p, y);
    }
  }
}
function Cn(n, r, e, i, t) {
  (n.depth & 1 ? K : T)(n, r, e, i, t);
}
const Dn = function n(r) {
  function e(i, t, u, f, h) {
    if ((l = i._squarify) && l.ratio === r)
      for (var l, s, c, o, a = -1, g, d = l.length, m = i.value; ++a < d; ) {
        for (s = l[a], c = s.children, o = s.value = 0, g = c.length; o < g; ++o) s.value += c[o].value;
        s.dice ? T(s, t, u, f, m ? u += (h - u) * s.value / m : h) : K(s, t, u, m ? t += (f - t) * s.value / m : f, h), m -= s.value;
      }
    else
      i._squarify = l = un(r, i, t, u, f, h), l.ratio = r;
  }
  return e.ratio = function(i) {
    return n((i = +i) > 1 ? i : 1);
  }, e;
}(tn);
export {
  an as Node,
  En as cluster,
  Kn as hierarchy,
  bn as pack,
  Nn as packEnclose,
  zn as packSiblings,
  Ln as partition,
  Tn as stratify,
  Xn as tree,
  Vn as treemap,
  $n as treemapBinary,
  T as treemapDice,
  Dn as treemapResquarify,
  K as treemapSlice,
  Cn as treemapSliceDice,
  An as treemapSquarify
};
