const se = { BASE_URL: "/", DEV: !1, MODE: "production", PROD: !0, SSR: !1 };
let sr = 0;
function I(t, e) {
  const n = `atom${++sr}`, s = {
    toString() {
      return (se ? "production" : void 0) !== "production" && this.debugLabel ? n + ":" + this.debugLabel : n;
    }
  };
  return typeof t == "function" ? s.read = t : (s.init = t, s.read = rr, s.write = ir), e && (s.write = e), s;
}
function rr(t) {
  return t(this);
}
function ir(t, e, n) {
  return e(
    this,
    typeof n == "function" ? n(t(this)) : n
  );
}
const rn = (t, e) => t.unstable_is ? t.unstable_is(e) : e === t, Nt = (t) => "init" in t, vt = (t) => !!t.write, at = /* @__PURE__ */ new WeakMap(), Vt = (t) => {
  var e;
  return Pt(t) && !((e = at.get(t)) != null && e[1]);
}, ar = (t, e) => {
  const n = at.get(t);
  if (n)
    n[1] = !0, n[0].forEach((s) => s(e));
  else if ((se ? "production" : void 0) !== "production")
    throw new Error("[Bug] cancelable promise not found");
}, or = (t) => {
  if (at.has(t))
    return;
  const e = [/* @__PURE__ */ new Set(), !1];
  at.set(t, e);
  const n = () => {
    e[1] = !0;
  };
  t.then(n, n), t.onCancel = (s) => {
    e[0].add(s);
  };
}, Pt = (t) => typeof t?.then == "function", an = (t) => "v" in t || "e" in t, qe = (t) => {
  if ("e" in t)
    throw t.e;
  if ((se ? "production" : void 0) !== "production" && !("v" in t))
    throw new Error("[Bug] atom state is not initialized");
  return t.v;
}, Bn = (t, e, n) => {
  n.p.has(t) || (n.p.add(t), e.then(
    () => {
      n.p.delete(t);
    },
    () => {
      n.p.delete(t);
    }
  ));
}, on = (t, e, n, s, r) => {
  var i;
  if ((se ? "production" : void 0) !== "production" && s === e)
    throw new Error("[Bug] atom cannot depend on itself");
  n.d.set(s, r.n), Vt(n.v) && Bn(e, n.v, r), (i = r.m) == null || i.t.add(e), t && ur(t, s, e);
}, ye = () => [/* @__PURE__ */ new Map(), /* @__PURE__ */ new Map(), /* @__PURE__ */ new Set()], kt = (t, e, n) => {
  t[0].has(e) || t[0].set(e, /* @__PURE__ */ new Set()), t[1].set(e, n);
}, ur = (t, e, n) => {
  const s = t[0].get(e);
  s && s.add(n);
}, cr = (t, e) => t[0].get(e), un = (t, e) => {
  t[2].add(e);
}, le = (t) => {
  for (; t[1].size || t[2].size; ) {
    t[0].clear();
    const e = new Set(t[1].values());
    t[1].clear();
    const n = new Set(t[2]);
    t[2].clear(), e.forEach((s) => {
      var r;
      return (r = s.m) == null ? void 0 : r.l.forEach((i) => i());
    }), n.forEach((s) => s());
  }
}, Yn = (t) => {
  let e;
  (se ? "production" : void 0) !== "production" && (e = /* @__PURE__ */ new Set());
  const n = (y, m, d) => {
    const g = "v" in m, b = m.v, S = Vt(m.v) ? m.v : null;
    if (Pt(d)) {
      or(d);
      for (const C of m.d.keys())
        Bn(
          y,
          d,
          t(C, m)
        );
      m.v = d, delete m.e;
    } else
      m.v = d, delete m.e;
    (!g || !Object.is(b, m.v)) && (++m.n, S && ar(S, d));
  }, s = (y, m, d, g) => {
    var b;
    if (!g?.(m) && an(d) && (d.m || Array.from(d.d).every(
      ([k, V]) => (
        // Recursively, read the atom state of the dependency, and
        // check if the atom epoch number is unchanged
        s(y, k, t(k, d), g).n === V
      )
    )))
      return d;
    d.d.clear();
    let S = !0;
    const C = (k) => {
      if (rn(m, k)) {
        const B = t(k, d);
        if (!an(B))
          if (Nt(k))
            n(k, B, k.init);
          else
            throw new Error("no atom init");
        return qe(B);
      }
      const V = s(
        y,
        k,
        t(k, d),
        g
      );
      if (S)
        on(y, m, d, k, V);
      else {
        const B = ye();
        on(B, m, d, k, V), c(B, m, d), le(B);
      }
      return qe(V);
    };
    let M, R;
    const _ = {
      get signal() {
        return M || (M = new AbortController()), M.signal;
      },
      get setSelf() {
        return (se ? "production" : void 0) !== "production" && !vt(m) && console.warn("setSelf function cannot be used with read-only atom"), !R && vt(m) && (R = (...k) => {
          if ((se ? "production" : void 0) !== "production" && S && console.warn("setSelf function cannot be called in sync"), !S)
            return u(m, ...k);
        }), R;
      }
    };
    try {
      const k = m.read(C, _);
      if (n(m, d, k), Pt(k)) {
        (b = k.onCancel) == null || b.call(k, () => M?.abort());
        const V = () => {
          if (d.m) {
            const B = ye();
            c(B, m, d), le(B);
          }
        };
        k.then(V, V);
      }
      return d;
    } catch (k) {
      return delete d.v, d.e = k, ++d.n, d;
    } finally {
      S = !1;
    }
  }, r = (y) => qe(s(void 0, y, t(y))), i = (y, m, d) => {
    var g, b;
    const S = /* @__PURE__ */ new Map();
    for (const C of ((g = d.m) == null ? void 0 : g.t) || [])
      S.set(C, t(C, d));
    for (const C of d.p)
      S.set(
        C,
        t(C, d)
      );
    return (b = cr(y, m)) == null || b.forEach((C) => {
      S.set(C, t(C, d));
    }), S;
  }, a = (y, m, d) => {
    const g = [], b = /* @__PURE__ */ new Set(), S = (R, _) => {
      if (!b.has(R)) {
        b.add(R);
        for (const [k, V] of i(y, R, _))
          R !== k && S(k, V);
        g.push([R, _, _.n]);
      }
    };
    S(m, d);
    const C = /* @__PURE__ */ new Set([m]), M = (R) => b.has(R);
    for (let R = g.length - 1; R >= 0; --R) {
      const [_, k, V] = g[R];
      let B = !1;
      for (const Ze of k.d.keys())
        if (Ze !== _ && C.has(Ze)) {
          B = !0;
          break;
        }
      B && (s(y, _, k, M), c(y, _, k), V !== k.n && (kt(y, _, k), C.add(_))), b.delete(_);
    }
  }, o = (y, m, d, ...g) => {
    const b = (M) => qe(s(y, M, t(M, d))), S = (M, ...R) => {
      const _ = t(M, d);
      let k;
      if (rn(m, M)) {
        if (!Nt(M))
          throw new Error("atom not writable");
        const V = "v" in _, B = _.v, Ze = R[0];
        n(M, _, Ze), c(y, M, _), (!V || !Object.is(B, _.v)) && (kt(y, M, _), a(y, M, _));
      } else
        k = o(y, M, _, ...R);
      return le(y), k;
    };
    return m.write(b, S, ...g);
  }, u = (y, ...m) => {
    const d = ye(), g = o(d, y, t(y), ...m);
    return le(d), g;
  }, c = (y, m, d) => {
    if (d.m && !Vt(d.v)) {
      for (const g of d.d.keys())
        d.m.d.has(g) || (h(y, g, t(g, d)).t.add(m), d.m.d.add(g));
      for (const g of d.m.d || [])
        if (!d.d.has(g)) {
          d.m.d.delete(g);
          const b = p(y, g, t(g, d));
          b?.t.delete(m);
        }
    }
  }, h = (y, m, d) => {
    if (!d.m) {
      s(y, m, d);
      for (const g of d.d.keys())
        h(y, g, t(g, d)).t.add(m);
      if (d.m = {
        l: /* @__PURE__ */ new Set(),
        d: new Set(d.d.keys()),
        t: /* @__PURE__ */ new Set()
      }, (se ? "production" : void 0) !== "production" && e.add(m), vt(m) && m.onMount) {
        const g = d.m, { onMount: b } = m;
        un(y, () => {
          const S = b(
            (...C) => o(y, m, d, ...C)
          );
          S && (g.u = S);
        });
      }
    }
    return d.m;
  }, p = (y, m, d) => {
    if (d.m && !d.m.l.size && !Array.from(d.m.t).some(
      (g) => {
        var b;
        return (b = t(g, d).m) == null ? void 0 : b.d.has(m);
      }
    )) {
      const g = d.m.u;
      g && un(y, g), delete d.m, (se ? "production" : void 0) !== "production" && e.delete(m);
      for (const b of d.d.keys()) {
        const S = p(y, b, t(b, d));
        S?.t.delete(m);
      }
      return;
    }
    return d.m;
  }, N = {
    get: r,
    set: u,
    sub: (y, m) => {
      const d = ye(), g = t(y), b = h(d, y, g);
      le(d);
      const S = b.l;
      return S.add(m), () => {
        S.delete(m);
        const C = ye();
        p(C, y, g), le(C);
      };
    },
    unstable_derive: (y) => Yn(...y(t))
  };
  return (se ? "production" : void 0) !== "production" && Object.assign(N, {
    // store dev methods (these are tentative and subject to change without notice)
    dev4_get_internal_weak_map: () => ({
      get: (m) => {
        const d = t(m);
        if (d.n !== 0)
          return d;
      }
    }),
    dev4_get_mounted_atoms: () => e,
    dev4_restore_atoms: (m) => {
      const d = ye();
      for (const [g, b] of m)
        if (Nt(g)) {
          const S = t(g), C = "v" in S, M = S.v;
          n(g, S, b), c(d, g, S), (!C || !Object.is(M, S.v)) && (kt(d, g, S), a(d, g, S));
        }
      le(d);
    }
  }), N;
}, lr = () => {
  const t = /* @__PURE__ */ new WeakMap();
  return Yn((n) => {
    let s = t.get(n);
    return s || (s = { d: /* @__PURE__ */ new Map(), p: /* @__PURE__ */ new Set(), n: 0 }, t.set(n, s)), s;
  });
};
class pe extends Error {
}
class hr extends pe {
  constructor(e) {
    super(`Invalid DateTime: ${e.toMessage()}`);
  }
}
class dr extends pe {
  constructor(e) {
    super(`Invalid Interval: ${e.toMessage()}`);
  }
}
class fr extends pe {
  constructor(e) {
    super(`Invalid Duration: ${e.toMessage()}`);
  }
}
class Oe extends pe {
}
class Zn extends pe {
  constructor(e) {
    super(`Invalid unit ${e}`);
  }
}
class Z extends pe {
}
class ie extends pe {
  constructor() {
    super("Zone is an abstract class");
  }
}
const f = "numeric", ne = "short", j = "long", ot = {
  year: f,
  month: f,
  day: f
}, qn = {
  year: f,
  month: ne,
  day: f
}, mr = {
  year: f,
  month: ne,
  day: f,
  weekday: ne
}, zn = {
  year: f,
  month: j,
  day: f
}, jn = {
  year: f,
  month: j,
  day: f,
  weekday: j
}, Gn = {
  hour: f,
  minute: f
}, Jn = {
  hour: f,
  minute: f,
  second: f
}, Qn = {
  hour: f,
  minute: f,
  second: f,
  timeZoneName: ne
}, Xn = {
  hour: f,
  minute: f,
  second: f,
  timeZoneName: j
}, Kn = {
  hour: f,
  minute: f,
  hourCycle: "h23"
}, es = {
  hour: f,
  minute: f,
  second: f,
  hourCycle: "h23"
}, ts = {
  hour: f,
  minute: f,
  second: f,
  hourCycle: "h23",
  timeZoneName: ne
}, ns = {
  hour: f,
  minute: f,
  second: f,
  hourCycle: "h23",
  timeZoneName: j
}, ss = {
  year: f,
  month: f,
  day: f,
  hour: f,
  minute: f
}, rs = {
  year: f,
  month: f,
  day: f,
  hour: f,
  minute: f,
  second: f
}, is = {
  year: f,
  month: ne,
  day: f,
  hour: f,
  minute: f
}, as = {
  year: f,
  month: ne,
  day: f,
  hour: f,
  minute: f,
  second: f
}, pr = {
  year: f,
  month: ne,
  day: f,
  weekday: ne,
  hour: f,
  minute: f
}, os = {
  year: f,
  month: j,
  day: f,
  hour: f,
  minute: f,
  timeZoneName: ne
}, us = {
  year: f,
  month: j,
  day: f,
  hour: f,
  minute: f,
  second: f,
  timeZoneName: ne
}, cs = {
  year: f,
  month: j,
  day: f,
  weekday: j,
  hour: f,
  minute: f,
  timeZoneName: j
}, ls = {
  year: f,
  month: j,
  day: f,
  weekday: j,
  hour: f,
  minute: f,
  second: f,
  timeZoneName: j
};
class $e {
  /**
   * The type of zone
   * @abstract
   * @type {string}
   */
  get type() {
    throw new ie();
  }
  /**
   * The name of this zone.
   * @abstract
   * @type {string}
   */
  get name() {
    throw new ie();
  }
  /**
   * The IANA name of this zone.
   * Defaults to `name` if not overwritten by a subclass.
   * @abstract
   * @type {string}
   */
  get ianaName() {
    return this.name;
  }
  /**
   * Returns whether the offset is known to be fixed for the whole year.
   * @abstract
   * @type {boolean}
   */
  get isUniversal() {
    throw new ie();
  }
  /**
   * Returns the offset's common name (such as EST) at the specified timestamp
   * @abstract
   * @param {number} ts - Epoch milliseconds for which to get the name
   * @param {Object} opts - Options to affect the format
   * @param {string} opts.format - What style of offset to return. Accepts 'long' or 'short'.
   * @param {string} opts.locale - What locale to return the offset name in.
   * @return {string}
   */
  offsetName(e, n) {
    throw new ie();
  }
  /**
   * Returns the offset's value as a string
   * @abstract
   * @param {number} ts - Epoch milliseconds for which to get the offset
   * @param {string} format - What style of offset to return.
   *                          Accepts 'narrow', 'short', or 'techie'. Returning '+6', '+06:00', or '+0600' respectively
   * @return {string}
   */
  formatOffset(e, n) {
    throw new ie();
  }
  /**
   * Return the offset in minutes for this zone at the specified timestamp.
   * @abstract
   * @param {number} ts - Epoch milliseconds for which to compute the offset
   * @return {number}
   */
  offset(e) {
    throw new ie();
  }
  /**
   * Return whether this Zone is equal to another zone
   * @abstract
   * @param {Zone} otherZone - the zone to compare
   * @return {boolean}
   */
  equals(e) {
    throw new ie();
  }
  /**
   * Return whether this Zone is valid.
   * @abstract
   * @type {boolean}
   */
  get isValid() {
    throw new ie();
  }
}
let It = null;
class pt extends $e {
  /**
   * Get a singleton instance of the local zone
   * @return {SystemZone}
   */
  static get instance() {
    return It === null && (It = new pt()), It;
  }
  /** @override **/
  get type() {
    return "system";
  }
  /** @override **/
  get name() {
    return new Intl.DateTimeFormat().resolvedOptions().timeZone;
  }
  /** @override **/
  get isUniversal() {
    return !1;
  }
  /** @override **/
  offsetName(e, { format: n, locale: s }) {
    return Ts(e, n, s);
  }
  /** @override **/
  formatOffset(e, n) {
    return Ve(this.offset(e), n);
  }
  /** @override **/
  offset(e) {
    return -new Date(e).getTimezoneOffset();
  }
  /** @override **/
  equals(e) {
    return e.type === "system";
  }
  /** @override **/
  get isValid() {
    return !0;
  }
}
let et = {};
function yr(t) {
  return et[t] || (et[t] = new Intl.DateTimeFormat("en-US", {
    hour12: !1,
    timeZone: t,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    era: "short"
  })), et[t];
}
const Er = {
  year: 0,
  month: 1,
  day: 2,
  era: 3,
  hour: 4,
  minute: 5,
  second: 6
};
function gr(t, e) {
  const n = t.format(e).replace(/\u200E/g, ""), s = /(\d+)\/(\d+)\/(\d+) (AD|BC),? (\d+):(\d+):(\d+)/.exec(n), [, r, i, a, o, u, c, h] = s;
  return [a, r, i, o, u, c, h];
}
function Tr(t, e) {
  const n = t.formatToParts(e), s = [];
  for (let r = 0; r < n.length; r++) {
    const { type: i, value: a } = n[r], o = Er[i];
    i === "era" ? s[o] = a : O(o) || (s[o] = parseInt(a, 10));
  }
  return s;
}
let ze = {};
class re extends $e {
  /**
   * @param {string} name - Zone name
   * @return {IANAZone}
   */
  static create(e) {
    return ze[e] || (ze[e] = new re(e)), ze[e];
  }
  /**
   * Reset local caches. Should only be necessary in testing scenarios.
   * @return {void}
   */
  static resetCache() {
    ze = {}, et = {};
  }
  /**
   * Returns whether the provided string is a valid specifier. This only checks the string's format, not that the specifier identifies a known zone; see isValidZone for that.
   * @param {string} s - The string to check validity on
   * @example IANAZone.isValidSpecifier("America/New_York") //=> true
   * @example IANAZone.isValidSpecifier("Sport~~blorp") //=> false
   * @deprecated For backward compatibility, this forwards to isValidZone, better use `isValidZone()` directly instead.
   * @return {boolean}
   */
  static isValidSpecifier(e) {
    return this.isValidZone(e);
  }
  /**
   * Returns whether the provided string identifies a real zone
   * @param {string} zone - The string to check
   * @example IANAZone.isValidZone("America/New_York") //=> true
   * @example IANAZone.isValidZone("Fantasia/Castle") //=> false
   * @example IANAZone.isValidZone("Sport~~blorp") //=> false
   * @return {boolean}
   */
  static isValidZone(e) {
    if (!e)
      return !1;
    try {
      return new Intl.DateTimeFormat("en-US", { timeZone: e }).format(), !0;
    } catch {
      return !1;
    }
  }
  constructor(e) {
    super(), this.zoneName = e, this.valid = re.isValidZone(e);
  }
  /**
   * The type of zone. `iana` for all instances of `IANAZone`.
   * @override
   * @type {string}
   */
  get type() {
    return "iana";
  }
  /**
   * The name of this zone (i.e. the IANA zone name).
   * @override
   * @type {string}
   */
  get name() {
    return this.zoneName;
  }
  /**
   * Returns whether the offset is known to be fixed for the whole year:
   * Always returns false for all IANA zones.
   * @override
   * @type {boolean}
   */
  get isUniversal() {
    return !1;
  }
  /**
   * Returns the offset's common name (such as EST) at the specified timestamp
   * @override
   * @param {number} ts - Epoch milliseconds for which to get the name
   * @param {Object} opts - Options to affect the format
   * @param {string} opts.format - What style of offset to return. Accepts 'long' or 'short'.
   * @param {string} opts.locale - What locale to return the offset name in.
   * @return {string}
   */
  offsetName(e, { format: n, locale: s }) {
    return Ts(e, n, s, this.name);
  }
  /**
   * Returns the offset's value as a string
   * @override
   * @param {number} ts - Epoch milliseconds for which to get the offset
   * @param {string} format - What style of offset to return.
   *                          Accepts 'narrow', 'short', or 'techie'. Returning '+6', '+06:00', or '+0600' respectively
   * @return {string}
   */
  formatOffset(e, n) {
    return Ve(this.offset(e), n);
  }
  /**
   * Return the offset in minutes for this zone at the specified timestamp.
   * @override
   * @param {number} ts - Epoch milliseconds for which to compute the offset
   * @return {number}
   */
  offset(e) {
    const n = new Date(e);
    if (isNaN(n)) return NaN;
    const s = yr(this.name);
    let [r, i, a, o, u, c, h] = s.formatToParts ? Tr(s, n) : gr(s, n);
    o === "BC" && (r = -Math.abs(r) + 1);
    const v = Et({
      year: r,
      month: i,
      day: a,
      hour: u === 24 ? 0 : u,
      minute: c,
      second: h,
      millisecond: 0
    });
    let E = +n;
    const N = E % 1e3;
    return E -= N >= 0 ? N : 1e3 + N, (v - E) / (60 * 1e3);
  }
  /**
   * Return whether this Zone is equal to another zone
   * @override
   * @param {Zone} otherZone - the zone to compare
   * @return {boolean}
   */
  equals(e) {
    return e.type === "iana" && e.name === this.name;
  }
  /**
   * Return whether this Zone is valid.
   * @override
   * @type {boolean}
   */
  get isValid() {
    return this.valid;
  }
}
let cn = {};
function wr(t, e = {}) {
  const n = JSON.stringify([t, e]);
  let s = cn[n];
  return s || (s = new Intl.ListFormat(t, e), cn[n] = s), s;
}
let Ut = {};
function $t(t, e = {}) {
  const n = JSON.stringify([t, e]);
  let s = Ut[n];
  return s || (s = new Intl.DateTimeFormat(t, e), Ut[n] = s), s;
}
let Wt = {};
function Or(t, e = {}) {
  const n = JSON.stringify([t, e]);
  let s = Wt[n];
  return s || (s = new Intl.NumberFormat(t, e), Wt[n] = s), s;
}
let Ht = {};
function Nr(t, e = {}) {
  const { base: n, ...s } = e, r = JSON.stringify([t, s]);
  let i = Ht[r];
  return i || (i = new Intl.RelativeTimeFormat(t, e), Ht[r] = i), i;
}
let Fe = null;
function vr() {
  return Fe || (Fe = new Intl.DateTimeFormat().resolvedOptions().locale, Fe);
}
let ln = {};
function kr(t) {
  let e = ln[t];
  if (!e) {
    const n = new Intl.Locale(t);
    e = "getWeekInfo" in n ? n.getWeekInfo() : n.weekInfo, ln[t] = e;
  }
  return e;
}
function Ir(t) {
  const e = t.indexOf("-x-");
  e !== -1 && (t = t.substring(0, e));
  const n = t.indexOf("-u-");
  if (n === -1)
    return [t];
  {
    let s, r;
    try {
      s = $t(t).resolvedOptions(), r = t;
    } catch {
      const u = t.substring(0, n);
      s = $t(u).resolvedOptions(), r = u;
    }
    const { numberingSystem: i, calendar: a } = s;
    return [r, i, a];
  }
}
function Sr(t, e, n) {
  return (n || e) && (t.includes("-u-") || (t += "-u"), n && (t += `-ca-${n}`), e && (t += `-nu-${e}`)), t;
}
function br(t) {
  const e = [];
  for (let n = 1; n <= 12; n++) {
    const s = w.utc(2009, n, 1);
    e.push(t(s));
  }
  return e;
}
function Dr(t) {
  const e = [];
  for (let n = 1; n <= 7; n++) {
    const s = w.utc(2016, 11, 13 + n);
    e.push(t(s));
  }
  return e;
}
function je(t, e, n, s) {
  const r = t.listingMode();
  return r === "error" ? null : r === "en" ? n(e) : s(e);
}
function xr(t) {
  return t.numberingSystem && t.numberingSystem !== "latn" ? !1 : t.numberingSystem === "latn" || !t.locale || t.locale.startsWith("en") || new Intl.DateTimeFormat(t.intl).resolvedOptions().numberingSystem === "latn";
}
class Ar {
  constructor(e, n, s) {
    this.padTo = s.padTo || 0, this.floor = s.floor || !1;
    const { padTo: r, floor: i, ...a } = s;
    if (!n || Object.keys(a).length > 0) {
      const o = { useGrouping: !1, ...s };
      s.padTo > 0 && (o.minimumIntegerDigits = s.padTo), this.inf = Or(e, o);
    }
  }
  format(e) {
    if (this.inf) {
      const n = this.floor ? Math.floor(e) : e;
      return this.inf.format(n);
    } else {
      const n = this.floor ? Math.floor(e) : Xt(e, 3);
      return U(n, this.padTo);
    }
  }
}
class Cr {
  constructor(e, n, s) {
    this.opts = s, this.originalZone = void 0;
    let r;
    if (this.opts.timeZone)
      this.dt = e;
    else if (e.zone.type === "fixed") {
      const a = -1 * (e.offset / 60), o = a >= 0 ? `Etc/GMT+${a}` : `Etc/GMT${a}`;
      e.offset !== 0 && re.create(o).valid ? (r = o, this.dt = e) : (r = "UTC", this.dt = e.offset === 0 ? e : e.setZone("UTC").plus({ minutes: e.offset }), this.originalZone = e.zone);
    } else e.zone.type === "system" ? this.dt = e : e.zone.type === "iana" ? (this.dt = e, r = e.zone.name) : (r = "UTC", this.dt = e.setZone("UTC").plus({ minutes: e.offset }), this.originalZone = e.zone);
    const i = { ...this.opts };
    i.timeZone = i.timeZone || r, this.dtf = $t(n, i);
  }
  format() {
    return this.originalZone ? this.formatToParts().map(({ value: e }) => e).join("") : this.dtf.format(this.dt.toJSDate());
  }
  formatToParts() {
    const e = this.dtf.formatToParts(this.dt.toJSDate());
    return this.originalZone ? e.map((n) => {
      if (n.type === "timeZoneName") {
        const s = this.originalZone.offsetName(this.dt.ts, {
          locale: this.dt.locale,
          format: this.opts.timeZoneName
        });
        return {
          ...n,
          value: s
        };
      } else
        return n;
    }) : e;
  }
  resolvedOptions() {
    return this.dtf.resolvedOptions();
  }
}
class Mr {
  constructor(e, n, s) {
    this.opts = { style: "long", ...s }, !n && Es() && (this.rtf = Nr(e, s));
  }
  format(e, n) {
    return this.rtf ? this.rtf.format(e, n) : ti(n, e, this.opts.numeric, this.opts.style !== "long");
  }
  formatToParts(e, n) {
    return this.rtf ? this.rtf.formatToParts(e, n) : [];
  }
}
const _r = {
  firstDay: 1,
  minimalDays: 4,
  weekend: [6, 7]
};
class A {
  static fromOpts(e) {
    return A.create(
      e.locale,
      e.numberingSystem,
      e.outputCalendar,
      e.weekSettings,
      e.defaultToEN
    );
  }
  static create(e, n, s, r, i = !1) {
    const a = e || L.defaultLocale, o = a || (i ? "en-US" : vr()), u = n || L.defaultNumberingSystem, c = s || L.defaultOutputCalendar, h = Bt(r) || L.defaultWeekSettings;
    return new A(o, u, c, h, a);
  }
  static resetCache() {
    Fe = null, Ut = {}, Wt = {}, Ht = {};
  }
  static fromObject({ locale: e, numberingSystem: n, outputCalendar: s, weekSettings: r } = {}) {
    return A.create(e, n, s, r);
  }
  constructor(e, n, s, r, i) {
    const [a, o, u] = Ir(e);
    this.locale = a, this.numberingSystem = n || o || null, this.outputCalendar = s || u || null, this.weekSettings = r, this.intl = Sr(this.locale, this.numberingSystem, this.outputCalendar), this.weekdaysCache = { format: {}, standalone: {} }, this.monthsCache = { format: {}, standalone: {} }, this.meridiemCache = null, this.eraCache = {}, this.specifiedLocale = i, this.fastNumbersCached = null;
  }
  get fastNumbers() {
    return this.fastNumbersCached == null && (this.fastNumbersCached = xr(this)), this.fastNumbersCached;
  }
  listingMode() {
    const e = this.isEnglish(), n = (this.numberingSystem === null || this.numberingSystem === "latn") && (this.outputCalendar === null || this.outputCalendar === "gregory");
    return e && n ? "en" : "intl";
  }
  clone(e) {
    return !e || Object.getOwnPropertyNames(e).length === 0 ? this : A.create(
      e.locale || this.specifiedLocale,
      e.numberingSystem || this.numberingSystem,
      e.outputCalendar || this.outputCalendar,
      Bt(e.weekSettings) || this.weekSettings,
      e.defaultToEN || !1
    );
  }
  redefaultToEN(e = {}) {
    return this.clone({ ...e, defaultToEN: !0 });
  }
  redefaultToSystem(e = {}) {
    return this.clone({ ...e, defaultToEN: !1 });
  }
  months(e, n = !1) {
    return je(this, e, Ns, () => {
      const s = n ? { month: e, day: "numeric" } : { month: e }, r = n ? "format" : "standalone";
      return this.monthsCache[r][e] || (this.monthsCache[r][e] = br((i) => this.extract(i, s, "month"))), this.monthsCache[r][e];
    });
  }
  weekdays(e, n = !1) {
    return je(this, e, Is, () => {
      const s = n ? { weekday: e, year: "numeric", month: "long", day: "numeric" } : { weekday: e }, r = n ? "format" : "standalone";
      return this.weekdaysCache[r][e] || (this.weekdaysCache[r][e] = Dr(
        (i) => this.extract(i, s, "weekday")
      )), this.weekdaysCache[r][e];
    });
  }
  meridiems() {
    return je(
      this,
      void 0,
      () => Ss,
      () => {
        if (!this.meridiemCache) {
          const e = { hour: "numeric", hourCycle: "h12" };
          this.meridiemCache = [w.utc(2016, 11, 13, 9), w.utc(2016, 11, 13, 19)].map(
            (n) => this.extract(n, e, "dayperiod")
          );
        }
        return this.meridiemCache;
      }
    );
  }
  eras(e) {
    return je(this, e, bs, () => {
      const n = { era: e };
      return this.eraCache[e] || (this.eraCache[e] = [w.utc(-40, 1, 1), w.utc(2017, 1, 1)].map(
        (s) => this.extract(s, n, "era")
      )), this.eraCache[e];
    });
  }
  extract(e, n, s) {
    const r = this.dtFormatter(e, n), i = r.formatToParts(), a = i.find((o) => o.type.toLowerCase() === s);
    return a ? a.value : null;
  }
  numberFormatter(e = {}) {
    return new Ar(this.intl, e.forceSimple || this.fastNumbers, e);
  }
  dtFormatter(e, n = {}) {
    return new Cr(e, this.intl, n);
  }
  relFormatter(e = {}) {
    return new Mr(this.intl, this.isEnglish(), e);
  }
  listFormatter(e = {}) {
    return wr(this.intl, e);
  }
  isEnglish() {
    return this.locale === "en" || this.locale.toLowerCase() === "en-us" || new Intl.DateTimeFormat(this.intl).resolvedOptions().locale.startsWith("en-us");
  }
  getWeekSettings() {
    return this.weekSettings ? this.weekSettings : gs() ? kr(this.locale) : _r;
  }
  getStartOfWeek() {
    return this.getWeekSettings().firstDay;
  }
  getMinDaysInFirstWeek() {
    return this.getWeekSettings().minimalDays;
  }
  getWeekendDays() {
    return this.getWeekSettings().weekend;
  }
  equals(e) {
    return this.locale === e.locale && this.numberingSystem === e.numberingSystem && this.outputCalendar === e.outputCalendar;
  }
  toString() {
    return `Locale(${this.locale}, ${this.numberingSystem}, ${this.outputCalendar})`;
  }
}
let St = null;
class z extends $e {
  /**
   * Get a singleton instance of UTC
   * @return {FixedOffsetZone}
   */
  static get utcInstance() {
    return St === null && (St = new z(0)), St;
  }
  /**
   * Get an instance with a specified offset
   * @param {number} offset - The offset in minutes
   * @return {FixedOffsetZone}
   */
  static instance(e) {
    return e === 0 ? z.utcInstance : new z(e);
  }
  /**
   * Get an instance of FixedOffsetZone from a UTC offset string, like "UTC+6"
   * @param {string} s - The offset string to parse
   * @example FixedOffsetZone.parseSpecifier("UTC+6")
   * @example FixedOffsetZone.parseSpecifier("UTC+06")
   * @example FixedOffsetZone.parseSpecifier("UTC-6:00")
   * @return {FixedOffsetZone}
   */
  static parseSpecifier(e) {
    if (e) {
      const n = e.match(/^utc(?:([+-]\d{1,2})(?::(\d{2}))?)?$/i);
      if (n)
        return new z(gt(n[1], n[2]));
    }
    return null;
  }
  constructor(e) {
    super(), this.fixed = e;
  }
  /**
   * The type of zone. `fixed` for all instances of `FixedOffsetZone`.
   * @override
   * @type {string}
   */
  get type() {
    return "fixed";
  }
  /**
   * The name of this zone.
   * All fixed zones' names always start with "UTC" (plus optional offset)
   * @override
   * @type {string}
   */
  get name() {
    return this.fixed === 0 ? "UTC" : `UTC${Ve(this.fixed, "narrow")}`;
  }
  /**
   * The IANA name of this zone, i.e. `Etc/UTC` or `Etc/GMT+/-nn`
   *
   * @override
   * @type {string}
   */
  get ianaName() {
    return this.fixed === 0 ? "Etc/UTC" : `Etc/GMT${Ve(-this.fixed, "narrow")}`;
  }
  /**
   * Returns the offset's common name at the specified timestamp.
   *
   * For fixed offset zones this equals to the zone name.
   * @override
   */
  offsetName() {
    return this.name;
  }
  /**
   * Returns the offset's value as a string
   * @override
   * @param {number} ts - Epoch milliseconds for which to get the offset
   * @param {string} format - What style of offset to return.
   *                          Accepts 'narrow', 'short', or 'techie'. Returning '+6', '+06:00', or '+0600' respectively
   * @return {string}
   */
  formatOffset(e, n) {
    return Ve(this.fixed, n);
  }
  /**
   * Returns whether the offset is known to be fixed for the whole year:
   * Always returns true for all fixed offset zones.
   * @override
   * @type {boolean}
   */
  get isUniversal() {
    return !0;
  }
  /**
   * Return the offset in minutes for this zone at the specified timestamp.
   *
   * For fixed offset zones, this is constant and does not depend on a timestamp.
   * @override
   * @return {number}
   */
  offset() {
    return this.fixed;
  }
  /**
   * Return whether this Zone is equal to another zone (i.e. also fixed and same offset)
   * @override
   * @param {Zone} otherZone - the zone to compare
   * @return {boolean}
   */
  equals(e) {
    return e.type === "fixed" && e.fixed === this.fixed;
  }
  /**
   * Return whether this Zone is valid:
   * All fixed offset zones are valid.
   * @override
   * @type {boolean}
   */
  get isValid() {
    return !0;
  }
}
class Fr extends $e {
  constructor(e) {
    super(), this.zoneName = e;
  }
  /** @override **/
  get type() {
    return "invalid";
  }
  /** @override **/
  get name() {
    return this.zoneName;
  }
  /** @override **/
  get isUniversal() {
    return !1;
  }
  /** @override **/
  offsetName() {
    return null;
  }
  /** @override **/
  formatOffset() {
    return "";
  }
  /** @override **/
  offset() {
    return NaN;
  }
  /** @override **/
  equals() {
    return !1;
  }
  /** @override **/
  get isValid() {
    return !1;
  }
}
function ue(t, e) {
  if (O(t) || t === null)
    return e;
  if (t instanceof $e)
    return t;
  if ($r(t)) {
    const n = t.toLowerCase();
    return n === "default" ? e : n === "local" || n === "system" ? pt.instance : n === "utc" || n === "gmt" ? z.utcInstance : z.parseSpecifier(n) || re.create(t);
  } else return ce(t) ? z.instance(t) : typeof t == "object" && "offset" in t && typeof t.offset == "function" ? t : new Fr(t);
}
const jt = {
  arab: "[٠-٩]",
  arabext: "[۰-۹]",
  bali: "[᭐-᭙]",
  beng: "[০-৯]",
  deva: "[०-९]",
  fullwide: "[０-９]",
  gujr: "[૦-૯]",
  hanidec: "[〇|一|二|三|四|五|六|七|八|九]",
  khmr: "[០-៩]",
  knda: "[೦-೯]",
  laoo: "[໐-໙]",
  limb: "[᥆-᥏]",
  mlym: "[൦-൯]",
  mong: "[᠐-᠙]",
  mymr: "[၀-၉]",
  orya: "[୦-୯]",
  tamldec: "[௦-௯]",
  telu: "[౦-౯]",
  thai: "[๐-๙]",
  tibt: "[༠-༩]",
  latn: "\\d"
}, hn = {
  arab: [1632, 1641],
  arabext: [1776, 1785],
  bali: [6992, 7001],
  beng: [2534, 2543],
  deva: [2406, 2415],
  fullwide: [65296, 65303],
  gujr: [2790, 2799],
  khmr: [6112, 6121],
  knda: [3302, 3311],
  laoo: [3792, 3801],
  limb: [6470, 6479],
  mlym: [3430, 3439],
  mong: [6160, 6169],
  mymr: [4160, 4169],
  orya: [2918, 2927],
  tamldec: [3046, 3055],
  telu: [3174, 3183],
  thai: [3664, 3673],
  tibt: [3872, 3881]
}, Lr = jt.hanidec.replace(/[\[|\]]/g, "").split("");
function Rr(t) {
  let e = parseInt(t, 10);
  if (isNaN(e)) {
    e = "";
    for (let n = 0; n < t.length; n++) {
      const s = t.charCodeAt(n);
      if (t[n].search(jt.hanidec) !== -1)
        e += Lr.indexOf(t[n]);
      else
        for (const r in hn) {
          const [i, a] = hn[r];
          s >= i && s <= a && (e += s - i);
        }
    }
    return parseInt(e, 10);
  } else
    return e;
}
let we = {};
function Vr() {
  we = {};
}
function K({ numberingSystem: t }, e = "") {
  const n = t || "latn";
  return we[n] || (we[n] = {}), we[n][e] || (we[n][e] = new RegExp(`${jt[n]}${e}`)), we[n][e];
}
let dn = () => Date.now(), fn = "system", mn = null, pn = null, yn = null, En = 60, gn, Tn = null;
class L {
  /**
   * Get the callback for returning the current timestamp.
   * @type {function}
   */
  static get now() {
    return dn;
  }
  /**
   * Set the callback for returning the current timestamp.
   * The function should return a number, which will be interpreted as an Epoch millisecond count
   * @type {function}
   * @example Settings.now = () => Date.now() + 3000 // pretend it is 3 seconds in the future
   * @example Settings.now = () => 0 // always pretend it's Jan 1, 1970 at midnight in UTC time
   */
  static set now(e) {
    dn = e;
  }
  /**
   * Set the default time zone to create DateTimes in. Does not affect existing instances.
   * Use the value "system" to reset this value to the system's time zone.
   * @type {string}
   */
  static set defaultZone(e) {
    fn = e;
  }
  /**
   * Get the default time zone object currently used to create DateTimes. Does not affect existing instances.
   * The default value is the system's time zone (the one set on the machine that runs this code).
   * @type {Zone}
   */
  static get defaultZone() {
    return ue(fn, pt.instance);
  }
  /**
   * Get the default locale to create DateTimes with. Does not affect existing instances.
   * @type {string}
   */
  static get defaultLocale() {
    return mn;
  }
  /**
   * Set the default locale to create DateTimes with. Does not affect existing instances.
   * @type {string}
   */
  static set defaultLocale(e) {
    mn = e;
  }
  /**
   * Get the default numbering system to create DateTimes with. Does not affect existing instances.
   * @type {string}
   */
  static get defaultNumberingSystem() {
    return pn;
  }
  /**
   * Set the default numbering system to create DateTimes with. Does not affect existing instances.
   * @type {string}
   */
  static set defaultNumberingSystem(e) {
    pn = e;
  }
  /**
   * Get the default output calendar to create DateTimes with. Does not affect existing instances.
   * @type {string}
   */
  static get defaultOutputCalendar() {
    return yn;
  }
  /**
   * Set the default output calendar to create DateTimes with. Does not affect existing instances.
   * @type {string}
   */
  static set defaultOutputCalendar(e) {
    yn = e;
  }
  /**
   * @typedef {Object} WeekSettings
   * @property {number} firstDay
   * @property {number} minimalDays
   * @property {number[]} weekend
   */
  /**
   * @return {WeekSettings|null}
   */
  static get defaultWeekSettings() {
    return Tn;
  }
  /**
   * Allows overriding the default locale week settings, i.e. the start of the week, the weekend and
   * how many days are required in the first week of a year.
   * Does not affect existing instances.
   *
   * @param {WeekSettings|null} weekSettings
   */
  static set defaultWeekSettings(e) {
    Tn = Bt(e);
  }
  /**
   * Get the cutoff year for whether a 2-digit year string is interpreted in the current or previous century. Numbers higher than the cutoff will be considered to mean 19xx and numbers lower or equal to the cutoff will be considered 20xx.
   * @type {number}
   */
  static get twoDigitCutoffYear() {
    return En;
  }
  /**
   * Set the cutoff year for whether a 2-digit year string is interpreted in the current or previous century. Numbers higher than the cutoff will be considered to mean 19xx and numbers lower or equal to the cutoff will be considered 20xx.
   * @type {number}
   * @example Settings.twoDigitCutoffYear = 0 // all 'yy' are interpreted as 20th century
   * @example Settings.twoDigitCutoffYear = 99 // all 'yy' are interpreted as 21st century
   * @example Settings.twoDigitCutoffYear = 50 // '49' -> 2049; '50' -> 1950
   * @example Settings.twoDigitCutoffYear = 1950 // interpreted as 50
   * @example Settings.twoDigitCutoffYear = 2050 // ALSO interpreted as 50
   */
  static set twoDigitCutoffYear(e) {
    En = e % 100;
  }
  /**
   * Get whether Luxon will throw when it encounters invalid DateTimes, Durations, or Intervals
   * @type {boolean}
   */
  static get throwOnInvalid() {
    return gn;
  }
  /**
   * Set whether Luxon will throw when it encounters invalid DateTimes, Durations, or Intervals
   * @type {boolean}
   */
  static set throwOnInvalid(e) {
    gn = e;
  }
  /**
   * Reset Luxon's global caches. Should only be necessary in testing scenarios.
   * @return {void}
   */
  static resetCaches() {
    A.resetCache(), re.resetCache(), w.resetCache(), Vr();
  }
}
class te {
  constructor(e, n) {
    this.reason = e, this.explanation = n;
  }
  toMessage() {
    return this.explanation ? `${this.reason}: ${this.explanation}` : this.reason;
  }
}
const hs = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334], ds = [0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335];
function J(t, e) {
  return new te(
    "unit out of range",
    `you specified ${e} (of type ${typeof e}) as a ${t}, which is invalid`
  );
}
function Gt(t, e, n) {
  const s = new Date(Date.UTC(t, e - 1, n));
  t < 100 && t >= 0 && s.setUTCFullYear(s.getUTCFullYear() - 1900);
  const r = s.getUTCDay();
  return r === 0 ? 7 : r;
}
function fs(t, e, n) {
  return n + (We(t) ? ds : hs)[e - 1];
}
function ms(t, e) {
  const n = We(t) ? ds : hs, s = n.findIndex((i) => i < e), r = e - n[s];
  return { month: s + 1, day: r };
}
function Jt(t, e) {
  return (t - e + 7) % 7 + 1;
}
function ut(t, e = 4, n = 1) {
  const { year: s, month: r, day: i } = t, a = fs(s, r, i), o = Jt(Gt(s, r, i), n);
  let u = Math.floor((a - o + 14 - e) / 7), c;
  return u < 1 ? (c = s - 1, u = Pe(c, e, n)) : u > Pe(s, e, n) ? (c = s + 1, u = 1) : c = s, { weekYear: c, weekNumber: u, weekday: o, ...Tt(t) };
}
function wn(t, e = 4, n = 1) {
  const { weekYear: s, weekNumber: r, weekday: i } = t, a = Jt(Gt(s, 1, e), n), o = ke(s);
  let u = r * 7 + i - a - 7 + e, c;
  u < 1 ? (c = s - 1, u += ke(c)) : u > o ? (c = s + 1, u -= ke(s)) : c = s;
  const { month: h, day: p } = ms(c, u);
  return { year: c, month: h, day: p, ...Tt(t) };
}
function bt(t) {
  const { year: e, month: n, day: s } = t, r = fs(e, n, s);
  return { year: e, ordinal: r, ...Tt(t) };
}
function On(t) {
  const { year: e, ordinal: n } = t, { month: s, day: r } = ms(e, n);
  return { year: e, month: s, day: r, ...Tt(t) };
}
function Nn(t, e) {
  if (!O(t.localWeekday) || !O(t.localWeekNumber) || !O(t.localWeekYear)) {
    if (!O(t.weekday) || !O(t.weekNumber) || !O(t.weekYear))
      throw new Oe(
        "Cannot mix locale-based week fields with ISO-based week fields"
      );
    return O(t.localWeekday) || (t.weekday = t.localWeekday), O(t.localWeekNumber) || (t.weekNumber = t.localWeekNumber), O(t.localWeekYear) || (t.weekYear = t.localWeekYear), delete t.localWeekday, delete t.localWeekNumber, delete t.localWeekYear, {
      minDaysInFirstWeek: e.getMinDaysInFirstWeek(),
      startOfWeek: e.getStartOfWeek()
    };
  } else
    return { minDaysInFirstWeek: 4, startOfWeek: 1 };
}
function Pr(t, e = 4, n = 1) {
  const s = yt(t.weekYear), r = Q(
    t.weekNumber,
    1,
    Pe(t.weekYear, e, n)
  ), i = Q(t.weekday, 1, 7);
  return s ? r ? i ? !1 : J("weekday", t.weekday) : J("week", t.weekNumber) : J("weekYear", t.weekYear);
}
function Ur(t) {
  const e = yt(t.year), n = Q(t.ordinal, 1, ke(t.year));
  return e ? n ? !1 : J("ordinal", t.ordinal) : J("year", t.year);
}
function ps(t) {
  const e = yt(t.year), n = Q(t.month, 1, 12), s = Q(t.day, 1, ct(t.year, t.month));
  return e ? n ? s ? !1 : J("day", t.day) : J("month", t.month) : J("year", t.year);
}
function ys(t) {
  const { hour: e, minute: n, second: s, millisecond: r } = t, i = Q(e, 0, 23) || e === 24 && n === 0 && s === 0 && r === 0, a = Q(n, 0, 59), o = Q(s, 0, 59), u = Q(r, 0, 999);
  return i ? a ? o ? u ? !1 : J("millisecond", r) : J("second", s) : J("minute", n) : J("hour", e);
}
function O(t) {
  return typeof t > "u";
}
function ce(t) {
  return typeof t == "number";
}
function yt(t) {
  return typeof t == "number" && t % 1 === 0;
}
function $r(t) {
  return typeof t == "string";
}
function Wr(t) {
  return Object.prototype.toString.call(t) === "[object Date]";
}
function Es() {
  try {
    return typeof Intl < "u" && !!Intl.RelativeTimeFormat;
  } catch {
    return !1;
  }
}
function gs() {
  try {
    return typeof Intl < "u" && !!Intl.Locale && ("weekInfo" in Intl.Locale.prototype || "getWeekInfo" in Intl.Locale.prototype);
  } catch {
    return !1;
  }
}
function Hr(t) {
  return Array.isArray(t) ? t : [t];
}
function vn(t, e, n) {
  if (t.length !== 0)
    return t.reduce((s, r) => {
      const i = [e(r), r];
      return s && n(s[0], i[0]) === s[0] ? s : i;
    }, null)[1];
}
function Br(t, e) {
  return e.reduce((n, s) => (n[s] = t[s], n), {});
}
function Se(t, e) {
  return Object.prototype.hasOwnProperty.call(t, e);
}
function Bt(t) {
  if (t == null)
    return null;
  if (typeof t != "object")
    throw new Z("Week settings must be an object");
  if (!Q(t.firstDay, 1, 7) || !Q(t.minimalDays, 1, 7) || !Array.isArray(t.weekend) || t.weekend.some((e) => !Q(e, 1, 7)))
    throw new Z("Invalid week settings");
  return {
    firstDay: t.firstDay,
    minimalDays: t.minimalDays,
    weekend: Array.from(t.weekend)
  };
}
function Q(t, e, n) {
  return yt(t) && t >= e && t <= n;
}
function Yr(t, e) {
  return t - e * Math.floor(t / e);
}
function U(t, e = 2) {
  const n = t < 0;
  let s;
  return n ? s = "-" + ("" + -t).padStart(e, "0") : s = ("" + t).padStart(e, "0"), s;
}
function oe(t) {
  if (!(O(t) || t === null || t === ""))
    return parseInt(t, 10);
}
function he(t) {
  if (!(O(t) || t === null || t === ""))
    return parseFloat(t);
}
function Qt(t) {
  if (!(O(t) || t === null || t === "")) {
    const e = parseFloat("0." + t) * 1e3;
    return Math.floor(e);
  }
}
function Xt(t, e, n = !1) {
  const s = 10 ** e;
  return (n ? Math.trunc : Math.round)(t * s) / s;
}
function We(t) {
  return t % 4 === 0 && (t % 100 !== 0 || t % 400 === 0);
}
function ke(t) {
  return We(t) ? 366 : 365;
}
function ct(t, e) {
  const n = Yr(e - 1, 12) + 1, s = t + (e - n) / 12;
  return n === 2 ? We(s) ? 29 : 28 : [31, null, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][n - 1];
}
function Et(t) {
  let e = Date.UTC(
    t.year,
    t.month - 1,
    t.day,
    t.hour,
    t.minute,
    t.second,
    t.millisecond
  );
  return t.year < 100 && t.year >= 0 && (e = new Date(e), e.setUTCFullYear(t.year, t.month - 1, t.day)), +e;
}
function kn(t, e, n) {
  return -Jt(Gt(t, 1, e), n) + e - 1;
}
function Pe(t, e = 4, n = 1) {
  const s = kn(t, e, n), r = kn(t + 1, e, n);
  return (ke(t) - s + r) / 7;
}
function Yt(t) {
  return t > 99 ? t : t > L.twoDigitCutoffYear ? 1900 + t : 2e3 + t;
}
function Ts(t, e, n, s = null) {
  const r = new Date(t), i = {
    hourCycle: "h23",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit"
  };
  s && (i.timeZone = s);
  const a = { timeZoneName: e, ...i }, o = new Intl.DateTimeFormat(n, a).formatToParts(r).find((u) => u.type.toLowerCase() === "timezonename");
  return o ? o.value : null;
}
function gt(t, e) {
  let n = parseInt(t, 10);
  Number.isNaN(n) && (n = 0);
  const s = parseInt(e, 10) || 0, r = n < 0 || Object.is(n, -0) ? -s : s;
  return n * 60 + r;
}
function ws(t) {
  const e = Number(t);
  if (typeof t == "boolean" || t === "" || Number.isNaN(e))
    throw new Z(`Invalid unit value ${t}`);
  return e;
}
function lt(t, e) {
  const n = {};
  for (const s in t)
    if (Se(t, s)) {
      const r = t[s];
      if (r == null) continue;
      n[e(s)] = ws(r);
    }
  return n;
}
function Ve(t, e) {
  const n = Math.trunc(Math.abs(t / 60)), s = Math.trunc(Math.abs(t % 60)), r = t >= 0 ? "+" : "-";
  switch (e) {
    case "short":
      return `${r}${U(n, 2)}:${U(s, 2)}`;
    case "narrow":
      return `${r}${n}${s > 0 ? `:${s}` : ""}`;
    case "techie":
      return `${r}${U(n, 2)}${U(s, 2)}`;
    default:
      throw new RangeError(`Value format ${e} is out of range for property format`);
  }
}
function Tt(t) {
  return Br(t, ["hour", "minute", "second", "millisecond"]);
}
const Zr = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December"
], Os = [
  "Jan",
  "Feb",
  "Mar",
  "Apr",
  "May",
  "Jun",
  "Jul",
  "Aug",
  "Sep",
  "Oct",
  "Nov",
  "Dec"
], qr = ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"];
function Ns(t) {
  switch (t) {
    case "narrow":
      return [...qr];
    case "short":
      return [...Os];
    case "long":
      return [...Zr];
    case "numeric":
      return ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"];
    case "2-digit":
      return ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"];
    default:
      return null;
  }
}
const vs = [
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
  "Sunday"
], ks = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"], zr = ["M", "T", "W", "T", "F", "S", "S"];
function Is(t) {
  switch (t) {
    case "narrow":
      return [...zr];
    case "short":
      return [...ks];
    case "long":
      return [...vs];
    case "numeric":
      return ["1", "2", "3", "4", "5", "6", "7"];
    default:
      return null;
  }
}
const Ss = ["AM", "PM"], jr = ["Before Christ", "Anno Domini"], Gr = ["BC", "AD"], Jr = ["B", "A"];
function bs(t) {
  switch (t) {
    case "narrow":
      return [...Jr];
    case "short":
      return [...Gr];
    case "long":
      return [...jr];
    default:
      return null;
  }
}
function Qr(t) {
  return Ss[t.hour < 12 ? 0 : 1];
}
function Xr(t, e) {
  return Is(e)[t.weekday - 1];
}
function Kr(t, e) {
  return Ns(e)[t.month - 1];
}
function ei(t, e) {
  return bs(e)[t.year < 0 ? 0 : 1];
}
function ti(t, e, n = "always", s = !1) {
  const r = {
    years: ["year", "yr."],
    quarters: ["quarter", "qtr."],
    months: ["month", "mo."],
    weeks: ["week", "wk."],
    days: ["day", "day", "days"],
    hours: ["hour", "hr."],
    minutes: ["minute", "min."],
    seconds: ["second", "sec."]
  }, i = ["hours", "minutes", "seconds"].indexOf(t) === -1;
  if (n === "auto" && i) {
    const p = t === "days";
    switch (e) {
      case 1:
        return p ? "tomorrow" : `next ${r[t][0]}`;
      case -1:
        return p ? "yesterday" : `last ${r[t][0]}`;
      case 0:
        return p ? "today" : `this ${r[t][0]}`;
    }
  }
  const a = Object.is(e, -0) || e < 0, o = Math.abs(e), u = o === 1, c = r[t], h = s ? u ? c[1] : c[2] || c[1] : u ? r[t][0] : t;
  return a ? `${o} ${h} ago` : `in ${o} ${h}`;
}
function In(t, e) {
  let n = "";
  for (const s of t)
    s.literal ? n += s.val : n += e(s.val);
  return n;
}
const ni = {
  D: ot,
  DD: qn,
  DDD: zn,
  DDDD: jn,
  t: Gn,
  tt: Jn,
  ttt: Qn,
  tttt: Xn,
  T: Kn,
  TT: es,
  TTT: ts,
  TTTT: ns,
  f: ss,
  ff: is,
  fff: os,
  ffff: cs,
  F: rs,
  FF: as,
  FFF: us,
  FFFF: ls
};
class q {
  static create(e, n = {}) {
    return new q(e, n);
  }
  static parseFormat(e) {
    let n = null, s = "", r = !1;
    const i = [];
    for (let a = 0; a < e.length; a++) {
      const o = e.charAt(a);
      o === "'" ? (s.length > 0 && i.push({ literal: r || /^\s+$/.test(s), val: s }), n = null, s = "", r = !r) : r || o === n ? s += o : (s.length > 0 && i.push({ literal: /^\s+$/.test(s), val: s }), s = o, n = o);
    }
    return s.length > 0 && i.push({ literal: r || /^\s+$/.test(s), val: s }), i;
  }
  static macroTokenToFormatOpts(e) {
    return ni[e];
  }
  constructor(e, n) {
    this.opts = n, this.loc = e, this.systemLoc = null;
  }
  formatWithSystemDefault(e, n) {
    return this.systemLoc === null && (this.systemLoc = this.loc.redefaultToSystem()), this.systemLoc.dtFormatter(e, { ...this.opts, ...n }).format();
  }
  dtFormatter(e, n = {}) {
    return this.loc.dtFormatter(e, { ...this.opts, ...n });
  }
  formatDateTime(e, n) {
    return this.dtFormatter(e, n).format();
  }
  formatDateTimeParts(e, n) {
    return this.dtFormatter(e, n).formatToParts();
  }
  formatInterval(e, n) {
    return this.dtFormatter(e.start, n).dtf.formatRange(e.start.toJSDate(), e.end.toJSDate());
  }
  resolvedOptions(e, n) {
    return this.dtFormatter(e, n).resolvedOptions();
  }
  num(e, n = 0) {
    if (this.opts.forceSimple)
      return U(e, n);
    const s = { ...this.opts };
    return n > 0 && (s.padTo = n), this.loc.numberFormatter(s).format(e);
  }
  formatDateTimeFromString(e, n) {
    const s = this.loc.listingMode() === "en", r = this.loc.outputCalendar && this.loc.outputCalendar !== "gregory", i = (E, N) => this.loc.extract(e, E, N), a = (E) => e.isOffsetFixed && e.offset === 0 && E.allowZ ? "Z" : e.isValid ? e.zone.formatOffset(e.ts, E.format) : "", o = () => s ? Qr(e) : i({ hour: "numeric", hourCycle: "h12" }, "dayperiod"), u = (E, N) => s ? Kr(e, E) : i(N ? { month: E } : { month: E, day: "numeric" }, "month"), c = (E, N) => s ? Xr(e, E) : i(
      N ? { weekday: E } : { weekday: E, month: "long", day: "numeric" },
      "weekday"
    ), h = (E) => {
      const N = q.macroTokenToFormatOpts(E);
      return N ? this.formatWithSystemDefault(e, N) : E;
    }, p = (E) => s ? ei(e, E) : i({ era: E }, "era"), v = (E) => {
      switch (E) {
        case "S":
          return this.num(e.millisecond);
        case "u":
        case "SSS":
          return this.num(e.millisecond, 3);
        case "s":
          return this.num(e.second);
        case "ss":
          return this.num(e.second, 2);
        case "uu":
          return this.num(Math.floor(e.millisecond / 10), 2);
        case "uuu":
          return this.num(Math.floor(e.millisecond / 100));
        case "m":
          return this.num(e.minute);
        case "mm":
          return this.num(e.minute, 2);
        case "h":
          return this.num(e.hour % 12 === 0 ? 12 : e.hour % 12);
        case "hh":
          return this.num(e.hour % 12 === 0 ? 12 : e.hour % 12, 2);
        case "H":
          return this.num(e.hour);
        case "HH":
          return this.num(e.hour, 2);
        case "Z":
          return a({ format: "narrow", allowZ: this.opts.allowZ });
        case "ZZ":
          return a({ format: "short", allowZ: this.opts.allowZ });
        case "ZZZ":
          return a({ format: "techie", allowZ: this.opts.allowZ });
        case "ZZZZ":
          return e.zone.offsetName(e.ts, { format: "short", locale: this.loc.locale });
        case "ZZZZZ":
          return e.zone.offsetName(e.ts, { format: "long", locale: this.loc.locale });
        case "z":
          return e.zoneName;
        case "a":
          return o();
        case "d":
          return r ? i({ day: "numeric" }, "day") : this.num(e.day);
        case "dd":
          return r ? i({ day: "2-digit" }, "day") : this.num(e.day, 2);
        case "c":
          return this.num(e.weekday);
        case "ccc":
          return c("short", !0);
        case "cccc":
          return c("long", !0);
        case "ccccc":
          return c("narrow", !0);
        case "E":
          return this.num(e.weekday);
        case "EEE":
          return c("short", !1);
        case "EEEE":
          return c("long", !1);
        case "EEEEE":
          return c("narrow", !1);
        case "L":
          return r ? i({ month: "numeric", day: "numeric" }, "month") : this.num(e.month);
        case "LL":
          return r ? i({ month: "2-digit", day: "numeric" }, "month") : this.num(e.month, 2);
        case "LLL":
          return u("short", !0);
        case "LLLL":
          return u("long", !0);
        case "LLLLL":
          return u("narrow", !0);
        case "M":
          return r ? i({ month: "numeric" }, "month") : this.num(e.month);
        case "MM":
          return r ? i({ month: "2-digit" }, "month") : this.num(e.month, 2);
        case "MMM":
          return u("short", !1);
        case "MMMM":
          return u("long", !1);
        case "MMMMM":
          return u("narrow", !1);
        case "y":
          return r ? i({ year: "numeric" }, "year") : this.num(e.year);
        case "yy":
          return r ? i({ year: "2-digit" }, "year") : this.num(e.year.toString().slice(-2), 2);
        case "yyyy":
          return r ? i({ year: "numeric" }, "year") : this.num(e.year, 4);
        case "yyyyyy":
          return r ? i({ year: "numeric" }, "year") : this.num(e.year, 6);
        case "G":
          return p("short");
        case "GG":
          return p("long");
        case "GGGGG":
          return p("narrow");
        case "kk":
          return this.num(e.weekYear.toString().slice(-2), 2);
        case "kkkk":
          return this.num(e.weekYear, 4);
        case "W":
          return this.num(e.weekNumber);
        case "WW":
          return this.num(e.weekNumber, 2);
        case "n":
          return this.num(e.localWeekNumber);
        case "nn":
          return this.num(e.localWeekNumber, 2);
        case "ii":
          return this.num(e.localWeekYear.toString().slice(-2), 2);
        case "iiii":
          return this.num(e.localWeekYear, 4);
        case "o":
          return this.num(e.ordinal);
        case "ooo":
          return this.num(e.ordinal, 3);
        case "q":
          return this.num(e.quarter);
        case "qq":
          return this.num(e.quarter, 2);
        case "X":
          return this.num(Math.floor(e.ts / 1e3));
        case "x":
          return this.num(e.ts);
        default:
          return h(E);
      }
    };
    return In(q.parseFormat(n), v);
  }
  formatDurationFromString(e, n) {
    const s = (u) => {
      switch (u[0]) {
        case "S":
          return "millisecond";
        case "s":
          return "second";
        case "m":
          return "minute";
        case "h":
          return "hour";
        case "d":
          return "day";
        case "w":
          return "week";
        case "M":
          return "month";
        case "y":
          return "year";
        default:
          return null;
      }
    }, r = (u) => (c) => {
      const h = s(c);
      return h ? this.num(u.get(h), c.length) : c;
    }, i = q.parseFormat(n), a = i.reduce(
      (u, { literal: c, val: h }) => c ? u : u.concat(h),
      []
    ), o = e.shiftTo(...a.map(s).filter((u) => u));
    return In(i, r(o));
  }
}
const Ds = /[A-Za-z_+-]{1,256}(?::?\/[A-Za-z0-9_+-]{1,256}(?:\/[A-Za-z0-9_+-]{1,256})?)?/;
function be(...t) {
  const e = t.reduce((n, s) => n + s.source, "");
  return RegExp(`^${e}$`);
}
function De(...t) {
  return (e) => t.reduce(
    ([n, s, r], i) => {
      const [a, o, u] = i(e, r);
      return [{ ...n, ...a }, o || s, u];
    },
    [{}, null, 1]
  ).slice(0, 2);
}
function xe(t, ...e) {
  if (t == null)
    return [null, null];
  for (const [n, s] of e) {
    const r = n.exec(t);
    if (r)
      return s(r);
  }
  return [null, null];
}
function xs(...t) {
  return (e, n) => {
    const s = {};
    let r;
    for (r = 0; r < t.length; r++)
      s[t[r]] = oe(e[n + r]);
    return [s, null, n + r];
  };
}
const As = /(?:(Z)|([+-]\d\d)(?::?(\d\d))?)/, si = `(?:${As.source}?(?:\\[(${Ds.source})\\])?)?`, Kt = /(\d\d)(?::?(\d\d)(?::?(\d\d)(?:[.,](\d{1,30}))?)?)?/, Cs = RegExp(`${Kt.source}${si}`), en = RegExp(`(?:T${Cs.source})?`), ri = /([+-]\d{6}|\d{4})(?:-?(\d\d)(?:-?(\d\d))?)?/, ii = /(\d{4})-?W(\d\d)(?:-?(\d))?/, ai = /(\d{4})-?(\d{3})/, oi = xs("weekYear", "weekNumber", "weekDay"), ui = xs("year", "ordinal"), ci = /(\d{4})-(\d\d)-(\d\d)/, Ms = RegExp(
  `${Kt.source} ?(?:${As.source}|(${Ds.source}))?`
), li = RegExp(`(?: ${Ms.source})?`);
function Ie(t, e, n) {
  const s = t[e];
  return O(s) ? n : oe(s);
}
function hi(t, e) {
  return [{
    year: Ie(t, e),
    month: Ie(t, e + 1, 1),
    day: Ie(t, e + 2, 1)
  }, null, e + 3];
}
function Ae(t, e) {
  return [{
    hours: Ie(t, e, 0),
    minutes: Ie(t, e + 1, 0),
    seconds: Ie(t, e + 2, 0),
    milliseconds: Qt(t[e + 3])
  }, null, e + 4];
}
function He(t, e) {
  const n = !t[e] && !t[e + 1], s = gt(t[e + 1], t[e + 2]), r = n ? null : z.instance(s);
  return [{}, r, e + 3];
}
function Be(t, e) {
  const n = t[e] ? re.create(t[e]) : null;
  return [{}, n, e + 1];
}
const di = RegExp(`^T?${Kt.source}$`), fi = /^-?P(?:(?:(-?\d{1,20}(?:\.\d{1,20})?)Y)?(?:(-?\d{1,20}(?:\.\d{1,20})?)M)?(?:(-?\d{1,20}(?:\.\d{1,20})?)W)?(?:(-?\d{1,20}(?:\.\d{1,20})?)D)?(?:T(?:(-?\d{1,20}(?:\.\d{1,20})?)H)?(?:(-?\d{1,20}(?:\.\d{1,20})?)M)?(?:(-?\d{1,20})(?:[.,](-?\d{1,20}))?S)?)?)$/;
function mi(t) {
  const [e, n, s, r, i, a, o, u, c] = t, h = e[0] === "-", p = u && u[0] === "-", v = (E, N = !1) => E !== void 0 && (N || E && h) ? -E : E;
  return [
    {
      years: v(he(n)),
      months: v(he(s)),
      weeks: v(he(r)),
      days: v(he(i)),
      hours: v(he(a)),
      minutes: v(he(o)),
      seconds: v(he(u), u === "-0"),
      milliseconds: v(Qt(c), p)
    }
  ];
}
const pi = {
  GMT: 0,
  EDT: -4 * 60,
  EST: -5 * 60,
  CDT: -5 * 60,
  CST: -6 * 60,
  MDT: -6 * 60,
  MST: -7 * 60,
  PDT: -7 * 60,
  PST: -8 * 60
};
function tn(t, e, n, s, r, i, a) {
  const o = {
    year: e.length === 2 ? Yt(oe(e)) : oe(e),
    month: Os.indexOf(n) + 1,
    day: oe(s),
    hour: oe(r),
    minute: oe(i)
  };
  return a && (o.second = oe(a)), t && (o.weekday = t.length > 3 ? vs.indexOf(t) + 1 : ks.indexOf(t) + 1), o;
}
const yi = /^(?:(Mon|Tue|Wed|Thu|Fri|Sat|Sun),\s)?(\d{1,2})\s(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s(\d{2,4})\s(\d\d):(\d\d)(?::(\d\d))?\s(?:(UT|GMT|[ECMP][SD]T)|([Zz])|(?:([+-]\d\d)(\d\d)))$/;
function Ei(t) {
  const [
    ,
    e,
    n,
    s,
    r,
    i,
    a,
    o,
    u,
    c,
    h,
    p
  ] = t, v = tn(e, r, s, n, i, a, o);
  let E;
  return u ? E = pi[u] : c ? E = 0 : E = gt(h, p), [v, new z(E)];
}
function gi(t) {
  return t.replace(/\([^()]*\)|[\n\t]/g, " ").replace(/(\s\s+)/g, " ").trim();
}
const Ti = /^(Mon|Tue|Wed|Thu|Fri|Sat|Sun), (\d\d) (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) (\d{4}) (\d\d):(\d\d):(\d\d) GMT$/, wi = /^(Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday), (\d\d)-(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)-(\d\d) (\d\d):(\d\d):(\d\d) GMT$/, Oi = /^(Mon|Tue|Wed|Thu|Fri|Sat|Sun) (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) ( \d|\d\d) (\d\d):(\d\d):(\d\d) (\d{4})$/;
function Sn(t) {
  const [, e, n, s, r, i, a, o] = t;
  return [tn(e, r, s, n, i, a, o), z.utcInstance];
}
function Ni(t) {
  const [, e, n, s, r, i, a, o] = t;
  return [tn(e, o, n, s, r, i, a), z.utcInstance];
}
const vi = be(ri, en), ki = be(ii, en), Ii = be(ai, en), Si = be(Cs), _s = De(
  hi,
  Ae,
  He,
  Be
), bi = De(
  oi,
  Ae,
  He,
  Be
), Di = De(
  ui,
  Ae,
  He,
  Be
), xi = De(
  Ae,
  He,
  Be
);
function Ai(t) {
  return xe(
    t,
    [vi, _s],
    [ki, bi],
    [Ii, Di],
    [Si, xi]
  );
}
function Ci(t) {
  return xe(gi(t), [yi, Ei]);
}
function Mi(t) {
  return xe(
    t,
    [Ti, Sn],
    [wi, Sn],
    [Oi, Ni]
  );
}
function _i(t) {
  return xe(t, [fi, mi]);
}
const Fi = De(Ae);
function Li(t) {
  return xe(t, [di, Fi]);
}
const Ri = be(ci, li), Vi = be(Ms), Pi = De(
  Ae,
  He,
  Be
);
function Ui(t) {
  return xe(
    t,
    [Ri, _s],
    [Vi, Pi]
  );
}
const bn = "Invalid Duration", Fs = {
  weeks: {
    days: 7,
    hours: 7 * 24,
    minutes: 7 * 24 * 60,
    seconds: 7 * 24 * 60 * 60,
    milliseconds: 7 * 24 * 60 * 60 * 1e3
  },
  days: {
    hours: 24,
    minutes: 24 * 60,
    seconds: 24 * 60 * 60,
    milliseconds: 24 * 60 * 60 * 1e3
  },
  hours: { minutes: 60, seconds: 60 * 60, milliseconds: 60 * 60 * 1e3 },
  minutes: { seconds: 60, milliseconds: 60 * 1e3 },
  seconds: { milliseconds: 1e3 }
}, $i = {
  years: {
    quarters: 4,
    months: 12,
    weeks: 52,
    days: 365,
    hours: 365 * 24,
    minutes: 365 * 24 * 60,
    seconds: 365 * 24 * 60 * 60,
    milliseconds: 365 * 24 * 60 * 60 * 1e3
  },
  quarters: {
    months: 3,
    weeks: 13,
    days: 91,
    hours: 91 * 24,
    minutes: 91 * 24 * 60,
    seconds: 91 * 24 * 60 * 60,
    milliseconds: 91 * 24 * 60 * 60 * 1e3
  },
  months: {
    weeks: 4,
    days: 30,
    hours: 30 * 24,
    minutes: 30 * 24 * 60,
    seconds: 30 * 24 * 60 * 60,
    milliseconds: 30 * 24 * 60 * 60 * 1e3
  },
  ...Fs
}, G = 146097 / 400, Ee = 146097 / 4800, Wi = {
  years: {
    quarters: 4,
    months: 12,
    weeks: G / 7,
    days: G,
    hours: G * 24,
    minutes: G * 24 * 60,
    seconds: G * 24 * 60 * 60,
    milliseconds: G * 24 * 60 * 60 * 1e3
  },
  quarters: {
    months: 3,
    weeks: G / 28,
    days: G / 4,
    hours: G * 24 / 4,
    minutes: G * 24 * 60 / 4,
    seconds: G * 24 * 60 * 60 / 4,
    milliseconds: G * 24 * 60 * 60 * 1e3 / 4
  },
  months: {
    weeks: Ee / 7,
    days: Ee,
    hours: Ee * 24,
    minutes: Ee * 24 * 60,
    seconds: Ee * 24 * 60 * 60,
    milliseconds: Ee * 24 * 60 * 60 * 1e3
  },
  ...Fs
}, fe = [
  "years",
  "quarters",
  "months",
  "weeks",
  "days",
  "hours",
  "minutes",
  "seconds",
  "milliseconds"
], Hi = fe.slice(0).reverse();
function ae(t, e, n = !1) {
  const s = {
    values: n ? e.values : { ...t.values, ...e.values || {} },
    loc: t.loc.clone(e.loc),
    conversionAccuracy: e.conversionAccuracy || t.conversionAccuracy,
    matrix: e.matrix || t.matrix
  };
  return new D(s);
}
function Ls(t, e) {
  let n = e.milliseconds ?? 0;
  for (const s of Hi.slice(1))
    e[s] && (n += e[s] * t[s].milliseconds);
  return n;
}
function Dn(t, e) {
  const n = Ls(t, e) < 0 ? -1 : 1;
  fe.reduceRight((s, r) => {
    if (O(e[r]))
      return s;
    if (s) {
      const i = e[s] * n, a = t[r][s], o = Math.floor(i / a);
      e[r] += o * n, e[s] -= o * a * n;
    }
    return r;
  }, null), fe.reduce((s, r) => {
    if (O(e[r]))
      return s;
    if (s) {
      const i = e[s] % 1;
      e[s] -= i, e[r] += i * t[s][r];
    }
    return r;
  }, null);
}
function Bi(t) {
  const e = {};
  for (const [n, s] of Object.entries(t))
    s !== 0 && (e[n] = s);
  return e;
}
class D {
  /**
   * @private
   */
  constructor(e) {
    const n = e.conversionAccuracy === "longterm" || !1;
    let s = n ? Wi : $i;
    e.matrix && (s = e.matrix), this.values = e.values, this.loc = e.loc || A.create(), this.conversionAccuracy = n ? "longterm" : "casual", this.invalid = e.invalid || null, this.matrix = s, this.isLuxonDuration = !0;
  }
  /**
   * Create Duration from a number of milliseconds.
   * @param {number} count of milliseconds
   * @param {Object} opts - options for parsing
   * @param {string} [opts.locale='en-US'] - the locale to use
   * @param {string} opts.numberingSystem - the numbering system to use
   * @param {string} [opts.conversionAccuracy='casual'] - the conversion system to use
   * @return {Duration}
   */
  static fromMillis(e, n) {
    return D.fromObject({ milliseconds: e }, n);
  }
  /**
   * Create a Duration from a JavaScript object with keys like 'years' and 'hours'.
   * If this object is empty then a zero milliseconds duration is returned.
   * @param {Object} obj - the object to create the DateTime from
   * @param {number} obj.years
   * @param {number} obj.quarters
   * @param {number} obj.months
   * @param {number} obj.weeks
   * @param {number} obj.days
   * @param {number} obj.hours
   * @param {number} obj.minutes
   * @param {number} obj.seconds
   * @param {number} obj.milliseconds
   * @param {Object} [opts=[]] - options for creating this Duration
   * @param {string} [opts.locale='en-US'] - the locale to use
   * @param {string} opts.numberingSystem - the numbering system to use
   * @param {string} [opts.conversionAccuracy='casual'] - the preset conversion system to use
   * @param {string} [opts.matrix=Object] - the custom conversion system to use
   * @return {Duration}
   */
  static fromObject(e, n = {}) {
    if (e == null || typeof e != "object")
      throw new Z(
        `Duration.fromObject: argument expected to be an object, got ${e === null ? "null" : typeof e}`
      );
    return new D({
      values: lt(e, D.normalizeUnit),
      loc: A.fromObject(n),
      conversionAccuracy: n.conversionAccuracy,
      matrix: n.matrix
    });
  }
  /**
   * Create a Duration from DurationLike.
   *
   * @param {Object | number | Duration} durationLike
   * One of:
   * - object with keys like 'years' and 'hours'.
   * - number representing milliseconds
   * - Duration instance
   * @return {Duration}
   */
  static fromDurationLike(e) {
    if (ce(e))
      return D.fromMillis(e);
    if (D.isDuration(e))
      return e;
    if (typeof e == "object")
      return D.fromObject(e);
    throw new Z(
      `Unknown duration argument ${e} of type ${typeof e}`
    );
  }
  /**
   * Create a Duration from an ISO 8601 duration string.
   * @param {string} text - text to parse
   * @param {Object} opts - options for parsing
   * @param {string} [opts.locale='en-US'] - the locale to use
   * @param {string} opts.numberingSystem - the numbering system to use
   * @param {string} [opts.conversionAccuracy='casual'] - the preset conversion system to use
   * @param {string} [opts.matrix=Object] - the preset conversion system to use
   * @see https://en.wikipedia.org/wiki/ISO_8601#Durations
   * @example Duration.fromISO('P3Y6M1W4DT12H30M5S').toObject() //=> { years: 3, months: 6, weeks: 1, days: 4, hours: 12, minutes: 30, seconds: 5 }
   * @example Duration.fromISO('PT23H').toObject() //=> { hours: 23 }
   * @example Duration.fromISO('P5Y3M').toObject() //=> { years: 5, months: 3 }
   * @return {Duration}
   */
  static fromISO(e, n) {
    const [s] = _i(e);
    return s ? D.fromObject(s, n) : D.invalid("unparsable", `the input "${e}" can't be parsed as ISO 8601`);
  }
  /**
   * Create a Duration from an ISO 8601 time string.
   * @param {string} text - text to parse
   * @param {Object} opts - options for parsing
   * @param {string} [opts.locale='en-US'] - the locale to use
   * @param {string} opts.numberingSystem - the numbering system to use
   * @param {string} [opts.conversionAccuracy='casual'] - the preset conversion system to use
   * @param {string} [opts.matrix=Object] - the conversion system to use
   * @see https://en.wikipedia.org/wiki/ISO_8601#Times
   * @example Duration.fromISOTime('11:22:33.444').toObject() //=> { hours: 11, minutes: 22, seconds: 33, milliseconds: 444 }
   * @example Duration.fromISOTime('11:00').toObject() //=> { hours: 11, minutes: 0, seconds: 0 }
   * @example Duration.fromISOTime('T11:00').toObject() //=> { hours: 11, minutes: 0, seconds: 0 }
   * @example Duration.fromISOTime('1100').toObject() //=> { hours: 11, minutes: 0, seconds: 0 }
   * @example Duration.fromISOTime('T1100').toObject() //=> { hours: 11, minutes: 0, seconds: 0 }
   * @return {Duration}
   */
  static fromISOTime(e, n) {
    const [s] = Li(e);
    return s ? D.fromObject(s, n) : D.invalid("unparsable", `the input "${e}" can't be parsed as ISO 8601`);
  }
  /**
   * Create an invalid Duration.
   * @param {string} reason - simple string of why this datetime is invalid. Should not contain parameters or anything else data-dependent
   * @param {string} [explanation=null] - longer explanation, may include parameters and other useful debugging information
   * @return {Duration}
   */
  static invalid(e, n = null) {
    if (!e)
      throw new Z("need to specify a reason the Duration is invalid");
    const s = e instanceof te ? e : new te(e, n);
    if (L.throwOnInvalid)
      throw new fr(s);
    return new D({ invalid: s });
  }
  /**
   * @private
   */
  static normalizeUnit(e) {
    const n = {
      year: "years",
      years: "years",
      quarter: "quarters",
      quarters: "quarters",
      month: "months",
      months: "months",
      week: "weeks",
      weeks: "weeks",
      day: "days",
      days: "days",
      hour: "hours",
      hours: "hours",
      minute: "minutes",
      minutes: "minutes",
      second: "seconds",
      seconds: "seconds",
      millisecond: "milliseconds",
      milliseconds: "milliseconds"
    }[e && e.toLowerCase()];
    if (!n) throw new Zn(e);
    return n;
  }
  /**
   * Check if an object is a Duration. Works across context boundaries
   * @param {object} o
   * @return {boolean}
   */
  static isDuration(e) {
    return e && e.isLuxonDuration || !1;
  }
  /**
   * Get  the locale of a Duration, such 'en-GB'
   * @type {string}
   */
  get locale() {
    return this.isValid ? this.loc.locale : null;
  }
  /**
   * Get the numbering system of a Duration, such 'beng'. The numbering system is used when formatting the Duration
   *
   * @type {string}
   */
  get numberingSystem() {
    return this.isValid ? this.loc.numberingSystem : null;
  }
  /**
   * Returns a string representation of this Duration formatted according to the specified format string. You may use these tokens:
   * * `S` for milliseconds
   * * `s` for seconds
   * * `m` for minutes
   * * `h` for hours
   * * `d` for days
   * * `w` for weeks
   * * `M` for months
   * * `y` for years
   * Notes:
   * * Add padding by repeating the token, e.g. "yy" pads the years to two digits, "hhhh" pads the hours out to four digits
   * * Tokens can be escaped by wrapping with single quotes.
   * * The duration will be converted to the set of units in the format string using {@link Duration#shiftTo} and the Durations's conversion accuracy setting.
   * @param {string} fmt - the format string
   * @param {Object} opts - options
   * @param {boolean} [opts.floor=true] - floor numerical values
   * @example Duration.fromObject({ years: 1, days: 6, seconds: 2 }).toFormat("y d s") //=> "1 6 2"
   * @example Duration.fromObject({ years: 1, days: 6, seconds: 2 }).toFormat("yy dd sss") //=> "01 06 002"
   * @example Duration.fromObject({ years: 1, days: 6, seconds: 2 }).toFormat("M S") //=> "12 518402000"
   * @return {string}
   */
  toFormat(e, n = {}) {
    const s = {
      ...n,
      floor: n.round !== !1 && n.floor !== !1
    };
    return this.isValid ? q.create(this.loc, s).formatDurationFromString(this, e) : bn;
  }
  /**
   * Returns a string representation of a Duration with all units included.
   * To modify its behavior, use `listStyle` and any Intl.NumberFormat option, though `unitDisplay` is especially relevant.
   * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Intl/NumberFormat/NumberFormat#options
   * @param {Object} opts - Formatting options. Accepts the same keys as the options parameter of the native `Intl.NumberFormat` constructor, as well as `listStyle`.
   * @param {string} [opts.listStyle='narrow'] - How to format the merged list. Corresponds to the `style` property of the options parameter of the native `Intl.ListFormat` constructor.
   * @example
   * ```js
   * var dur = Duration.fromObject({ days: 1, hours: 5, minutes: 6 })
   * dur.toHuman() //=> '1 day, 5 hours, 6 minutes'
   * dur.toHuman({ listStyle: "long" }) //=> '1 day, 5 hours, and 6 minutes'
   * dur.toHuman({ unitDisplay: "short" }) //=> '1 day, 5 hr, 6 min'
   * ```
   */
  toHuman(e = {}) {
    if (!this.isValid) return bn;
    const n = fe.map((s) => {
      const r = this.values[s];
      return O(r) ? null : this.loc.numberFormatter({ style: "unit", unitDisplay: "long", ...e, unit: s.slice(0, -1) }).format(r);
    }).filter((s) => s);
    return this.loc.listFormatter({ type: "conjunction", style: e.listStyle || "narrow", ...e }).format(n);
  }
  /**
   * Returns a JavaScript object with this Duration's values.
   * @example Duration.fromObject({ years: 1, days: 6, seconds: 2 }).toObject() //=> { years: 1, days: 6, seconds: 2 }
   * @return {Object}
   */
  toObject() {
    return this.isValid ? { ...this.values } : {};
  }
  /**
   * Returns an ISO 8601-compliant string representation of this Duration.
   * @see https://en.wikipedia.org/wiki/ISO_8601#Durations
   * @example Duration.fromObject({ years: 3, seconds: 45 }).toISO() //=> 'P3YT45S'
   * @example Duration.fromObject({ months: 4, seconds: 45 }).toISO() //=> 'P4MT45S'
   * @example Duration.fromObject({ months: 5 }).toISO() //=> 'P5M'
   * @example Duration.fromObject({ minutes: 5 }).toISO() //=> 'PT5M'
   * @example Duration.fromObject({ milliseconds: 6 }).toISO() //=> 'PT0.006S'
   * @return {string}
   */
  toISO() {
    if (!this.isValid) return null;
    let e = "P";
    return this.years !== 0 && (e += this.years + "Y"), (this.months !== 0 || this.quarters !== 0) && (e += this.months + this.quarters * 3 + "M"), this.weeks !== 0 && (e += this.weeks + "W"), this.days !== 0 && (e += this.days + "D"), (this.hours !== 0 || this.minutes !== 0 || this.seconds !== 0 || this.milliseconds !== 0) && (e += "T"), this.hours !== 0 && (e += this.hours + "H"), this.minutes !== 0 && (e += this.minutes + "M"), (this.seconds !== 0 || this.milliseconds !== 0) && (e += Xt(this.seconds + this.milliseconds / 1e3, 3) + "S"), e === "P" && (e += "T0S"), e;
  }
  /**
   * Returns an ISO 8601-compliant string representation of this Duration, formatted as a time of day.
   * Note that this will return null if the duration is invalid, negative, or equal to or greater than 24 hours.
   * @see https://en.wikipedia.org/wiki/ISO_8601#Times
   * @param {Object} opts - options
   * @param {boolean} [opts.suppressMilliseconds=false] - exclude milliseconds from the format if they're 0
   * @param {boolean} [opts.suppressSeconds=false] - exclude seconds from the format if they're 0
   * @param {boolean} [opts.includePrefix=false] - include the `T` prefix
   * @param {string} [opts.format='extended'] - choose between the basic and extended format
   * @example Duration.fromObject({ hours: 11 }).toISOTime() //=> '11:00:00.000'
   * @example Duration.fromObject({ hours: 11 }).toISOTime({ suppressMilliseconds: true }) //=> '11:00:00'
   * @example Duration.fromObject({ hours: 11 }).toISOTime({ suppressSeconds: true }) //=> '11:00'
   * @example Duration.fromObject({ hours: 11 }).toISOTime({ includePrefix: true }) //=> 'T11:00:00.000'
   * @example Duration.fromObject({ hours: 11 }).toISOTime({ format: 'basic' }) //=> '110000.000'
   * @return {string}
   */
  toISOTime(e = {}) {
    if (!this.isValid) return null;
    const n = this.toMillis();
    return n < 0 || n >= 864e5 ? null : (e = {
      suppressMilliseconds: !1,
      suppressSeconds: !1,
      includePrefix: !1,
      format: "extended",
      ...e,
      includeOffset: !1
    }, w.fromMillis(n, { zone: "UTC" }).toISOTime(e));
  }
  /**
   * Returns an ISO 8601 representation of this Duration appropriate for use in JSON.
   * @return {string}
   */
  toJSON() {
    return this.toISO();
  }
  /**
   * Returns an ISO 8601 representation of this Duration appropriate for use in debugging.
   * @return {string}
   */
  toString() {
    return this.toISO();
  }
  /**
   * Returns a string representation of this Duration appropriate for the REPL.
   * @return {string}
   */
  [Symbol.for("nodejs.util.inspect.custom")]() {
    return this.isValid ? `Duration { values: ${JSON.stringify(this.values)} }` : `Duration { Invalid, reason: ${this.invalidReason} }`;
  }
  /**
   * Returns an milliseconds value of this Duration.
   * @return {number}
   */
  toMillis() {
    return this.isValid ? Ls(this.matrix, this.values) : NaN;
  }
  /**
   * Returns an milliseconds value of this Duration. Alias of {@link toMillis}
   * @return {number}
   */
  valueOf() {
    return this.toMillis();
  }
  /**
   * Make this Duration longer by the specified amount. Return a newly-constructed Duration.
   * @param {Duration|Object|number} duration - The amount to add. Either a Luxon Duration, a number of milliseconds, the object argument to Duration.fromObject()
   * @return {Duration}
   */
  plus(e) {
    if (!this.isValid) return this;
    const n = D.fromDurationLike(e), s = {};
    for (const r of fe)
      (Se(n.values, r) || Se(this.values, r)) && (s[r] = n.get(r) + this.get(r));
    return ae(this, { values: s }, !0);
  }
  /**
   * Make this Duration shorter by the specified amount. Return a newly-constructed Duration.
   * @param {Duration|Object|number} duration - The amount to subtract. Either a Luxon Duration, a number of milliseconds, the object argument to Duration.fromObject()
   * @return {Duration}
   */
  minus(e) {
    if (!this.isValid) return this;
    const n = D.fromDurationLike(e);
    return this.plus(n.negate());
  }
  /**
   * Scale this Duration by the specified amount. Return a newly-constructed Duration.
   * @param {function} fn - The function to apply to each unit. Arity is 1 or 2: the value of the unit and, optionally, the unit name. Must return a number.
   * @example Duration.fromObject({ hours: 1, minutes: 30 }).mapUnits(x => x * 2) //=> { hours: 2, minutes: 60 }
   * @example Duration.fromObject({ hours: 1, minutes: 30 }).mapUnits((x, u) => u === "hours" ? x * 2 : x) //=> { hours: 2, minutes: 30 }
   * @return {Duration}
   */
  mapUnits(e) {
    if (!this.isValid) return this;
    const n = {};
    for (const s of Object.keys(this.values))
      n[s] = ws(e(this.values[s], s));
    return ae(this, { values: n }, !0);
  }
  /**
   * Get the value of unit.
   * @param {string} unit - a unit such as 'minute' or 'day'
   * @example Duration.fromObject({years: 2, days: 3}).get('years') //=> 2
   * @example Duration.fromObject({years: 2, days: 3}).get('months') //=> 0
   * @example Duration.fromObject({years: 2, days: 3}).get('days') //=> 3
   * @return {number}
   */
  get(e) {
    return this[D.normalizeUnit(e)];
  }
  /**
   * "Set" the values of specified units. Return a newly-constructed Duration.
   * @param {Object} values - a mapping of units to numbers
   * @example dur.set({ years: 2017 })
   * @example dur.set({ hours: 8, minutes: 30 })
   * @return {Duration}
   */
  set(e) {
    if (!this.isValid) return this;
    const n = { ...this.values, ...lt(e, D.normalizeUnit) };
    return ae(this, { values: n });
  }
  /**
   * "Set" the locale and/or numberingSystem.  Returns a newly-constructed Duration.
   * @example dur.reconfigure({ locale: 'en-GB' })
   * @return {Duration}
   */
  reconfigure({ locale: e, numberingSystem: n, conversionAccuracy: s, matrix: r } = {}) {
    const a = { loc: this.loc.clone({ locale: e, numberingSystem: n }), matrix: r, conversionAccuracy: s };
    return ae(this, a);
  }
  /**
   * Return the length of the duration in the specified unit.
   * @param {string} unit - a unit such as 'minutes' or 'days'
   * @example Duration.fromObject({years: 1}).as('days') //=> 365
   * @example Duration.fromObject({years: 1}).as('months') //=> 12
   * @example Duration.fromObject({hours: 60}).as('days') //=> 2.5
   * @return {number}
   */
  as(e) {
    return this.isValid ? this.shiftTo(e).get(e) : NaN;
  }
  /**
   * Reduce this Duration to its canonical representation in its current units.
   * Assuming the overall value of the Duration is positive, this means:
   * - excessive values for lower-order units are converted to higher-order units (if possible, see first and second example)
   * - negative lower-order units are converted to higher order units (there must be such a higher order unit, otherwise
   *   the overall value would be negative, see third example)
   * - fractional values for higher-order units are converted to lower-order units (if possible, see fourth example)
   *
   * If the overall value is negative, the result of this method is equivalent to `this.negate().normalize().negate()`.
   * @example Duration.fromObject({ years: 2, days: 5000 }).normalize().toObject() //=> { years: 15, days: 255 }
   * @example Duration.fromObject({ days: 5000 }).normalize().toObject() //=> { days: 5000 }
   * @example Duration.fromObject({ hours: 12, minutes: -45 }).normalize().toObject() //=> { hours: 11, minutes: 15 }
   * @example Duration.fromObject({ years: 2.5, days: 0, hours: 0 }).normalize().toObject() //=> { years: 2, days: 182, hours: 12 }
   * @return {Duration}
   */
  normalize() {
    if (!this.isValid) return this;
    const e = this.toObject();
    return Dn(this.matrix, e), ae(this, { values: e }, !0);
  }
  /**
   * Rescale units to its largest representation
   * @example Duration.fromObject({ milliseconds: 90000 }).rescale().toObject() //=> { minutes: 1, seconds: 30 }
   * @return {Duration}
   */
  rescale() {
    if (!this.isValid) return this;
    const e = Bi(this.normalize().shiftToAll().toObject());
    return ae(this, { values: e }, !0);
  }
  /**
   * Convert this Duration into its representation in a different set of units.
   * @example Duration.fromObject({ hours: 1, seconds: 30 }).shiftTo('minutes', 'milliseconds').toObject() //=> { minutes: 60, milliseconds: 30000 }
   * @return {Duration}
   */
  shiftTo(...e) {
    if (!this.isValid) return this;
    if (e.length === 0)
      return this;
    e = e.map((a) => D.normalizeUnit(a));
    const n = {}, s = {}, r = this.toObject();
    let i;
    for (const a of fe)
      if (e.indexOf(a) >= 0) {
        i = a;
        let o = 0;
        for (const c in s)
          o += this.matrix[c][a] * s[c], s[c] = 0;
        ce(r[a]) && (o += r[a]);
        const u = Math.trunc(o);
        n[a] = u, s[a] = (o * 1e3 - u * 1e3) / 1e3;
      } else ce(r[a]) && (s[a] = r[a]);
    for (const a in s)
      s[a] !== 0 && (n[i] += a === i ? s[a] : s[a] / this.matrix[i][a]);
    return Dn(this.matrix, n), ae(this, { values: n }, !0);
  }
  /**
   * Shift this Duration to all available units.
   * Same as shiftTo("years", "months", "weeks", "days", "hours", "minutes", "seconds", "milliseconds")
   * @return {Duration}
   */
  shiftToAll() {
    return this.isValid ? this.shiftTo(
      "years",
      "months",
      "weeks",
      "days",
      "hours",
      "minutes",
      "seconds",
      "milliseconds"
    ) : this;
  }
  /**
   * Return the negative of this Duration.
   * @example Duration.fromObject({ hours: 1, seconds: 30 }).negate().toObject() //=> { hours: -1, seconds: -30 }
   * @return {Duration}
   */
  negate() {
    if (!this.isValid) return this;
    const e = {};
    for (const n of Object.keys(this.values))
      e[n] = this.values[n] === 0 ? 0 : -this.values[n];
    return ae(this, { values: e }, !0);
  }
  /**
   * Get the years.
   * @type {number}
   */
  get years() {
    return this.isValid ? this.values.years || 0 : NaN;
  }
  /**
   * Get the quarters.
   * @type {number}
   */
  get quarters() {
    return this.isValid ? this.values.quarters || 0 : NaN;
  }
  /**
   * Get the months.
   * @type {number}
   */
  get months() {
    return this.isValid ? this.values.months || 0 : NaN;
  }
  /**
   * Get the weeks
   * @type {number}
   */
  get weeks() {
    return this.isValid ? this.values.weeks || 0 : NaN;
  }
  /**
   * Get the days.
   * @type {number}
   */
  get days() {
    return this.isValid ? this.values.days || 0 : NaN;
  }
  /**
   * Get the hours.
   * @type {number}
   */
  get hours() {
    return this.isValid ? this.values.hours || 0 : NaN;
  }
  /**
   * Get the minutes.
   * @type {number}
   */
  get minutes() {
    return this.isValid ? this.values.minutes || 0 : NaN;
  }
  /**
   * Get the seconds.
   * @return {number}
   */
  get seconds() {
    return this.isValid ? this.values.seconds || 0 : NaN;
  }
  /**
   * Get the milliseconds.
   * @return {number}
   */
  get milliseconds() {
    return this.isValid ? this.values.milliseconds || 0 : NaN;
  }
  /**
   * Returns whether the Duration is invalid. Invalid durations are returned by diff operations
   * on invalid DateTimes or Intervals.
   * @return {boolean}
   */
  get isValid() {
    return this.invalid === null;
  }
  /**
   * Returns an error code if this Duration became invalid, or null if the Duration is valid
   * @return {string}
   */
  get invalidReason() {
    return this.invalid ? this.invalid.reason : null;
  }
  /**
   * Returns an explanation of why this Duration became invalid, or null if the Duration is valid
   * @type {string}
   */
  get invalidExplanation() {
    return this.invalid ? this.invalid.explanation : null;
  }
  /**
   * Equality check
   * Two Durations are equal iff they have the same units and the same values for each unit.
   * @param {Duration} other
   * @return {boolean}
   */
  equals(e) {
    if (!this.isValid || !e.isValid || !this.loc.equals(e.loc))
      return !1;
    function n(s, r) {
      return s === void 0 || s === 0 ? r === void 0 || r === 0 : s === r;
    }
    for (const s of fe)
      if (!n(this.values[s], e.values[s]))
        return !1;
    return !0;
  }
}
const ge = "Invalid Interval";
function Yi(t, e) {
  return !t || !t.isValid ? F.invalid("missing or invalid start") : !e || !e.isValid ? F.invalid("missing or invalid end") : e < t ? F.invalid(
    "end before start",
    `The end of an interval must be after its start, but you had start=${t.toISO()} and end=${e.toISO()}`
  ) : null;
}
class F {
  /**
   * @private
   */
  constructor(e) {
    this.s = e.start, this.e = e.end, this.invalid = e.invalid || null, this.isLuxonInterval = !0;
  }
  /**
   * Create an invalid Interval.
   * @param {string} reason - simple string of why this Interval is invalid. Should not contain parameters or anything else data-dependent
   * @param {string} [explanation=null] - longer explanation, may include parameters and other useful debugging information
   * @return {Interval}
   */
  static invalid(e, n = null) {
    if (!e)
      throw new Z("need to specify a reason the Interval is invalid");
    const s = e instanceof te ? e : new te(e, n);
    if (L.throwOnInvalid)
      throw new dr(s);
    return new F({ invalid: s });
  }
  /**
   * Create an Interval from a start DateTime and an end DateTime. Inclusive of the start but not the end.
   * @param {DateTime|Date|Object} start
   * @param {DateTime|Date|Object} end
   * @return {Interval}
   */
  static fromDateTimes(e, n) {
    const s = Me(e), r = Me(n), i = Yi(s, r);
    return i ?? new F({
      start: s,
      end: r
    });
  }
  /**
   * Create an Interval from a start DateTime and a Duration to extend to.
   * @param {DateTime|Date|Object} start
   * @param {Duration|Object|number} duration - the length of the Interval.
   * @return {Interval}
   */
  static after(e, n) {
    const s = D.fromDurationLike(n), r = Me(e);
    return F.fromDateTimes(r, r.plus(s));
  }
  /**
   * Create an Interval from an end DateTime and a Duration to extend backwards to.
   * @param {DateTime|Date|Object} end
   * @param {Duration|Object|number} duration - the length of the Interval.
   * @return {Interval}
   */
  static before(e, n) {
    const s = D.fromDurationLike(n), r = Me(e);
    return F.fromDateTimes(r.minus(s), r);
  }
  /**
   * Create an Interval from an ISO 8601 string.
   * Accepts `<start>/<end>`, `<start>/<duration>`, and `<duration>/<end>` formats.
   * @param {string} text - the ISO string to parse
   * @param {Object} [opts] - options to pass {@link DateTime#fromISO} and optionally {@link Duration#fromISO}
   * @see https://en.wikipedia.org/wiki/ISO_8601#Time_intervals
   * @return {Interval}
   */
  static fromISO(e, n) {
    const [s, r] = (e || "").split("/", 2);
    if (s && r) {
      let i, a;
      try {
        i = w.fromISO(s, n), a = i.isValid;
      } catch {
        a = !1;
      }
      let o, u;
      try {
        o = w.fromISO(r, n), u = o.isValid;
      } catch {
        u = !1;
      }
      if (a && u)
        return F.fromDateTimes(i, o);
      if (a) {
        const c = D.fromISO(r, n);
        if (c.isValid)
          return F.after(i, c);
      } else if (u) {
        const c = D.fromISO(s, n);
        if (c.isValid)
          return F.before(o, c);
      }
    }
    return F.invalid("unparsable", `the input "${e}" can't be parsed as ISO 8601`);
  }
  /**
   * Check if an object is an Interval. Works across context boundaries
   * @param {object} o
   * @return {boolean}
   */
  static isInterval(e) {
    return e && e.isLuxonInterval || !1;
  }
  /**
   * Returns the start of the Interval
   * @type {DateTime}
   */
  get start() {
    return this.isValid ? this.s : null;
  }
  /**
   * Returns the end of the Interval
   * @type {DateTime}
   */
  get end() {
    return this.isValid ? this.e : null;
  }
  /**
   * Returns whether this Interval's end is at least its start, meaning that the Interval isn't 'backwards'.
   * @type {boolean}
   */
  get isValid() {
    return this.invalidReason === null;
  }
  /**
   * Returns an error code if this Interval is invalid, or null if the Interval is valid
   * @type {string}
   */
  get invalidReason() {
    return this.invalid ? this.invalid.reason : null;
  }
  /**
   * Returns an explanation of why this Interval became invalid, or null if the Interval is valid
   * @type {string}
   */
  get invalidExplanation() {
    return this.invalid ? this.invalid.explanation : null;
  }
  /**
   * Returns the length of the Interval in the specified unit.
   * @param {string} unit - the unit (such as 'hours' or 'days') to return the length in.
   * @return {number}
   */
  length(e = "milliseconds") {
    return this.isValid ? this.toDuration(e).get(e) : NaN;
  }
  /**
   * Returns the count of minutes, hours, days, months, or years included in the Interval, even in part.
   * Unlike {@link Interval#length} this counts sections of the calendar, not periods of time, e.g. specifying 'day'
   * asks 'what dates are included in this interval?', not 'how many days long is this interval?'
   * @param {string} [unit='milliseconds'] - the unit of time to count.
   * @param {Object} opts - options
   * @param {boolean} [opts.useLocaleWeeks=false] - If true, use weeks based on the locale, i.e. use the locale-dependent start of the week; this operation will always use the locale of the start DateTime
   * @return {number}
   */
  count(e = "milliseconds", n) {
    if (!this.isValid) return NaN;
    const s = this.start.startOf(e, n);
    let r;
    return n?.useLocaleWeeks ? r = this.end.reconfigure({ locale: s.locale }) : r = this.end, r = r.startOf(e, n), Math.floor(r.diff(s, e).get(e)) + (r.valueOf() !== this.end.valueOf());
  }
  /**
   * Returns whether this Interval's start and end are both in the same unit of time
   * @param {string} unit - the unit of time to check sameness on
   * @return {boolean}
   */
  hasSame(e) {
    return this.isValid ? this.isEmpty() || this.e.minus(1).hasSame(this.s, e) : !1;
  }
  /**
   * Return whether this Interval has the same start and end DateTimes.
   * @return {boolean}
   */
  isEmpty() {
    return this.s.valueOf() === this.e.valueOf();
  }
  /**
   * Return whether this Interval's start is after the specified DateTime.
   * @param {DateTime} dateTime
   * @return {boolean}
   */
  isAfter(e) {
    return this.isValid ? this.s > e : !1;
  }
  /**
   * Return whether this Interval's end is before the specified DateTime.
   * @param {DateTime} dateTime
   * @return {boolean}
   */
  isBefore(e) {
    return this.isValid ? this.e <= e : !1;
  }
  /**
   * Return whether this Interval contains the specified DateTime.
   * @param {DateTime} dateTime
   * @return {boolean}
   */
  contains(e) {
    return this.isValid ? this.s <= e && this.e > e : !1;
  }
  /**
   * "Sets" the start and/or end dates. Returns a newly-constructed Interval.
   * @param {Object} values - the values to set
   * @param {DateTime} values.start - the starting DateTime
   * @param {DateTime} values.end - the ending DateTime
   * @return {Interval}
   */
  set({ start: e, end: n } = {}) {
    return this.isValid ? F.fromDateTimes(e || this.s, n || this.e) : this;
  }
  /**
   * Split this Interval at each of the specified DateTimes
   * @param {...DateTime} dateTimes - the unit of time to count.
   * @return {Array}
   */
  splitAt(...e) {
    if (!this.isValid) return [];
    const n = e.map(Me).filter((a) => this.contains(a)).sort((a, o) => a.toMillis() - o.toMillis()), s = [];
    let { s: r } = this, i = 0;
    for (; r < this.e; ) {
      const a = n[i] || this.e, o = +a > +this.e ? this.e : a;
      s.push(F.fromDateTimes(r, o)), r = o, i += 1;
    }
    return s;
  }
  /**
   * Split this Interval into smaller Intervals, each of the specified length.
   * Left over time is grouped into a smaller interval
   * @param {Duration|Object|number} duration - The length of each resulting interval.
   * @return {Array}
   */
  splitBy(e) {
    const n = D.fromDurationLike(e);
    if (!this.isValid || !n.isValid || n.as("milliseconds") === 0)
      return [];
    let { s } = this, r = 1, i;
    const a = [];
    for (; s < this.e; ) {
      const o = this.start.plus(n.mapUnits((u) => u * r));
      i = +o > +this.e ? this.e : o, a.push(F.fromDateTimes(s, i)), s = i, r += 1;
    }
    return a;
  }
  /**
   * Split this Interval into the specified number of smaller intervals.
   * @param {number} numberOfParts - The number of Intervals to divide the Interval into.
   * @return {Array}
   */
  divideEqually(e) {
    return this.isValid ? this.splitBy(this.length() / e).slice(0, e) : [];
  }
  /**
   * Return whether this Interval overlaps with the specified Interval
   * @param {Interval} other
   * @return {boolean}
   */
  overlaps(e) {
    return this.e > e.s && this.s < e.e;
  }
  /**
   * Return whether this Interval's end is adjacent to the specified Interval's start.
   * @param {Interval} other
   * @return {boolean}
   */
  abutsStart(e) {
    return this.isValid ? +this.e == +e.s : !1;
  }
  /**
   * Return whether this Interval's start is adjacent to the specified Interval's end.
   * @param {Interval} other
   * @return {boolean}
   */
  abutsEnd(e) {
    return this.isValid ? +e.e == +this.s : !1;
  }
  /**
   * Returns true if this Interval fully contains the specified Interval, specifically if the intersect (of this Interval and the other Interval) is equal to the other Interval; false otherwise.
   * @param {Interval} other
   * @return {boolean}
   */
  engulfs(e) {
    return this.isValid ? this.s <= e.s && this.e >= e.e : !1;
  }
  /**
   * Return whether this Interval has the same start and end as the specified Interval.
   * @param {Interval} other
   * @return {boolean}
   */
  equals(e) {
    return !this.isValid || !e.isValid ? !1 : this.s.equals(e.s) && this.e.equals(e.e);
  }
  /**
   * Return an Interval representing the intersection of this Interval and the specified Interval.
   * Specifically, the resulting Interval has the maximum start time and the minimum end time of the two Intervals.
   * Returns null if the intersection is empty, meaning, the intervals don't intersect.
   * @param {Interval} other
   * @return {Interval}
   */
  intersection(e) {
    if (!this.isValid) return this;
    const n = this.s > e.s ? this.s : e.s, s = this.e < e.e ? this.e : e.e;
    return n >= s ? null : F.fromDateTimes(n, s);
  }
  /**
   * Return an Interval representing the union of this Interval and the specified Interval.
   * Specifically, the resulting Interval has the minimum start time and the maximum end time of the two Intervals.
   * @param {Interval} other
   * @return {Interval}
   */
  union(e) {
    if (!this.isValid) return this;
    const n = this.s < e.s ? this.s : e.s, s = this.e > e.e ? this.e : e.e;
    return F.fromDateTimes(n, s);
  }
  /**
   * Merge an array of Intervals into a equivalent minimal set of Intervals.
   * Combines overlapping and adjacent Intervals.
   * @param {Array} intervals
   * @return {Array}
   */
  static merge(e) {
    const [n, s] = e.sort((r, i) => r.s - i.s).reduce(
      ([r, i], a) => i ? i.overlaps(a) || i.abutsStart(a) ? [r, i.union(a)] : [r.concat([i]), a] : [r, a],
      [[], null]
    );
    return s && n.push(s), n;
  }
  /**
   * Return an array of Intervals representing the spans of time that only appear in one of the specified Intervals.
   * @param {Array} intervals
   * @return {Array}
   */
  static xor(e) {
    let n = null, s = 0;
    const r = [], i = e.map((u) => [
      { time: u.s, type: "s" },
      { time: u.e, type: "e" }
    ]), a = Array.prototype.concat(...i), o = a.sort((u, c) => u.time - c.time);
    for (const u of o)
      s += u.type === "s" ? 1 : -1, s === 1 ? n = u.time : (n && +n != +u.time && r.push(F.fromDateTimes(n, u.time)), n = null);
    return F.merge(r);
  }
  /**
   * Return an Interval representing the span of time in this Interval that doesn't overlap with any of the specified Intervals.
   * @param {...Interval} intervals
   * @return {Array}
   */
  difference(...e) {
    return F.xor([this].concat(e)).map((n) => this.intersection(n)).filter((n) => n && !n.isEmpty());
  }
  /**
   * Returns a string representation of this Interval appropriate for debugging.
   * @return {string}
   */
  toString() {
    return this.isValid ? `[${this.s.toISO()} – ${this.e.toISO()})` : ge;
  }
  /**
   * Returns a string representation of this Interval appropriate for the REPL.
   * @return {string}
   */
  [Symbol.for("nodejs.util.inspect.custom")]() {
    return this.isValid ? `Interval { start: ${this.s.toISO()}, end: ${this.e.toISO()} }` : `Interval { Invalid, reason: ${this.invalidReason} }`;
  }
  /**
   * Returns a localized string representing this Interval. Accepts the same options as the
   * Intl.DateTimeFormat constructor and any presets defined by Luxon, such as
   * {@link DateTime.DATE_FULL} or {@link DateTime.TIME_SIMPLE}. The exact behavior of this method
   * is browser-specific, but in general it will return an appropriate representation of the
   * Interval in the assigned locale. Defaults to the system's locale if no locale has been
   * specified.
   * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DateTimeFormat
   * @param {Object} [formatOpts=DateTime.DATE_SHORT] - Either a DateTime preset or
   * Intl.DateTimeFormat constructor options.
   * @param {Object} opts - Options to override the configuration of the start DateTime.
   * @example Interval.fromISO('2022-11-07T09:00Z/2022-11-08T09:00Z').toLocaleString(); //=> 11/7/2022 – 11/8/2022
   * @example Interval.fromISO('2022-11-07T09:00Z/2022-11-08T09:00Z').toLocaleString(DateTime.DATE_FULL); //=> November 7 – 8, 2022
   * @example Interval.fromISO('2022-11-07T09:00Z/2022-11-08T09:00Z').toLocaleString(DateTime.DATE_FULL, { locale: 'fr-FR' }); //=> 7–8 novembre 2022
   * @example Interval.fromISO('2022-11-07T17:00Z/2022-11-07T19:00Z').toLocaleString(DateTime.TIME_SIMPLE); //=> 6:00 – 8:00 PM
   * @example Interval.fromISO('2022-11-07T17:00Z/2022-11-07T19:00Z').toLocaleString({ weekday: 'short', month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit' }); //=> Mon, Nov 07, 6:00 – 8:00 p
   * @return {string}
   */
  toLocaleString(e = ot, n = {}) {
    return this.isValid ? q.create(this.s.loc.clone(n), e).formatInterval(this) : ge;
  }
  /**
   * Returns an ISO 8601-compliant string representation of this Interval.
   * @see https://en.wikipedia.org/wiki/ISO_8601#Time_intervals
   * @param {Object} opts - The same options as {@link DateTime#toISO}
   * @return {string}
   */
  toISO(e) {
    return this.isValid ? `${this.s.toISO(e)}/${this.e.toISO(e)}` : ge;
  }
  /**
   * Returns an ISO 8601-compliant string representation of date of this Interval.
   * The time components are ignored.
   * @see https://en.wikipedia.org/wiki/ISO_8601#Time_intervals
   * @return {string}
   */
  toISODate() {
    return this.isValid ? `${this.s.toISODate()}/${this.e.toISODate()}` : ge;
  }
  /**
   * Returns an ISO 8601-compliant string representation of time of this Interval.
   * The date components are ignored.
   * @see https://en.wikipedia.org/wiki/ISO_8601#Time_intervals
   * @param {Object} opts - The same options as {@link DateTime#toISO}
   * @return {string}
   */
  toISOTime(e) {
    return this.isValid ? `${this.s.toISOTime(e)}/${this.e.toISOTime(e)}` : ge;
  }
  /**
   * Returns a string representation of this Interval formatted according to the specified format
   * string. **You may not want this.** See {@link Interval#toLocaleString} for a more flexible
   * formatting tool.
   * @param {string} dateFormat - The format string. This string formats the start and end time.
   * See {@link DateTime#toFormat} for details.
   * @param {Object} opts - Options.
   * @param {string} [opts.separator =  ' – '] - A separator to place between the start and end
   * representations.
   * @return {string}
   */
  toFormat(e, { separator: n = " – " } = {}) {
    return this.isValid ? `${this.s.toFormat(e)}${n}${this.e.toFormat(e)}` : ge;
  }
  /**
   * Return a Duration representing the time spanned by this interval.
   * @param {string|string[]} [unit=['milliseconds']] - the unit or units (such as 'hours' or 'days') to include in the duration.
   * @param {Object} opts - options that affect the creation of the Duration
   * @param {string} [opts.conversionAccuracy='casual'] - the conversion system to use
   * @example Interval.fromDateTimes(dt1, dt2).toDuration().toObject() //=> { milliseconds: 88489257 }
   * @example Interval.fromDateTimes(dt1, dt2).toDuration('days').toObject() //=> { days: 1.0241812152777778 }
   * @example Interval.fromDateTimes(dt1, dt2).toDuration(['hours', 'minutes']).toObject() //=> { hours: 24, minutes: 34.82095 }
   * @example Interval.fromDateTimes(dt1, dt2).toDuration(['hours', 'minutes', 'seconds']).toObject() //=> { hours: 24, minutes: 34, seconds: 49.257 }
   * @example Interval.fromDateTimes(dt1, dt2).toDuration('seconds').toObject() //=> { seconds: 88489.257 }
   * @return {Duration}
   */
  toDuration(e, n) {
    return this.isValid ? this.e.diff(this.s, e, n) : D.invalid(this.invalidReason);
  }
  /**
   * Run mapFn on the interval start and end, returning a new Interval from the resulting DateTimes
   * @param {function} mapFn
   * @return {Interval}
   * @example Interval.fromDateTimes(dt1, dt2).mapEndpoints(endpoint => endpoint.toUTC())
   * @example Interval.fromDateTimes(dt1, dt2).mapEndpoints(endpoint => endpoint.plus({ hours: 2 }))
   */
  mapEndpoints(e) {
    return F.fromDateTimes(e(this.s), e(this.e));
  }
}
class Ge {
  /**
   * Return whether the specified zone contains a DST.
   * @param {string|Zone} [zone='local'] - Zone to check. Defaults to the environment's local zone.
   * @return {boolean}
   */
  static hasDST(e = L.defaultZone) {
    const n = w.now().setZone(e).set({ month: 12 });
    return !e.isUniversal && n.offset !== n.set({ month: 6 }).offset;
  }
  /**
   * Return whether the specified zone is a valid IANA specifier.
   * @param {string} zone - Zone to check
   * @return {boolean}
   */
  static isValidIANAZone(e) {
    return re.isValidZone(e);
  }
  /**
   * Converts the input into a {@link Zone} instance.
   *
   * * If `input` is already a Zone instance, it is returned unchanged.
   * * If `input` is a string containing a valid time zone name, a Zone instance
   *   with that name is returned.
   * * If `input` is a string that doesn't refer to a known time zone, a Zone
   *   instance with {@link Zone#isValid} == false is returned.
   * * If `input is a number, a Zone instance with the specified fixed offset
   *   in minutes is returned.
   * * If `input` is `null` or `undefined`, the default zone is returned.
   * @param {string|Zone|number} [input] - the value to be converted
   * @return {Zone}
   */
  static normalizeZone(e) {
    return ue(e, L.defaultZone);
  }
  /**
   * Get the weekday on which the week starts according to the given locale.
   * @param {Object} opts - options
   * @param {string} [opts.locale] - the locale code
   * @param {string} [opts.locObj=null] - an existing locale object to use
   * @returns {number} the start of the week, 1 for Monday through 7 for Sunday
   */
  static getStartOfWeek({ locale: e = null, locObj: n = null } = {}) {
    return (n || A.create(e)).getStartOfWeek();
  }
  /**
   * Get the minimum number of days necessary in a week before it is considered part of the next year according
   * to the given locale.
   * @param {Object} opts - options
   * @param {string} [opts.locale] - the locale code
   * @param {string} [opts.locObj=null] - an existing locale object to use
   * @returns {number}
   */
  static getMinimumDaysInFirstWeek({ locale: e = null, locObj: n = null } = {}) {
    return (n || A.create(e)).getMinDaysInFirstWeek();
  }
  /**
   * Get the weekdays, which are considered the weekend according to the given locale
   * @param {Object} opts - options
   * @param {string} [opts.locale] - the locale code
   * @param {string} [opts.locObj=null] - an existing locale object to use
   * @returns {number[]} an array of weekdays, 1 for Monday through 7 for Sunday
   */
  static getWeekendWeekdays({ locale: e = null, locObj: n = null } = {}) {
    return (n || A.create(e)).getWeekendDays().slice();
  }
  /**
   * Return an array of standalone month names.
   * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DateTimeFormat
   * @param {string} [length='long'] - the length of the month representation, such as "numeric", "2-digit", "narrow", "short", "long"
   * @param {Object} opts - options
   * @param {string} [opts.locale] - the locale code
   * @param {string} [opts.numberingSystem=null] - the numbering system
   * @param {string} [opts.locObj=null] - an existing locale object to use
   * @param {string} [opts.outputCalendar='gregory'] - the calendar
   * @example Info.months()[0] //=> 'January'
   * @example Info.months('short')[0] //=> 'Jan'
   * @example Info.months('numeric')[0] //=> '1'
   * @example Info.months('short', { locale: 'fr-CA' } )[0] //=> 'janv.'
   * @example Info.months('numeric', { locale: 'ar' })[0] //=> '١'
   * @example Info.months('long', { outputCalendar: 'islamic' })[0] //=> 'Rabiʻ I'
   * @return {Array}
   */
  static months(e = "long", { locale: n = null, numberingSystem: s = null, locObj: r = null, outputCalendar: i = "gregory" } = {}) {
    return (r || A.create(n, s, i)).months(e);
  }
  /**
   * Return an array of format month names.
   * Format months differ from standalone months in that they're meant to appear next to the day of the month. In some languages, that
   * changes the string.
   * See {@link Info#months}
   * @param {string} [length='long'] - the length of the month representation, such as "numeric", "2-digit", "narrow", "short", "long"
   * @param {Object} opts - options
   * @param {string} [opts.locale] - the locale code
   * @param {string} [opts.numberingSystem=null] - the numbering system
   * @param {string} [opts.locObj=null] - an existing locale object to use
   * @param {string} [opts.outputCalendar='gregory'] - the calendar
   * @return {Array}
   */
  static monthsFormat(e = "long", { locale: n = null, numberingSystem: s = null, locObj: r = null, outputCalendar: i = "gregory" } = {}) {
    return (r || A.create(n, s, i)).months(e, !0);
  }
  /**
   * Return an array of standalone week names.
   * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DateTimeFormat
   * @param {string} [length='long'] - the length of the weekday representation, such as "narrow", "short", "long".
   * @param {Object} opts - options
   * @param {string} [opts.locale] - the locale code
   * @param {string} [opts.numberingSystem=null] - the numbering system
   * @param {string} [opts.locObj=null] - an existing locale object to use
   * @example Info.weekdays()[0] //=> 'Monday'
   * @example Info.weekdays('short')[0] //=> 'Mon'
   * @example Info.weekdays('short', { locale: 'fr-CA' })[0] //=> 'lun.'
   * @example Info.weekdays('short', { locale: 'ar' })[0] //=> 'الاثنين'
   * @return {Array}
   */
  static weekdays(e = "long", { locale: n = null, numberingSystem: s = null, locObj: r = null } = {}) {
    return (r || A.create(n, s, null)).weekdays(e);
  }
  /**
   * Return an array of format week names.
   * Format weekdays differ from standalone weekdays in that they're meant to appear next to more date information. In some languages, that
   * changes the string.
   * See {@link Info#weekdays}
   * @param {string} [length='long'] - the length of the month representation, such as "narrow", "short", "long".
   * @param {Object} opts - options
   * @param {string} [opts.locale=null] - the locale code
   * @param {string} [opts.numberingSystem=null] - the numbering system
   * @param {string} [opts.locObj=null] - an existing locale object to use
   * @return {Array}
   */
  static weekdaysFormat(e = "long", { locale: n = null, numberingSystem: s = null, locObj: r = null } = {}) {
    return (r || A.create(n, s, null)).weekdays(e, !0);
  }
  /**
   * Return an array of meridiems.
   * @param {Object} opts - options
   * @param {string} [opts.locale] - the locale code
   * @example Info.meridiems() //=> [ 'AM', 'PM' ]
   * @example Info.meridiems({ locale: 'my' }) //=> [ 'နံနက်', 'ညနေ' ]
   * @return {Array}
   */
  static meridiems({ locale: e = null } = {}) {
    return A.create(e).meridiems();
  }
  /**
   * Return an array of eras, such as ['BC', 'AD']. The locale can be specified, but the calendar system is always Gregorian.
   * @param {string} [length='short'] - the length of the era representation, such as "short" or "long".
   * @param {Object} opts - options
   * @param {string} [opts.locale] - the locale code
   * @example Info.eras() //=> [ 'BC', 'AD' ]
   * @example Info.eras('long') //=> [ 'Before Christ', 'Anno Domini' ]
   * @example Info.eras('long', { locale: 'fr' }) //=> [ 'avant Jésus-Christ', 'après Jésus-Christ' ]
   * @return {Array}
   */
  static eras(e = "short", { locale: n = null } = {}) {
    return A.create(n, null, "gregory").eras(e);
  }
  /**
   * Return the set of available features in this environment.
   * Some features of Luxon are not available in all environments. For example, on older browsers, relative time formatting support is not available. Use this function to figure out if that's the case.
   * Keys:
   * * `relative`: whether this environment supports relative time formatting
   * * `localeWeek`: whether this environment supports different weekdays for the start of the week based on the locale
   * @example Info.features() //=> { relative: false, localeWeek: true }
   * @return {Object}
   */
  static features() {
    return { relative: Es(), localeWeek: gs() };
  }
}
function xn(t, e) {
  const n = (r) => r.toUTC(0, { keepLocalTime: !0 }).startOf("day").valueOf(), s = n(e) - n(t);
  return Math.floor(D.fromMillis(s).as("days"));
}
function Zi(t, e, n) {
  const s = [
    ["years", (u, c) => c.year - u.year],
    ["quarters", (u, c) => c.quarter - u.quarter + (c.year - u.year) * 4],
    ["months", (u, c) => c.month - u.month + (c.year - u.year) * 12],
    [
      "weeks",
      (u, c) => {
        const h = xn(u, c);
        return (h - h % 7) / 7;
      }
    ],
    ["days", xn]
  ], r = {}, i = t;
  let a, o;
  for (const [u, c] of s)
    n.indexOf(u) >= 0 && (a = u, r[u] = c(t, e), o = i.plus(r), o > e ? (r[u]--, t = i.plus(r), t > e && (o = t, r[u]--, t = i.plus(r))) : t = o);
  return [t, r, o, a];
}
function qi(t, e, n, s) {
  let [r, i, a, o] = Zi(t, e, n);
  const u = e - r, c = n.filter(
    (p) => ["hours", "minutes", "seconds", "milliseconds"].indexOf(p) >= 0
  );
  c.length === 0 && (a < e && (a = r.plus({ [o]: 1 })), a !== r && (i[o] = (i[o] || 0) + u / (a - r)));
  const h = D.fromObject(i, s);
  return c.length > 0 ? D.fromMillis(u, s).shiftTo(...c).plus(h) : h;
}
const zi = "missing Intl.DateTimeFormat.formatToParts support";
function x(t, e = (n) => n) {
  return { regex: t, deser: ([n]) => e(Rr(n)) };
}
const ji = " ", Rs = `[ ${ji}]`, Vs = new RegExp(Rs, "g");
function Gi(t) {
  return t.replace(/\./g, "\\.?").replace(Vs, Rs);
}
function An(t) {
  return t.replace(/\./g, "").replace(Vs, " ").toLowerCase();
}
function ee(t, e) {
  return t === null ? null : {
    regex: RegExp(t.map(Gi).join("|")),
    deser: ([n]) => t.findIndex((s) => An(n) === An(s)) + e
  };
}
function Cn(t, e) {
  return { regex: t, deser: ([, n, s]) => gt(n, s), groups: e };
}
function Je(t) {
  return { regex: t, deser: ([e]) => e };
}
function Ji(t) {
  return t.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g, "\\$&");
}
function Qi(t, e) {
  const n = K(e), s = K(e, "{2}"), r = K(e, "{3}"), i = K(e, "{4}"), a = K(e, "{6}"), o = K(e, "{1,2}"), u = K(e, "{1,3}"), c = K(e, "{1,6}"), h = K(e, "{1,9}"), p = K(e, "{2,4}"), v = K(e, "{4,6}"), E = (m) => ({ regex: RegExp(Ji(m.val)), deser: ([d]) => d, literal: !0 }), y = ((m) => {
    if (t.literal)
      return E(m);
    switch (m.val) {
      case "G":
        return ee(e.eras("short"), 0);
      case "GG":
        return ee(e.eras("long"), 0);
      case "y":
        return x(c);
      case "yy":
        return x(p, Yt);
      case "yyyy":
        return x(i);
      case "yyyyy":
        return x(v);
      case "yyyyyy":
        return x(a);
      case "M":
        return x(o);
      case "MM":
        return x(s);
      case "MMM":
        return ee(e.months("short", !0), 1);
      case "MMMM":
        return ee(e.months("long", !0), 1);
      case "L":
        return x(o);
      case "LL":
        return x(s);
      case "LLL":
        return ee(e.months("short", !1), 1);
      case "LLLL":
        return ee(e.months("long", !1), 1);
      case "d":
        return x(o);
      case "dd":
        return x(s);
      case "o":
        return x(u);
      case "ooo":
        return x(r);
      case "HH":
        return x(s);
      case "H":
        return x(o);
      case "hh":
        return x(s);
      case "h":
        return x(o);
      case "mm":
        return x(s);
      case "m":
        return x(o);
      case "q":
        return x(o);
      case "qq":
        return x(s);
      case "s":
        return x(o);
      case "ss":
        return x(s);
      case "S":
        return x(u);
      case "SSS":
        return x(r);
      case "u":
        return Je(h);
      case "uu":
        return Je(o);
      case "uuu":
        return x(n);
      case "a":
        return ee(e.meridiems(), 0);
      case "kkkk":
        return x(i);
      case "kk":
        return x(p, Yt);
      case "W":
        return x(o);
      case "WW":
        return x(s);
      case "E":
      case "c":
        return x(n);
      case "EEE":
        return ee(e.weekdays("short", !1), 1);
      case "EEEE":
        return ee(e.weekdays("long", !1), 1);
      case "ccc":
        return ee(e.weekdays("short", !0), 1);
      case "cccc":
        return ee(e.weekdays("long", !0), 1);
      case "Z":
      case "ZZ":
        return Cn(new RegExp(`([+-]${o.source})(?::(${s.source}))?`), 2);
      case "ZZZ":
        return Cn(new RegExp(`([+-]${o.source})(${s.source})?`), 2);
      case "z":
        return Je(/[a-z_+-/]{1,256}?/i);
      case " ":
        return Je(/[^\S\n\r]/);
      default:
        return E(m);
    }
  })(t) || {
    invalidReason: zi
  };
  return y.token = t, y;
}
const Xi = {
  year: {
    "2-digit": "yy",
    numeric: "yyyyy"
  },
  month: {
    numeric: "M",
    "2-digit": "MM",
    short: "MMM",
    long: "MMMM"
  },
  day: {
    numeric: "d",
    "2-digit": "dd"
  },
  weekday: {
    short: "EEE",
    long: "EEEE"
  },
  dayperiod: "a",
  dayPeriod: "a",
  hour12: {
    numeric: "h",
    "2-digit": "hh"
  },
  hour24: {
    numeric: "H",
    "2-digit": "HH"
  },
  minute: {
    numeric: "m",
    "2-digit": "mm"
  },
  second: {
    numeric: "s",
    "2-digit": "ss"
  },
  timeZoneName: {
    long: "ZZZZZ",
    short: "ZZZ"
  }
};
function Ki(t, e, n) {
  const { type: s, value: r } = t;
  if (s === "literal") {
    const u = /^\s+$/.test(r);
    return {
      literal: !u,
      val: u ? " " : r
    };
  }
  const i = e[s];
  let a = s;
  s === "hour" && (e.hour12 != null ? a = e.hour12 ? "hour12" : "hour24" : e.hourCycle != null ? e.hourCycle === "h11" || e.hourCycle === "h12" ? a = "hour12" : a = "hour24" : a = n.hour12 ? "hour12" : "hour24");
  let o = Xi[a];
  if (typeof o == "object" && (o = o[i]), o)
    return {
      literal: !1,
      val: o
    };
}
function ea(t) {
  return [`^${t.map((n) => n.regex).reduce((n, s) => `${n}(${s.source})`, "")}$`, t];
}
function ta(t, e, n) {
  const s = t.match(e);
  if (s) {
    const r = {};
    let i = 1;
    for (const a in n)
      if (Se(n, a)) {
        const o = n[a], u = o.groups ? o.groups + 1 : 1;
        !o.literal && o.token && (r[o.token.val[0]] = o.deser(s.slice(i, i + u))), i += u;
      }
    return [s, r];
  } else
    return [s, {}];
}
function na(t) {
  const e = (i) => {
    switch (i) {
      case "S":
        return "millisecond";
      case "s":
        return "second";
      case "m":
        return "minute";
      case "h":
      case "H":
        return "hour";
      case "d":
        return "day";
      case "o":
        return "ordinal";
      case "L":
      case "M":
        return "month";
      case "y":
        return "year";
      case "E":
      case "c":
        return "weekday";
      case "W":
        return "weekNumber";
      case "k":
        return "weekYear";
      case "q":
        return "quarter";
      default:
        return null;
    }
  };
  let n = null, s;
  return O(t.z) || (n = re.create(t.z)), O(t.Z) || (n || (n = new z(t.Z)), s = t.Z), O(t.q) || (t.M = (t.q - 1) * 3 + 1), O(t.h) || (t.h < 12 && t.a === 1 ? t.h += 12 : t.h === 12 && t.a === 0 && (t.h = 0)), t.G === 0 && t.y && (t.y = -t.y), O(t.u) || (t.S = Qt(t.u)), [Object.keys(t).reduce((i, a) => {
    const o = e(a);
    return o && (i[o] = t[a]), i;
  }, {}), n, s];
}
let Dt = null;
function sa() {
  return Dt || (Dt = w.fromMillis(1555555555555)), Dt;
}
function ra(t, e) {
  if (t.literal)
    return t;
  const n = q.macroTokenToFormatOpts(t.val), s = Ws(n, e);
  return s == null || s.includes(void 0) ? t : s;
}
function Ps(t, e) {
  return Array.prototype.concat(...t.map((n) => ra(n, e)));
}
class Us {
  constructor(e, n) {
    if (this.locale = e, this.format = n, this.tokens = Ps(q.parseFormat(n), e), this.units = this.tokens.map((s) => Qi(s, e)), this.disqualifyingUnit = this.units.find((s) => s.invalidReason), !this.disqualifyingUnit) {
      const [s, r] = ea(this.units);
      this.regex = RegExp(s, "i"), this.handlers = r;
    }
  }
  explainFromTokens(e) {
    if (this.isValid) {
      const [n, s] = ta(e, this.regex, this.handlers), [r, i, a] = s ? na(s) : [null, null, void 0];
      if (Se(s, "a") && Se(s, "H"))
        throw new Oe(
          "Can't include meridiem when specifying 24-hour format"
        );
      return {
        input: e,
        tokens: this.tokens,
        regex: this.regex,
        rawMatches: n,
        matches: s,
        result: r,
        zone: i,
        specificOffset: a
      };
    } else
      return { input: e, tokens: this.tokens, invalidReason: this.invalidReason };
  }
  get isValid() {
    return !this.disqualifyingUnit;
  }
  get invalidReason() {
    return this.disqualifyingUnit ? this.disqualifyingUnit.invalidReason : null;
  }
}
function $s(t, e, n) {
  return new Us(t, n).explainFromTokens(e);
}
function ia(t, e, n) {
  const { result: s, zone: r, specificOffset: i, invalidReason: a } = $s(t, e, n);
  return [s, r, i, a];
}
function Ws(t, e) {
  if (!t)
    return null;
  const s = q.create(e, t).dtFormatter(sa()), r = s.formatToParts(), i = s.resolvedOptions();
  return r.map((a) => Ki(a, t, i));
}
const xt = "Invalid DateTime", Mn = 864e13;
function Le(t) {
  return new te("unsupported zone", `the zone "${t.name}" is not supported`);
}
function At(t) {
  return t.weekData === null && (t.weekData = ut(t.c)), t.weekData;
}
function Ct(t) {
  return t.localWeekData === null && (t.localWeekData = ut(
    t.c,
    t.loc.getMinDaysInFirstWeek(),
    t.loc.getStartOfWeek()
  )), t.localWeekData;
}
function de(t, e) {
  const n = {
    ts: t.ts,
    zone: t.zone,
    c: t.c,
    o: t.o,
    loc: t.loc,
    invalid: t.invalid
  };
  return new w({ ...n, ...e, old: n });
}
function Hs(t, e, n) {
  let s = t - e * 60 * 1e3;
  const r = n.offset(s);
  if (e === r)
    return [s, e];
  s -= (r - e) * 60 * 1e3;
  const i = n.offset(s);
  return r === i ? [s, r] : [t - Math.min(r, i) * 60 * 1e3, Math.max(r, i)];
}
function Qe(t, e) {
  t += e * 60 * 1e3;
  const n = new Date(t);
  return {
    year: n.getUTCFullYear(),
    month: n.getUTCMonth() + 1,
    day: n.getUTCDate(),
    hour: n.getUTCHours(),
    minute: n.getUTCMinutes(),
    second: n.getUTCSeconds(),
    millisecond: n.getUTCMilliseconds()
  };
}
function tt(t, e, n) {
  return Hs(Et(t), e, n);
}
function _n(t, e) {
  const n = t.o, s = t.c.year + Math.trunc(e.years), r = t.c.month + Math.trunc(e.months) + Math.trunc(e.quarters) * 3, i = {
    ...t.c,
    year: s,
    month: r,
    day: Math.min(t.c.day, ct(s, r)) + Math.trunc(e.days) + Math.trunc(e.weeks) * 7
  }, a = D.fromObject({
    years: e.years - Math.trunc(e.years),
    quarters: e.quarters - Math.trunc(e.quarters),
    months: e.months - Math.trunc(e.months),
    weeks: e.weeks - Math.trunc(e.weeks),
    days: e.days - Math.trunc(e.days),
    hours: e.hours,
    minutes: e.minutes,
    seconds: e.seconds,
    milliseconds: e.milliseconds
  }).as("milliseconds"), o = Et(i);
  let [u, c] = Hs(o, n, t.zone);
  return a !== 0 && (u += a, c = t.zone.offset(u)), { ts: u, o: c };
}
function Te(t, e, n, s, r, i) {
  const { setZone: a, zone: o } = n;
  if (t && Object.keys(t).length !== 0 || e) {
    const u = e || o, c = w.fromObject(t, {
      ...n,
      zone: u,
      specificOffset: i
    });
    return a ? c : c.setZone(o);
  } else
    return w.invalid(
      new te("unparsable", `the input "${r}" can't be parsed as ${s}`)
    );
}
function Xe(t, e, n = !0) {
  return t.isValid ? q.create(A.create("en-US"), {
    allowZ: n,
    forceSimple: !0
  }).formatDateTimeFromString(t, e) : null;
}
function Mt(t, e) {
  const n = t.c.year > 9999 || t.c.year < 0;
  let s = "";
  return n && t.c.year >= 0 && (s += "+"), s += U(t.c.year, n ? 6 : 4), e ? (s += "-", s += U(t.c.month), s += "-", s += U(t.c.day)) : (s += U(t.c.month), s += U(t.c.day)), s;
}
function Fn(t, e, n, s, r, i) {
  let a = U(t.c.hour);
  return e ? (a += ":", a += U(t.c.minute), (t.c.millisecond !== 0 || t.c.second !== 0 || !n) && (a += ":")) : a += U(t.c.minute), (t.c.millisecond !== 0 || t.c.second !== 0 || !n) && (a += U(t.c.second), (t.c.millisecond !== 0 || !s) && (a += ".", a += U(t.c.millisecond, 3))), r && (t.isOffsetFixed && t.offset === 0 && !i ? a += "Z" : t.o < 0 ? (a += "-", a += U(Math.trunc(-t.o / 60)), a += ":", a += U(Math.trunc(-t.o % 60))) : (a += "+", a += U(Math.trunc(t.o / 60)), a += ":", a += U(Math.trunc(t.o % 60)))), i && (a += "[" + t.zone.ianaName + "]"), a;
}
const Bs = {
  month: 1,
  day: 1,
  hour: 0,
  minute: 0,
  second: 0,
  millisecond: 0
}, aa = {
  weekNumber: 1,
  weekday: 1,
  hour: 0,
  minute: 0,
  second: 0,
  millisecond: 0
}, oa = {
  ordinal: 1,
  hour: 0,
  minute: 0,
  second: 0,
  millisecond: 0
}, Ys = ["year", "month", "day", "hour", "minute", "second", "millisecond"], ua = [
  "weekYear",
  "weekNumber",
  "weekday",
  "hour",
  "minute",
  "second",
  "millisecond"
], ca = ["year", "ordinal", "hour", "minute", "second", "millisecond"];
function la(t) {
  const e = {
    year: "year",
    years: "year",
    month: "month",
    months: "month",
    day: "day",
    days: "day",
    hour: "hour",
    hours: "hour",
    minute: "minute",
    minutes: "minute",
    quarter: "quarter",
    quarters: "quarter",
    second: "second",
    seconds: "second",
    millisecond: "millisecond",
    milliseconds: "millisecond",
    weekday: "weekday",
    weekdays: "weekday",
    weeknumber: "weekNumber",
    weeksnumber: "weekNumber",
    weeknumbers: "weekNumber",
    weekyear: "weekYear",
    weekyears: "weekYear",
    ordinal: "ordinal"
  }[t.toLowerCase()];
  if (!e) throw new Zn(t);
  return e;
}
function Ln(t) {
  switch (t.toLowerCase()) {
    case "localweekday":
    case "localweekdays":
      return "localWeekday";
    case "localweeknumber":
    case "localweeknumbers":
      return "localWeekNumber";
    case "localweekyear":
    case "localweekyears":
      return "localWeekYear";
    default:
      return la(t);
  }
}
function ha(t) {
  return st[t] || (nt === void 0 && (nt = L.now()), st[t] = t.offset(nt)), st[t];
}
function Rn(t, e) {
  const n = ue(e.zone, L.defaultZone);
  if (!n.isValid)
    return w.invalid(Le(n));
  const s = A.fromObject(e);
  let r, i;
  if (O(t.year))
    r = L.now();
  else {
    for (const u of Ys)
      O(t[u]) && (t[u] = Bs[u]);
    const a = ps(t) || ys(t);
    if (a)
      return w.invalid(a);
    const o = ha(n);
    [r, i] = tt(t, o, n);
  }
  return new w({ ts: r, zone: n, loc: s, o: i });
}
function Vn(t, e, n) {
  const s = O(n.round) ? !0 : n.round, r = (a, o) => (a = Xt(a, s || n.calendary ? 0 : 2, !0), e.loc.clone(n).relFormatter(n).format(a, o)), i = (a) => n.calendary ? e.hasSame(t, a) ? 0 : e.startOf(a).diff(t.startOf(a), a).get(a) : e.diff(t, a).get(a);
  if (n.unit)
    return r(i(n.unit), n.unit);
  for (const a of n.units) {
    const o = i(a);
    if (Math.abs(o) >= 1)
      return r(o, a);
  }
  return r(t > e ? -0 : 0, n.units[n.units.length - 1]);
}
function Pn(t) {
  let e = {}, n;
  return t.length > 0 && typeof t[t.length - 1] == "object" ? (e = t[t.length - 1], n = Array.from(t).slice(0, t.length - 1)) : n = Array.from(t), [e, n];
}
let nt, st = {};
class w {
  /**
   * @access private
   */
  constructor(e) {
    const n = e.zone || L.defaultZone;
    let s = e.invalid || (Number.isNaN(e.ts) ? new te("invalid input") : null) || (n.isValid ? null : Le(n));
    this.ts = O(e.ts) ? L.now() : e.ts;
    let r = null, i = null;
    if (!s)
      if (e.old && e.old.ts === this.ts && e.old.zone.equals(n))
        [r, i] = [e.old.c, e.old.o];
      else {
        const o = ce(e.o) && !e.old ? e.o : n.offset(this.ts);
        r = Qe(this.ts, o), s = Number.isNaN(r.year) ? new te("invalid input") : null, r = s ? null : r, i = s ? null : o;
      }
    this._zone = n, this.loc = e.loc || A.create(), this.invalid = s, this.weekData = null, this.localWeekData = null, this.c = r, this.o = i, this.isLuxonDateTime = !0;
  }
  // CONSTRUCT
  /**
   * Create a DateTime for the current instant, in the system's time zone.
   *
   * Use Settings to override these default values if needed.
   * @example DateTime.now().toISO() //~> now in the ISO format
   * @return {DateTime}
   */
  static now() {
    return new w({});
  }
  /**
   * Create a local DateTime
   * @param {number} [year] - The calendar year. If omitted (as in, call `local()` with no arguments), the current time will be used
   * @param {number} [month=1] - The month, 1-indexed
   * @param {number} [day=1] - The day of the month, 1-indexed
   * @param {number} [hour=0] - The hour of the day, in 24-hour time
   * @param {number} [minute=0] - The minute of the hour, meaning a number between 0 and 59
   * @param {number} [second=0] - The second of the minute, meaning a number between 0 and 59
   * @param {number} [millisecond=0] - The millisecond of the second, meaning a number between 0 and 999
   * @example DateTime.local()                                  //~> now
   * @example DateTime.local({ zone: "America/New_York" })      //~> now, in US east coast time
   * @example DateTime.local(2017)                              //~> 2017-01-01T00:00:00
   * @example DateTime.local(2017, 3)                           //~> 2017-03-01T00:00:00
   * @example DateTime.local(2017, 3, 12, { locale: "fr" })     //~> 2017-03-12T00:00:00, with a French locale
   * @example DateTime.local(2017, 3, 12, 5)                    //~> 2017-03-12T05:00:00
   * @example DateTime.local(2017, 3, 12, 5, { zone: "utc" })   //~> 2017-03-12T05:00:00, in UTC
   * @example DateTime.local(2017, 3, 12, 5, 45)                //~> 2017-03-12T05:45:00
   * @example DateTime.local(2017, 3, 12, 5, 45, 10)            //~> 2017-03-12T05:45:10
   * @example DateTime.local(2017, 3, 12, 5, 45, 10, 765)       //~> 2017-03-12T05:45:10.765
   * @return {DateTime}
   */
  static local() {
    const [e, n] = Pn(arguments), [s, r, i, a, o, u, c] = n;
    return Rn({ year: s, month: r, day: i, hour: a, minute: o, second: u, millisecond: c }, e);
  }
  /**
   * Create a DateTime in UTC
   * @param {number} [year] - The calendar year. If omitted (as in, call `utc()` with no arguments), the current time will be used
   * @param {number} [month=1] - The month, 1-indexed
   * @param {number} [day=1] - The day of the month
   * @param {number} [hour=0] - The hour of the day, in 24-hour time
   * @param {number} [minute=0] - The minute of the hour, meaning a number between 0 and 59
   * @param {number} [second=0] - The second of the minute, meaning a number between 0 and 59
   * @param {number} [millisecond=0] - The millisecond of the second, meaning a number between 0 and 999
   * @param {Object} options - configuration options for the DateTime
   * @param {string} [options.locale] - a locale to set on the resulting DateTime instance
   * @param {string} [options.outputCalendar] - the output calendar to set on the resulting DateTime instance
   * @param {string} [options.numberingSystem] - the numbering system to set on the resulting DateTime instance
   * @param {string} [options.weekSettings] - the week settings to set on the resulting DateTime instance
   * @example DateTime.utc()                                              //~> now
   * @example DateTime.utc(2017)                                          //~> 2017-01-01T00:00:00Z
   * @example DateTime.utc(2017, 3)                                       //~> 2017-03-01T00:00:00Z
   * @example DateTime.utc(2017, 3, 12)                                   //~> 2017-03-12T00:00:00Z
   * @example DateTime.utc(2017, 3, 12, 5)                                //~> 2017-03-12T05:00:00Z
   * @example DateTime.utc(2017, 3, 12, 5, 45)                            //~> 2017-03-12T05:45:00Z
   * @example DateTime.utc(2017, 3, 12, 5, 45, { locale: "fr" })          //~> 2017-03-12T05:45:00Z with a French locale
   * @example DateTime.utc(2017, 3, 12, 5, 45, 10)                        //~> 2017-03-12T05:45:10Z
   * @example DateTime.utc(2017, 3, 12, 5, 45, 10, 765, { locale: "fr" }) //~> 2017-03-12T05:45:10.765Z with a French locale
   * @return {DateTime}
   */
  static utc() {
    const [e, n] = Pn(arguments), [s, r, i, a, o, u, c] = n;
    return e.zone = z.utcInstance, Rn({ year: s, month: r, day: i, hour: a, minute: o, second: u, millisecond: c }, e);
  }
  /**
   * Create a DateTime from a JavaScript Date object. Uses the default zone.
   * @param {Date} date - a JavaScript Date object
   * @param {Object} options - configuration options for the DateTime
   * @param {string|Zone} [options.zone='local'] - the zone to place the DateTime into
   * @return {DateTime}
   */
  static fromJSDate(e, n = {}) {
    const s = Wr(e) ? e.valueOf() : NaN;
    if (Number.isNaN(s))
      return w.invalid("invalid input");
    const r = ue(n.zone, L.defaultZone);
    return r.isValid ? new w({
      ts: s,
      zone: r,
      loc: A.fromObject(n)
    }) : w.invalid(Le(r));
  }
  /**
   * Create a DateTime from a number of milliseconds since the epoch (meaning since 1 January 1970 00:00:00 UTC). Uses the default zone.
   * @param {number} milliseconds - a number of milliseconds since 1970 UTC
   * @param {Object} options - configuration options for the DateTime
   * @param {string|Zone} [options.zone='local'] - the zone to place the DateTime into
   * @param {string} [options.locale] - a locale to set on the resulting DateTime instance
   * @param {string} options.outputCalendar - the output calendar to set on the resulting DateTime instance
   * @param {string} options.numberingSystem - the numbering system to set on the resulting DateTime instance
   * @param {string} options.weekSettings - the week settings to set on the resulting DateTime instance
   * @return {DateTime}
   */
  static fromMillis(e, n = {}) {
    if (ce(e))
      return e < -Mn || e > Mn ? w.invalid("Timestamp out of range") : new w({
        ts: e,
        zone: ue(n.zone, L.defaultZone),
        loc: A.fromObject(n)
      });
    throw new Z(
      `fromMillis requires a numerical input, but received a ${typeof e} with value ${e}`
    );
  }
  /**
   * Create a DateTime from a number of seconds since the epoch (meaning since 1 January 1970 00:00:00 UTC). Uses the default zone.
   * @param {number} seconds - a number of seconds since 1970 UTC
   * @param {Object} options - configuration options for the DateTime
   * @param {string|Zone} [options.zone='local'] - the zone to place the DateTime into
   * @param {string} [options.locale] - a locale to set on the resulting DateTime instance
   * @param {string} options.outputCalendar - the output calendar to set on the resulting DateTime instance
   * @param {string} options.numberingSystem - the numbering system to set on the resulting DateTime instance
   * @param {string} options.weekSettings - the week settings to set on the resulting DateTime instance
   * @return {DateTime}
   */
  static fromSeconds(e, n = {}) {
    if (ce(e))
      return new w({
        ts: e * 1e3,
        zone: ue(n.zone, L.defaultZone),
        loc: A.fromObject(n)
      });
    throw new Z("fromSeconds requires a numerical input");
  }
  /**
   * Create a DateTime from a JavaScript object with keys like 'year' and 'hour' with reasonable defaults.
   * @param {Object} obj - the object to create the DateTime from
   * @param {number} obj.year - a year, such as 1987
   * @param {number} obj.month - a month, 1-12
   * @param {number} obj.day - a day of the month, 1-31, depending on the month
   * @param {number} obj.ordinal - day of the year, 1-365 or 366
   * @param {number} obj.weekYear - an ISO week year
   * @param {number} obj.weekNumber - an ISO week number, between 1 and 52 or 53, depending on the year
   * @param {number} obj.weekday - an ISO weekday, 1-7, where 1 is Monday and 7 is Sunday
   * @param {number} obj.localWeekYear - a week year, according to the locale
   * @param {number} obj.localWeekNumber - a week number, between 1 and 52 or 53, depending on the year, according to the locale
   * @param {number} obj.localWeekday - a weekday, 1-7, where 1 is the first and 7 is the last day of the week, according to the locale
   * @param {number} obj.hour - hour of the day, 0-23
   * @param {number} obj.minute - minute of the hour, 0-59
   * @param {number} obj.second - second of the minute, 0-59
   * @param {number} obj.millisecond - millisecond of the second, 0-999
   * @param {Object} opts - options for creating this DateTime
   * @param {string|Zone} [opts.zone='local'] - interpret the numbers in the context of a particular zone. Can take any value taken as the first argument to setZone()
   * @param {string} [opts.locale='system\'s locale'] - a locale to set on the resulting DateTime instance
   * @param {string} opts.outputCalendar - the output calendar to set on the resulting DateTime instance
   * @param {string} opts.numberingSystem - the numbering system to set on the resulting DateTime instance
   * @param {string} opts.weekSettings - the week settings to set on the resulting DateTime instance
   * @example DateTime.fromObject({ year: 1982, month: 5, day: 25}).toISODate() //=> '1982-05-25'
   * @example DateTime.fromObject({ year: 1982 }).toISODate() //=> '1982-01-01'
   * @example DateTime.fromObject({ hour: 10, minute: 26, second: 6 }) //~> today at 10:26:06
   * @example DateTime.fromObject({ hour: 10, minute: 26, second: 6 }, { zone: 'utc' }),
   * @example DateTime.fromObject({ hour: 10, minute: 26, second: 6 }, { zone: 'local' })
   * @example DateTime.fromObject({ hour: 10, minute: 26, second: 6 }, { zone: 'America/New_York' })
   * @example DateTime.fromObject({ weekYear: 2016, weekNumber: 2, weekday: 3 }).toISODate() //=> '2016-01-13'
   * @example DateTime.fromObject({ localWeekYear: 2022, localWeekNumber: 1, localWeekday: 1 }, { locale: "en-US" }).toISODate() //=> '2021-12-26'
   * @return {DateTime}
   */
  static fromObject(e, n = {}) {
    e = e || {};
    const s = ue(n.zone, L.defaultZone);
    if (!s.isValid)
      return w.invalid(Le(s));
    const r = A.fromObject(n), i = lt(e, Ln), { minDaysInFirstWeek: a, startOfWeek: o } = Nn(i, r), u = L.now(), c = O(n.specificOffset) ? s.offset(u) : n.specificOffset, h = !O(i.ordinal), p = !O(i.year), v = !O(i.month) || !O(i.day), E = p || v, N = i.weekYear || i.weekNumber;
    if ((E || h) && N)
      throw new Oe(
        "Can't mix weekYear/weekNumber units with year/month/day or ordinals"
      );
    if (v && h)
      throw new Oe("Can't mix ordinal dates with month/day");
    const y = N || i.weekday && !E;
    let m, d, g = Qe(u, c);
    y ? (m = ua, d = aa, g = ut(g, a, o)) : h ? (m = ca, d = oa, g = bt(g)) : (m = Ys, d = Bs);
    let b = !1;
    for (const V of m) {
      const B = i[V];
      O(B) ? b ? i[V] = d[V] : i[V] = g[V] : b = !0;
    }
    const S = y ? Pr(i, a, o) : h ? Ur(i) : ps(i), C = S || ys(i);
    if (C)
      return w.invalid(C);
    const M = y ? wn(i, a, o) : h ? On(i) : i, [R, _] = tt(M, c, s), k = new w({
      ts: R,
      zone: s,
      o: _,
      loc: r
    });
    return i.weekday && E && e.weekday !== k.weekday ? w.invalid(
      "mismatched weekday",
      `you can't specify both a weekday of ${i.weekday} and a date of ${k.toISO()}`
    ) : k.isValid ? k : w.invalid(k.invalid);
  }
  /**
   * Create a DateTime from an ISO 8601 string
   * @param {string} text - the ISO string
   * @param {Object} opts - options to affect the creation
   * @param {string|Zone} [opts.zone='local'] - use this zone if no offset is specified in the input string itself. Will also convert the time to this zone
   * @param {boolean} [opts.setZone=false] - override the zone with a fixed-offset zone specified in the string itself, if it specifies one
   * @param {string} [opts.locale='system's locale'] - a locale to set on the resulting DateTime instance
   * @param {string} [opts.outputCalendar] - the output calendar to set on the resulting DateTime instance
   * @param {string} [opts.numberingSystem] - the numbering system to set on the resulting DateTime instance
   * @param {string} [opts.weekSettings] - the week settings to set on the resulting DateTime instance
   * @example DateTime.fromISO('2016-05-25T09:08:34.123')
   * @example DateTime.fromISO('2016-05-25T09:08:34.123+06:00')
   * @example DateTime.fromISO('2016-05-25T09:08:34.123+06:00', {setZone: true})
   * @example DateTime.fromISO('2016-05-25T09:08:34.123', {zone: 'utc'})
   * @example DateTime.fromISO('2016-W05-4')
   * @return {DateTime}
   */
  static fromISO(e, n = {}) {
    const [s, r] = Ai(e);
    return Te(s, r, n, "ISO 8601", e);
  }
  /**
   * Create a DateTime from an RFC 2822 string
   * @param {string} text - the RFC 2822 string
   * @param {Object} opts - options to affect the creation
   * @param {string|Zone} [opts.zone='local'] - convert the time to this zone. Since the offset is always specified in the string itself, this has no effect on the interpretation of string, merely the zone the resulting DateTime is expressed in.
   * @param {boolean} [opts.setZone=false] - override the zone with a fixed-offset zone specified in the string itself, if it specifies one
   * @param {string} [opts.locale='system's locale'] - a locale to set on the resulting DateTime instance
   * @param {string} opts.outputCalendar - the output calendar to set on the resulting DateTime instance
   * @param {string} opts.numberingSystem - the numbering system to set on the resulting DateTime instance
   * @param {string} opts.weekSettings - the week settings to set on the resulting DateTime instance
   * @example DateTime.fromRFC2822('25 Nov 2016 13:23:12 GMT')
   * @example DateTime.fromRFC2822('Fri, 25 Nov 2016 13:23:12 +0600')
   * @example DateTime.fromRFC2822('25 Nov 2016 13:23 Z')
   * @return {DateTime}
   */
  static fromRFC2822(e, n = {}) {
    const [s, r] = Ci(e);
    return Te(s, r, n, "RFC 2822", e);
  }
  /**
   * Create a DateTime from an HTTP header date
   * @see https://www.w3.org/Protocols/rfc2616/rfc2616-sec3.html#sec3.3.1
   * @param {string} text - the HTTP header date
   * @param {Object} opts - options to affect the creation
   * @param {string|Zone} [opts.zone='local'] - convert the time to this zone. Since HTTP dates are always in UTC, this has no effect on the interpretation of string, merely the zone the resulting DateTime is expressed in.
   * @param {boolean} [opts.setZone=false] - override the zone with the fixed-offset zone specified in the string. For HTTP dates, this is always UTC, so this option is equivalent to setting the `zone` option to 'utc', but this option is included for consistency with similar methods.
   * @param {string} [opts.locale='system's locale'] - a locale to set on the resulting DateTime instance
   * @param {string} opts.outputCalendar - the output calendar to set on the resulting DateTime instance
   * @param {string} opts.numberingSystem - the numbering system to set on the resulting DateTime instance
   * @param {string} opts.weekSettings - the week settings to set on the resulting DateTime instance
   * @example DateTime.fromHTTP('Sun, 06 Nov 1994 08:49:37 GMT')
   * @example DateTime.fromHTTP('Sunday, 06-Nov-94 08:49:37 GMT')
   * @example DateTime.fromHTTP('Sun Nov  6 08:49:37 1994')
   * @return {DateTime}
   */
  static fromHTTP(e, n = {}) {
    const [s, r] = Mi(e);
    return Te(s, r, n, "HTTP", n);
  }
  /**
   * Create a DateTime from an input string and format string.
   * Defaults to en-US if no locale has been specified, regardless of the system's locale. For a table of tokens and their interpretations, see [here](https://moment.github.io/luxon/#/parsing?id=table-of-tokens).
   * @param {string} text - the string to parse
   * @param {string} fmt - the format the string is expected to be in (see the link below for the formats)
   * @param {Object} opts - options to affect the creation
   * @param {string|Zone} [opts.zone='local'] - use this zone if no offset is specified in the input string itself. Will also convert the DateTime to this zone
   * @param {boolean} [opts.setZone=false] - override the zone with a zone specified in the string itself, if it specifies one
   * @param {string} [opts.locale='en-US'] - a locale string to use when parsing. Will also set the DateTime to this locale
   * @param {string} opts.numberingSystem - the numbering system to use when parsing. Will also set the resulting DateTime to this numbering system
   * @param {string} opts.weekSettings - the week settings to set on the resulting DateTime instance
   * @param {string} opts.outputCalendar - the output calendar to set on the resulting DateTime instance
   * @return {DateTime}
   */
  static fromFormat(e, n, s = {}) {
    if (O(e) || O(n))
      throw new Z("fromFormat requires an input string and a format");
    const { locale: r = null, numberingSystem: i = null } = s, a = A.fromOpts({
      locale: r,
      numberingSystem: i,
      defaultToEN: !0
    }), [o, u, c, h] = ia(a, e, n);
    return h ? w.invalid(h) : Te(o, u, s, `format ${n}`, e, c);
  }
  /**
   * @deprecated use fromFormat instead
   */
  static fromString(e, n, s = {}) {
    return w.fromFormat(e, n, s);
  }
  /**
   * Create a DateTime from a SQL date, time, or datetime
   * Defaults to en-US if no locale has been specified, regardless of the system's locale
   * @param {string} text - the string to parse
   * @param {Object} opts - options to affect the creation
   * @param {string|Zone} [opts.zone='local'] - use this zone if no offset is specified in the input string itself. Will also convert the DateTime to this zone
   * @param {boolean} [opts.setZone=false] - override the zone with a zone specified in the string itself, if it specifies one
   * @param {string} [opts.locale='en-US'] - a locale string to use when parsing. Will also set the DateTime to this locale
   * @param {string} opts.numberingSystem - the numbering system to use when parsing. Will also set the resulting DateTime to this numbering system
   * @param {string} opts.weekSettings - the week settings to set on the resulting DateTime instance
   * @param {string} opts.outputCalendar - the output calendar to set on the resulting DateTime instance
   * @example DateTime.fromSQL('2017-05-15')
   * @example DateTime.fromSQL('2017-05-15 09:12:34')
   * @example DateTime.fromSQL('2017-05-15 09:12:34.342')
   * @example DateTime.fromSQL('2017-05-15 09:12:34.342+06:00')
   * @example DateTime.fromSQL('2017-05-15 09:12:34.342 America/Los_Angeles')
   * @example DateTime.fromSQL('2017-05-15 09:12:34.342 America/Los_Angeles', { setZone: true })
   * @example DateTime.fromSQL('2017-05-15 09:12:34.342', { zone: 'America/Los_Angeles' })
   * @example DateTime.fromSQL('09:12:34.342')
   * @return {DateTime}
   */
  static fromSQL(e, n = {}) {
    const [s, r] = Ui(e);
    return Te(s, r, n, "SQL", e);
  }
  /**
   * Create an invalid DateTime.
   * @param {string} reason - simple string of why this DateTime is invalid. Should not contain parameters or anything else data-dependent.
   * @param {string} [explanation=null] - longer explanation, may include parameters and other useful debugging information
   * @return {DateTime}
   */
  static invalid(e, n = null) {
    if (!e)
      throw new Z("need to specify a reason the DateTime is invalid");
    const s = e instanceof te ? e : new te(e, n);
    if (L.throwOnInvalid)
      throw new hr(s);
    return new w({ invalid: s });
  }
  /**
   * Check if an object is an instance of DateTime. Works across context boundaries
   * @param {object} o
   * @return {boolean}
   */
  static isDateTime(e) {
    return e && e.isLuxonDateTime || !1;
  }
  /**
   * Produce the format string for a set of options
   * @param formatOpts
   * @param localeOpts
   * @returns {string}
   */
  static parseFormatForOpts(e, n = {}) {
    const s = Ws(e, A.fromObject(n));
    return s ? s.map((r) => r ? r.val : null).join("") : null;
  }
  /**
   * Produce the the fully expanded format token for the locale
   * Does NOT quote characters, so quoted tokens will not round trip correctly
   * @param fmt
   * @param localeOpts
   * @returns {string}
   */
  static expandFormat(e, n = {}) {
    return Ps(q.parseFormat(e), A.fromObject(n)).map((r) => r.val).join("");
  }
  static resetCache() {
    nt = void 0, st = {};
  }
  // INFO
  /**
   * Get the value of unit.
   * @param {string} unit - a unit such as 'minute' or 'day'
   * @example DateTime.local(2017, 7, 4).get('month'); //=> 7
   * @example DateTime.local(2017, 7, 4).get('day'); //=> 4
   * @return {number}
   */
  get(e) {
    return this[e];
  }
  /**
   * Returns whether the DateTime is valid. Invalid DateTimes occur when:
   * * The DateTime was created from invalid calendar information, such as the 13th month or February 30
   * * The DateTime was created by an operation on another invalid date
   * @type {boolean}
   */
  get isValid() {
    return this.invalid === null;
  }
  /**
   * Returns an error code if this DateTime is invalid, or null if the DateTime is valid
   * @type {string}
   */
  get invalidReason() {
    return this.invalid ? this.invalid.reason : null;
  }
  /**
   * Returns an explanation of why this DateTime became invalid, or null if the DateTime is valid
   * @type {string}
   */
  get invalidExplanation() {
    return this.invalid ? this.invalid.explanation : null;
  }
  /**
   * Get the locale of a DateTime, such 'en-GB'. The locale is used when formatting the DateTime
   *
   * @type {string}
   */
  get locale() {
    return this.isValid ? this.loc.locale : null;
  }
  /**
   * Get the numbering system of a DateTime, such 'beng'. The numbering system is used when formatting the DateTime
   *
   * @type {string}
   */
  get numberingSystem() {
    return this.isValid ? this.loc.numberingSystem : null;
  }
  /**
   * Get the output calendar of a DateTime, such 'islamic'. The output calendar is used when formatting the DateTime
   *
   * @type {string}
   */
  get outputCalendar() {
    return this.isValid ? this.loc.outputCalendar : null;
  }
  /**
   * Get the time zone associated with this DateTime.
   * @type {Zone}
   */
  get zone() {
    return this._zone;
  }
  /**
   * Get the name of the time zone.
   * @type {string}
   */
  get zoneName() {
    return this.isValid ? this.zone.name : null;
  }
  /**
   * Get the year
   * @example DateTime.local(2017, 5, 25).year //=> 2017
   * @type {number}
   */
  get year() {
    return this.isValid ? this.c.year : NaN;
  }
  /**
   * Get the quarter
   * @example DateTime.local(2017, 5, 25).quarter //=> 2
   * @type {number}
   */
  get quarter() {
    return this.isValid ? Math.ceil(this.c.month / 3) : NaN;
  }
  /**
   * Get the month (1-12).
   * @example DateTime.local(2017, 5, 25).month //=> 5
   * @type {number}
   */
  get month() {
    return this.isValid ? this.c.month : NaN;
  }
  /**
   * Get the day of the month (1-30ish).
   * @example DateTime.local(2017, 5, 25).day //=> 25
   * @type {number}
   */
  get day() {
    return this.isValid ? this.c.day : NaN;
  }
  /**
   * Get the hour of the day (0-23).
   * @example DateTime.local(2017, 5, 25, 9).hour //=> 9
   * @type {number}
   */
  get hour() {
    return this.isValid ? this.c.hour : NaN;
  }
  /**
   * Get the minute of the hour (0-59).
   * @example DateTime.local(2017, 5, 25, 9, 30).minute //=> 30
   * @type {number}
   */
  get minute() {
    return this.isValid ? this.c.minute : NaN;
  }
  /**
   * Get the second of the minute (0-59).
   * @example DateTime.local(2017, 5, 25, 9, 30, 52).second //=> 52
   * @type {number}
   */
  get second() {
    return this.isValid ? this.c.second : NaN;
  }
  /**
   * Get the millisecond of the second (0-999).
   * @example DateTime.local(2017, 5, 25, 9, 30, 52, 654).millisecond //=> 654
   * @type {number}
   */
  get millisecond() {
    return this.isValid ? this.c.millisecond : NaN;
  }
  /**
   * Get the week year
   * @see https://en.wikipedia.org/wiki/ISO_week_date
   * @example DateTime.local(2014, 12, 31).weekYear //=> 2015
   * @type {number}
   */
  get weekYear() {
    return this.isValid ? At(this).weekYear : NaN;
  }
  /**
   * Get the week number of the week year (1-52ish).
   * @see https://en.wikipedia.org/wiki/ISO_week_date
   * @example DateTime.local(2017, 5, 25).weekNumber //=> 21
   * @type {number}
   */
  get weekNumber() {
    return this.isValid ? At(this).weekNumber : NaN;
  }
  /**
   * Get the day of the week.
   * 1 is Monday and 7 is Sunday
   * @see https://en.wikipedia.org/wiki/ISO_week_date
   * @example DateTime.local(2014, 11, 31).weekday //=> 4
   * @type {number}
   */
  get weekday() {
    return this.isValid ? At(this).weekday : NaN;
  }
  /**
   * Returns true if this date is on a weekend according to the locale, false otherwise
   * @returns {boolean}
   */
  get isWeekend() {
    return this.isValid && this.loc.getWeekendDays().includes(this.weekday);
  }
  /**
   * Get the day of the week according to the locale.
   * 1 is the first day of the week and 7 is the last day of the week.
   * If the locale assigns Sunday as the first day of the week, then a date which is a Sunday will return 1,
   * @returns {number}
   */
  get localWeekday() {
    return this.isValid ? Ct(this).weekday : NaN;
  }
  /**
   * Get the week number of the week year according to the locale. Different locales assign week numbers differently,
   * because the week can start on different days of the week (see localWeekday) and because a different number of days
   * is required for a week to count as the first week of a year.
   * @returns {number}
   */
  get localWeekNumber() {
    return this.isValid ? Ct(this).weekNumber : NaN;
  }
  /**
   * Get the week year according to the locale. Different locales assign week numbers (and therefor week years)
   * differently, see localWeekNumber.
   * @returns {number}
   */
  get localWeekYear() {
    return this.isValid ? Ct(this).weekYear : NaN;
  }
  /**
   * Get the ordinal (meaning the day of the year)
   * @example DateTime.local(2017, 5, 25).ordinal //=> 145
   * @type {number|DateTime}
   */
  get ordinal() {
    return this.isValid ? bt(this.c).ordinal : NaN;
  }
  /**
   * Get the human readable short month name, such as 'Oct'.
   * Defaults to the system's locale if no locale has been specified
   * @example DateTime.local(2017, 10, 30).monthShort //=> Oct
   * @type {string}
   */
  get monthShort() {
    return this.isValid ? Ge.months("short", { locObj: this.loc })[this.month - 1] : null;
  }
  /**
   * Get the human readable long month name, such as 'October'.
   * Defaults to the system's locale if no locale has been specified
   * @example DateTime.local(2017, 10, 30).monthLong //=> October
   * @type {string}
   */
  get monthLong() {
    return this.isValid ? Ge.months("long", { locObj: this.loc })[this.month - 1] : null;
  }
  /**
   * Get the human readable short weekday, such as 'Mon'.
   * Defaults to the system's locale if no locale has been specified
   * @example DateTime.local(2017, 10, 30).weekdayShort //=> Mon
   * @type {string}
   */
  get weekdayShort() {
    return this.isValid ? Ge.weekdays("short", { locObj: this.loc })[this.weekday - 1] : null;
  }
  /**
   * Get the human readable long weekday, such as 'Monday'.
   * Defaults to the system's locale if no locale has been specified
   * @example DateTime.local(2017, 10, 30).weekdayLong //=> Monday
   * @type {string}
   */
  get weekdayLong() {
    return this.isValid ? Ge.weekdays("long", { locObj: this.loc })[this.weekday - 1] : null;
  }
  /**
   * Get the UTC offset of this DateTime in minutes
   * @example DateTime.now().offset //=> -240
   * @example DateTime.utc().offset //=> 0
   * @type {number}
   */
  get offset() {
    return this.isValid ? +this.o : NaN;
  }
  /**
   * Get the short human name for the zone's current offset, for example "EST" or "EDT".
   * Defaults to the system's locale if no locale has been specified
   * @type {string}
   */
  get offsetNameShort() {
    return this.isValid ? this.zone.offsetName(this.ts, {
      format: "short",
      locale: this.locale
    }) : null;
  }
  /**
   * Get the long human name for the zone's current offset, for example "Eastern Standard Time" or "Eastern Daylight Time".
   * Defaults to the system's locale if no locale has been specified
   * @type {string}
   */
  get offsetNameLong() {
    return this.isValid ? this.zone.offsetName(this.ts, {
      format: "long",
      locale: this.locale
    }) : null;
  }
  /**
   * Get whether this zone's offset ever changes, as in a DST.
   * @type {boolean}
   */
  get isOffsetFixed() {
    return this.isValid ? this.zone.isUniversal : null;
  }
  /**
   * Get whether the DateTime is in a DST.
   * @type {boolean}
   */
  get isInDST() {
    return this.isOffsetFixed ? !1 : this.offset > this.set({ month: 1, day: 1 }).offset || this.offset > this.set({ month: 5 }).offset;
  }
  /**
   * Get those DateTimes which have the same local time as this DateTime, but a different offset from UTC
   * in this DateTime's zone. During DST changes local time can be ambiguous, for example
   * `2023-10-29T02:30:00` in `Europe/Berlin` can have offset `+01:00` or `+02:00`.
   * This method will return both possible DateTimes if this DateTime's local time is ambiguous.
   * @returns {DateTime[]}
   */
  getPossibleOffsets() {
    if (!this.isValid || this.isOffsetFixed)
      return [this];
    const e = 864e5, n = 6e4, s = Et(this.c), r = this.zone.offset(s - e), i = this.zone.offset(s + e), a = this.zone.offset(s - r * n), o = this.zone.offset(s - i * n);
    if (a === o)
      return [this];
    const u = s - a * n, c = s - o * n, h = Qe(u, a), p = Qe(c, o);
    return h.hour === p.hour && h.minute === p.minute && h.second === p.second && h.millisecond === p.millisecond ? [de(this, { ts: u }), de(this, { ts: c })] : [this];
  }
  /**
   * Returns true if this DateTime is in a leap year, false otherwise
   * @example DateTime.local(2016).isInLeapYear //=> true
   * @example DateTime.local(2013).isInLeapYear //=> false
   * @type {boolean}
   */
  get isInLeapYear() {
    return We(this.year);
  }
  /**
   * Returns the number of days in this DateTime's month
   * @example DateTime.local(2016, 2).daysInMonth //=> 29
   * @example DateTime.local(2016, 3).daysInMonth //=> 31
   * @type {number}
   */
  get daysInMonth() {
    return ct(this.year, this.month);
  }
  /**
   * Returns the number of days in this DateTime's year
   * @example DateTime.local(2016).daysInYear //=> 366
   * @example DateTime.local(2013).daysInYear //=> 365
   * @type {number}
   */
  get daysInYear() {
    return this.isValid ? ke(this.year) : NaN;
  }
  /**
   * Returns the number of weeks in this DateTime's year
   * @see https://en.wikipedia.org/wiki/ISO_week_date
   * @example DateTime.local(2004).weeksInWeekYear //=> 53
   * @example DateTime.local(2013).weeksInWeekYear //=> 52
   * @type {number}
   */
  get weeksInWeekYear() {
    return this.isValid ? Pe(this.weekYear) : NaN;
  }
  /**
   * Returns the number of weeks in this DateTime's local week year
   * @example DateTime.local(2020, 6, {locale: 'en-US'}).weeksInLocalWeekYear //=> 52
   * @example DateTime.local(2020, 6, {locale: 'de-DE'}).weeksInLocalWeekYear //=> 53
   * @type {number}
   */
  get weeksInLocalWeekYear() {
    return this.isValid ? Pe(
      this.localWeekYear,
      this.loc.getMinDaysInFirstWeek(),
      this.loc.getStartOfWeek()
    ) : NaN;
  }
  /**
   * Returns the resolved Intl options for this DateTime.
   * This is useful in understanding the behavior of formatting methods
   * @param {Object} opts - the same options as toLocaleString
   * @return {Object}
   */
  resolvedLocaleOptions(e = {}) {
    const { locale: n, numberingSystem: s, calendar: r } = q.create(
      this.loc.clone(e),
      e
    ).resolvedOptions(this);
    return { locale: n, numberingSystem: s, outputCalendar: r };
  }
  // TRANSFORM
  /**
   * "Set" the DateTime's zone to UTC. Returns a newly-constructed DateTime.
   *
   * Equivalent to {@link DateTime#setZone}('utc')
   * @param {number} [offset=0] - optionally, an offset from UTC in minutes
   * @param {Object} [opts={}] - options to pass to `setZone()`
   * @return {DateTime}
   */
  toUTC(e = 0, n = {}) {
    return this.setZone(z.instance(e), n);
  }
  /**
   * "Set" the DateTime's zone to the host's local zone. Returns a newly-constructed DateTime.
   *
   * Equivalent to `setZone('local')`
   * @return {DateTime}
   */
  toLocal() {
    return this.setZone(L.defaultZone);
  }
  /**
   * "Set" the DateTime's zone to specified zone. Returns a newly-constructed DateTime.
   *
   * By default, the setter keeps the underlying time the same (as in, the same timestamp), but the new instance will report different local times and consider DSTs when making computations, as with {@link DateTime#plus}. You may wish to use {@link DateTime#toLocal} and {@link DateTime#toUTC} which provide simple convenience wrappers for commonly used zones.
   * @param {string|Zone} [zone='local'] - a zone identifier. As a string, that can be any IANA zone supported by the host environment, or a fixed-offset name of the form 'UTC+3', or the strings 'local' or 'utc'. You may also supply an instance of a {@link DateTime#Zone} class.
   * @param {Object} opts - options
   * @param {boolean} [opts.keepLocalTime=false] - If true, adjust the underlying time so that the local time stays the same, but in the target zone. You should rarely need this.
   * @return {DateTime}
   */
  setZone(e, { keepLocalTime: n = !1, keepCalendarTime: s = !1 } = {}) {
    if (e = ue(e, L.defaultZone), e.equals(this.zone))
      return this;
    if (e.isValid) {
      let r = this.ts;
      if (n || s) {
        const i = e.offset(this.ts), a = this.toObject();
        [r] = tt(a, i, e);
      }
      return de(this, { ts: r, zone: e });
    } else
      return w.invalid(Le(e));
  }
  /**
   * "Set" the locale, numberingSystem, or outputCalendar. Returns a newly-constructed DateTime.
   * @param {Object} properties - the properties to set
   * @example DateTime.local(2017, 5, 25).reconfigure({ locale: 'en-GB' })
   * @return {DateTime}
   */
  reconfigure({ locale: e, numberingSystem: n, outputCalendar: s } = {}) {
    const r = this.loc.clone({ locale: e, numberingSystem: n, outputCalendar: s });
    return de(this, { loc: r });
  }
  /**
   * "Set" the locale. Returns a newly-constructed DateTime.
   * Just a convenient alias for reconfigure({ locale })
   * @example DateTime.local(2017, 5, 25).setLocale('en-GB')
   * @return {DateTime}
   */
  setLocale(e) {
    return this.reconfigure({ locale: e });
  }
  /**
   * "Set" the values of specified units. Returns a newly-constructed DateTime.
   * You can only set units with this method; for "setting" metadata, see {@link DateTime#reconfigure} and {@link DateTime#setZone}.
   *
   * This method also supports setting locale-based week units, i.e. `localWeekday`, `localWeekNumber` and `localWeekYear`.
   * They cannot be mixed with ISO-week units like `weekday`.
   * @param {Object} values - a mapping of units to numbers
   * @example dt.set({ year: 2017 })
   * @example dt.set({ hour: 8, minute: 30 })
   * @example dt.set({ weekday: 5 })
   * @example dt.set({ year: 2005, ordinal: 234 })
   * @return {DateTime}
   */
  set(e) {
    if (!this.isValid) return this;
    const n = lt(e, Ln), { minDaysInFirstWeek: s, startOfWeek: r } = Nn(n, this.loc), i = !O(n.weekYear) || !O(n.weekNumber) || !O(n.weekday), a = !O(n.ordinal), o = !O(n.year), u = !O(n.month) || !O(n.day), c = o || u, h = n.weekYear || n.weekNumber;
    if ((c || a) && h)
      throw new Oe(
        "Can't mix weekYear/weekNumber units with year/month/day or ordinals"
      );
    if (u && a)
      throw new Oe("Can't mix ordinal dates with month/day");
    let p;
    i ? p = wn(
      { ...ut(this.c, s, r), ...n },
      s,
      r
    ) : O(n.ordinal) ? (p = { ...this.toObject(), ...n }, O(n.day) && (p.day = Math.min(ct(p.year, p.month), p.day))) : p = On({ ...bt(this.c), ...n });
    const [v, E] = tt(p, this.o, this.zone);
    return de(this, { ts: v, o: E });
  }
  /**
   * Add a period of time to this DateTime and return the resulting DateTime
   *
   * Adding hours, minutes, seconds, or milliseconds increases the timestamp by the right number of milliseconds. Adding days, months, or years shifts the calendar, accounting for DSTs and leap years along the way. Thus, `dt.plus({ hours: 24 })` may result in a different time than `dt.plus({ days: 1 })` if there's a DST shift in between.
   * @param {Duration|Object|number} duration - The amount to add. Either a Luxon Duration, a number of milliseconds, the object argument to Duration.fromObject()
   * @example DateTime.now().plus(123) //~> in 123 milliseconds
   * @example DateTime.now().plus({ minutes: 15 }) //~> in 15 minutes
   * @example DateTime.now().plus({ days: 1 }) //~> this time tomorrow
   * @example DateTime.now().plus({ days: -1 }) //~> this time yesterday
   * @example DateTime.now().plus({ hours: 3, minutes: 13 }) //~> in 3 hr, 13 min
   * @example DateTime.now().plus(Duration.fromObject({ hours: 3, minutes: 13 })) //~> in 3 hr, 13 min
   * @return {DateTime}
   */
  plus(e) {
    if (!this.isValid) return this;
    const n = D.fromDurationLike(e);
    return de(this, _n(this, n));
  }
  /**
   * Subtract a period of time to this DateTime and return the resulting DateTime
   * See {@link DateTime#plus}
   * @param {Duration|Object|number} duration - The amount to subtract. Either a Luxon Duration, a number of milliseconds, the object argument to Duration.fromObject()
   @return {DateTime}
   */
  minus(e) {
    if (!this.isValid) return this;
    const n = D.fromDurationLike(e).negate();
    return de(this, _n(this, n));
  }
  /**
   * "Set" this DateTime to the beginning of a unit of time.
   * @param {string} unit - The unit to go to the beginning of. Can be 'year', 'quarter', 'month', 'week', 'day', 'hour', 'minute', 'second', or 'millisecond'.
   * @param {Object} opts - options
   * @param {boolean} [opts.useLocaleWeeks=false] - If true, use weeks based on the locale, i.e. use the locale-dependent start of the week
   * @example DateTime.local(2014, 3, 3).startOf('month').toISODate(); //=> '2014-03-01'
   * @example DateTime.local(2014, 3, 3).startOf('year').toISODate(); //=> '2014-01-01'
   * @example DateTime.local(2014, 3, 3).startOf('week').toISODate(); //=> '2014-03-03', weeks always start on Mondays
   * @example DateTime.local(2014, 3, 3, 5, 30).startOf('day').toISOTime(); //=> '00:00.000-05:00'
   * @example DateTime.local(2014, 3, 3, 5, 30).startOf('hour').toISOTime(); //=> '05:00:00.000-05:00'
   * @return {DateTime}
   */
  startOf(e, { useLocaleWeeks: n = !1 } = {}) {
    if (!this.isValid) return this;
    const s = {}, r = D.normalizeUnit(e);
    switch (r) {
      case "years":
        s.month = 1;
      case "quarters":
      case "months":
        s.day = 1;
      case "weeks":
      case "days":
        s.hour = 0;
      case "hours":
        s.minute = 0;
      case "minutes":
        s.second = 0;
      case "seconds":
        s.millisecond = 0;
        break;
    }
    if (r === "weeks")
      if (n) {
        const i = this.loc.getStartOfWeek(), { weekday: a } = this;
        a < i && (s.weekNumber = this.weekNumber - 1), s.weekday = i;
      } else
        s.weekday = 1;
    if (r === "quarters") {
      const i = Math.ceil(this.month / 3);
      s.month = (i - 1) * 3 + 1;
    }
    return this.set(s);
  }
  /**
   * "Set" this DateTime to the end (meaning the last millisecond) of a unit of time
   * @param {string} unit - The unit to go to the end of. Can be 'year', 'quarter', 'month', 'week', 'day', 'hour', 'minute', 'second', or 'millisecond'.
   * @param {Object} opts - options
   * @param {boolean} [opts.useLocaleWeeks=false] - If true, use weeks based on the locale, i.e. use the locale-dependent start of the week
   * @example DateTime.local(2014, 3, 3).endOf('month').toISO(); //=> '2014-03-31T23:59:59.999-05:00'
   * @example DateTime.local(2014, 3, 3).endOf('year').toISO(); //=> '2014-12-31T23:59:59.999-05:00'
   * @example DateTime.local(2014, 3, 3).endOf('week').toISO(); // => '2014-03-09T23:59:59.999-05:00', weeks start on Mondays
   * @example DateTime.local(2014, 3, 3, 5, 30).endOf('day').toISO(); //=> '2014-03-03T23:59:59.999-05:00'
   * @example DateTime.local(2014, 3, 3, 5, 30).endOf('hour').toISO(); //=> '2014-03-03T05:59:59.999-05:00'
   * @return {DateTime}
   */
  endOf(e, n) {
    return this.isValid ? this.plus({ [e]: 1 }).startOf(e, n).minus(1) : this;
  }
  // OUTPUT
  /**
   * Returns a string representation of this DateTime formatted according to the specified format string.
   * **You may not want this.** See {@link DateTime#toLocaleString} for a more flexible formatting tool. For a table of tokens and their interpretations, see [here](https://moment.github.io/luxon/#/formatting?id=table-of-tokens).
   * Defaults to en-US if no locale has been specified, regardless of the system's locale.
   * @param {string} fmt - the format string
   * @param {Object} opts - opts to override the configuration options on this DateTime
   * @example DateTime.now().toFormat('yyyy LLL dd') //=> '2017 Apr 22'
   * @example DateTime.now().setLocale('fr').toFormat('yyyy LLL dd') //=> '2017 avr. 22'
   * @example DateTime.now().toFormat('yyyy LLL dd', { locale: "fr" }) //=> '2017 avr. 22'
   * @example DateTime.now().toFormat("HH 'hours and' mm 'minutes'") //=> '20 hours and 55 minutes'
   * @return {string}
   */
  toFormat(e, n = {}) {
    return this.isValid ? q.create(this.loc.redefaultToEN(n)).formatDateTimeFromString(this, e) : xt;
  }
  /**
   * Returns a localized string representing this date. Accepts the same options as the Intl.DateTimeFormat constructor and any presets defined by Luxon, such as `DateTime.DATE_FULL` or `DateTime.TIME_SIMPLE`.
   * The exact behavior of this method is browser-specific, but in general it will return an appropriate representation
   * of the DateTime in the assigned locale.
   * Defaults to the system's locale if no locale has been specified
   * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DateTimeFormat
   * @param formatOpts {Object} - Intl.DateTimeFormat constructor options and configuration options
   * @param {Object} opts - opts to override the configuration options on this DateTime
   * @example DateTime.now().toLocaleString(); //=> 4/20/2017
   * @example DateTime.now().setLocale('en-gb').toLocaleString(); //=> '20/04/2017'
   * @example DateTime.now().toLocaleString(DateTime.DATE_FULL); //=> 'April 20, 2017'
   * @example DateTime.now().toLocaleString(DateTime.DATE_FULL, { locale: 'fr' }); //=> '28 août 2022'
   * @example DateTime.now().toLocaleString(DateTime.TIME_SIMPLE); //=> '11:32 AM'
   * @example DateTime.now().toLocaleString(DateTime.DATETIME_SHORT); //=> '4/20/2017, 11:32 AM'
   * @example DateTime.now().toLocaleString({ weekday: 'long', month: 'long', day: '2-digit' }); //=> 'Thursday, April 20'
   * @example DateTime.now().toLocaleString({ weekday: 'short', month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit' }); //=> 'Thu, Apr 20, 11:27 AM'
   * @example DateTime.now().toLocaleString({ hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }); //=> '11:32'
   * @return {string}
   */
  toLocaleString(e = ot, n = {}) {
    return this.isValid ? q.create(this.loc.clone(n), e).formatDateTime(this) : xt;
  }
  /**
   * Returns an array of format "parts", meaning individual tokens along with metadata. This is allows callers to post-process individual sections of the formatted output.
   * Defaults to the system's locale if no locale has been specified
   * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/DateTimeFormat/formatToParts
   * @param opts {Object} - Intl.DateTimeFormat constructor options, same as `toLocaleString`.
   * @example DateTime.now().toLocaleParts(); //=> [
   *                                   //=>   { type: 'day', value: '25' },
   *                                   //=>   { type: 'literal', value: '/' },
   *                                   //=>   { type: 'month', value: '05' },
   *                                   //=>   { type: 'literal', value: '/' },
   *                                   //=>   { type: 'year', value: '1982' }
   *                                   //=> ]
   */
  toLocaleParts(e = {}) {
    return this.isValid ? q.create(this.loc.clone(e), e).formatDateTimeParts(this) : [];
  }
  /**
   * Returns an ISO 8601-compliant string representation of this DateTime
   * @param {Object} opts - options
   * @param {boolean} [opts.suppressMilliseconds=false] - exclude milliseconds from the format if they're 0
   * @param {boolean} [opts.suppressSeconds=false] - exclude seconds from the format if they're 0
   * @param {boolean} [opts.includeOffset=true] - include the offset, such as 'Z' or '-04:00'
   * @param {boolean} [opts.extendedZone=false] - add the time zone format extension
   * @param {string} [opts.format='extended'] - choose between the basic and extended format
   * @example DateTime.utc(1983, 5, 25).toISO() //=> '1982-05-25T00:00:00.000Z'
   * @example DateTime.now().toISO() //=> '2017-04-22T20:47:05.335-04:00'
   * @example DateTime.now().toISO({ includeOffset: false }) //=> '2017-04-22T20:47:05.335'
   * @example DateTime.now().toISO({ format: 'basic' }) //=> '20170422T204705.335-0400'
   * @return {string}
   */
  toISO({
    format: e = "extended",
    suppressSeconds: n = !1,
    suppressMilliseconds: s = !1,
    includeOffset: r = !0,
    extendedZone: i = !1
  } = {}) {
    if (!this.isValid)
      return null;
    const a = e === "extended";
    let o = Mt(this, a);
    return o += "T", o += Fn(this, a, n, s, r, i), o;
  }
  /**
   * Returns an ISO 8601-compliant string representation of this DateTime's date component
   * @param {Object} opts - options
   * @param {string} [opts.format='extended'] - choose between the basic and extended format
   * @example DateTime.utc(1982, 5, 25).toISODate() //=> '1982-05-25'
   * @example DateTime.utc(1982, 5, 25).toISODate({ format: 'basic' }) //=> '19820525'
   * @return {string}
   */
  toISODate({ format: e = "extended" } = {}) {
    return this.isValid ? Mt(this, e === "extended") : null;
  }
  /**
   * Returns an ISO 8601-compliant string representation of this DateTime's week date
   * @example DateTime.utc(1982, 5, 25).toISOWeekDate() //=> '1982-W21-2'
   * @return {string}
   */
  toISOWeekDate() {
    return Xe(this, "kkkk-'W'WW-c");
  }
  /**
   * Returns an ISO 8601-compliant string representation of this DateTime's time component
   * @param {Object} opts - options
   * @param {boolean} [opts.suppressMilliseconds=false] - exclude milliseconds from the format if they're 0
   * @param {boolean} [opts.suppressSeconds=false] - exclude seconds from the format if they're 0
   * @param {boolean} [opts.includeOffset=true] - include the offset, such as 'Z' or '-04:00'
   * @param {boolean} [opts.extendedZone=true] - add the time zone format extension
   * @param {boolean} [opts.includePrefix=false] - include the `T` prefix
   * @param {string} [opts.format='extended'] - choose between the basic and extended format
   * @example DateTime.utc().set({ hour: 7, minute: 34 }).toISOTime() //=> '07:34:19.361Z'
   * @example DateTime.utc().set({ hour: 7, minute: 34, seconds: 0, milliseconds: 0 }).toISOTime({ suppressSeconds: true }) //=> '07:34Z'
   * @example DateTime.utc().set({ hour: 7, minute: 34 }).toISOTime({ format: 'basic' }) //=> '073419.361Z'
   * @example DateTime.utc().set({ hour: 7, minute: 34 }).toISOTime({ includePrefix: true }) //=> 'T07:34:19.361Z'
   * @return {string}
   */
  toISOTime({
    suppressMilliseconds: e = !1,
    suppressSeconds: n = !1,
    includeOffset: s = !0,
    includePrefix: r = !1,
    extendedZone: i = !1,
    format: a = "extended"
  } = {}) {
    return this.isValid ? (r ? "T" : "") + Fn(
      this,
      a === "extended",
      n,
      e,
      s,
      i
    ) : null;
  }
  /**
   * Returns an RFC 2822-compatible string representation of this DateTime
   * @example DateTime.utc(2014, 7, 13).toRFC2822() //=> 'Sun, 13 Jul 2014 00:00:00 +0000'
   * @example DateTime.local(2014, 7, 13).toRFC2822() //=> 'Sun, 13 Jul 2014 00:00:00 -0400'
   * @return {string}
   */
  toRFC2822() {
    return Xe(this, "EEE, dd LLL yyyy HH:mm:ss ZZZ", !1);
  }
  /**
   * Returns a string representation of this DateTime appropriate for use in HTTP headers. The output is always expressed in GMT.
   * Specifically, the string conforms to RFC 1123.
   * @see https://www.w3.org/Protocols/rfc2616/rfc2616-sec3.html#sec3.3.1
   * @example DateTime.utc(2014, 7, 13).toHTTP() //=> 'Sun, 13 Jul 2014 00:00:00 GMT'
   * @example DateTime.utc(2014, 7, 13, 19).toHTTP() //=> 'Sun, 13 Jul 2014 19:00:00 GMT'
   * @return {string}
   */
  toHTTP() {
    return Xe(this.toUTC(), "EEE, dd LLL yyyy HH:mm:ss 'GMT'");
  }
  /**
   * Returns a string representation of this DateTime appropriate for use in SQL Date
   * @example DateTime.utc(2014, 7, 13).toSQLDate() //=> '2014-07-13'
   * @return {string}
   */
  toSQLDate() {
    return this.isValid ? Mt(this, !0) : null;
  }
  /**
   * Returns a string representation of this DateTime appropriate for use in SQL Time
   * @param {Object} opts - options
   * @param {boolean} [opts.includeZone=false] - include the zone, such as 'America/New_York'. Overrides includeOffset.
   * @param {boolean} [opts.includeOffset=true] - include the offset, such as 'Z' or '-04:00'
   * @param {boolean} [opts.includeOffsetSpace=true] - include the space between the time and the offset, such as '05:15:16.345 -04:00'
   * @example DateTime.utc().toSQL() //=> '05:15:16.345'
   * @example DateTime.now().toSQL() //=> '05:15:16.345 -04:00'
   * @example DateTime.now().toSQL({ includeOffset: false }) //=> '05:15:16.345'
   * @example DateTime.now().toSQL({ includeZone: false }) //=> '05:15:16.345 America/New_York'
   * @return {string}
   */
  toSQLTime({ includeOffset: e = !0, includeZone: n = !1, includeOffsetSpace: s = !0 } = {}) {
    let r = "HH:mm:ss.SSS";
    return (n || e) && (s && (r += " "), n ? r += "z" : e && (r += "ZZ")), Xe(this, r, !0);
  }
  /**
   * Returns a string representation of this DateTime appropriate for use in SQL DateTime
   * @param {Object} opts - options
   * @param {boolean} [opts.includeZone=false] - include the zone, such as 'America/New_York'. Overrides includeOffset.
   * @param {boolean} [opts.includeOffset=true] - include the offset, such as 'Z' or '-04:00'
   * @param {boolean} [opts.includeOffsetSpace=true] - include the space between the time and the offset, such as '05:15:16.345 -04:00'
   * @example DateTime.utc(2014, 7, 13).toSQL() //=> '2014-07-13 00:00:00.000 Z'
   * @example DateTime.local(2014, 7, 13).toSQL() //=> '2014-07-13 00:00:00.000 -04:00'
   * @example DateTime.local(2014, 7, 13).toSQL({ includeOffset: false }) //=> '2014-07-13 00:00:00.000'
   * @example DateTime.local(2014, 7, 13).toSQL({ includeZone: true }) //=> '2014-07-13 00:00:00.000 America/New_York'
   * @return {string}
   */
  toSQL(e = {}) {
    return this.isValid ? `${this.toSQLDate()} ${this.toSQLTime(e)}` : null;
  }
  /**
   * Returns a string representation of this DateTime appropriate for debugging
   * @return {string}
   */
  toString() {
    return this.isValid ? this.toISO() : xt;
  }
  /**
   * Returns a string representation of this DateTime appropriate for the REPL.
   * @return {string}
   */
  [Symbol.for("nodejs.util.inspect.custom")]() {
    return this.isValid ? `DateTime { ts: ${this.toISO()}, zone: ${this.zone.name}, locale: ${this.locale} }` : `DateTime { Invalid, reason: ${this.invalidReason} }`;
  }
  /**
   * Returns the epoch milliseconds of this DateTime. Alias of {@link DateTime#toMillis}
   * @return {number}
   */
  valueOf() {
    return this.toMillis();
  }
  /**
   * Returns the epoch milliseconds of this DateTime.
   * @return {number}
   */
  toMillis() {
    return this.isValid ? this.ts : NaN;
  }
  /**
   * Returns the epoch seconds of this DateTime.
   * @return {number}
   */
  toSeconds() {
    return this.isValid ? this.ts / 1e3 : NaN;
  }
  /**
   * Returns the epoch seconds (as a whole number) of this DateTime.
   * @return {number}
   */
  toUnixInteger() {
    return this.isValid ? Math.floor(this.ts / 1e3) : NaN;
  }
  /**
   * Returns an ISO 8601 representation of this DateTime appropriate for use in JSON.
   * @return {string}
   */
  toJSON() {
    return this.toISO();
  }
  /**
   * Returns a BSON serializable equivalent to this DateTime.
   * @return {Date}
   */
  toBSON() {
    return this.toJSDate();
  }
  /**
   * Returns a JavaScript object with this DateTime's year, month, day, and so on.
   * @param opts - options for generating the object
   * @param {boolean} [opts.includeConfig=false] - include configuration attributes in the output
   * @example DateTime.now().toObject() //=> { year: 2017, month: 4, day: 22, hour: 20, minute: 49, second: 42, millisecond: 268 }
   * @return {Object}
   */
  toObject(e = {}) {
    if (!this.isValid) return {};
    const n = { ...this.c };
    return e.includeConfig && (n.outputCalendar = this.outputCalendar, n.numberingSystem = this.loc.numberingSystem, n.locale = this.loc.locale), n;
  }
  /**
   * Returns a JavaScript Date equivalent to this DateTime.
   * @return {Date}
   */
  toJSDate() {
    return new Date(this.isValid ? this.ts : NaN);
  }
  // COMPARE
  /**
   * Return the difference between two DateTimes as a Duration.
   * @param {DateTime} otherDateTime - the DateTime to compare this one to
   * @param {string|string[]} [unit=['milliseconds']] - the unit or array of units (such as 'hours' or 'days') to include in the duration.
   * @param {Object} opts - options that affect the creation of the Duration
   * @param {string} [opts.conversionAccuracy='casual'] - the conversion system to use
   * @example
   * var i1 = DateTime.fromISO('1982-05-25T09:45'),
   *     i2 = DateTime.fromISO('1983-10-14T10:30');
   * i2.diff(i1).toObject() //=> { milliseconds: 43807500000 }
   * i2.diff(i1, 'hours').toObject() //=> { hours: 12168.75 }
   * i2.diff(i1, ['months', 'days']).toObject() //=> { months: 16, days: 19.03125 }
   * i2.diff(i1, ['months', 'days', 'hours']).toObject() //=> { months: 16, days: 19, hours: 0.75 }
   * @return {Duration}
   */
  diff(e, n = "milliseconds", s = {}) {
    if (!this.isValid || !e.isValid)
      return D.invalid("created by diffing an invalid DateTime");
    const r = { locale: this.locale, numberingSystem: this.numberingSystem, ...s }, i = Hr(n).map(D.normalizeUnit), a = e.valueOf() > this.valueOf(), o = a ? this : e, u = a ? e : this, c = qi(o, u, i, r);
    return a ? c.negate() : c;
  }
  /**
   * Return the difference between this DateTime and right now.
   * See {@link DateTime#diff}
   * @param {string|string[]} [unit=['milliseconds']] - the unit or units units (such as 'hours' or 'days') to include in the duration
   * @param {Object} opts - options that affect the creation of the Duration
   * @param {string} [opts.conversionAccuracy='casual'] - the conversion system to use
   * @return {Duration}
   */
  diffNow(e = "milliseconds", n = {}) {
    return this.diff(w.now(), e, n);
  }
  /**
   * Return an Interval spanning between this DateTime and another DateTime
   * @param {DateTime} otherDateTime - the other end point of the Interval
   * @return {Interval}
   */
  until(e) {
    return this.isValid ? F.fromDateTimes(this, e) : this;
  }
  /**
   * Return whether this DateTime is in the same unit of time as another DateTime.
   * Higher-order units must also be identical for this function to return `true`.
   * Note that time zones are **ignored** in this comparison, which compares the **local** calendar time. Use {@link DateTime#setZone} to convert one of the dates if needed.
   * @param {DateTime} otherDateTime - the other DateTime
   * @param {string} unit - the unit of time to check sameness on
   * @param {Object} opts - options
   * @param {boolean} [opts.useLocaleWeeks=false] - If true, use weeks based on the locale, i.e. use the locale-dependent start of the week; only the locale of this DateTime is used
   * @example DateTime.now().hasSame(otherDT, 'day'); //~> true if otherDT is in the same current calendar day
   * @return {boolean}
   */
  hasSame(e, n, s) {
    if (!this.isValid) return !1;
    const r = e.valueOf(), i = this.setZone(e.zone, { keepLocalTime: !0 });
    return i.startOf(n, s) <= r && r <= i.endOf(n, s);
  }
  /**
   * Equality check
   * Two DateTimes are equal if and only if they represent the same millisecond, have the same zone and location, and are both valid.
   * To compare just the millisecond values, use `+dt1 === +dt2`.
   * @param {DateTime} other - the other DateTime
   * @return {boolean}
   */
  equals(e) {
    return this.isValid && e.isValid && this.valueOf() === e.valueOf() && this.zone.equals(e.zone) && this.loc.equals(e.loc);
  }
  /**
   * Returns a string representation of a this time relative to now, such as "in two days". Can only internationalize if your
   * platform supports Intl.RelativeTimeFormat. Rounds down by default.
   * @param {Object} options - options that affect the output
   * @param {DateTime} [options.base=DateTime.now()] - the DateTime to use as the basis to which this time is compared. Defaults to now.
   * @param {string} [options.style="long"] - the style of units, must be "long", "short", or "narrow"
   * @param {string|string[]} options.unit - use a specific unit or array of units; if omitted, or an array, the method will pick the best unit. Use an array or one of "years", "quarters", "months", "weeks", "days", "hours", "minutes", or "seconds"
   * @param {boolean} [options.round=true] - whether to round the numbers in the output.
   * @param {number} [options.padding=0] - padding in milliseconds. This allows you to round up the result if it fits inside the threshold. Don't use in combination with {round: false} because the decimal output will include the padding.
   * @param {string} options.locale - override the locale of this DateTime
   * @param {string} options.numberingSystem - override the numberingSystem of this DateTime. The Intl system may choose not to honor this
   * @example DateTime.now().plus({ days: 1 }).toRelative() //=> "in 1 day"
   * @example DateTime.now().setLocale("es").toRelative({ days: 1 }) //=> "dentro de 1 día"
   * @example DateTime.now().plus({ days: 1 }).toRelative({ locale: "fr" }) //=> "dans 23 heures"
   * @example DateTime.now().minus({ days: 2 }).toRelative() //=> "2 days ago"
   * @example DateTime.now().minus({ days: 2 }).toRelative({ unit: "hours" }) //=> "48 hours ago"
   * @example DateTime.now().minus({ hours: 36 }).toRelative({ round: false }) //=> "1.5 days ago"
   */
  toRelative(e = {}) {
    if (!this.isValid) return null;
    const n = e.base || w.fromObject({}, { zone: this.zone }), s = e.padding ? this < n ? -e.padding : e.padding : 0;
    let r = ["years", "months", "days", "hours", "minutes", "seconds"], i = e.unit;
    return Array.isArray(e.unit) && (r = e.unit, i = void 0), Vn(n, this.plus(s), {
      ...e,
      numeric: "always",
      units: r,
      unit: i
    });
  }
  /**
   * Returns a string representation of this date relative to today, such as "yesterday" or "next month".
   * Only internationalizes on platforms that supports Intl.RelativeTimeFormat.
   * @param {Object} options - options that affect the output
   * @param {DateTime} [options.base=DateTime.now()] - the DateTime to use as the basis to which this time is compared. Defaults to now.
   * @param {string} options.locale - override the locale of this DateTime
   * @param {string} options.unit - use a specific unit; if omitted, the method will pick the unit. Use one of "years", "quarters", "months", "weeks", or "days"
   * @param {string} options.numberingSystem - override the numberingSystem of this DateTime. The Intl system may choose not to honor this
   * @example DateTime.now().plus({ days: 1 }).toRelativeCalendar() //=> "tomorrow"
   * @example DateTime.now().setLocale("es").plus({ days: 1 }).toRelative() //=> ""mañana"
   * @example DateTime.now().plus({ days: 1 }).toRelativeCalendar({ locale: "fr" }) //=> "demain"
   * @example DateTime.now().minus({ days: 2 }).toRelativeCalendar() //=> "2 days ago"
   */
  toRelativeCalendar(e = {}) {
    return this.isValid ? Vn(e.base || w.fromObject({}, { zone: this.zone }), this, {
      ...e,
      numeric: "auto",
      units: ["years", "months", "days"],
      calendary: !0
    }) : null;
  }
  /**
   * Return the min of several date times
   * @param {...DateTime} dateTimes - the DateTimes from which to choose the minimum
   * @return {DateTime} the min DateTime, or undefined if called with no argument
   */
  static min(...e) {
    if (!e.every(w.isDateTime))
      throw new Z("min requires all arguments be DateTimes");
    return vn(e, (n) => n.valueOf(), Math.min);
  }
  /**
   * Return the max of several date times
   * @param {...DateTime} dateTimes - the DateTimes from which to choose the maximum
   * @return {DateTime} the max DateTime, or undefined if called with no argument
   */
  static max(...e) {
    if (!e.every(w.isDateTime))
      throw new Z("max requires all arguments be DateTimes");
    return vn(e, (n) => n.valueOf(), Math.max);
  }
  // MISC
  /**
   * Explain how a string would be parsed by fromFormat()
   * @param {string} text - the string to parse
   * @param {string} fmt - the format the string is expected to be in (see description)
   * @param {Object} options - options taken by fromFormat()
   * @return {Object}
   */
  static fromFormatExplain(e, n, s = {}) {
    const { locale: r = null, numberingSystem: i = null } = s, a = A.fromOpts({
      locale: r,
      numberingSystem: i,
      defaultToEN: !0
    });
    return $s(a, e, n);
  }
  /**
   * @deprecated use fromFormatExplain instead
   */
  static fromStringExplain(e, n, s = {}) {
    return w.fromFormatExplain(e, n, s);
  }
  /**
   * Build a parser for `fmt` using the given locale. This parser can be passed
   * to {@link DateTime.fromFormatParser} to a parse a date in this format. This
   * can be used to optimize cases where many dates need to be parsed in a
   * specific format.
   *
   * @param {String} fmt - the format the string is expected to be in (see
   * description)
   * @param {Object} options - options used to set locale and numberingSystem
   * for parser
   * @returns {TokenParser} - opaque object to be used
   */
  static buildFormatParser(e, n = {}) {
    const { locale: s = null, numberingSystem: r = null } = n, i = A.fromOpts({
      locale: s,
      numberingSystem: r,
      defaultToEN: !0
    });
    return new Us(i, e);
  }
  /**
   * Create a DateTime from an input string and format parser.
   *
   * The format parser must have been created with the same locale as this call.
   *
   * @param {String} text - the string to parse
   * @param {TokenParser} formatParser - parser from {@link DateTime.buildFormatParser}
   * @param {Object} opts - options taken by fromFormat()
   * @returns {DateTime}
   */
  static fromFormatParser(e, n, s = {}) {
    if (O(e) || O(n))
      throw new Z(
        "fromFormatParser requires an input string and a format parser"
      );
    const { locale: r = null, numberingSystem: i = null } = s, a = A.fromOpts({
      locale: r,
      numberingSystem: i,
      defaultToEN: !0
    });
    if (!a.equals(n.locale))
      throw new Z(
        `fromFormatParser called with a locale of ${a}, but the format parser was created for ${n.locale}`
      );
    const { result: o, zone: u, specificOffset: c, invalidReason: h } = n.explainFromTokens(e);
    return h ? w.invalid(h) : Te(
      o,
      u,
      s,
      `format ${n.format}`,
      e,
      c
    );
  }
  // FORMAT PRESETS
  /**
   * {@link DateTime#toLocaleString} format like 10/14/1983
   * @type {Object}
   */
  static get DATE_SHORT() {
    return ot;
  }
  /**
   * {@link DateTime#toLocaleString} format like 'Oct 14, 1983'
   * @type {Object}
   */
  static get DATE_MED() {
    return qn;
  }
  /**
   * {@link DateTime#toLocaleString} format like 'Fri, Oct 14, 1983'
   * @type {Object}
   */
  static get DATE_MED_WITH_WEEKDAY() {
    return mr;
  }
  /**
   * {@link DateTime#toLocaleString} format like 'October 14, 1983'
   * @type {Object}
   */
  static get DATE_FULL() {
    return zn;
  }
  /**
   * {@link DateTime#toLocaleString} format like 'Tuesday, October 14, 1983'
   * @type {Object}
   */
  static get DATE_HUGE() {
    return jn;
  }
  /**
   * {@link DateTime#toLocaleString} format like '09:30 AM'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get TIME_SIMPLE() {
    return Gn;
  }
  /**
   * {@link DateTime#toLocaleString} format like '09:30:23 AM'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get TIME_WITH_SECONDS() {
    return Jn;
  }
  /**
   * {@link DateTime#toLocaleString} format like '09:30:23 AM EDT'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get TIME_WITH_SHORT_OFFSET() {
    return Qn;
  }
  /**
   * {@link DateTime#toLocaleString} format like '09:30:23 AM Eastern Daylight Time'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get TIME_WITH_LONG_OFFSET() {
    return Xn;
  }
  /**
   * {@link DateTime#toLocaleString} format like '09:30', always 24-hour.
   * @type {Object}
   */
  static get TIME_24_SIMPLE() {
    return Kn;
  }
  /**
   * {@link DateTime#toLocaleString} format like '09:30:23', always 24-hour.
   * @type {Object}
   */
  static get TIME_24_WITH_SECONDS() {
    return es;
  }
  /**
   * {@link DateTime#toLocaleString} format like '09:30:23 EDT', always 24-hour.
   * @type {Object}
   */
  static get TIME_24_WITH_SHORT_OFFSET() {
    return ts;
  }
  /**
   * {@link DateTime#toLocaleString} format like '09:30:23 Eastern Daylight Time', always 24-hour.
   * @type {Object}
   */
  static get TIME_24_WITH_LONG_OFFSET() {
    return ns;
  }
  /**
   * {@link DateTime#toLocaleString} format like '10/14/1983, 9:30 AM'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get DATETIME_SHORT() {
    return ss;
  }
  /**
   * {@link DateTime#toLocaleString} format like '10/14/1983, 9:30:33 AM'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get DATETIME_SHORT_WITH_SECONDS() {
    return rs;
  }
  /**
   * {@link DateTime#toLocaleString} format like 'Oct 14, 1983, 9:30 AM'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get DATETIME_MED() {
    return is;
  }
  /**
   * {@link DateTime#toLocaleString} format like 'Oct 14, 1983, 9:30:33 AM'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get DATETIME_MED_WITH_SECONDS() {
    return as;
  }
  /**
   * {@link DateTime#toLocaleString} format like 'Fri, 14 Oct 1983, 9:30 AM'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get DATETIME_MED_WITH_WEEKDAY() {
    return pr;
  }
  /**
   * {@link DateTime#toLocaleString} format like 'October 14, 1983, 9:30 AM EDT'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get DATETIME_FULL() {
    return os;
  }
  /**
   * {@link DateTime#toLocaleString} format like 'October 14, 1983, 9:30:33 AM EDT'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get DATETIME_FULL_WITH_SECONDS() {
    return us;
  }
  /**
   * {@link DateTime#toLocaleString} format like 'Friday, October 14, 1983, 9:30 AM Eastern Daylight Time'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get DATETIME_HUGE() {
    return cs;
  }
  /**
   * {@link DateTime#toLocaleString} format like 'Friday, October 14, 1983, 9:30:33 AM Eastern Daylight Time'. Only 12-hour if the locale is.
   * @type {Object}
   */
  static get DATETIME_HUGE_WITH_SECONDS() {
    return ls;
  }
}
function Me(t) {
  if (w.isDateTime(t))
    return t;
  if (t && t.valueOf && ce(t.valueOf()))
    return w.fromJSDate(t);
  if (t && typeof t == "object")
    return w.fromObject(t);
  throw new Z(
    `Unknown datetime argument: ${t}, of type ${typeof t}`
  );
}
const No = I(w.local()), nn = { BASE_URL: "/", DEV: !1, MODE: "production", PROD: !0, SSR: !1 }, da = Symbol(
  (nn ? "production" : void 0) !== "production" ? "RESET" : ""
);
function fa(t, e) {
  let n = null;
  const s = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Set(), i = (o) => {
    let u;
    if (u = s.get(o), u !== void 0)
      if (n?.(u[1], o))
        i.remove(o);
      else
        return u[0];
    const c = t(o);
    return s.set(o, [c, Date.now()]), a("CREATE", o, c), c;
  };
  function a(o, u, c) {
    for (const h of r)
      h({ type: o, param: u, atom: c });
  }
  return i.unstable_listen = (o) => (r.add(o), () => {
    r.delete(o);
  }), i.getParams = () => s.keys(), i.remove = (o) => {
    {
      if (!s.has(o)) return;
      const [u] = s.get(o);
      s.delete(o), a("REMOVE", o, u);
    }
  }, i.setShouldRemove = (o) => {
    if (n = o, !!n)
      for (const [u, [c, h]] of s)
        n(h, u) && (s.delete(u), a("REMOVE", u, c));
  }, i;
}
const ma = (t) => typeof t?.then == "function";
function pa(t = () => {
  try {
    return window.localStorage;
  } catch (n) {
    (nn ? "production" : void 0) !== "production" && typeof window < "u" && console.warn(n);
    return;
  }
}, e) {
  var n;
  let s, r;
  const i = {
    getItem: (u, c) => {
      var h, p;
      const v = (N) => {
        if (N = N || "", s !== N) {
          try {
            r = JSON.parse(N, e?.reviver);
          } catch {
            return c;
          }
          s = N;
        }
        return r;
      }, E = (p = (h = t()) == null ? void 0 : h.getItem(u)) != null ? p : null;
      return ma(E) ? E.then(v) : v(E);
    },
    setItem: (u, c) => {
      var h;
      return (h = t()) == null ? void 0 : h.setItem(
        u,
        JSON.stringify(c, void 0)
      );
    },
    removeItem: (u) => {
      var c;
      return (c = t()) == null ? void 0 : c.removeItem(u);
    }
  }, a = (u) => (c, h, p) => u(c, (v) => {
    let E;
    try {
      E = JSON.parse(v || "");
    } catch {
      E = p;
    }
    h(E);
  });
  let o;
  try {
    o = (n = t()) == null ? void 0 : n.subscribe;
  } catch {
  }
  return !o && typeof window < "u" && typeof window.addEventListener == "function" && window.Storage && (o = (u, c) => {
    if (!(t() instanceof window.Storage))
      return () => {
      };
    const h = (p) => {
      p.storageArea === t() && p.key === u && c(p.newValue);
    };
    return window.addEventListener("storage", h), () => {
      window.removeEventListener("storage", h);
    };
  }), o && (i.subscribe = a(o)), i;
}
const ya = pa();
function Ea(t, e, n = ya, s) {
  const r = I(
    e
  );
  return (nn ? "production" : void 0) !== "production" && (r.debugPrivate = !0), r.onMount = (a) => {
    a(n.getItem(t, e));
    let o;
    return n.subscribe && (o = n.subscribe(t, a, e)), o;
  }, I(
    (a) => a(r),
    (a, o, u) => {
      const c = typeof u == "function" ? u(a(r)) : u;
      return c === da ? (o(r, e), n.removeItem(t)) : c instanceof Promise ? c.then((h) => (o(r, h), n.setItem(t, h))) : (o(r, c), n.setItem(t, c));
    }
  );
}
const H = Ea("appState", {
  spheres: {
    currentSphereHash: "",
    byHash: {}
  },
  hierarchies: {
    byRootOrbitEntryHash: {}
  },
  orbitNodes: {
    currentOrbitHash: null,
    byHash: {}
  },
  wins: {},
  ui: {
    listSortFilter: {
      sortCriteria: "name",
      sortOrder: "lowestToGreatest"
    },
    currentDay: (/* @__PURE__ */ new Date()).toISOString()
  }
}), vo = (t) => I((n) => {
  const s = n(H), r = s.orbitNodes.byHash[t];
  return s.wins[t], r ? 0 : null;
}), ko = (t) => I((n) => n(H).hierarchies.byRootOrbitEntryHash[t] || null), Io = (t) => I((n) => {
  const s = n(H), r = s.hierarchies.byRootOrbitEntryHash[t];
  return r ? r.nodeHashes.map((i) => s.orbitNodes.byHash[i]) : [];
}), ht = I({}), dt = I({ x: 0, y: 0 }), So = I(
  null,
  (t, e, n) => {
    const s = t(dt);
    e(dt, { ...s, x: n });
  }
), bo = I(
  null,
  (t, e, n) => {
    const s = t(dt);
    e(dt, { ...s, x: n });
  }
), Do = I(
  null,
  (t, e, n, [s, r]) => {
    const i = t(ht);
    e(ht, { ...i, [n]: { ...i[n], minDepth: s, maxDepth: r } });
  }
), xo = I(
  null,
  (t, e, n, [s, r]) => {
    const i = t(ht);
    e(ht, { ...i, [n]: { ...i[n], minBreadth: s, maxBreadth: r } });
  }
), Ao = I({ id: null });
var ga = Object.defineProperty, Ta = (t, e, n) => e in t ? ga(t, e, { enumerable: !0, configurable: !0, writable: !0, value: n }) : t[e] = n, $ = (t, e, n) => (Ta(t, typeof e != "symbol" ? e + "" : e, n), n);
function X(t) {
  return new Promise((e, n) => {
    t.oncomplete = t.onsuccess = () => e(t.result), t.onabort = t.onerror = () => n(t.error);
  });
}
function wa(t, e) {
  const n = indexedDB.open(t);
  n.onupgradeneeded = () => n.result.createObjectStore(e);
  const s = X(n);
  return (r, i) => s.then((a) => i(a.transaction(e, r).objectStore(e)));
}
let _t;
function Ye() {
  return _t || (_t = wa("keyval-store", "keyval")), _t;
}
function Oa(t, e, n = Ye()) {
  return n("readwrite", (s) => (s.put(e, t), X(s.transaction)));
}
function Un(t, e = Ye()) {
  return e("readwrite", (n) => (t.forEach((s) => n.put(s[1], s[0])), X(n.transaction)));
}
function Na(t, e = Ye()) {
  return e("readwrite", (n) => (n.delete(t), X(n.transaction)));
}
function va(t = Ye()) {
  return t("readwrite", (e) => (e.clear(), X(e.transaction)));
}
function ka(t, e) {
  return t.openCursor().onsuccess = function() {
    this.result && (e(this.result), this.result.continue());
  }, X(t.transaction);
}
function Ft(t = Ye()) {
  return t("readonly", (e) => {
    if (e.getAll && e.getAllKeys)
      return Promise.all([
        X(e.getAllKeys()),
        X(e.getAll())
      ]).then(([s, r]) => s.map((i, a) => [i, r[a]]));
    const n = [];
    return t("readonly", (s) => ka(s, (r) => n.push([r.key, r.value])).then(() => n));
  });
}
const Ia = "jotai-minidb", Sa = {
  name: Ia,
  version: 0,
  migrations: {},
  onMigrationCompleted: () => {
    alert("Data has been migrated. Page will be reloaded"), window.location.reload();
  },
  onVersionMissmatch: () => {
  }
};
class ba {
  constructor(e = {}) {
    $(this, "channel"), $(this, "cache", I(void 0)), $(this, "idbStorage"), $(this, "metaStorage"), $(this, "config"), $(this, "initStarted", I(!1)), $(this, "initialDataThenable", Da()), $(this, "suspendBeforeInit", I(async (r) => {
      r(this.items), await r(this.initialDataThenable).promise;
    })), $(this, "isInitialized", I(!1)), $(this, "items", I(
      (r, { setSelf: i }) => (r(this.initStarted) || Promise.resolve().then(i), r(this.cache)),
      async (r, i) => {
        r(this.initStarted) || (i(this.initStarted, !0), this.preloadData().then((a) => {
          i(this.cache, a), r(this.initialDataThenable).resolve();
        }), this.channel.onmessage = async (a) => {
          const o = a.data;
          o.type === "UPDATE" ? i(this.cache, (u) => ({
            ...u,
            [o.id]: o.item
          })) : o.type === "DELETE" ? i(this.cache, (u) => {
            const c = { ...u };
            return delete c[o.id], c;
          }) : o.type === "UPDATE_MANY" ? i(
            this.cache,
            Object.fromEntries(await Ft(this.idbStorage))
          ) : o.type === "MIGRATION_COMPLETED" && this.config.onMigrationCompleted();
        });
      }
    )), $(this, "entries", I((r) => Object.entries(r(this.items) || {}))), $(this, "keys", I((r) => Object.keys(r(this.items) || {}))), $(this, "values", I((r) => Object.values(r(this.items) || {}))), $(this, "item", fa(
      (r) => I(
        (i) => {
          var a;
          return (a = i(this.items)) == null ? void 0 : a[r];
        },
        async (i, a, o) => {
          await a(this.set, r, o);
        }
      )
    )), $(this, "set", I(
      null,
      async (r, i, a, o) => {
        r(this.cache) || await r(this.suspendBeforeInit);
        const u = r(this.cache);
        if (!u)
          throw new Error("Cache was not initialized");
        const c = Aa(o) ? o(u[a]) : o;
        i(this.cache, (h) => ({ ...h, [a]: c })), await Oa(a, c, this.idbStorage), this.channel.postMessage({ type: "UPDATE", id: a, item: c });
      }
    )), $(this, "setMany", I(null, async (r, i, a) => {
      r(this.cache) || await r(this.suspendBeforeInit);
      const o = { ...r(this.cache) };
      for (const [u, c] of a)
        o[u] = c;
      i(this.cache, o), await Un(a, this.idbStorage), this.channel.postMessage({ type: "UPDATE_MANY" });
    })), $(this, "delete", I(null, async (r, i, a) => {
      r(this.cache) || await r(this.suspendBeforeInit), i(this.cache, (o) => {
        const u = { ...o };
        return delete u[a], u;
      }), await Na(a, this.idbStorage), this.channel.postMessage({ type: "DELETE", id: a });
    })), $(this, "clear", I(null, async (r, i) => {
      r(this.cache) || await r(this.suspendBeforeInit), i(this.cache, {}), await va(this.idbStorage), this.channel.postMessage({ type: "UPDATE_MANY" });
    })), this.config = { ...Sa, initialData: {}, ...e };
    const { keyvalStorage: n, metaStorage: s } = xa(
      this.config.name,
      "key-value",
      this.config.initialData
    );
    this.idbStorage = n, this.metaStorage = s, this.channel = new BroadcastChannel(
      `jotai-minidb-broadcast:${this.config.name}`
    );
  }
  async preloadData() {
    return await this.migrate(), Object.fromEntries(await Ft(this.idbStorage));
  }
  async migrate() {
    const e = await this.metaStorage(
      "readonly",
      (n) => X(n.get("version"))
    ) || 0;
    if (this.config.version > e) {
      let n = await Ft(this.idbStorage);
      for (let s = e + 1; s <= this.config.version; s++) {
        const r = this.config.migrations[s];
        if (!r)
          throw new Error(
            `Migrate function for version ${s} is not provided`
          );
        n = await Promise.all(
          n.map(
            async ([i, a]) => [i, await r(a)]
          )
        );
      }
      await Un(n, this.idbStorage), await this.metaStorage(
        "readwrite",
        (s) => X(s.put(this.config.version, "version"))
      ), this.channel.postMessage({ type: "MIGRATION_COMPLETED" });
    } else if (this.config.version < e)
      throw this.config.onVersionMissmatch(), new Error(
        `[jotai-minidb] Minimal client version is ${this.config.version} but indexeddb database version is ${e}`
      );
  }
}
function Da() {
  return I(() => {
    let t, e;
    return {
      promise: new Promise((n, s) => {
        t = n, e = s;
      }),
      resolve: t,
      reject: e
    };
  });
}
function xa(t, e, n) {
  const s = indexedDB.open(t), r = [];
  s.onupgradeneeded = (a) => {
    const o = s.result.createObjectStore(e);
    s.result.createObjectStore("_meta");
    for (const [u, c] of Object.entries(n))
      r.push(
        X(o.add(c, u))
      );
  };
  const i = X(s);
  return {
    keyvalStorage: async (a, o) => {
      const u = await i;
      return await Promise.all(r), o(u.transaction(e, a).objectStore(e));
    },
    metaStorage: (a, o) => i.then(
      (u) => o(u.transaction("_meta", a).objectStore("_meta"))
    )
  };
}
function Aa(t) {
  return typeof t == "function";
}
const Ca = new ba(), Co = lr(), Mo = I((t) => t(Ca.items));
var Ne;
((t) => {
  t.LESS_THAN_DAILY = {
    WEEKLY: 0.143,
    // 1/7 rounded to 3 decimal places
    MONTHLY: 0.032,
    // 1/31 rounded to 3 decimal places
    QUARTERLY: 0.011
    // 1/91 rounded to 3 decimal places
  }, t.DAILY_OR_MORE = {
    DAILY: 1,
    TWO: 2,
    THREE: 3,
    FOUR: 4,
    FIVE: 5,
    SIX: 6,
    SEVEN: 7,
    EIGHT: 8,
    NINE: 9,
    TEN: 10,
    ELEVEN: 11,
    TWELVE: 12,
    THIRTEEN: 13,
    FOURTEEN: 14,
    FIFTEEN: 15,
    SIXTEEN: 16,
    SEVENTEEN: 17,
    EIGHTEEN: 18,
    NINETEEN: 19,
    TWENTY: 20,
    TWENTY_ONE: 21,
    TWENTY_TWO: 22,
    TWENTY_THREE: 23,
    HOURLY: 24
  };
})(Ne || (Ne = {}));
var ft = function() {
  return ft = Object.assign || function(e) {
    for (var n, s = 1, r = arguments.length; s < r; s++) {
      n = arguments[s];
      for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (e[i] = n[i]);
    }
    return e;
  }, ft.apply(this, arguments);
};
function Lt(t, e) {
  if (!!!t)
    throw new Error(e);
}
function Ma(t) {
  return typeof t == "object" && t !== null;
}
function _a(t, e) {
  if (!!!t)
    throw new Error(
      "Unexpected invariant triggered."
    );
}
const Fa = /\r\n|[\n\r]/g;
function Zt(t, e) {
  let n = 0, s = 1;
  for (const r of t.body.matchAll(Fa)) {
    if (typeof r.index == "number" || _a(!1), r.index >= e)
      break;
    n = r.index + r[0].length, s += 1;
  }
  return {
    line: s,
    column: e + 1 - n
  };
}
function La(t) {
  return Zs(
    t.source,
    Zt(t.source, t.start)
  );
}
function Zs(t, e) {
  const n = t.locationOffset.column - 1, s = "".padStart(n) + t.body, r = e.line - 1, i = t.locationOffset.line - 1, a = e.line + i, o = e.line === 1 ? n : 0, u = e.column + o, c = `${t.name}:${a}:${u}
`, h = s.split(/\r\n|[\n\r]/g), p = h[r];
  if (p.length > 120) {
    const v = Math.floor(u / 80), E = u % 80, N = [];
    for (let y = 0; y < p.length; y += 80)
      N.push(p.slice(y, y + 80));
    return c + $n([
      [`${a} |`, N[0]],
      ...N.slice(1, v + 1).map((y) => ["|", y]),
      ["|", "^".padStart(E)],
      ["|", N[v + 1]]
    ]);
  }
  return c + $n([
    // Lines specified like this: ["prefix", "string"],
    [`${a - 1} |`, h[r - 1]],
    [`${a} |`, p],
    ["|", "^".padStart(u)],
    [`${a + 1} |`, h[r + 1]]
  ]);
}
function $n(t) {
  const e = t.filter(([s, r]) => r !== void 0), n = Math.max(...e.map(([s]) => s.length));
  return e.map(([s, r]) => s.padStart(n) + (r ? " " + r : "")).join(`
`);
}
function Ra(t) {
  const e = t[0];
  return e == null || "kind" in e || "length" in e ? {
    nodes: e,
    source: t[1],
    positions: t[2],
    path: t[3],
    originalError: t[4],
    extensions: t[5]
  } : e;
}
class sn extends Error {
  /**
   * An array of `{ line, column }` locations within the source GraphQL document
   * which correspond to this error.
   *
   * Errors during validation often contain multiple locations, for example to
   * point out two things with the same name. Errors during execution include a
   * single location, the field which produced the error.
   *
   * Enumerable, and appears in the result of JSON.stringify().
   */
  /**
   * An array describing the JSON-path into the execution response which
   * corresponds to this error. Only included for errors during execution.
   *
   * Enumerable, and appears in the result of JSON.stringify().
   */
  /**
   * An array of GraphQL AST Nodes corresponding to this error.
   */
  /**
   * The source GraphQL document for the first location of this error.
   *
   * Note that if this Error represents more than one node, the source may not
   * represent nodes after the first node.
   */
  /**
   * An array of character offsets within the source GraphQL document
   * which correspond to this error.
   */
  /**
   * The original error thrown from a field resolver during execution.
   */
  /**
   * Extension fields to add to the formatted error.
   */
  /**
   * @deprecated Please use the `GraphQLErrorOptions` constructor overload instead.
   */
  constructor(e, ...n) {
    var s, r, i;
    const { nodes: a, source: o, positions: u, path: c, originalError: h, extensions: p } = Ra(n);
    super(e), this.name = "GraphQLError", this.path = c ?? void 0, this.originalError = h ?? void 0, this.nodes = Wn(
      Array.isArray(a) ? a : a ? [a] : void 0
    );
    const v = Wn(
      (s = this.nodes) === null || s === void 0 ? void 0 : s.map((N) => N.loc).filter((N) => N != null)
    );
    this.source = o ?? (v == null || (r = v[0]) === null || r === void 0 ? void 0 : r.source), this.positions = u ?? v?.map((N) => N.start), this.locations = u && o ? u.map((N) => Zt(o, N)) : v?.map((N) => Zt(N.source, N.start));
    const E = Ma(
      h?.extensions
    ) ? h?.extensions : void 0;
    this.extensions = (i = p ?? E) !== null && i !== void 0 ? i : /* @__PURE__ */ Object.create(null), Object.defineProperties(this, {
      message: {
        writable: !0,
        enumerable: !0
      },
      name: {
        enumerable: !1
      },
      nodes: {
        enumerable: !1
      },
      source: {
        enumerable: !1
      },
      positions: {
        enumerable: !1
      },
      originalError: {
        enumerable: !1
      }
    }), h != null && h.stack ? Object.defineProperty(this, "stack", {
      value: h.stack,
      writable: !0,
      configurable: !0
    }) : Error.captureStackTrace ? Error.captureStackTrace(this, sn) : Object.defineProperty(this, "stack", {
      value: Error().stack,
      writable: !0,
      configurable: !0
    });
  }
  get [Symbol.toStringTag]() {
    return "GraphQLError";
  }
  toString() {
    let e = this.message;
    if (this.nodes)
      for (const n of this.nodes)
        n.loc && (e += `

` + La(n.loc));
    else if (this.source && this.locations)
      for (const n of this.locations)
        e += `

` + Zs(this.source, n);
    return e;
  }
  toJSON() {
    const e = {
      message: this.message
    };
    return this.locations != null && (e.locations = this.locations), this.path != null && (e.path = this.path), this.extensions != null && Object.keys(this.extensions).length > 0 && (e.extensions = this.extensions), e;
  }
}
function Wn(t) {
  return t === void 0 || t.length === 0 ? void 0 : t;
}
function W(t, e, n) {
  return new sn(`Syntax Error: ${n}`, {
    source: t,
    positions: [e]
  });
}
class Va {
  /**
   * The character offset at which this Node begins.
   */
  /**
   * The character offset at which this Node ends.
   */
  /**
   * The Token at which this Node begins.
   */
  /**
   * The Token at which this Node ends.
   */
  /**
   * The Source document the AST represents.
   */
  constructor(e, n, s) {
    this.start = e.start, this.end = n.end, this.startToken = e, this.endToken = n, this.source = s;
  }
  get [Symbol.toStringTag]() {
    return "Location";
  }
  toJSON() {
    return {
      start: this.start,
      end: this.end
    };
  }
}
class qs {
  /**
   * The kind of Token.
   */
  /**
   * The character offset at which this Node begins.
   */
  /**
   * The character offset at which this Node ends.
   */
  /**
   * The 1-indexed line number on which this Token appears.
   */
  /**
   * The 1-indexed column number at which this Token begins.
   */
  /**
   * For non-punctuation tokens, represents the interpreted value of the token.
   *
   * Note: is undefined for punctuation tokens, but typed as string for
   * convenience in the parser.
   */
  /**
   * Tokens exist as nodes in a double-linked-list amongst all tokens
   * including ignored tokens. <SOF> is always the first node and <EOF>
   * the last.
   */
  constructor(e, n, s, r, i, a) {
    this.kind = e, this.start = n, this.end = s, this.line = r, this.column = i, this.value = a, this.prev = null, this.next = null;
  }
  get [Symbol.toStringTag]() {
    return "Token";
  }
  toJSON() {
    return {
      kind: this.kind,
      value: this.value,
      line: this.line,
      column: this.column
    };
  }
}
const Pa = {
  Name: [],
  Document: ["definitions"],
  OperationDefinition: [
    "name",
    "variableDefinitions",
    "directives",
    "selectionSet"
  ],
  VariableDefinition: ["variable", "type", "defaultValue", "directives"],
  Variable: ["name"],
  SelectionSet: ["selections"],
  Field: ["alias", "name", "arguments", "directives", "selectionSet"],
  Argument: ["name", "value"],
  FragmentSpread: ["name", "directives"],
  InlineFragment: ["typeCondition", "directives", "selectionSet"],
  FragmentDefinition: [
    "name",
    // Note: fragment variable definitions are deprecated and will removed in v17.0.0
    "variableDefinitions",
    "typeCondition",
    "directives",
    "selectionSet"
  ],
  IntValue: [],
  FloatValue: [],
  StringValue: [],
  BooleanValue: [],
  NullValue: [],
  EnumValue: [],
  ListValue: ["values"],
  ObjectValue: ["fields"],
  ObjectField: ["name", "value"],
  Directive: ["name", "arguments"],
  NamedType: ["name"],
  ListType: ["type"],
  NonNullType: ["type"],
  SchemaDefinition: ["description", "directives", "operationTypes"],
  OperationTypeDefinition: ["type"],
  ScalarTypeDefinition: ["description", "name", "directives"],
  ObjectTypeDefinition: [
    "description",
    "name",
    "interfaces",
    "directives",
    "fields"
  ],
  FieldDefinition: ["description", "name", "arguments", "type", "directives"],
  InputValueDefinition: [
    "description",
    "name",
    "type",
    "defaultValue",
    "directives"
  ],
  InterfaceTypeDefinition: [
    "description",
    "name",
    "interfaces",
    "directives",
    "fields"
  ],
  UnionTypeDefinition: ["description", "name", "directives", "types"],
  EnumTypeDefinition: ["description", "name", "directives", "values"],
  EnumValueDefinition: ["description", "name", "directives"],
  InputObjectTypeDefinition: ["description", "name", "directives", "fields"],
  DirectiveDefinition: ["description", "name", "arguments", "locations"],
  SchemaExtension: ["directives", "operationTypes"],
  ScalarTypeExtension: ["name", "directives"],
  ObjectTypeExtension: ["name", "interfaces", "directives", "fields"],
  InterfaceTypeExtension: ["name", "interfaces", "directives", "fields"],
  UnionTypeExtension: ["name", "directives", "types"],
  EnumTypeExtension: ["name", "directives", "values"],
  InputObjectTypeExtension: ["name", "directives", "fields"]
};
new Set(Object.keys(Pa));
var ve;
(function(t) {
  t.QUERY = "query", t.MUTATION = "mutation", t.SUBSCRIPTION = "subscription";
})(ve || (ve = {}));
var qt;
(function(t) {
  t.QUERY = "QUERY", t.MUTATION = "MUTATION", t.SUBSCRIPTION = "SUBSCRIPTION", t.FIELD = "FIELD", t.FRAGMENT_DEFINITION = "FRAGMENT_DEFINITION", t.FRAGMENT_SPREAD = "FRAGMENT_SPREAD", t.INLINE_FRAGMENT = "INLINE_FRAGMENT", t.VARIABLE_DEFINITION = "VARIABLE_DEFINITION", t.SCHEMA = "SCHEMA", t.SCALAR = "SCALAR", t.OBJECT = "OBJECT", t.FIELD_DEFINITION = "FIELD_DEFINITION", t.ARGUMENT_DEFINITION = "ARGUMENT_DEFINITION", t.INTERFACE = "INTERFACE", t.UNION = "UNION", t.ENUM = "ENUM", t.ENUM_VALUE = "ENUM_VALUE", t.INPUT_OBJECT = "INPUT_OBJECT", t.INPUT_FIELD_DEFINITION = "INPUT_FIELD_DEFINITION";
})(qt || (qt = {}));
var T;
(function(t) {
  t.NAME = "Name", t.DOCUMENT = "Document", t.OPERATION_DEFINITION = "OperationDefinition", t.VARIABLE_DEFINITION = "VariableDefinition", t.SELECTION_SET = "SelectionSet", t.FIELD = "Field", t.ARGUMENT = "Argument", t.FRAGMENT_SPREAD = "FragmentSpread", t.INLINE_FRAGMENT = "InlineFragment", t.FRAGMENT_DEFINITION = "FragmentDefinition", t.VARIABLE = "Variable", t.INT = "IntValue", t.FLOAT = "FloatValue", t.STRING = "StringValue", t.BOOLEAN = "BooleanValue", t.NULL = "NullValue", t.ENUM = "EnumValue", t.LIST = "ListValue", t.OBJECT = "ObjectValue", t.OBJECT_FIELD = "ObjectField", t.DIRECTIVE = "Directive", t.NAMED_TYPE = "NamedType", t.LIST_TYPE = "ListType", t.NON_NULL_TYPE = "NonNullType", t.SCHEMA_DEFINITION = "SchemaDefinition", t.OPERATION_TYPE_DEFINITION = "OperationTypeDefinition", t.SCALAR_TYPE_DEFINITION = "ScalarTypeDefinition", t.OBJECT_TYPE_DEFINITION = "ObjectTypeDefinition", t.FIELD_DEFINITION = "FieldDefinition", t.INPUT_VALUE_DEFINITION = "InputValueDefinition", t.INTERFACE_TYPE_DEFINITION = "InterfaceTypeDefinition", t.UNION_TYPE_DEFINITION = "UnionTypeDefinition", t.ENUM_TYPE_DEFINITION = "EnumTypeDefinition", t.ENUM_VALUE_DEFINITION = "EnumValueDefinition", t.INPUT_OBJECT_TYPE_DEFINITION = "InputObjectTypeDefinition", t.DIRECTIVE_DEFINITION = "DirectiveDefinition", t.SCHEMA_EXTENSION = "SchemaExtension", t.SCALAR_TYPE_EXTENSION = "ScalarTypeExtension", t.OBJECT_TYPE_EXTENSION = "ObjectTypeExtension", t.INTERFACE_TYPE_EXTENSION = "InterfaceTypeExtension", t.UNION_TYPE_EXTENSION = "UnionTypeExtension", t.ENUM_TYPE_EXTENSION = "EnumTypeExtension", t.INPUT_OBJECT_TYPE_EXTENSION = "InputObjectTypeExtension";
})(T || (T = {}));
function Ua(t) {
  return t === 9 || t === 32;
}
function Ue(t) {
  return t >= 48 && t <= 57;
}
function zs(t) {
  return t >= 97 && t <= 122 || // A-Z
  t >= 65 && t <= 90;
}
function js(t) {
  return zs(t) || t === 95;
}
function $a(t) {
  return zs(t) || Ue(t) || t === 95;
}
function Wa(t) {
  var e;
  let n = Number.MAX_SAFE_INTEGER, s = null, r = -1;
  for (let a = 0; a < t.length; ++a) {
    var i;
    const o = t[a], u = Ha(o);
    u !== o.length && (s = (i = s) !== null && i !== void 0 ? i : a, r = a, a !== 0 && u < n && (n = u));
  }
  return t.map((a, o) => o === 0 ? a : a.slice(n)).slice(
    (e = s) !== null && e !== void 0 ? e : 0,
    r + 1
  );
}
function Ha(t) {
  let e = 0;
  for (; e < t.length && Ua(t.charCodeAt(e)); )
    ++e;
  return e;
}
var l;
(function(t) {
  t.SOF = "<SOF>", t.EOF = "<EOF>", t.BANG = "!", t.DOLLAR = "$", t.AMP = "&", t.PAREN_L = "(", t.PAREN_R = ")", t.SPREAD = "...", t.COLON = ":", t.EQUALS = "=", t.AT = "@", t.BRACKET_L = "[", t.BRACKET_R = "]", t.BRACE_L = "{", t.PIPE = "|", t.BRACE_R = "}", t.NAME = "Name", t.INT = "Int", t.FLOAT = "Float", t.STRING = "String", t.BLOCK_STRING = "BlockString", t.COMMENT = "Comment";
})(l || (l = {}));
class Ba {
  /**
   * The previously focused non-ignored token.
   */
  /**
   * The currently focused non-ignored token.
   */
  /**
   * The (1-indexed) line containing the current token.
   */
  /**
   * The character offset at which the current line begins.
   */
  constructor(e) {
    const n = new qs(l.SOF, 0, 0, 0, 0);
    this.source = e, this.lastToken = n, this.token = n, this.line = 1, this.lineStart = 0;
  }
  get [Symbol.toStringTag]() {
    return "Lexer";
  }
  /**
   * Advances the token stream to the next non-ignored token.
   */
  advance() {
    return this.lastToken = this.token, this.token = this.lookahead();
  }
  /**
   * Looks ahead and returns the next non-ignored token, but does not change
   * the state of Lexer.
   */
  lookahead() {
    let e = this.token;
    if (e.kind !== l.EOF)
      do
        if (e.next)
          e = e.next;
        else {
          const n = Za(this, e.end);
          e.next = n, n.prev = e, e = n;
        }
      while (e.kind === l.COMMENT);
    return e;
  }
}
function Ya(t) {
  return t === l.BANG || t === l.DOLLAR || t === l.AMP || t === l.PAREN_L || t === l.PAREN_R || t === l.SPREAD || t === l.COLON || t === l.EQUALS || t === l.AT || t === l.BRACKET_L || t === l.BRACKET_R || t === l.BRACE_L || t === l.PIPE || t === l.BRACE_R;
}
function Ce(t) {
  return t >= 0 && t <= 55295 || t >= 57344 && t <= 1114111;
}
function wt(t, e) {
  return Gs(t.charCodeAt(e)) && Js(t.charCodeAt(e + 1));
}
function Gs(t) {
  return t >= 55296 && t <= 56319;
}
function Js(t) {
  return t >= 56320 && t <= 57343;
}
function me(t, e) {
  const n = t.source.body.codePointAt(e);
  if (n === void 0)
    return l.EOF;
  if (n >= 32 && n <= 126) {
    const s = String.fromCodePoint(n);
    return s === '"' ? `'"'` : `"${s}"`;
  }
  return "U+" + n.toString(16).toUpperCase().padStart(4, "0");
}
function P(t, e, n, s, r) {
  const i = t.line, a = 1 + n - t.lineStart;
  return new qs(e, n, s, i, a, r);
}
function Za(t, e) {
  const n = t.source.body, s = n.length;
  let r = e;
  for (; r < s; ) {
    const i = n.charCodeAt(r);
    switch (i) {
      case 65279:
      case 9:
      case 32:
      case 44:
        ++r;
        continue;
      case 10:
        ++r, ++t.line, t.lineStart = r;
        continue;
      case 13:
        n.charCodeAt(r + 1) === 10 ? r += 2 : ++r, ++t.line, t.lineStart = r;
        continue;
      case 35:
        return qa(t, r);
      case 33:
        return P(t, l.BANG, r, r + 1);
      case 36:
        return P(t, l.DOLLAR, r, r + 1);
      case 38:
        return P(t, l.AMP, r, r + 1);
      case 40:
        return P(t, l.PAREN_L, r, r + 1);
      case 41:
        return P(t, l.PAREN_R, r, r + 1);
      case 46:
        if (n.charCodeAt(r + 1) === 46 && n.charCodeAt(r + 2) === 46)
          return P(t, l.SPREAD, r, r + 3);
        break;
      case 58:
        return P(t, l.COLON, r, r + 1);
      case 61:
        return P(t, l.EQUALS, r, r + 1);
      case 64:
        return P(t, l.AT, r, r + 1);
      case 91:
        return P(t, l.BRACKET_L, r, r + 1);
      case 93:
        return P(t, l.BRACKET_R, r, r + 1);
      case 123:
        return P(t, l.BRACE_L, r, r + 1);
      case 124:
        return P(t, l.PIPE, r, r + 1);
      case 125:
        return P(t, l.BRACE_R, r, r + 1);
      case 34:
        return n.charCodeAt(r + 1) === 34 && n.charCodeAt(r + 2) === 34 ? Xa(t, r) : ja(t, r);
    }
    if (Ue(i) || i === 45)
      return za(t, r, i);
    if (js(i))
      return Ka(t, r);
    throw W(
      t.source,
      r,
      i === 39 ? `Unexpected single quote character ('), did you mean to use a double quote (")?` : Ce(i) || wt(n, r) ? `Unexpected character: ${me(t, r)}.` : `Invalid character: ${me(t, r)}.`
    );
  }
  return P(t, l.EOF, s, s);
}
function qa(t, e) {
  const n = t.source.body, s = n.length;
  let r = e + 1;
  for (; r < s; ) {
    const i = n.charCodeAt(r);
    if (i === 10 || i === 13)
      break;
    if (Ce(i))
      ++r;
    else if (wt(n, r))
      r += 2;
    else
      break;
  }
  return P(
    t,
    l.COMMENT,
    e,
    r,
    n.slice(e + 1, r)
  );
}
function za(t, e, n) {
  const s = t.source.body;
  let r = e, i = n, a = !1;
  if (i === 45 && (i = s.charCodeAt(++r)), i === 48) {
    if (i = s.charCodeAt(++r), Ue(i))
      throw W(
        t.source,
        r,
        `Invalid number, unexpected digit after 0: ${me(
          t,
          r
        )}.`
      );
  } else
    r = Rt(t, r, i), i = s.charCodeAt(r);
  if (i === 46 && (a = !0, i = s.charCodeAt(++r), r = Rt(t, r, i), i = s.charCodeAt(r)), (i === 69 || i === 101) && (a = !0, i = s.charCodeAt(++r), (i === 43 || i === 45) && (i = s.charCodeAt(++r)), r = Rt(t, r, i), i = s.charCodeAt(r)), i === 46 || js(i))
    throw W(
      t.source,
      r,
      `Invalid number, expected digit but got: ${me(
        t,
        r
      )}.`
    );
  return P(
    t,
    a ? l.FLOAT : l.INT,
    e,
    r,
    s.slice(e, r)
  );
}
function Rt(t, e, n) {
  if (!Ue(n))
    throw W(
      t.source,
      e,
      `Invalid number, expected digit but got: ${me(
        t,
        e
      )}.`
    );
  const s = t.source.body;
  let r = e + 1;
  for (; Ue(s.charCodeAt(r)); )
    ++r;
  return r;
}
function ja(t, e) {
  const n = t.source.body, s = n.length;
  let r = e + 1, i = r, a = "";
  for (; r < s; ) {
    const o = n.charCodeAt(r);
    if (o === 34)
      return a += n.slice(i, r), P(t, l.STRING, e, r + 1, a);
    if (o === 92) {
      a += n.slice(i, r);
      const u = n.charCodeAt(r + 1) === 117 ? n.charCodeAt(r + 2) === 123 ? Ga(t, r) : Ja(t, r) : Qa(t, r);
      a += u.value, r += u.size, i = r;
      continue;
    }
    if (o === 10 || o === 13)
      break;
    if (Ce(o))
      ++r;
    else if (wt(n, r))
      r += 2;
    else
      throw W(
        t.source,
        r,
        `Invalid character within String: ${me(
          t,
          r
        )}.`
      );
  }
  throw W(t.source, r, "Unterminated string.");
}
function Ga(t, e) {
  const n = t.source.body;
  let s = 0, r = 3;
  for (; r < 12; ) {
    const i = n.charCodeAt(e + r++);
    if (i === 125) {
      if (r < 5 || !Ce(s))
        break;
      return {
        value: String.fromCodePoint(s),
        size: r
      };
    }
    if (s = s << 4 | Re(i), s < 0)
      break;
  }
  throw W(
    t.source,
    e,
    `Invalid Unicode escape sequence: "${n.slice(
      e,
      e + r
    )}".`
  );
}
function Ja(t, e) {
  const n = t.source.body, s = Hn(n, e + 2);
  if (Ce(s))
    return {
      value: String.fromCodePoint(s),
      size: 6
    };
  if (Gs(s) && n.charCodeAt(e + 6) === 92 && n.charCodeAt(e + 7) === 117) {
    const r = Hn(n, e + 8);
    if (Js(r))
      return {
        value: String.fromCodePoint(s, r),
        size: 12
      };
  }
  throw W(
    t.source,
    e,
    `Invalid Unicode escape sequence: "${n.slice(e, e + 6)}".`
  );
}
function Hn(t, e) {
  return Re(t.charCodeAt(e)) << 12 | Re(t.charCodeAt(e + 1)) << 8 | Re(t.charCodeAt(e + 2)) << 4 | Re(t.charCodeAt(e + 3));
}
function Re(t) {
  return t >= 48 && t <= 57 ? t - 48 : t >= 65 && t <= 70 ? t - 55 : t >= 97 && t <= 102 ? t - 87 : -1;
}
function Qa(t, e) {
  const n = t.source.body;
  switch (n.charCodeAt(e + 1)) {
    case 34:
      return {
        value: '"',
        size: 2
      };
    case 92:
      return {
        value: "\\",
        size: 2
      };
    case 47:
      return {
        value: "/",
        size: 2
      };
    case 98:
      return {
        value: "\b",
        size: 2
      };
    case 102:
      return {
        value: "\f",
        size: 2
      };
    case 110:
      return {
        value: `
`,
        size: 2
      };
    case 114:
      return {
        value: "\r",
        size: 2
      };
    case 116:
      return {
        value: "	",
        size: 2
      };
  }
  throw W(
    t.source,
    e,
    `Invalid character escape sequence: "${n.slice(
      e,
      e + 2
    )}".`
  );
}
function Xa(t, e) {
  const n = t.source.body, s = n.length;
  let r = t.lineStart, i = e + 3, a = i, o = "";
  const u = [];
  for (; i < s; ) {
    const c = n.charCodeAt(i);
    if (c === 34 && n.charCodeAt(i + 1) === 34 && n.charCodeAt(i + 2) === 34) {
      o += n.slice(a, i), u.push(o);
      const h = P(
        t,
        l.BLOCK_STRING,
        e,
        i + 3,
        // Return a string of the lines joined with U+000A.
        Wa(u).join(`
`)
      );
      return t.line += u.length - 1, t.lineStart = r, h;
    }
    if (c === 92 && n.charCodeAt(i + 1) === 34 && n.charCodeAt(i + 2) === 34 && n.charCodeAt(i + 3) === 34) {
      o += n.slice(a, i), a = i + 1, i += 4;
      continue;
    }
    if (c === 10 || c === 13) {
      o += n.slice(a, i), u.push(o), c === 13 && n.charCodeAt(i + 1) === 10 ? i += 2 : ++i, o = "", a = i, r = i;
      continue;
    }
    if (Ce(c))
      ++i;
    else if (wt(n, i))
      i += 2;
    else
      throw W(
        t.source,
        i,
        `Invalid character within String: ${me(
          t,
          i
        )}.`
      );
  }
  throw W(t.source, i, "Unterminated string.");
}
function Ka(t, e) {
  const n = t.source.body, s = n.length;
  let r = e + 1;
  for (; r < s; ) {
    const i = n.charCodeAt(r);
    if ($a(i))
      ++r;
    else
      break;
  }
  return P(
    t,
    l.NAME,
    e,
    r,
    n.slice(e, r)
  );
}
const eo = 10, Qs = 2;
function Xs(t) {
  return Ot(t, []);
}
function Ot(t, e) {
  switch (typeof t) {
    case "string":
      return JSON.stringify(t);
    case "function":
      return t.name ? `[function ${t.name}]` : "[function]";
    case "object":
      return to(t, e);
    default:
      return String(t);
  }
}
function to(t, e) {
  if (t === null)
    return "null";
  if (e.includes(t))
    return "[Circular]";
  const n = [...e, t];
  if (no(t)) {
    const s = t.toJSON();
    if (s !== t)
      return typeof s == "string" ? s : Ot(s, n);
  } else if (Array.isArray(t))
    return ro(t, n);
  return so(t, n);
}
function no(t) {
  return typeof t.toJSON == "function";
}
function so(t, e) {
  const n = Object.entries(t);
  return n.length === 0 ? "{}" : e.length > Qs ? "[" + io(t) + "]" : "{ " + n.map(
    ([r, i]) => r + ": " + Ot(i, e)
  ).join(", ") + " }";
}
function ro(t, e) {
  if (t.length === 0)
    return "[]";
  if (e.length > Qs)
    return "[Array]";
  const n = Math.min(eo, t.length), s = t.length - n, r = [];
  for (let i = 0; i < n; ++i)
    r.push(Ot(t[i], e));
  return s === 1 ? r.push("... 1 more item") : s > 1 && r.push(`... ${s} more items`), "[" + r.join(", ") + "]";
}
function io(t) {
  const e = Object.prototype.toString.call(t).replace(/^\[object /, "").replace(/]$/, "");
  if (e === "Object" && typeof t.constructor == "function") {
    const n = t.constructor.name;
    if (typeof n == "string" && n !== "")
      return n;
  }
  return e;
}
var ao = {};
const oo = globalThis.process && // eslint-disable-next-line no-undef
ao.NODE_ENV === "production", uo = (
  /* c8 ignore next 6 */
  // FIXME: https://github.com/graphql/graphql-js/issues/2317
  oo ? function(e, n) {
    return e instanceof n;
  } : function(e, n) {
    if (e instanceof n)
      return !0;
    if (typeof e == "object" && e !== null) {
      var s;
      const r = n.prototype[Symbol.toStringTag], i = (
        // We still need to support constructor's name to detect conflicts with older versions of this library.
        Symbol.toStringTag in e ? e[Symbol.toStringTag] : (s = e.constructor) === null || s === void 0 ? void 0 : s.name
      );
      if (r === i) {
        const a = Xs(e);
        throw new Error(`Cannot use ${r} "${a}" from another module or realm.

Ensure that there is only one instance of "graphql" in the node_modules
directory. If different versions of "graphql" are the dependencies of other
relied on modules, use "resolutions" to ensure only one version is installed.

https://yarnpkg.com/en/docs/selective-version-resolutions

Duplicate "graphql" modules cannot be used at the same time since different
versions may have different capabilities and behavior. The data from one
version used in the function from another could produce confusing and
spurious results.`);
      }
    }
    return !1;
  }
);
class Ks {
  constructor(e, n = "GraphQL request", s = {
    line: 1,
    column: 1
  }) {
    typeof e == "string" || Lt(!1, `Body must be a string. Received: ${Xs(e)}.`), this.body = e, this.name = n, this.locationOffset = s, this.locationOffset.line > 0 || Lt(
      !1,
      "line in locationOffset is 1-indexed and must be positive."
    ), this.locationOffset.column > 0 || Lt(
      !1,
      "column in locationOffset is 1-indexed and must be positive."
    );
  }
  get [Symbol.toStringTag]() {
    return "Source";
  }
}
function co(t) {
  return uo(t, Ks);
}
function lo(t, e) {
  return new ho(t, e).parseDocument();
}
class ho {
  constructor(e, n = {}) {
    const s = co(e) ? e : new Ks(e);
    this._lexer = new Ba(s), this._options = n, this._tokenCounter = 0;
  }
  /**
   * Converts a name lex token into a name parse node.
   */
  parseName() {
    const e = this.expectToken(l.NAME);
    return this.node(e, {
      kind: T.NAME,
      value: e.value
    });
  }
  // Implements the parsing rules in the Document section.
  /**
   * Document : Definition+
   */
  parseDocument() {
    return this.node(this._lexer.token, {
      kind: T.DOCUMENT,
      definitions: this.many(
        l.SOF,
        this.parseDefinition,
        l.EOF
      )
    });
  }
  /**
   * Definition :
   *   - ExecutableDefinition
   *   - TypeSystemDefinition
   *   - TypeSystemExtension
   *
   * ExecutableDefinition :
   *   - OperationDefinition
   *   - FragmentDefinition
   *
   * TypeSystemDefinition :
   *   - SchemaDefinition
   *   - TypeDefinition
   *   - DirectiveDefinition
   *
   * TypeDefinition :
   *   - ScalarTypeDefinition
   *   - ObjectTypeDefinition
   *   - InterfaceTypeDefinition
   *   - UnionTypeDefinition
   *   - EnumTypeDefinition
   *   - InputObjectTypeDefinition
   */
  parseDefinition() {
    if (this.peek(l.BRACE_L))
      return this.parseOperationDefinition();
    const e = this.peekDescription(), n = e ? this._lexer.lookahead() : this._lexer.token;
    if (n.kind === l.NAME) {
      switch (n.value) {
        case "schema":
          return this.parseSchemaDefinition();
        case "scalar":
          return this.parseScalarTypeDefinition();
        case "type":
          return this.parseObjectTypeDefinition();
        case "interface":
          return this.parseInterfaceTypeDefinition();
        case "union":
          return this.parseUnionTypeDefinition();
        case "enum":
          return this.parseEnumTypeDefinition();
        case "input":
          return this.parseInputObjectTypeDefinition();
        case "directive":
          return this.parseDirectiveDefinition();
      }
      if (e)
        throw W(
          this._lexer.source,
          this._lexer.token.start,
          "Unexpected description, descriptions are supported only on type definitions."
        );
      switch (n.value) {
        case "query":
        case "mutation":
        case "subscription":
          return this.parseOperationDefinition();
        case "fragment":
          return this.parseFragmentDefinition();
        case "extend":
          return this.parseTypeSystemExtension();
      }
    }
    throw this.unexpected(n);
  }
  // Implements the parsing rules in the Operations section.
  /**
   * OperationDefinition :
   *  - SelectionSet
   *  - OperationType Name? VariableDefinitions? Directives? SelectionSet
   */
  parseOperationDefinition() {
    const e = this._lexer.token;
    if (this.peek(l.BRACE_L))
      return this.node(e, {
        kind: T.OPERATION_DEFINITION,
        operation: ve.QUERY,
        name: void 0,
        variableDefinitions: [],
        directives: [],
        selectionSet: this.parseSelectionSet()
      });
    const n = this.parseOperationType();
    let s;
    return this.peek(l.NAME) && (s = this.parseName()), this.node(e, {
      kind: T.OPERATION_DEFINITION,
      operation: n,
      name: s,
      variableDefinitions: this.parseVariableDefinitions(),
      directives: this.parseDirectives(!1),
      selectionSet: this.parseSelectionSet()
    });
  }
  /**
   * OperationType : one of query mutation subscription
   */
  parseOperationType() {
    const e = this.expectToken(l.NAME);
    switch (e.value) {
      case "query":
        return ve.QUERY;
      case "mutation":
        return ve.MUTATION;
      case "subscription":
        return ve.SUBSCRIPTION;
    }
    throw this.unexpected(e);
  }
  /**
   * VariableDefinitions : ( VariableDefinition+ )
   */
  parseVariableDefinitions() {
    return this.optionalMany(
      l.PAREN_L,
      this.parseVariableDefinition,
      l.PAREN_R
    );
  }
  /**
   * VariableDefinition : Variable : Type DefaultValue? Directives[Const]?
   */
  parseVariableDefinition() {
    return this.node(this._lexer.token, {
      kind: T.VARIABLE_DEFINITION,
      variable: this.parseVariable(),
      type: (this.expectToken(l.COLON), this.parseTypeReference()),
      defaultValue: this.expectOptionalToken(l.EQUALS) ? this.parseConstValueLiteral() : void 0,
      directives: this.parseConstDirectives()
    });
  }
  /**
   * Variable : $ Name
   */
  parseVariable() {
    const e = this._lexer.token;
    return this.expectToken(l.DOLLAR), this.node(e, {
      kind: T.VARIABLE,
      name: this.parseName()
    });
  }
  /**
   * ```
   * SelectionSet : { Selection+ }
   * ```
   */
  parseSelectionSet() {
    return this.node(this._lexer.token, {
      kind: T.SELECTION_SET,
      selections: this.many(
        l.BRACE_L,
        this.parseSelection,
        l.BRACE_R
      )
    });
  }
  /**
   * Selection :
   *   - Field
   *   - FragmentSpread
   *   - InlineFragment
   */
  parseSelection() {
    return this.peek(l.SPREAD) ? this.parseFragment() : this.parseField();
  }
  /**
   * Field : Alias? Name Arguments? Directives? SelectionSet?
   *
   * Alias : Name :
   */
  parseField() {
    const e = this._lexer.token, n = this.parseName();
    let s, r;
    return this.expectOptionalToken(l.COLON) ? (s = n, r = this.parseName()) : r = n, this.node(e, {
      kind: T.FIELD,
      alias: s,
      name: r,
      arguments: this.parseArguments(!1),
      directives: this.parseDirectives(!1),
      selectionSet: this.peek(l.BRACE_L) ? this.parseSelectionSet() : void 0
    });
  }
  /**
   * Arguments[Const] : ( Argument[?Const]+ )
   */
  parseArguments(e) {
    const n = e ? this.parseConstArgument : this.parseArgument;
    return this.optionalMany(l.PAREN_L, n, l.PAREN_R);
  }
  /**
   * Argument[Const] : Name : Value[?Const]
   */
  parseArgument(e = !1) {
    const n = this._lexer.token, s = this.parseName();
    return this.expectToken(l.COLON), this.node(n, {
      kind: T.ARGUMENT,
      name: s,
      value: this.parseValueLiteral(e)
    });
  }
  parseConstArgument() {
    return this.parseArgument(!0);
  }
  // Implements the parsing rules in the Fragments section.
  /**
   * Corresponds to both FragmentSpread and InlineFragment in the spec.
   *
   * FragmentSpread : ... FragmentName Directives?
   *
   * InlineFragment : ... TypeCondition? Directives? SelectionSet
   */
  parseFragment() {
    const e = this._lexer.token;
    this.expectToken(l.SPREAD);
    const n = this.expectOptionalKeyword("on");
    return !n && this.peek(l.NAME) ? this.node(e, {
      kind: T.FRAGMENT_SPREAD,
      name: this.parseFragmentName(),
      directives: this.parseDirectives(!1)
    }) : this.node(e, {
      kind: T.INLINE_FRAGMENT,
      typeCondition: n ? this.parseNamedType() : void 0,
      directives: this.parseDirectives(!1),
      selectionSet: this.parseSelectionSet()
    });
  }
  /**
   * FragmentDefinition :
   *   - fragment FragmentName on TypeCondition Directives? SelectionSet
   *
   * TypeCondition : NamedType
   */
  parseFragmentDefinition() {
    const e = this._lexer.token;
    return this.expectKeyword("fragment"), this._options.allowLegacyFragmentVariables === !0 ? this.node(e, {
      kind: T.FRAGMENT_DEFINITION,
      name: this.parseFragmentName(),
      variableDefinitions: this.parseVariableDefinitions(),
      typeCondition: (this.expectKeyword("on"), this.parseNamedType()),
      directives: this.parseDirectives(!1),
      selectionSet: this.parseSelectionSet()
    }) : this.node(e, {
      kind: T.FRAGMENT_DEFINITION,
      name: this.parseFragmentName(),
      typeCondition: (this.expectKeyword("on"), this.parseNamedType()),
      directives: this.parseDirectives(!1),
      selectionSet: this.parseSelectionSet()
    });
  }
  /**
   * FragmentName : Name but not `on`
   */
  parseFragmentName() {
    if (this._lexer.token.value === "on")
      throw this.unexpected();
    return this.parseName();
  }
  // Implements the parsing rules in the Values section.
  /**
   * Value[Const] :
   *   - [~Const] Variable
   *   - IntValue
   *   - FloatValue
   *   - StringValue
   *   - BooleanValue
   *   - NullValue
   *   - EnumValue
   *   - ListValue[?Const]
   *   - ObjectValue[?Const]
   *
   * BooleanValue : one of `true` `false`
   *
   * NullValue : `null`
   *
   * EnumValue : Name but not `true`, `false` or `null`
   */
  parseValueLiteral(e) {
    const n = this._lexer.token;
    switch (n.kind) {
      case l.BRACKET_L:
        return this.parseList(e);
      case l.BRACE_L:
        return this.parseObject(e);
      case l.INT:
        return this.advanceLexer(), this.node(n, {
          kind: T.INT,
          value: n.value
        });
      case l.FLOAT:
        return this.advanceLexer(), this.node(n, {
          kind: T.FLOAT,
          value: n.value
        });
      case l.STRING:
      case l.BLOCK_STRING:
        return this.parseStringLiteral();
      case l.NAME:
        switch (this.advanceLexer(), n.value) {
          case "true":
            return this.node(n, {
              kind: T.BOOLEAN,
              value: !0
            });
          case "false":
            return this.node(n, {
              kind: T.BOOLEAN,
              value: !1
            });
          case "null":
            return this.node(n, {
              kind: T.NULL
            });
          default:
            return this.node(n, {
              kind: T.ENUM,
              value: n.value
            });
        }
      case l.DOLLAR:
        if (e)
          if (this.expectToken(l.DOLLAR), this._lexer.token.kind === l.NAME) {
            const s = this._lexer.token.value;
            throw W(
              this._lexer.source,
              n.start,
              `Unexpected variable "$${s}" in constant value.`
            );
          } else
            throw this.unexpected(n);
        return this.parseVariable();
      default:
        throw this.unexpected();
    }
  }
  parseConstValueLiteral() {
    return this.parseValueLiteral(!0);
  }
  parseStringLiteral() {
    const e = this._lexer.token;
    return this.advanceLexer(), this.node(e, {
      kind: T.STRING,
      value: e.value,
      block: e.kind === l.BLOCK_STRING
    });
  }
  /**
   * ListValue[Const] :
   *   - [ ]
   *   - [ Value[?Const]+ ]
   */
  parseList(e) {
    const n = () => this.parseValueLiteral(e);
    return this.node(this._lexer.token, {
      kind: T.LIST,
      values: this.any(l.BRACKET_L, n, l.BRACKET_R)
    });
  }
  /**
   * ```
   * ObjectValue[Const] :
   *   - { }
   *   - { ObjectField[?Const]+ }
   * ```
   */
  parseObject(e) {
    const n = () => this.parseObjectField(e);
    return this.node(this._lexer.token, {
      kind: T.OBJECT,
      fields: this.any(l.BRACE_L, n, l.BRACE_R)
    });
  }
  /**
   * ObjectField[Const] : Name : Value[?Const]
   */
  parseObjectField(e) {
    const n = this._lexer.token, s = this.parseName();
    return this.expectToken(l.COLON), this.node(n, {
      kind: T.OBJECT_FIELD,
      name: s,
      value: this.parseValueLiteral(e)
    });
  }
  // Implements the parsing rules in the Directives section.
  /**
   * Directives[Const] : Directive[?Const]+
   */
  parseDirectives(e) {
    const n = [];
    for (; this.peek(l.AT); )
      n.push(this.parseDirective(e));
    return n;
  }
  parseConstDirectives() {
    return this.parseDirectives(!0);
  }
  /**
   * ```
   * Directive[Const] : @ Name Arguments[?Const]?
   * ```
   */
  parseDirective(e) {
    const n = this._lexer.token;
    return this.expectToken(l.AT), this.node(n, {
      kind: T.DIRECTIVE,
      name: this.parseName(),
      arguments: this.parseArguments(e)
    });
  }
  // Implements the parsing rules in the Types section.
  /**
   * Type :
   *   - NamedType
   *   - ListType
   *   - NonNullType
   */
  parseTypeReference() {
    const e = this._lexer.token;
    let n;
    if (this.expectOptionalToken(l.BRACKET_L)) {
      const s = this.parseTypeReference();
      this.expectToken(l.BRACKET_R), n = this.node(e, {
        kind: T.LIST_TYPE,
        type: s
      });
    } else
      n = this.parseNamedType();
    return this.expectOptionalToken(l.BANG) ? this.node(e, {
      kind: T.NON_NULL_TYPE,
      type: n
    }) : n;
  }
  /**
   * NamedType : Name
   */
  parseNamedType() {
    return this.node(this._lexer.token, {
      kind: T.NAMED_TYPE,
      name: this.parseName()
    });
  }
  // Implements the parsing rules in the Type Definition section.
  peekDescription() {
    return this.peek(l.STRING) || this.peek(l.BLOCK_STRING);
  }
  /**
   * Description : StringValue
   */
  parseDescription() {
    if (this.peekDescription())
      return this.parseStringLiteral();
  }
  /**
   * ```
   * SchemaDefinition : Description? schema Directives[Const]? { OperationTypeDefinition+ }
   * ```
   */
  parseSchemaDefinition() {
    const e = this._lexer.token, n = this.parseDescription();
    this.expectKeyword("schema");
    const s = this.parseConstDirectives(), r = this.many(
      l.BRACE_L,
      this.parseOperationTypeDefinition,
      l.BRACE_R
    );
    return this.node(e, {
      kind: T.SCHEMA_DEFINITION,
      description: n,
      directives: s,
      operationTypes: r
    });
  }
  /**
   * OperationTypeDefinition : OperationType : NamedType
   */
  parseOperationTypeDefinition() {
    const e = this._lexer.token, n = this.parseOperationType();
    this.expectToken(l.COLON);
    const s = this.parseNamedType();
    return this.node(e, {
      kind: T.OPERATION_TYPE_DEFINITION,
      operation: n,
      type: s
    });
  }
  /**
   * ScalarTypeDefinition : Description? scalar Name Directives[Const]?
   */
  parseScalarTypeDefinition() {
    const e = this._lexer.token, n = this.parseDescription();
    this.expectKeyword("scalar");
    const s = this.parseName(), r = this.parseConstDirectives();
    return this.node(e, {
      kind: T.SCALAR_TYPE_DEFINITION,
      description: n,
      name: s,
      directives: r
    });
  }
  /**
   * ObjectTypeDefinition :
   *   Description?
   *   type Name ImplementsInterfaces? Directives[Const]? FieldsDefinition?
   */
  parseObjectTypeDefinition() {
    const e = this._lexer.token, n = this.parseDescription();
    this.expectKeyword("type");
    const s = this.parseName(), r = this.parseImplementsInterfaces(), i = this.parseConstDirectives(), a = this.parseFieldsDefinition();
    return this.node(e, {
      kind: T.OBJECT_TYPE_DEFINITION,
      description: n,
      name: s,
      interfaces: r,
      directives: i,
      fields: a
    });
  }
  /**
   * ImplementsInterfaces :
   *   - implements `&`? NamedType
   *   - ImplementsInterfaces & NamedType
   */
  parseImplementsInterfaces() {
    return this.expectOptionalKeyword("implements") ? this.delimitedMany(l.AMP, this.parseNamedType) : [];
  }
  /**
   * ```
   * FieldsDefinition : { FieldDefinition+ }
   * ```
   */
  parseFieldsDefinition() {
    return this.optionalMany(
      l.BRACE_L,
      this.parseFieldDefinition,
      l.BRACE_R
    );
  }
  /**
   * FieldDefinition :
   *   - Description? Name ArgumentsDefinition? : Type Directives[Const]?
   */
  parseFieldDefinition() {
    const e = this._lexer.token, n = this.parseDescription(), s = this.parseName(), r = this.parseArgumentDefs();
    this.expectToken(l.COLON);
    const i = this.parseTypeReference(), a = this.parseConstDirectives();
    return this.node(e, {
      kind: T.FIELD_DEFINITION,
      description: n,
      name: s,
      arguments: r,
      type: i,
      directives: a
    });
  }
  /**
   * ArgumentsDefinition : ( InputValueDefinition+ )
   */
  parseArgumentDefs() {
    return this.optionalMany(
      l.PAREN_L,
      this.parseInputValueDef,
      l.PAREN_R
    );
  }
  /**
   * InputValueDefinition :
   *   - Description? Name : Type DefaultValue? Directives[Const]?
   */
  parseInputValueDef() {
    const e = this._lexer.token, n = this.parseDescription(), s = this.parseName();
    this.expectToken(l.COLON);
    const r = this.parseTypeReference();
    let i;
    this.expectOptionalToken(l.EQUALS) && (i = this.parseConstValueLiteral());
    const a = this.parseConstDirectives();
    return this.node(e, {
      kind: T.INPUT_VALUE_DEFINITION,
      description: n,
      name: s,
      type: r,
      defaultValue: i,
      directives: a
    });
  }
  /**
   * InterfaceTypeDefinition :
   *   - Description? interface Name Directives[Const]? FieldsDefinition?
   */
  parseInterfaceTypeDefinition() {
    const e = this._lexer.token, n = this.parseDescription();
    this.expectKeyword("interface");
    const s = this.parseName(), r = this.parseImplementsInterfaces(), i = this.parseConstDirectives(), a = this.parseFieldsDefinition();
    return this.node(e, {
      kind: T.INTERFACE_TYPE_DEFINITION,
      description: n,
      name: s,
      interfaces: r,
      directives: i,
      fields: a
    });
  }
  /**
   * UnionTypeDefinition :
   *   - Description? union Name Directives[Const]? UnionMemberTypes?
   */
  parseUnionTypeDefinition() {
    const e = this._lexer.token, n = this.parseDescription();
    this.expectKeyword("union");
    const s = this.parseName(), r = this.parseConstDirectives(), i = this.parseUnionMemberTypes();
    return this.node(e, {
      kind: T.UNION_TYPE_DEFINITION,
      description: n,
      name: s,
      directives: r,
      types: i
    });
  }
  /**
   * UnionMemberTypes :
   *   - = `|`? NamedType
   *   - UnionMemberTypes | NamedType
   */
  parseUnionMemberTypes() {
    return this.expectOptionalToken(l.EQUALS) ? this.delimitedMany(l.PIPE, this.parseNamedType) : [];
  }
  /**
   * EnumTypeDefinition :
   *   - Description? enum Name Directives[Const]? EnumValuesDefinition?
   */
  parseEnumTypeDefinition() {
    const e = this._lexer.token, n = this.parseDescription();
    this.expectKeyword("enum");
    const s = this.parseName(), r = this.parseConstDirectives(), i = this.parseEnumValuesDefinition();
    return this.node(e, {
      kind: T.ENUM_TYPE_DEFINITION,
      description: n,
      name: s,
      directives: r,
      values: i
    });
  }
  /**
   * ```
   * EnumValuesDefinition : { EnumValueDefinition+ }
   * ```
   */
  parseEnumValuesDefinition() {
    return this.optionalMany(
      l.BRACE_L,
      this.parseEnumValueDefinition,
      l.BRACE_R
    );
  }
  /**
   * EnumValueDefinition : Description? EnumValue Directives[Const]?
   */
  parseEnumValueDefinition() {
    const e = this._lexer.token, n = this.parseDescription(), s = this.parseEnumValueName(), r = this.parseConstDirectives();
    return this.node(e, {
      kind: T.ENUM_VALUE_DEFINITION,
      description: n,
      name: s,
      directives: r
    });
  }
  /**
   * EnumValue : Name but not `true`, `false` or `null`
   */
  parseEnumValueName() {
    if (this._lexer.token.value === "true" || this._lexer.token.value === "false" || this._lexer.token.value === "null")
      throw W(
        this._lexer.source,
        this._lexer.token.start,
        `${Ke(
          this._lexer.token
        )} is reserved and cannot be used for an enum value.`
      );
    return this.parseName();
  }
  /**
   * InputObjectTypeDefinition :
   *   - Description? input Name Directives[Const]? InputFieldsDefinition?
   */
  parseInputObjectTypeDefinition() {
    const e = this._lexer.token, n = this.parseDescription();
    this.expectKeyword("input");
    const s = this.parseName(), r = this.parseConstDirectives(), i = this.parseInputFieldsDefinition();
    return this.node(e, {
      kind: T.INPUT_OBJECT_TYPE_DEFINITION,
      description: n,
      name: s,
      directives: r,
      fields: i
    });
  }
  /**
   * ```
   * InputFieldsDefinition : { InputValueDefinition+ }
   * ```
   */
  parseInputFieldsDefinition() {
    return this.optionalMany(
      l.BRACE_L,
      this.parseInputValueDef,
      l.BRACE_R
    );
  }
  /**
   * TypeSystemExtension :
   *   - SchemaExtension
   *   - TypeExtension
   *
   * TypeExtension :
   *   - ScalarTypeExtension
   *   - ObjectTypeExtension
   *   - InterfaceTypeExtension
   *   - UnionTypeExtension
   *   - EnumTypeExtension
   *   - InputObjectTypeDefinition
   */
  parseTypeSystemExtension() {
    const e = this._lexer.lookahead();
    if (e.kind === l.NAME)
      switch (e.value) {
        case "schema":
          return this.parseSchemaExtension();
        case "scalar":
          return this.parseScalarTypeExtension();
        case "type":
          return this.parseObjectTypeExtension();
        case "interface":
          return this.parseInterfaceTypeExtension();
        case "union":
          return this.parseUnionTypeExtension();
        case "enum":
          return this.parseEnumTypeExtension();
        case "input":
          return this.parseInputObjectTypeExtension();
      }
    throw this.unexpected(e);
  }
  /**
   * ```
   * SchemaExtension :
   *  - extend schema Directives[Const]? { OperationTypeDefinition+ }
   *  - extend schema Directives[Const]
   * ```
   */
  parseSchemaExtension() {
    const e = this._lexer.token;
    this.expectKeyword("extend"), this.expectKeyword("schema");
    const n = this.parseConstDirectives(), s = this.optionalMany(
      l.BRACE_L,
      this.parseOperationTypeDefinition,
      l.BRACE_R
    );
    if (n.length === 0 && s.length === 0)
      throw this.unexpected();
    return this.node(e, {
      kind: T.SCHEMA_EXTENSION,
      directives: n,
      operationTypes: s
    });
  }
  /**
   * ScalarTypeExtension :
   *   - extend scalar Name Directives[Const]
   */
  parseScalarTypeExtension() {
    const e = this._lexer.token;
    this.expectKeyword("extend"), this.expectKeyword("scalar");
    const n = this.parseName(), s = this.parseConstDirectives();
    if (s.length === 0)
      throw this.unexpected();
    return this.node(e, {
      kind: T.SCALAR_TYPE_EXTENSION,
      name: n,
      directives: s
    });
  }
  /**
   * ObjectTypeExtension :
   *  - extend type Name ImplementsInterfaces? Directives[Const]? FieldsDefinition
   *  - extend type Name ImplementsInterfaces? Directives[Const]
   *  - extend type Name ImplementsInterfaces
   */
  parseObjectTypeExtension() {
    const e = this._lexer.token;
    this.expectKeyword("extend"), this.expectKeyword("type");
    const n = this.parseName(), s = this.parseImplementsInterfaces(), r = this.parseConstDirectives(), i = this.parseFieldsDefinition();
    if (s.length === 0 && r.length === 0 && i.length === 0)
      throw this.unexpected();
    return this.node(e, {
      kind: T.OBJECT_TYPE_EXTENSION,
      name: n,
      interfaces: s,
      directives: r,
      fields: i
    });
  }
  /**
   * InterfaceTypeExtension :
   *  - extend interface Name ImplementsInterfaces? Directives[Const]? FieldsDefinition
   *  - extend interface Name ImplementsInterfaces? Directives[Const]
   *  - extend interface Name ImplementsInterfaces
   */
  parseInterfaceTypeExtension() {
    const e = this._lexer.token;
    this.expectKeyword("extend"), this.expectKeyword("interface");
    const n = this.parseName(), s = this.parseImplementsInterfaces(), r = this.parseConstDirectives(), i = this.parseFieldsDefinition();
    if (s.length === 0 && r.length === 0 && i.length === 0)
      throw this.unexpected();
    return this.node(e, {
      kind: T.INTERFACE_TYPE_EXTENSION,
      name: n,
      interfaces: s,
      directives: r,
      fields: i
    });
  }
  /**
   * UnionTypeExtension :
   *   - extend union Name Directives[Const]? UnionMemberTypes
   *   - extend union Name Directives[Const]
   */
  parseUnionTypeExtension() {
    const e = this._lexer.token;
    this.expectKeyword("extend"), this.expectKeyword("union");
    const n = this.parseName(), s = this.parseConstDirectives(), r = this.parseUnionMemberTypes();
    if (s.length === 0 && r.length === 0)
      throw this.unexpected();
    return this.node(e, {
      kind: T.UNION_TYPE_EXTENSION,
      name: n,
      directives: s,
      types: r
    });
  }
  /**
   * EnumTypeExtension :
   *   - extend enum Name Directives[Const]? EnumValuesDefinition
   *   - extend enum Name Directives[Const]
   */
  parseEnumTypeExtension() {
    const e = this._lexer.token;
    this.expectKeyword("extend"), this.expectKeyword("enum");
    const n = this.parseName(), s = this.parseConstDirectives(), r = this.parseEnumValuesDefinition();
    if (s.length === 0 && r.length === 0)
      throw this.unexpected();
    return this.node(e, {
      kind: T.ENUM_TYPE_EXTENSION,
      name: n,
      directives: s,
      values: r
    });
  }
  /**
   * InputObjectTypeExtension :
   *   - extend input Name Directives[Const]? InputFieldsDefinition
   *   - extend input Name Directives[Const]
   */
  parseInputObjectTypeExtension() {
    const e = this._lexer.token;
    this.expectKeyword("extend"), this.expectKeyword("input");
    const n = this.parseName(), s = this.parseConstDirectives(), r = this.parseInputFieldsDefinition();
    if (s.length === 0 && r.length === 0)
      throw this.unexpected();
    return this.node(e, {
      kind: T.INPUT_OBJECT_TYPE_EXTENSION,
      name: n,
      directives: s,
      fields: r
    });
  }
  /**
   * ```
   * DirectiveDefinition :
   *   - Description? directive @ Name ArgumentsDefinition? `repeatable`? on DirectiveLocations
   * ```
   */
  parseDirectiveDefinition() {
    const e = this._lexer.token, n = this.parseDescription();
    this.expectKeyword("directive"), this.expectToken(l.AT);
    const s = this.parseName(), r = this.parseArgumentDefs(), i = this.expectOptionalKeyword("repeatable");
    this.expectKeyword("on");
    const a = this.parseDirectiveLocations();
    return this.node(e, {
      kind: T.DIRECTIVE_DEFINITION,
      description: n,
      name: s,
      arguments: r,
      repeatable: i,
      locations: a
    });
  }
  /**
   * DirectiveLocations :
   *   - `|`? DirectiveLocation
   *   - DirectiveLocations | DirectiveLocation
   */
  parseDirectiveLocations() {
    return this.delimitedMany(l.PIPE, this.parseDirectiveLocation);
  }
  /*
   * DirectiveLocation :
   *   - ExecutableDirectiveLocation
   *   - TypeSystemDirectiveLocation
   *
   * ExecutableDirectiveLocation : one of
   *   `QUERY`
   *   `MUTATION`
   *   `SUBSCRIPTION`
   *   `FIELD`
   *   `FRAGMENT_DEFINITION`
   *   `FRAGMENT_SPREAD`
   *   `INLINE_FRAGMENT`
   *
   * TypeSystemDirectiveLocation : one of
   *   `SCHEMA`
   *   `SCALAR`
   *   `OBJECT`
   *   `FIELD_DEFINITION`
   *   `ARGUMENT_DEFINITION`
   *   `INTERFACE`
   *   `UNION`
   *   `ENUM`
   *   `ENUM_VALUE`
   *   `INPUT_OBJECT`
   *   `INPUT_FIELD_DEFINITION`
   */
  parseDirectiveLocation() {
    const e = this._lexer.token, n = this.parseName();
    if (Object.prototype.hasOwnProperty.call(qt, n.value))
      return n;
    throw this.unexpected(e);
  }
  // Core parsing utility functions
  /**
   * Returns a node that, if configured to do so, sets a "loc" field as a
   * location object, used to identify the place in the source that created a
   * given parsed object.
   */
  node(e, n) {
    return this._options.noLocation !== !0 && (n.loc = new Va(
      e,
      this._lexer.lastToken,
      this._lexer.source
    )), n;
  }
  /**
   * Determines if the next token is of a given kind
   */
  peek(e) {
    return this._lexer.token.kind === e;
  }
  /**
   * If the next token is of the given kind, return that token after advancing the lexer.
   * Otherwise, do not change the parser state and throw an error.
   */
  expectToken(e) {
    const n = this._lexer.token;
    if (n.kind === e)
      return this.advanceLexer(), n;
    throw W(
      this._lexer.source,
      n.start,
      `Expected ${er(e)}, found ${Ke(n)}.`
    );
  }
  /**
   * If the next token is of the given kind, return "true" after advancing the lexer.
   * Otherwise, do not change the parser state and return "false".
   */
  expectOptionalToken(e) {
    return this._lexer.token.kind === e ? (this.advanceLexer(), !0) : !1;
  }
  /**
   * If the next token is a given keyword, advance the lexer.
   * Otherwise, do not change the parser state and throw an error.
   */
  expectKeyword(e) {
    const n = this._lexer.token;
    if (n.kind === l.NAME && n.value === e)
      this.advanceLexer();
    else
      throw W(
        this._lexer.source,
        n.start,
        `Expected "${e}", found ${Ke(n)}.`
      );
  }
  /**
   * If the next token is a given keyword, return "true" after advancing the lexer.
   * Otherwise, do not change the parser state and return "false".
   */
  expectOptionalKeyword(e) {
    const n = this._lexer.token;
    return n.kind === l.NAME && n.value === e ? (this.advanceLexer(), !0) : !1;
  }
  /**
   * Helper function for creating an error when an unexpected lexed token is encountered.
   */
  unexpected(e) {
    const n = e ?? this._lexer.token;
    return W(
      this._lexer.source,
      n.start,
      `Unexpected ${Ke(n)}.`
    );
  }
  /**
   * Returns a possibly empty list of parse nodes, determined by the parseFn.
   * This list begins with a lex token of openKind and ends with a lex token of closeKind.
   * Advances the parser to the next lex token after the closing token.
   */
  any(e, n, s) {
    this.expectToken(e);
    const r = [];
    for (; !this.expectOptionalToken(s); )
      r.push(n.call(this));
    return r;
  }
  /**
   * Returns a list of parse nodes, determined by the parseFn.
   * It can be empty only if open token is missing otherwise it will always return non-empty list
   * that begins with a lex token of openKind and ends with a lex token of closeKind.
   * Advances the parser to the next lex token after the closing token.
   */
  optionalMany(e, n, s) {
    if (this.expectOptionalToken(e)) {
      const r = [];
      do
        r.push(n.call(this));
      while (!this.expectOptionalToken(s));
      return r;
    }
    return [];
  }
  /**
   * Returns a non-empty list of parse nodes, determined by the parseFn.
   * This list begins with a lex token of openKind and ends with a lex token of closeKind.
   * Advances the parser to the next lex token after the closing token.
   */
  many(e, n, s) {
    this.expectToken(e);
    const r = [];
    do
      r.push(n.call(this));
    while (!this.expectOptionalToken(s));
    return r;
  }
  /**
   * Returns a non-empty list of parse nodes, determined by the parseFn.
   * This list may begin with a lex token of delimiterKind followed by items separated by lex tokens of tokenKind.
   * Advances the parser to the next lex token after last item in the list.
   */
  delimitedMany(e, n) {
    this.expectOptionalToken(e);
    const s = [];
    do
      s.push(n.call(this));
    while (this.expectOptionalToken(e));
    return s;
  }
  advanceLexer() {
    const { maxTokens: e } = this._options, n = this._lexer.advance();
    if (e !== void 0 && n.kind !== l.EOF && (++this._tokenCounter, this._tokenCounter > e))
      throw W(
        this._lexer.source,
        n.start,
        `Document contains more that ${e} tokens. Parsing aborted.`
      );
  }
}
function Ke(t) {
  const e = t.value;
  return er(t.kind) + (e != null ? ` "${e}"` : "");
}
function er(t) {
  return Ya(t) ? `"${t}"` : t;
}
var rt = /* @__PURE__ */ new Map(), zt = /* @__PURE__ */ new Map(), tr = !0, mt = !1;
function nr(t) {
  return t.replace(/[\s,]+/g, " ").trim();
}
function fo(t) {
  return nr(t.source.body.substring(t.start, t.end));
}
function mo(t) {
  var e = /* @__PURE__ */ new Set(), n = [];
  return t.definitions.forEach(function(s) {
    if (s.kind === "FragmentDefinition") {
      var r = s.name.value, i = fo(s.loc), a = zt.get(r);
      a && !a.has(i) ? tr && console.warn("Warning: fragment with name " + r + ` already exists.
graphql-tag enforces all fragment names across your application to be unique; read more about
this in the docs: http://dev.apollodata.com/core/fragments.html#unique-names`) : a || zt.set(r, a = /* @__PURE__ */ new Set()), a.add(i), e.has(i) || (e.add(i), n.push(s));
    } else
      n.push(s);
  }), ft(ft({}, t), { definitions: n });
}
function po(t) {
  var e = new Set(t.definitions);
  e.forEach(function(s) {
    s.loc && delete s.loc, Object.keys(s).forEach(function(r) {
      var i = s[r];
      i && typeof i == "object" && e.add(i);
    });
  });
  var n = t.loc;
  return n && (delete n.startToken, delete n.endToken), t;
}
function yo(t) {
  var e = nr(t);
  if (!rt.has(e)) {
    var n = lo(t, {
      experimentalFragmentVariables: mt,
      allowLegacyFragmentVariables: mt
    });
    if (!n || n.kind !== "Document")
      throw new Error("Not a valid GraphQL document.");
    rt.set(e, po(mo(n)));
  }
  return rt.get(e);
}
function Y(t) {
  for (var e = [], n = 1; n < arguments.length; n++)
    e[n - 1] = arguments[n];
  typeof t == "string" && (t = [t]);
  var s = t[0];
  return e.forEach(function(r, i) {
    r && r.kind === "Document" ? s += r.loc.source.body : s += r, s += t[i + 1];
  }), yo(s);
}
function Eo() {
  rt.clear(), zt.clear();
}
function go() {
  tr = !1;
}
function To() {
  mt = !0;
}
function wo() {
  mt = !1;
}
var _e = {
  gql: Y,
  resetCaches: Eo,
  disableFragmentWarnings: go,
  enableExperimentalFragmentVariables: To,
  disableExperimentalFragmentVariables: wo
};
(function(t) {
  t.gql = _e.gql, t.resetCaches = _e.resetCaches, t.disableFragmentWarnings = _e.disableFragmentWarnings, t.enableExperimentalFragmentVariables = _e.enableExperimentalFragmentVariables, t.disableExperimentalFragmentVariables = _e.disableExperimentalFragmentVariables;
})(Y || (Y = {}));
Y.default = Y;
var it = /* @__PURE__ */ ((t) => (t.Day = "Day", t.Week = "Week", t.Month = "Month", t.Quarter = "Quarter", t))(it || {});
Y`
    mutation createOrbit($variables: OrbitCreateParams!) {
  createOrbit(orbit: $variables) {
    id
    eH
    name
    parentHash
    sphereHash
    scale
    frequency
    metadata {
      description
      timeframe {
        startTime
        endTime
      }
    }
  }
}
    `;
Y`
    mutation deleteOrbit($id: ID!) {
  deleteOrbit(orbitHash: $id)
}
    `;
Y`
    mutation updateOrbit($orbitFields: OrbitUpdateParams!) {
  updateOrbit(orbit: $orbitFields) {
    actionHash
    entryHash
  }
}
    `;
Y`
    mutation createSphere($variables: SphereCreateParams!) {
  createSphere(sphere: $variables) {
    actionHash
    entryHash
  }
}
    `;
Y`
    mutation deleteSphere($id: ID!) {
  deleteSphere(sphereHash: $id)
}
    `;
Y`
    mutation updateSphere($sphere: SphereUpdateParams!) {
  updateSphere(sphere: $sphere) {
    actionHash
    entryHash
  }
}
    `;
Y`
    query getOrbit($id: ID!) {
  orbit(id: $id) {
    id
    eH
    name
    sphereHash
    frequency
    scale
    parentHash
    metadata {
      description
      timeframe {
        startTime
        endTime
      }
    }
  }
}
    `;
Y`
    query getOrbitHierarchy($params: OrbitHierarchyQueryParams!) {
  getOrbitHierarchy(params: $params)
}
    `;
Y`
    query getOrbits($sphereEntryHashB64: String) {
  orbits(sphereEntryHashB64: $sphereEntryHashB64) {
    edges {
      node {
        id
        eH
        name
        sphereHash
        parentHash
        frequency
        scale
        metadata {
          description
          timeframe {
            startTime
            endTime
          }
        }
      }
    }
  }
}
    `;
Y`
    query getLowestSphereHierarchyLevel($sphereEntryHashB64: String!) {
  getLowestSphereHierarchyLevel(sphereEntryHashB64: $sphereEntryHashB64)
}
    `;
Y`
    query getSphere($id: ID!) {
  sphere(id: $id) {
    id
    eH
    name
    metadata {
      description
      image
    }
  }
}
    `;
Y`
    query getSpheres {
  spheres {
    edges {
      node {
        id
        eH
        name
        metadata {
          description
          image
        }
      }
    }
  }
}
    `;
const Oo = (t) => {
  switch (t) {
    case it.Day:
      return Ne.DAILY_OR_MORE.DAILY;
    case it.Month:
      return Ne.LESS_THAN_DAILY.MONTHLY;
    case it.Quarter:
      return Ne.LESS_THAN_DAILY.QUARTERLY;
    default:
      return Ne.DAILY_OR_MORE.DAILY;
  }
}, _o = (t) => {
  const e = Oo(t.frequency);
  return {
    id: t.id,
    eH: t.eH,
    parentEh: t.parentHash || void 0,
    name: t.name,
    scale: t.scale,
    sphereHash: t.sphereHash,
    frequency: e,
    description: t.metadata?.description || "",
    startTime: t.metadata?.timeframe.startTime,
    endTime: t.metadata?.timeframe.endTime || void 0
  };
}, Fo = I(
  (t) => {
    const e = t(H), n = e.spheres.currentSphereHash, s = e.spheres.byHash[n];
    if (!s) return null;
    const r = {};
    return Object.entries(e.orbitNodes.byHash).forEach(([i, a]) => {
      a.sphereHash === s.details.entryHash && (r[i] = a);
    }), Object.keys(r).length > 0 ? r : null;
  }
), Lo = I((t) => {
  const e = t(H), n = e.orbitNodes.currentOrbitHash;
  return n && e.orbitNodes.byHash[n] || null;
}), Ro = I(
  (t) => {
    const e = t(H);
    return e.orbitNodes.currentOrbitHash ? { id: e.orbitNodes.currentOrbitHash } : null;
  },
  (t, e, n) => {
    e(H, (s) => ({
      ...s,
      orbitNodes: {
        ...s.orbitNodes,
        currentOrbitHash: n
      }
    }));
  }
), Vo = (t) => I((e) => e(H).orbitNodes.byHash[t] || null), Po = I(
  null,
  (t, e, {
    orbitEh: n,
    update: s
  }) => {
    e(H, (r) => {
      const i = Object.keys(r.orbitNodes.byHash).find(
        (a) => r.orbitNodes.byHash[a].eH === n
      );
      return i ? {
        ...r,
        orbitNodes: {
          ...r.orbitNodes,
          byHash: {
            ...r.orbitNodes.byHash,
            [i]: {
              ...r.orbitNodes.byHash[i],
              ...s
            }
          }
        }
      } : r;
    });
  }
), Uo = (t) => I((n) => n(H).orbitNodes.byHash[t]?.frequency || null), $o = (t) => I((n) => n(H).wins[t] || {}), Wo = I(
  null,
  (t, e, {
    orbitHash: n,
    date: s,
    winIndex: r,
    hasWin: i
  }) => {
    const a = t(H), o = a.orbitNodes.byHash[n];
    if (!o) {
      console.warn(`Attempted to set win for non-existent orbit: ${n}`);
      return;
    }
    const u = o.frequency, c = a.wins[n] || {};
    let h;
    if (u > 1) {
      const v = [...Array.isArray(c[s]) ? c[s] : new Array(Math.round(u)).fill(!1)];
      r !== void 0 && r < Math.round(u) && (v[r] = i), h = { ...c, [s]: v };
    } else
      h = { ...c, [s]: i };
    e(H, {
      ...a,
      wins: {
        ...a.wins,
        [n]: h
      }
    });
  }
), Ho = (t) => I((n) => {
  const s = n(H), r = s.orbitNodes.byHash[t];
  return s.wins[t], r ? 0 : null;
}), Bo = I(
  (t) => {
    const e = t(H), n = e.spheres.currentSphereHash, s = e.spheres.byHash[n];
    return s ? {
      entryHash: s.details.entryHash,
      actionHash: n
    } : {};
  },
  (t, e, n) => {
    e(H, (s) => {
      const r = n.actionHash || "";
      return console.log("newCurrentSphereHash :>> ", r), {
        ...s,
        spheres: {
          ...s.spheres,
          currentSphereHash: r
        }
      };
    });
  }
), Yo = I((t) => {
  const e = t(H), n = e.spheres.currentSphereHash;
  return e.spheres.byHash[n]?.details || null;
}), Zo = I((t) => {
  const e = t(H), n = e.spheres.currentSphereHash, s = e.spheres.byHash[n];
  return s ? s.hierarchyRootOrbitEntryHashes.some((i) => {
    const a = e.hierarchies.byRootOrbitEntryHash[i];
    return a && a.nodeHashes.length > 0;
  }) : !1;
});
export {
  vo as calculateCompletionStatusAtom,
  Ho as calculateStreakAtom,
  No as currentDayAtom,
  Lo as currentOrbitDetailsAtom,
  Ro as currentOrbitIdAtom,
  Yo as currentSphereAtom,
  Zo as currentSphereHasCachedNodesAtom,
  Bo as currentSphereHashesAtom,
  ht as currentSphereHierarchyBounds,
  dt as currentSphereHierarchyIndices,
  Fo as currentSphereOrbitNodesAtom,
  Oo as decodeFrequency,
  ko as getHierarchyAtom,
  Io as getHierarchyOrbitsAtom,
  Vo as getOrbitAtom,
  Uo as getOrbitFrequency,
  _o as mapToCacheObject,
  Ao as newTraversalLevelIndexId,
  Ca as nodeCache,
  Mo as nodeCacheItemsAtom,
  $o as orbitWinDataAtom,
  xo as setBreadths,
  So as setCurrentBreadth,
  bo as setCurrentDepth,
  Do as setDepths,
  Po as setOrbitWithEntryHashAtom,
  Wo as setWinForOrbit,
  Co as store
};
